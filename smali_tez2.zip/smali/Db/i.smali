.class public final synthetic LDb/i;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LDb/i;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LDb/i;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lorg/tezza/domain/flow/Flow;

    .line 7
    .line 8
    invoke-static {p1}, Lorg/tezza/data/flow/FlowRepositoryImpl;->F(Lorg/tezza/domain/flow/Flow;)Le9/j;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1

    .line 13
    :pswitch_0
    check-cast p1, Ljava/util/List;

    .line 14
    .line 15
    const-string v0, "list"

    .line 16
    .line 17
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    new-instance v0, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 23
    .line 24
    .line 25
    check-cast p1, Ljava/lang/Iterable;

    .line 26
    .line 27
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_0

    .line 36
    .line 37
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    check-cast v1, Lcc/b;

    .line 42
    .line 43
    const-string v2, "<this>"

    .line 44
    .line 45
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    new-instance v2, Luc/d;

    .line 49
    .line 50
    iget-object v3, v1, Lcc/b;->a:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v1, v1, Lcc/b;->b:Ljava/lang/String;

    .line 53
    .line 54
    invoke-direct {v2, v3, v1}, Luc/d;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    return-object v0

    .line 62
    :pswitch_1
    check-cast p1, LAb/a;

    .line 63
    .line 64
    const-string v0, "$this$buildSerialDescriptor"

    .line 65
    .line 66
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    new-instance v0, LDb/j;

    .line 70
    .line 71
    const/4 v1, 0x0

    .line 72
    invoke-direct {v0, v1}, LDb/j;-><init>(I)V

    .line 73
    .line 74
    .line 75
    new-instance v1, LDb/p;

    .line 76
    .line 77
    invoke-direct {v1, v0}, LDb/p;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 78
    .line 79
    .line 80
    const-string v0, "JsonPrimitive"

    .line 81
    .line 82
    invoke-static {p1, v0, v1}, LAb/a;->a(LAb/a;Ljava/lang/String;LAb/f;)V

    .line 83
    .line 84
    .line 85
    new-instance v0, LDb/k;

    .line 86
    .line 87
    const/4 v1, 0x0

    .line 88
    invoke-direct {v0, v1}, LDb/k;-><init>(I)V

    .line 89
    .line 90
    .line 91
    new-instance v1, LDb/p;

    .line 92
    .line 93
    invoke-direct {v1, v0}, LDb/p;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 94
    .line 95
    .line 96
    const-string v0, "JsonNull"

    .line 97
    .line 98
    invoke-static {p1, v0, v1}, LAb/a;->a(LAb/a;Ljava/lang/String;LAb/f;)V

    .line 99
    .line 100
    .line 101
    new-instance v0, LDb/l;

    .line 102
    .line 103
    const/4 v1, 0x0

    .line 104
    invoke-direct {v0, v1}, LDb/l;-><init>(I)V

    .line 105
    .line 106
    .line 107
    new-instance v1, LDb/p;

    .line 108
    .line 109
    invoke-direct {v1, v0}, LDb/p;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 110
    .line 111
    .line 112
    const-string v0, "JsonLiteral"

    .line 113
    .line 114
    invoke-static {p1, v0, v1}, LAb/a;->a(LAb/a;Ljava/lang/String;LAb/f;)V

    .line 115
    .line 116
    .line 117
    new-instance v0, LDb/m;

    .line 118
    .line 119
    const/4 v1, 0x0

    .line 120
    invoke-direct {v0, v1}, LDb/m;-><init>(I)V

    .line 121
    .line 122
    .line 123
    new-instance v1, LDb/p;

    .line 124
    .line 125
    invoke-direct {v1, v0}, LDb/p;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 126
    .line 127
    .line 128
    const-string v0, "JsonObject"

    .line 129
    .line 130
    invoke-static {p1, v0, v1}, LAb/a;->a(LAb/a;Ljava/lang/String;LAb/f;)V

    .line 131
    .line 132
    .line 133
    new-instance v0, LDb/n;

    .line 134
    .line 135
    const/4 v1, 0x0

    .line 136
    invoke-direct {v0, v1}, LDb/n;-><init>(I)V

    .line 137
    .line 138
    .line 139
    new-instance v1, LDb/p;

    .line 140
    .line 141
    invoke-direct {v1, v0}, LDb/p;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 142
    .line 143
    .line 144
    const-string v0, "JsonArray"

    .line 145
    .line 146
    invoke-static {p1, v0, v1}, LAb/a;->a(LAb/a;Ljava/lang/String;LAb/f;)V

    .line 147
    .line 148
    .line 149
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 150
    .line 151
    return-object p1

    .line 152
    nop

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
