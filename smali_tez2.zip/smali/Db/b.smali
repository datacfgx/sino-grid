.class public abstract LDb/b;
.super Ljava/lang/Object;
.source "Json.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDb/b$a;
    }
.end annotation


# static fields
.field public static final d:LDb/b$a;


# instance fields
.field public final a:LDb/f;

.field public final b:LFb/c;

.field public final c:LEb/j;


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 1
    new-instance v0, LDb/b$a;

    .line 2
    .line 3
    new-instance v1, LDb/f;

    .line 4
    .line 5
    sget-object v7, LDb/a;->POLYMORPHIC:LDb/a;

    .line 6
    .line 7
    const-string v5, "type"

    .line 8
    .line 9
    const/4 v6, 0x1

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x1

    .line 12
    const-string v4, "    "

    .line 13
    .line 14
    invoke-direct/range {v1 .. v7}, LDb/f;-><init>(ZZLjava/lang/String;Ljava/lang/String;ZLDb/a;)V

    .line 15
    .line 16
    .line 17
    sget-object v2, LFb/e;->a:LFb/b;

    .line 18
    .line 19
    invoke-direct {v0, v1, v2}, LDb/b;-><init>(LDb/f;LFb/c;)V

    .line 20
    .line 21
    .line 22
    sput-object v0, LDb/b;->d:LDb/b$a;

    .line 23
    .line 24
    return-void
.end method

.method public constructor <init>(LDb/f;LFb/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LDb/b;->a:LDb/f;

    .line 5
    .line 6
    iput-object p2, p0, LDb/b;->b:LFb/c;

    .line 7
    .line 8
    new-instance p1, LEb/j;

    .line 9
    .line 10
    invoke-direct {p1}, LEb/j;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, LDb/b;->c:LEb/j;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final a(Lyb/a;Ljava/lang/String;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/a<",
            "+TT;>;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    .line 1
    const-string v0, "deserializer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "string"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, p2}, LEb/F;->a(LDb/b;Ljava/lang/String;)LEb/E;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    new-instance v1, LEb/B;

    .line 16
    .line 17
    sget-object v3, LEb/I;->OBJ:LEb/I;

    .line 18
    .line 19
    invoke-interface {p1}, Lyb/a;->b()LAb/f;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    const/4 v6, 0x0

    .line 24
    move-object v2, p0

    .line 25
    invoke-direct/range {v1 .. v6}, LEb/B;-><init>(LDb/b;LEb/I;LEb/E;LAb/f;LEb/B$a;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, p1}, LEb/B;->z(Lyb/a;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {v4}, LEb/E;->e()B

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    const/16 v0, 0xa

    .line 37
    .line 38
    if-ne p2, v0, :cond_0

    .line 39
    .line 40
    return-object p1

    .line 41
    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    const-string p2, "Expected EOF after parsing, but had "

    .line 44
    .line 45
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget p2, v4, LEb/E;->a:I

    .line 49
    .line 50
    add-int/lit8 p2, p2, -0x1

    .line 51
    .line 52
    iget-object v0, v4, LEb/E;->e:Ljava/lang/String;

    .line 53
    .line 54
    invoke-virtual {v0, p2}, Ljava/lang/String;->charAt(I)C

    .line 55
    .line 56
    .line 57
    move-result p2

    .line 58
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string p2, " instead"

    .line 62
    .line 63
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    const/4 p2, 0x0

    .line 71
    const/4 v0, 0x6

    .line 72
    const/4 v1, 0x0

    .line 73
    invoke-static {v4, p1, p2, v1, v0}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 74
    .line 75
    .line 76
    throw v1
.end method

.method public final b(Lyb/g;Ljava/lang/Object;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/g<",
            "-TT;>;TT;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    const-string v0, "serializer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, LEb/s;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    sget-object v1, LEb/d;->c:LEb/d;

    .line 12
    .line 13
    monitor-enter v1

    .line 14
    :try_start_0
    iget-object v2, v1, LEb/e;->a:Lkotlin/collections/ArrayDeque;

    .line 15
    .line 16
    invoke-virtual {v2}, Lkotlin/collections/ArrayDeque;->removeLastOrNull()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    check-cast v2, [C

    .line 21
    .line 22
    if-eqz v2, :cond_0

    .line 23
    .line 24
    iget v3, v1, LEb/e;->b:I

    .line 25
    .line 26
    array-length v4, v2

    .line 27
    sub-int/2addr v3, v4

    .line 28
    iput v3, v1, LEb/e;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :catchall_0
    move-exception p1

    .line 32
    goto :goto_1

    .line 33
    :cond_0
    const/4 v2, 0x0

    .line 34
    :goto_0
    monitor-exit v1

    .line 35
    if-nez v2, :cond_1

    .line 36
    .line 37
    const/16 v1, 0x80

    .line 38
    .line 39
    new-array v2, v1, [C

    .line 40
    .line 41
    :cond_1
    iput-object v2, v0, LEb/s;->a:[C

    .line 42
    .line 43
    :try_start_1
    invoke-static {p0, v0, p1, p2}, LEb/r;->a(LDb/b;LEb/s;Lyb/g;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, LEb/s;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 50
    invoke-virtual {v0}, LEb/s;->b()V

    .line 51
    .line 52
    .line 53
    return-object p1

    .line 54
    :catchall_1
    move-exception p1

    .line 55
    invoke-virtual {v0}, LEb/s;->b()V

    .line 56
    .line 57
    .line 58
    throw p1

    .line 59
    :goto_1
    monitor-exit v1

    .line 60
    throw p1
.end method
