.class public final LDb/y;
.super Ljava/lang/Object;
.source "JsonElementSerializers.kt"

# interfaces
.implements Lyb/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LDb/y$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lyb/b<",
        "Lkotlinx/serialization/json/JsonObject;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LDb/y;

.field public static final b:LDb/y$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LDb/y;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LDb/y;->a:LDb/y;

    .line 7
    .line 8
    sget-object v0, LDb/y$a;->b:LDb/y$a;

    .line 9
    .line 10
    sput-object v0, LDb/y;->b:LDb/y$a;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final b()LAb/f;
    .locals 1

    .line 1
    sget-object v0, LDb/y;->b:LDb/y$a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c(LBb/e;)Ljava/lang/Object;
    .locals 4

    .line 1
    const-string v0, "decoder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LDb/q;->b(LBb/e;)LDb/g;

    .line 7
    .line 8
    .line 9
    new-instance v0, Lkotlinx/serialization/json/JsonObject;

    .line 10
    .line 11
    sget-object v1, Lkotlin/jvm/internal/Z;->a:Lkotlin/jvm/internal/Z;

    .line 12
    .line 13
    invoke-static {v1}, Lzb/a;->b(Lkotlin/jvm/internal/Z;)V

    .line 14
    .line 15
    .line 16
    sget-object v1, LCb/s0;->a:LCb/s0;

    .line 17
    .line 18
    sget-object v1, LDb/o;->a:LDb/o;

    .line 19
    .line 20
    sget-object v1, LCb/s0;->a:LCb/s0;

    .line 21
    .line 22
    sget-object v2, LDb/o;->a:LDb/o;

    .line 23
    .line 24
    const-string v3, "keySerializer"

    .line 25
    .line 26
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    const-string v1, "valueSerializer"

    .line 30
    .line 31
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    new-instance v1, LCb/L;

    .line 35
    .line 36
    invoke-direct {v1, v2}, LCb/L;-><init>(Lyb/b;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1, p1}, LCb/a;->c(LBb/e;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, Ljava/util/Map;

    .line 44
    .line 45
    invoke-direct {v0, p1}, Lkotlinx/serialization/json/JsonObject;-><init>(Ljava/util/Map;)V

    .line 46
    .line 47
    .line 48
    return-object v0
.end method

.method public final e(LBb/b;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p2, Lkotlinx/serialization/json/JsonObject;

    .line 2
    .line 3
    const-string v0, "encoder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "value"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-static {p1}, LDb/q;->a(LBb/f;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, Lkotlin/jvm/internal/Z;->a:Lkotlin/jvm/internal/Z;

    .line 17
    .line 18
    invoke-static {v0}, Lzb/a;->b(Lkotlin/jvm/internal/Z;)V

    .line 19
    .line 20
    .line 21
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 22
    .line 23
    sget-object v0, LDb/o;->a:LDb/o;

    .line 24
    .line 25
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 26
    .line 27
    sget-object v1, LDb/o;->a:LDb/o;

    .line 28
    .line 29
    const-string v2, "keySerializer"

    .line 30
    .line 31
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const-string v0, "valueSerializer"

    .line 35
    .line 36
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    new-instance v0, LCb/L;

    .line 40
    .line 41
    invoke-direct {v0, v1}, LCb/L;-><init>(Lyb/b;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0, p1, p2}, LCb/S;->e(LBb/b;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method
