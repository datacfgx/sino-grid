.class public interface abstract LDb/r;
.super Ljava/lang/Object;
.source "JsonEncoder.kt"

# interfaces
.implements LBb/f;
.implements LBb/d;
