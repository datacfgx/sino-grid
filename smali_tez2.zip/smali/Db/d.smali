.class public final LDb/d;
.super Ljava/lang/Object;
.source "Json.kt"


# instance fields
.field public a:Z

.field public b:Z

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:LDb/a;

.field public f:Z

.field public g:LFb/c;
