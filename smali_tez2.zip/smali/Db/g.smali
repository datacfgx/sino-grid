.class public interface abstract LDb/g;
.super Ljava/lang/Object;
.source "JsonDecoder.kt"

# interfaces
.implements LBb/e;
.implements LBb/c;


# virtual methods
.method public abstract j()Lkotlinx/serialization/json/JsonElement;
.end method
