.class public final LDb/y$a;
.super Ljava/lang/Object;
.source "JsonElementSerializers.kt"

# interfaces
.implements LAb/f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LDb/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:LDb/y$a;

.field public static final c:Ljava/lang/String;


# instance fields
.field public final synthetic a:LCb/K;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LDb/y$a;

    .line 2
    .line 3
    invoke-direct {v0}, LDb/y$a;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LDb/y$a;->b:LDb/y$a;

    .line 7
    .line 8
    const-string v0, "kotlinx.serialization.json.JsonObject"

    .line 9
    .line 10
    sput-object v0, LDb/y$a;->c:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lkotlin/jvm/internal/Z;->a:Lkotlin/jvm/internal/Z;

    .line 5
    .line 6
    invoke-static {v0}, Lzb/a;->b(Lkotlin/jvm/internal/Z;)V

    .line 7
    .line 8
    .line 9
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 10
    .line 11
    sget-object v0, LDb/o;->a:LDb/o;

    .line 12
    .line 13
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 14
    .line 15
    sget-object v1, LDb/o;->a:LDb/o;

    .line 16
    .line 17
    const-string v2, "keySerializer"

    .line 18
    .line 19
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string v0, "valueSerializer"

    .line 23
    .line 24
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 28
    .line 29
    const-string v2, "kSerializer"

    .line 30
    .line 31
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const-string v0, "vSerializer"

    .line 35
    .line 36
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 40
    .line 41
    new-instance v0, LCb/K;

    .line 42
    .line 43
    sget-object v2, LCb/s0;->b:LCb/m0;

    .line 44
    .line 45
    invoke-interface {v1}, Lyb/g;->b()LAb/f;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    const-string v3, "keyDesc"

    .line 50
    .line 51
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string v3, "valueDesc"

    .line 55
    .line 56
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-direct {v0, v2, v1}, LCb/Q;-><init>(LAb/f;LAb/f;)V

    .line 60
    .line 61
    .line 62
    iput-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 63
    .line 64
    return-void
.end method


# virtual methods
.method public final f()LAb/n;
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v0, LAb/o$c;->a:LAb/o$c;

    .line 7
    .line 8
    return-object v0
.end method

.method public final getAnnotations()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/annotation/Annotation;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final i()Z
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    return v0
.end method

.method public final j()Ljava/lang/String;
    .locals 1

    .line 1
    sget-object v0, LDb/y$a;->c:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final k()Z
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    return v0
.end method

.method public final l(Ljava/lang/String;)I
    .locals 1

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, LCb/Q;->l(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method public final m()I
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    return v0
.end method

.method public final n(I)Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    return-object p1
.end method

.method public final o(I)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/annotation/Annotation;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LCb/Q;->o(I)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final p(I)LAb/f;
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LCb/Q;->p(I)LAb/f;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final q(I)Z
    .locals 1

    .line 1
    iget-object v0, p0, LDb/y$a;->a:LCb/K;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LCb/Q;->q(I)Z

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return p1
.end method
