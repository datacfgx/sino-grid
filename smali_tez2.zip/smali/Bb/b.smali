.class public abstract LBb/b;
.super Ljava/lang/Object;
.source "AbstractEncoder.kt"

# interfaces
.implements LBb/f;
.implements LBb/d;


# virtual methods
.method public final A(LAb/f;ILjava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "value"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, p3}, LBb/b;->C(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public abstract B(J)V
.end method

.method public abstract C(Ljava/lang/String;)V
.end method

.method public final D(LAb/f;)LBb/d;
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0, p1}, LBb/f;->a(LAb/f;)LBb/d;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    return-object p1
.end method

.method public abstract E(LAb/f;I)V
.end method

.method public final d(LCb/k0;IC)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3}, LBb/b;->t(C)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final e(LCb/k0;IB)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3}, LBb/b;->l(B)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final h(LAb/f;IZ)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3}, LBb/b;->m(Z)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final i(IILAb/f;)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p3, p1}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p2}, LBb/b;->x(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public abstract j(D)V
.end method

.method public abstract k(S)V
.end method

.method public abstract l(B)V
.end method

.method public abstract m(Z)V
.end method

.method public final n(LCb/k0;I)LBb/f;
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1, p2}, LCb/M;->p(I)LAb/f;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p0, p1}, LBb/b;->w(LAb/f;)LBb/f;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final o(LAb/f;ILyb/g;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "serializer"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, p3, p4}, LBb/b;->s(Lyb/g;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final p(LAb/f;IJ)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3, p4}, LBb/b;->B(J)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final q(LAb/f;IF)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3}, LBb/b;->r(F)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public abstract r(F)V
.end method

.method public abstract s(Lyb/g;Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation
.end method

.method public abstract t(C)V
.end method

.method public u(LAb/f;ILyb/g;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "serializer"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 12
    .line 13
    .line 14
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-interface {p3}, Lyb/g;->b()LAb/f;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-interface {p1}, LAb/f;->k()Z

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    invoke-interface {p0, p3, p4}, LBb/f;->s(Lyb/g;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_0
    if-nez p4, :cond_1

    .line 32
    .line 33
    invoke-interface {p0}, LBb/f;->f()V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-interface {p0, p3, p4}, LBb/f;->s(Lyb/g;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public abstract w(LAb/f;)LBb/f;
.end method

.method public abstract x(I)V
.end method

.method public final y(LCb/k0;ID)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3, p4}, LBb/b;->j(D)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final z(LCb/k0;IS)V
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, LBb/b;->E(LAb/f;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p3}, LBb/b;->k(S)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
