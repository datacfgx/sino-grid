.class public interface abstract LBb/d;
.super Ljava/lang/Object;
.source "Encoding.kt"


# virtual methods
.method public abstract A(LAb/f;ILjava/lang/String;)V
.end method

.method public abstract c(LAb/f;)V
.end method

.method public abstract d(LCb/k0;IC)V
.end method

.method public abstract e(LCb/k0;IB)V
.end method

.method public abstract h(LAb/f;IZ)V
.end method

.method public abstract i(IILAb/f;)V
.end method

.method public abstract n(LCb/k0;I)LBb/f;
.end method

.method public abstract o(LAb/f;ILyb/g;Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation
.end method

.method public abstract p(LAb/f;IJ)V
.end method

.method public abstract q(LAb/f;IF)V
.end method

.method public abstract u(LAb/f;ILyb/g;Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation
.end method

.method public abstract v(LAb/f;)Z
.end method

.method public abstract y(LCb/k0;ID)V
.end method

.method public abstract z(LCb/k0;IS)V
.end method
