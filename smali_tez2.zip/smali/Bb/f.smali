.class public interface abstract LBb/f;
.super Ljava/lang/Object;
.source "Encoding.kt"


# virtual methods
.method public abstract B(J)V
.end method

.method public abstract C(Ljava/lang/String;)V
.end method

.method public abstract a(LAb/f;)LBb/d;
.end method

.method public abstract b()LFb/c;
.end method

.method public abstract f()V
.end method

.method public abstract g(LAb/f;I)V
.end method

.method public abstract j(D)V
.end method

.method public abstract k(S)V
.end method

.method public abstract l(B)V
.end method

.method public abstract m(Z)V
.end method

.method public abstract r(F)V
.end method

.method public abstract s(Lyb/g;Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation
.end method

.method public abstract t(C)V
.end method

.method public abstract w(LAb/f;)LBb/f;
.end method

.method public abstract x(I)V
.end method
