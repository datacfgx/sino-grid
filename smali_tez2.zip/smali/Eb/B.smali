.class public final LEb/B;
.super LBb/a;
.source "StreamingJsonDecoder.kt"

# interfaces
.implements LDb/g;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LEb/B$a;,
        LEb/B$b;
    }
.end annotation


# instance fields
.field public final a:LDb/b;

.field public final b:LEb/I;

.field public final c:LEb/E;

.field public final d:LFb/c;

.field public e:I

.field public f:LEb/B$a;

.field public final g:LDb/f;

.field public final h:LEb/l;


# direct methods
.method public constructor <init>(LDb/b;LEb/I;LEb/E;LAb/f;LEb/B$a;)V
    .locals 1

    .line 1
    const-string v0, "json"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "mode"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "lexer"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "descriptor"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, LEb/B;->a:LDb/b;

    .line 25
    .line 26
    iput-object p2, p0, LEb/B;->b:LEb/I;

    .line 27
    .line 28
    iput-object p3, p0, LEb/B;->c:LEb/E;

    .line 29
    .line 30
    iget-object p2, p1, LDb/b;->b:LFb/c;

    .line 31
    .line 32
    iput-object p2, p0, LEb/B;->d:LFb/c;

    .line 33
    .line 34
    const/4 p2, -0x1

    .line 35
    iput p2, p0, LEb/B;->e:I

    .line 36
    .line 37
    iput-object p5, p0, LEb/B;->f:LEb/B$a;

    .line 38
    .line 39
    iget-object p1, p1, LDb/b;->a:LDb/f;

    .line 40
    .line 41
    iput-object p1, p0, LEb/B;->g:LDb/f;

    .line 42
    .line 43
    iget-boolean p1, p1, LDb/f;->b:Z

    .line 44
    .line 45
    if-eqz p1, :cond_0

    .line 46
    .line 47
    const/4 p1, 0x0

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    new-instance p1, LEb/l;

    .line 50
    .line 51
    invoke-direct {p1, p4}, LEb/l;-><init>(LAb/f;)V

    .line 52
    .line 53
    .line 54
    :goto_0
    iput-object p1, p0, LEb/B;->h:LEb/l;

    .line 55
    .line 56
    return-void
.end method


# virtual methods
.method public final A()S
    .locals 6

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->h()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    long-to-int v3, v1

    .line 8
    int-to-short v3, v3

    .line 9
    int-to-long v4, v3

    .line 10
    cmp-long v4, v1, v4

    .line 11
    .line 12
    if-nez v4, :cond_0

    .line 13
    .line 14
    return v3

    .line 15
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v4, "Failed to parse short for input \'"

    .line 18
    .line 19
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const/16 v1, 0x27

    .line 26
    .line 27
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const/4 v2, 0x0

    .line 35
    const/4 v3, 0x0

    .line 36
    const/4 v4, 0x6

    .line 37
    invoke-static {v0, v1, v2, v3, v4}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 38
    .line 39
    .line 40
    throw v3
.end method

.method public final B()F
    .locals 5

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->j()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const/4 v2, 0x0

    .line 8
    :try_start_0
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 9
    .line 10
    .line 11
    move-result v1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    iget-object v3, p0, LEb/B;->a:LDb/b;

    .line 13
    .line 14
    iget-object v3, v3, LDb/b;->a:LDb/f;

    .line 15
    .line 16
    invoke-static {v1}, Ljava/lang/Float;->isInfinite(F)Z

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-nez v3, :cond_0

    .line 21
    .line 22
    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_0

    .line 27
    .line 28
    return v1

    .line 29
    :cond_0
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-static {v0, v1}, LEb/m;->i(LEb/E;Ljava/lang/Number;)V

    .line 34
    .line 35
    .line 36
    throw v2

    .line 37
    :catch_0
    const-string v3, "Failed to parse type \'float\' for input \'"

    .line 38
    .line 39
    const/16 v4, 0x27

    .line 40
    .line 41
    invoke-static {v4, v3, v1}, LT4/Q;->b(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const/4 v3, 0x6

    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-static {v0, v1, v4, v2, v3}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 48
    .line 49
    .line 50
    throw v2
.end method

.method public final D()D
    .locals 5

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->j()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const/4 v2, 0x0

    .line 8
    :try_start_0
    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 9
    .line 10
    .line 11
    move-result-wide v3
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    iget-object v1, p0, LEb/B;->a:LDb/b;

    .line 13
    .line 14
    iget-object v1, v1, LDb/b;->a:LDb/f;

    .line 15
    .line 16
    invoke-static {v3, v4}, Ljava/lang/Double;->isInfinite(D)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-nez v1, :cond_0

    .line 21
    .line 22
    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-nez v1, :cond_0

    .line 27
    .line 28
    return-wide v3

    .line 29
    :cond_0
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-static {v0, v1}, LEb/m;->i(LEb/E;Ljava/lang/Number;)V

    .line 34
    .line 35
    .line 36
    throw v2

    .line 37
    :catch_0
    const-string v3, "Failed to parse type \'double\' for input \'"

    .line 38
    .line 39
    const/16 v4, 0x27

    .line 40
    .line 41
    invoke-static {v4, v3, v1}, LT4/Q;->b(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const/4 v3, 0x6

    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-static {v0, v1, v4, v2, v3}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 48
    .line 49
    .line 50
    throw v2
.end method

.method public final a(LAb/f;)LBb/c;
    .locals 9

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/B;->a:LDb/b;

    .line 7
    .line 8
    invoke-static {p1, v0}, LEb/J;->b(LAb/f;LDb/b;)LEb/I;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    iget-object v4, p0, LEb/B;->c:LEb/E;

    .line 13
    .line 14
    iget-object v1, v4, LEb/E;->b:LEb/p;

    .line 15
    .line 16
    const-string v2, "sd"

    .line 17
    .line 18
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget v2, v1, LEb/p;->c:I

    .line 22
    .line 23
    const/4 v5, 0x1

    .line 24
    add-int/2addr v2, v5

    .line 25
    iput v2, v1, LEb/p;->c:I

    .line 26
    .line 27
    iget-object v6, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 28
    .line 29
    array-length v7, v6

    .line 30
    if-ne v2, v7, :cond_0

    .line 31
    .line 32
    mul-int/lit8 v7, v2, 0x2

    .line 33
    .line 34
    invoke-static {v6, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    const-string v8, "copyOf(...)"

    .line 39
    .line 40
    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    iput-object v6, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 44
    .line 45
    iget-object v6, v1, LEb/p;->b:[I

    .line 46
    .line 47
    invoke-static {v6, v7}, Ljava/util/Arrays;->copyOf([II)[I

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    iput-object v6, v1, LEb/p;->b:[I

    .line 55
    .line 56
    :cond_0
    iget-object v1, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 57
    .line 58
    aput-object p1, v1, v2

    .line 59
    .line 60
    iget-char v1, v3, LEb/I;->begin:C

    .line 61
    .line 62
    invoke-virtual {v4, v1}, LEb/E;->g(C)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v4}, LEb/E;->r()B

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    const/4 v2, 0x4

    .line 70
    if-eq v1, v2, :cond_3

    .line 71
    .line 72
    sget-object v1, LEb/B$b;->a:[I

    .line 73
    .line 74
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    aget v1, v1, v2

    .line 79
    .line 80
    if-eq v1, v5, :cond_2

    .line 81
    .line 82
    const/4 v2, 0x2

    .line 83
    if-eq v1, v2, :cond_2

    .line 84
    .line 85
    const/4 v2, 0x3

    .line 86
    if-eq v1, v2, :cond_2

    .line 87
    .line 88
    iget-object v1, p0, LEb/B;->b:LEb/I;

    .line 89
    .line 90
    if-ne v1, v3, :cond_1

    .line 91
    .line 92
    iget-object v0, v0, LDb/b;->a:LDb/f;

    .line 93
    .line 94
    iget-boolean v0, v0, LDb/f;->b:Z

    .line 95
    .line 96
    if-eqz v0, :cond_1

    .line 97
    .line 98
    return-object p0

    .line 99
    :cond_1
    new-instance v1, LEb/B;

    .line 100
    .line 101
    iget-object v6, p0, LEb/B;->f:LEb/B$a;

    .line 102
    .line 103
    iget-object v2, p0, LEb/B;->a:LDb/b;

    .line 104
    .line 105
    move-object v5, p1

    .line 106
    invoke-direct/range {v1 .. v6}, LEb/B;-><init>(LDb/b;LEb/I;LEb/E;LAb/f;LEb/B$a;)V

    .line 107
    .line 108
    .line 109
    return-object v1

    .line 110
    :cond_2
    move-object v5, p1

    .line 111
    new-instance v1, LEb/B;

    .line 112
    .line 113
    iget-object v6, p0, LEb/B;->f:LEb/B$a;

    .line 114
    .line 115
    iget-object v2, p0, LEb/B;->a:LDb/b;

    .line 116
    .line 117
    invoke-direct/range {v1 .. v6}, LEb/B;-><init>(LDb/b;LEb/I;LEb/E;LAb/f;LEb/B$a;)V

    .line 118
    .line 119
    .line 120
    return-object v1

    .line 121
    :cond_3
    const-string p1, "Unexpected leading comma"

    .line 122
    .line 123
    const/4 v0, 0x6

    .line 124
    const/4 v1, 0x0

    .line 125
    const/4 v2, 0x0

    .line 126
    invoke-static {v4, p1, v1, v2, v0}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 127
    .line 128
    .line 129
    throw v2
.end method

.method public final b()LFb/c;
    .locals 1

    .line 1
    iget-object v0, p0, LEb/B;->d:LFb/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c(LAb/f;)V
    .locals 5

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/B;->a:LDb/b;

    .line 7
    .line 8
    iget-object v0, v0, LDb/b;->a:LDb/f;

    .line 9
    .line 10
    iget-boolean v0, v0, LDb/f;->a:Z

    .line 11
    .line 12
    const/4 v1, -0x1

    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    invoke-interface {p1}, LAb/f;->m()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    :cond_0
    invoke-virtual {p0, p1}, LEb/B;->l(LAb/f;)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-ne v0, v1, :cond_0

    .line 26
    .line 27
    :cond_1
    iget-object p1, p0, LEb/B;->c:LEb/E;

    .line 28
    .line 29
    invoke-virtual {p1}, LEb/E;->v()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_4

    .line 34
    .line 35
    iget-object v0, p0, LEb/B;->b:LEb/I;

    .line 36
    .line 37
    iget-char v0, v0, LEb/I;->end:C

    .line 38
    .line 39
    invoke-virtual {p1, v0}, LEb/E;->g(C)V

    .line 40
    .line 41
    .line 42
    iget-object p1, p1, LEb/E;->b:LEb/p;

    .line 43
    .line 44
    iget v0, p1, LEb/p;->c:I

    .line 45
    .line 46
    iget-object v2, p1, LEb/p;->b:[I

    .line 47
    .line 48
    aget v3, v2, v0

    .line 49
    .line 50
    const/4 v4, -0x2

    .line 51
    if-ne v3, v4, :cond_2

    .line 52
    .line 53
    aput v1, v2, v0

    .line 54
    .line 55
    add-int/2addr v0, v1

    .line 56
    iput v0, p1, LEb/p;->c:I

    .line 57
    .line 58
    :cond_2
    iget v0, p1, LEb/p;->c:I

    .line 59
    .line 60
    if-eq v0, v1, :cond_3

    .line 61
    .line 62
    add-int/2addr v0, v1

    .line 63
    iput v0, p1, LEb/p;->c:I

    .line 64
    .line 65
    :cond_3
    return-void

    .line 66
    :cond_4
    const-string v0, ""

    .line 67
    .line 68
    invoke-static {p1, v0}, LEb/m;->f(LEb/E;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    const/4 p1, 0x0

    .line 72
    throw p1
.end method

.method public final e()Z
    .locals 12

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->u()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    iget-object v2, v0, LEb/E;->e:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    const-string v4, "EOF"

    .line 14
    .line 15
    const/4 v5, 0x6

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eq v1, v3, :cond_7

    .line 19
    .line 20
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    const/4 v8, 0x1

    .line 25
    const/16 v9, 0x22

    .line 26
    .line 27
    if-ne v3, v9, :cond_0

    .line 28
    .line 29
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    move v3, v8

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    move v3, v6

    .line 34
    :goto_0
    invoke-virtual {v0, v1}, LEb/E;->t(I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 39
    .line 40
    .line 41
    move-result v10

    .line 42
    if-ge v1, v10, :cond_6

    .line 43
    .line 44
    const/4 v10, -0x1

    .line 45
    if-eq v1, v10, :cond_6

    .line 46
    .line 47
    add-int/lit8 v10, v1, 0x1

    .line 48
    .line 49
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    or-int/lit8 v1, v1, 0x20

    .line 54
    .line 55
    const/16 v11, 0x66

    .line 56
    .line 57
    if-eq v1, v11, :cond_2

    .line 58
    .line 59
    const/16 v11, 0x74

    .line 60
    .line 61
    if-ne v1, v11, :cond_1

    .line 62
    .line 63
    const-string v1, "rue"

    .line 64
    .line 65
    invoke-virtual {v0, v10, v1}, LEb/E;->c(ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    move v1, v8

    .line 69
    goto :goto_1

    .line 70
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    .line 71
    .line 72
    const-string v2, "Expected valid boolean literal prefix, but had \'"

    .line 73
    .line 74
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0}, LEb/E;->j()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    const/16 v2, 0x27

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-static {v0, v1, v6, v7, v5}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 94
    .line 95
    .line 96
    throw v7

    .line 97
    :cond_2
    const-string v1, "alse"

    .line 98
    .line 99
    invoke-virtual {v0, v10, v1}, LEb/E;->c(ILjava/lang/String;)V

    .line 100
    .line 101
    .line 102
    move v1, v6

    .line 103
    :goto_1
    if-eqz v3, :cond_5

    .line 104
    .line 105
    iget v3, v0, LEb/E;->a:I

    .line 106
    .line 107
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 108
    .line 109
    .line 110
    move-result v10

    .line 111
    if-eq v3, v10, :cond_4

    .line 112
    .line 113
    iget v3, v0, LEb/E;->a:I

    .line 114
    .line 115
    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    if-ne v2, v9, :cond_3

    .line 120
    .line 121
    iget v2, v0, LEb/E;->a:I

    .line 122
    .line 123
    add-int/2addr v2, v8

    .line 124
    iput v2, v0, LEb/E;->a:I

    .line 125
    .line 126
    return v1

    .line 127
    :cond_3
    const-string v1, "Expected closing quotation mark"

    .line 128
    .line 129
    invoke-static {v0, v1, v6, v7, v5}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 130
    .line 131
    .line 132
    throw v7

    .line 133
    :cond_4
    invoke-static {v0, v4, v6, v7, v5}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 134
    .line 135
    .line 136
    throw v7

    .line 137
    :cond_5
    return v1

    .line 138
    :cond_6
    invoke-static {v0, v4, v6, v7, v5}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 139
    .line 140
    .line 141
    throw v7

    .line 142
    :cond_7
    invoke-static {v0, v4, v6, v7, v5}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 143
    .line 144
    .line 145
    throw v7
.end method

.method public final f(LAb/f;ILyb/a;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/a<",
            "+TT;>;TT;)TT;"
        }
    .end annotation

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "deserializer"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, LEb/I;->MAP:LEb/I;

    .line 12
    .line 13
    iget-object v1, p0, LEb/B;->b:LEb/I;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    if-ne v1, v0, :cond_0

    .line 17
    .line 18
    and-int/lit8 v0, p2, 0x1

    .line 19
    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    move v0, v2

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v0, 0x0

    .line 25
    :goto_0
    iget-object v1, p0, LEb/B;->c:LEb/E;

    .line 26
    .line 27
    const/4 v3, -0x2

    .line 28
    iget-object v1, v1, LEb/E;->b:LEb/p;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    iget-object v4, v1, LEb/p;->b:[I

    .line 33
    .line 34
    iget v5, v1, LEb/p;->c:I

    .line 35
    .line 36
    aget v4, v4, v5

    .line 37
    .line 38
    if-ne v4, v3, :cond_1

    .line 39
    .line 40
    iget-object v4, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 41
    .line 42
    sget-object v6, LEb/p$a;->a:LEb/p$a;

    .line 43
    .line 44
    aput-object v6, v4, v5

    .line 45
    .line 46
    :cond_1
    invoke-super {p0, p1, p2, p3, p4}, LBb/a;->f(LAb/f;ILyb/a;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    iget-object p2, v1, LEb/p;->b:[I

    .line 53
    .line 54
    iget p3, v1, LEb/p;->c:I

    .line 55
    .line 56
    aget p2, p2, p3

    .line 57
    .line 58
    if-eq p2, v3, :cond_2

    .line 59
    .line 60
    add-int/2addr p3, v2

    .line 61
    iput p3, v1, LEb/p;->c:I

    .line 62
    .line 63
    iget-object p2, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 64
    .line 65
    array-length p4, p2

    .line 66
    if-ne p3, p4, :cond_2

    .line 67
    .line 68
    mul-int/lit8 p3, p3, 0x2

    .line 69
    .line 70
    invoke-static {p2, p3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    const-string p4, "copyOf(...)"

    .line 75
    .line 76
    invoke-static {p2, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    iput-object p2, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 80
    .line 81
    iget-object p2, v1, LEb/p;->b:[I

    .line 82
    .line 83
    invoke-static {p2, p3}, Ljava/util/Arrays;->copyOf([II)[I

    .line 84
    .line 85
    .line 86
    move-result-object p2

    .line 87
    invoke-static {p2, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    iput-object p2, v1, LEb/p;->b:[I

    .line 91
    .line 92
    :cond_2
    iget-object p2, v1, LEb/p;->a:[Ljava/lang/Object;

    .line 93
    .line 94
    iget p3, v1, LEb/p;->c:I

    .line 95
    .line 96
    aput-object p1, p2, p3

    .line 97
    .line 98
    iget-object p2, v1, LEb/p;->b:[I

    .line 99
    .line 100
    aput v3, p2, p3

    .line 101
    .line 102
    :cond_3
    return-object p1
.end method

.method public final g()C
    .locals 5

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->j()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x1

    .line 12
    const/4 v4, 0x0

    .line 13
    if-ne v2, v3, :cond_0

    .line 14
    .line 15
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    return v0

    .line 20
    :cond_0
    const-string v2, "Expected single char, but got \'"

    .line 21
    .line 22
    const/16 v3, 0x27

    .line 23
    .line 24
    invoke-static {v3, v2, v1}, LT4/Q;->b(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    const/4 v2, 0x6

    .line 29
    const/4 v3, 0x0

    .line 30
    invoke-static {v0, v1, v4, v3, v2}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    throw v3
.end method

.method public final j()Lkotlinx/serialization/json/JsonElement;
    .locals 3

    .line 1
    new-instance v0, LEb/y;

    .line 2
    .line 3
    iget-object v1, p0, LEb/B;->a:LDb/b;

    .line 4
    .line 5
    iget-object v1, v1, LDb/b;->a:LDb/f;

    .line 6
    .line 7
    iget-object v2, p0, LEb/B;->c:LEb/E;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2}, LEb/y;-><init>(LDb/f;LEb/E;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, LEb/y;->b()Lkotlinx/serialization/json/JsonElement;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method

.method public final k()I
    .locals 6

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->h()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    long-to-int v3, v1

    .line 8
    int-to-long v4, v3

    .line 9
    cmp-long v4, v1, v4

    .line 10
    .line 11
    if-nez v4, :cond_0

    .line 12
    .line 13
    return v3

    .line 14
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v4, "Failed to parse int for input \'"

    .line 17
    .line 18
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const/16 v1, 0x27

    .line 25
    .line 26
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const/4 v2, 0x0

    .line 34
    const/4 v3, 0x0

    .line 35
    const/4 v4, 0x6

    .line 36
    invoke-static {v0, v1, v2, v3, v4}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    throw v3
.end method

.method public final l(LAb/f;)I
    .locals 18

    .line 1
    .line 2
    move-object/from16 v0, p0

    .line 3
    .line 4
    move-object/from16 v1, p1

    .line 5
    .line 6
    const-string v2, "descriptor"

    .line 7
    .line 8
    .line 9
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    sget-object v2, LEb/B$b;->a:[I

    .line 12
    .line 13
    iget-object v3, v0, LEb/B;->b:LEb/I;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 17
    move-result v4

    .line 18
    .line 19
    aget v2, v2, v4

    .line 20
    .line 21
    iget-object v4, v0, LEb/B;->c:LEb/E;

    .line 22
    const/4 v5, 0x1

    .line 23
    const/4 v6, 0x2

    .line 24
    const/4 v7, 0x4

    .line 25
    const/4 v8, 0x0

    .line 26
    const/4 v9, 0x0

    .line 27
    .line 28
    const/16 v10, 0x3a

    .line 29
    .line 30
    iget-object v11, v0, LEb/B;->a:LDb/b;

    .line 31
    const/4 v12, -0x1

    .line 32
    .line 33
    iget-object v13, v4, LEb/E;->b:LEb/p;

    .line 34
    .line 35
    if-eq v2, v6, :cond_1a

    .line 36
    const/4 v6, 0x6

    .line 37
    .line 38
    if-eq v2, v7, :cond_4

    .line 39
    .line 40
    .line 41
    invoke-virtual {v4}, LEb/E;->v()Z

    .line 42
    move-result v1

    .line 43
    .line 44
    .line 45
    invoke-virtual {v4}, LEb/E;->b()Z

    .line 46
    move-result v2

    .line 47
    .line 48
    if-eqz v2, :cond_2

    .line 49
    .line 50
    iget v2, v0, LEb/B;->e:I

    .line 51
    .line 52
    if-eq v2, v12, :cond_1

    .line 53
    .line 54
    if-eqz v1, :cond_0

    .line 55
    goto :goto_0

    .line 56
    .line 57
    :cond_0
    const-string v1, "Expected end of the array or comma"

    .line 58
    .line 59
    .line 60
    invoke-static {v4, v1, v8, v9, v6}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 61
    throw v9

    .line 62
    .line 63
    :cond_1
    :goto_0
    add-int/lit8 v12, v2, 0x1

    .line 64
    .line 65
    iput v12, v0, LEb/B;->e:I

    .line 66
    .line 67
    goto/16 :goto_d

    .line 68
    .line 69
    :cond_2
    if-nez v1, :cond_3

    .line 70
    .line 71
    goto/16 :goto_d

    .line 72
    .line 73
    :cond_3
    iget-object v1, v11, LDb/b;->a:LDb/f;

    .line 74
    .line 75
    const-string v1, "array"

    .line 76
    .line 77
    .line 78
    invoke-static {v4, v1}, LEb/m;->f(LEb/E;Ljava/lang/String;)V

    .line 79
    throw v9

    .line 80
    .line 81
    .line 82
    :cond_4
    invoke-virtual {v4}, LEb/E;->v()Z

    .line 83
    move-result v2

    .line 84
    .line 85
    .line 86
    :goto_1
    invoke-virtual {v4}, LEb/E;->b()Z

    .line 87
    move-result v7

    .line 88
    .line 89
    const/16 v14, 0x40

    .line 90
    .line 91
    const-wide/16 v16, 0x1

    .line 92
    .line 93
    iget-object v15, v0, LEb/B;->h:LEb/l;

    .line 94
    .line 95
    if-eqz v7, :cond_13

    .line 96
    .line 97
    iget-object v2, v0, LEb/B;->g:LDb/f;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v4}, LEb/E;->d()Ljava/lang/String;

    .line 101
    move-result-object v7

    .line 102
    .line 103
    .line 104
    invoke-virtual {v4, v10}, LEb/E;->g(C)V

    .line 105
    .line 106
    .line 107
    invoke-static {v1, v11, v7}, LEb/o;->a(LAb/f;LDb/b;Ljava/lang/String;)I

    .line 108
    move-result v10

    .line 109
    const/4 v12, -0x3

    .line 110
    .line 111
    if-eq v10, v12, :cond_7

    .line 112
    .line 113
    if-eqz v15, :cond_5

    .line 114
    .line 115
    iget-object v1, v15, LEb/l;->a:LCb/u;

    .line 116
    .line 117
    if-ge v10, v14, :cond_6

    .line 118
    .line 119
    iget-wide v4, v1, LCb/u;->c:J

    .line 120
    .line 121
    shl-long v6, v16, v10

    .line 122
    or-long/2addr v4, v6

    .line 123
    .line 124
    iput-wide v4, v1, LCb/u;->c:J

    .line 125
    :cond_5
    :goto_2
    move v12, v10

    .line 126
    .line 127
    goto/16 :goto_d

    .line 128
    .line 129
    :cond_6
    ushr-int/lit8 v2, v10, 0x6

    .line 130
    sub-int/2addr v2, v5

    .line 131
    .line 132
    and-int/lit8 v4, v10, 0x3f

    .line 133
    .line 134
    iget-object v1, v1, LCb/u;->d:[J

    .line 135
    .line 136
    aget-wide v5, v1, v2

    .line 137
    .line 138
    shl-long v7, v16, v4

    .line 139
    .line 140
    or-long v4, v5, v7

    .line 141
    .line 142
    aput-wide v4, v1, v2

    .line 143
    goto :goto_2

    .line 144
    .line 145
    :cond_7
    iget-boolean v2, v2, LDb/f;->a:Z

    .line 146
    .line 147
    if-nez v2, :cond_9

    .line 148
    .line 149
    iget-object v2, v0, LEb/B;->f:LEb/B$a;

    .line 150
    .line 151
    if-eqz v2, :cond_8

    .line 152
    .line 153
    iget-object v10, v2, LEb/B$a;->a:Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    invoke-static {v10, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 157
    move-result v10

    .line 158
    .line 159
    if-eqz v10, :cond_8

    .line 160
    .line 161
    iput-object v9, v2, LEb/B$a;->a:Ljava/lang/String;

    .line 162
    goto :goto_3

    .line 163
    .line 164
    :cond_8
    const-string v1, "key"

    .line 165
    .line 166
    .line 167
    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 168
    .line 169
    iget v1, v4, LEb/E;->a:I

    .line 170
    .line 171
    .line 172
    invoke-virtual {v4}, LEb/E;->p()Ljava/lang/String;

    .line 173
    move-result-object v2

    .line 174
    .line 175
    .line 176
    invoke-virtual {v2, v8, v1}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 177
    move-result-object v1

    .line 178
    .line 179
    .line 180
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 181
    move-result-object v1

    .line 182
    .line 183
    .line 184
    invoke-static {v1, v8, v6, v7}, Lkotlin/text/StringsKt;->H(Ljava/lang/String;IILjava/lang/String;)I

    .line 185
    move-result v1

    .line 186
    .line 187
    const-string v2, "Encountered an unknown key \'"

    .line 188
    .line 189
    const/16 v3, 0x27

    .line 190
    .line 191
    .line 192
    invoke-static {v3, v2, v7}, LT4/Q;->b(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 193
    move-result-object v2

    .line 194
    .line 195
    const-string v3, "Use \'ignoreUnknownKeys = true\' in \'Json {}\' builder to ignore unknown keys."

    .line 196
    .line 197
    .line 198
    invoke-virtual {v4, v1, v2, v3}, LEb/E;->l(ILjava/lang/String;Ljava/lang/String;)V

    .line 199
    throw v9

    .line 200
    .line 201
    :cond_9
    :goto_3
    new-instance v7, Ljava/util/ArrayList;

    .line 202
    .line 203
    .line 204
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v4}, LEb/E;->r()B

    .line 208
    move-result v2

    .line 209
    .line 210
    const/16 v10, 0x8

    .line 211
    .line 212
    if-eq v2, v10, :cond_a

    .line 213
    .line 214
    if-eq v2, v6, :cond_a

    .line 215
    .line 216
    .line 217
    invoke-virtual {v4}, LEb/E;->j()Ljava/lang/String;

    .line 218
    .line 219
    goto/16 :goto_7

    .line 220
    .line 221
    .line 222
    :cond_a
    :goto_4
    invoke-virtual {v4}, LEb/E;->r()B

    .line 223
    move-result v2

    .line 224
    .line 225
    if-ne v2, v5, :cond_b

    .line 226
    .line 227
    .line 228
    invoke-virtual {v4}, LEb/E;->d()Ljava/lang/String;

    .line 229
    goto :goto_4

    .line 230
    .line 231
    :cond_b
    if-eq v2, v10, :cond_12

    .line 232
    .line 233
    if-ne v2, v6, :cond_c

    .line 234
    goto :goto_5

    .line 235
    .line 236
    :cond_c
    iget-object v12, v4, LEb/E;->e:Ljava/lang/String;

    .line 237
    .line 238
    const/16 v14, 0x9

    .line 239
    .line 240
    if-ne v2, v14, :cond_e

    .line 241
    .line 242
    .line 243
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 244
    move-result-object v2

    .line 245
    .line 246
    check-cast v2, Ljava/lang/Number;

    .line 247
    .line 248
    .line 249
    invoke-virtual {v2}, Ljava/lang/Number;->byteValue()B

    .line 250
    move-result v2

    .line 251
    .line 252
    if-ne v2, v10, :cond_d

    .line 253
    .line 254
    .line 255
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->removeLast(Ljava/util/List;)Ljava/lang/Object;

    .line 256
    goto :goto_6

    .line 257
    .line 258
    :cond_d
    iget v1, v4, LEb/E;->a:I

    .line 259
    .line 260
    new-instance v2, Ljava/lang/StringBuilder;

    .line 261
    .line 262
    const-string v3, "found ] instead of } at path: "

    .line 263
    .line 264
    .line 265
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 269
    .line 270
    .line 271
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 272
    move-result-object v2

    .line 273
    .line 274
    .line 275
    invoke-static {v1, v2, v12}, LEb/m;->e(ILjava/lang/String;Ljava/lang/CharSequence;)Lkotlinx/serialization/json/internal/JsonDecodingException;

    .line 276
    move-result-object v1

    .line 277
    throw v1

    .line 278
    :cond_e
    const/4 v14, 0x7

    .line 279
    .line 280
    if-ne v2, v14, :cond_10

    .line 281
    .line 282
    .line 283
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 284
    move-result-object v2

    .line 285
    .line 286
    check-cast v2, Ljava/lang/Number;

    .line 287
    .line 288
    .line 289
    invoke-virtual {v2}, Ljava/lang/Number;->byteValue()B

    .line 290
    move-result v2

    .line 291
    .line 292
    if-ne v2, v6, :cond_f

    .line 293
    .line 294
    .line 295
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->removeLast(Ljava/util/List;)Ljava/lang/Object;

    .line 296
    goto :goto_6

    .line 297
    .line 298
    :cond_f
    iget v1, v4, LEb/E;->a:I

    .line 299
    .line 300
    new-instance v2, Ljava/lang/StringBuilder;

    .line 301
    .line 302
    const/4 v3, 0x0

    sget-object v3, Le2/IPX/jaRKsJUzeIfpWZ;->rYyk:Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 309
    .line 310
    .line 311
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 312
    move-result-object v2

    .line 313
    .line 314
    .line 315
    invoke-static {v1, v2, v12}, LEb/m;->e(ILjava/lang/String;Ljava/lang/CharSequence;)Lkotlinx/serialization/json/internal/JsonDecodingException;

    .line 316
    move-result-object v1

    .line 317
    throw v1

    .line 318
    .line 319
    :cond_10
    const/16 v12, 0xa

    .line 320
    .line 321
    if-eq v2, v12, :cond_11

    .line 322
    goto :goto_6

    .line 323
    .line 324
    :cond_11
    const-string v1, "Unexpected end of input due to malformed JSON during ignoring unknown keys"

    .line 325
    .line 326
    .line 327
    invoke-static {v4, v1, v8, v9, v6}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 328
    throw v9

    .line 329
    .line 330
    .line 331
    :cond_12
    :goto_5
    invoke-static {v2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 332
    move-result-object v2

    .line 333
    .line 334
    .line 335
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    :goto_6
    invoke-virtual {v4}, LEb/E;->e()B

    .line 339
    .line 340
    .line 341
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 342
    move-result v2

    .line 343
    .line 344
    if-nez v2, :cond_a

    .line 345
    .line 346
    .line 347
    :goto_7
    invoke-virtual {v4}, LEb/E;->v()Z

    .line 348
    move-result v2

    .line 349
    .line 350
    const/16 v10, 0x3a

    .line 351
    const/4 v12, -0x1

    .line 352
    .line 353
    goto/16 :goto_1

    .line 354
    .line 355
    :cond_13
    if-nez v2, :cond_19

    .line 356
    .line 357
    if-eqz v15, :cond_18

    .line 358
    .line 359
    iget-object v1, v15, LEb/l;->a:LCb/u;

    .line 360
    .line 361
    iget-object v2, v1, LCb/u;->a:LAb/f;

    .line 362
    .line 363
    .line 364
    invoke-interface {v2}, LAb/f;->m()I

    .line 365
    move-result v4

    .line 366
    .line 367
    :cond_14
    iget-wide v5, v1, LCb/u;->c:J

    .line 368
    .line 369
    const-wide/16 v9, -0x1

    .line 370
    .line 371
    cmp-long v7, v5, v9

    .line 372
    .line 373
    iget-object v11, v1, LCb/u;->b:LEb/l$a;

    .line 374
    .line 375
    if-eqz v7, :cond_15

    .line 376
    not-long v5, v5

    .line 377
    .line 378
    .line 379
    invoke-static {v5, v6}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 380
    move-result v5

    .line 381
    .line 382
    iget-wide v6, v1, LCb/u;->c:J

    .line 383
    .line 384
    shl-long v9, v16, v5

    .line 385
    or-long/2addr v6, v9

    .line 386
    .line 387
    iput-wide v6, v1, LCb/u;->c:J

    .line 388
    .line 389
    .line 390
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 391
    move-result-object v6

    .line 392
    .line 393
    .line 394
    invoke-virtual {v11, v2, v6}, LEb/l$a;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 395
    move-result-object v6

    .line 396
    .line 397
    check-cast v6, Ljava/lang/Boolean;

    .line 398
    .line 399
    .line 400
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 401
    move-result v6

    .line 402
    .line 403
    if-eqz v6, :cond_14

    .line 404
    move v12, v5

    .line 405
    .line 406
    goto/16 :goto_d

    .line 407
    .line 408
    :cond_15
    if-le v4, v14, :cond_18

    .line 409
    .line 410
    iget-object v1, v1, LCb/u;->d:[J

    .line 411
    array-length v4, v1

    .line 412
    .line 413
    :goto_8
    if-ge v8, v4, :cond_18

    .line 414
    .line 415
    add-int/lit8 v5, v8, 0x1

    .line 416
    .line 417
    mul-int/lit8 v6, v5, 0x40

    .line 418
    .line 419
    aget-wide v14, v1, v8

    .line 420
    .line 421
    :goto_9
    cmp-long v7, v14, v9

    .line 422
    .line 423
    if-eqz v7, :cond_17

    .line 424
    not-long v9, v14

    .line 425
    .line 426
    .line 427
    invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 428
    move-result v7

    .line 429
    .line 430
    shl-long v9, v16, v7

    .line 431
    or-long/2addr v14, v9

    .line 432
    add-int/2addr v7, v6

    .line 433
    .line 434
    .line 435
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 436
    move-result-object v9

    .line 437
    .line 438
    .line 439
    invoke-virtual {v11, v2, v9}, LEb/l$a;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 440
    move-result-object v9

    .line 441
    .line 442
    check-cast v9, Ljava/lang/Boolean;

    .line 443
    .line 444
    .line 445
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 446
    move-result v9

    .line 447
    .line 448
    if-eqz v9, :cond_16

    .line 449
    .line 450
    aput-wide v14, v1, v8

    .line 451
    move v12, v7

    .line 452
    goto :goto_d

    .line 453
    .line 454
    :cond_16
    const-wide/16 v9, -0x1

    .line 455
    goto :goto_9

    .line 456
    .line 457
    :cond_17
    aput-wide v14, v1, v8

    .line 458
    move v8, v5

    .line 459
    .line 460
    const-wide/16 v9, -0x1

    .line 461
    goto :goto_8

    .line 462
    :cond_18
    const/4 v12, -0x1

    .line 463
    goto :goto_d

    .line 464
    .line 465
    :cond_19
    iget-object v1, v11, LDb/b;->a:LDb/f;

    .line 466
    .line 467
    .line 468
    invoke-static {v4}, LEb/m;->g(LEb/E;)V

    .line 469
    throw v9

    .line 470
    .line 471
    :cond_1a
    iget v1, v0, LEb/B;->e:I

    .line 472
    .line 473
    rem-int/lit8 v2, v1, 0x2

    .line 474
    .line 475
    if-eqz v2, :cond_1b

    .line 476
    move v2, v5

    .line 477
    goto :goto_a

    .line 478
    :cond_1b
    move v2, v8

    .line 479
    .line 480
    :goto_a
    if-eqz v2, :cond_1c

    .line 481
    const/4 v6, -0x1

    .line 482
    .line 483
    if-eq v1, v6, :cond_1d

    .line 484
    .line 485
    .line 486
    invoke-virtual {v4}, LEb/E;->v()Z

    .line 487
    move-result v8

    .line 488
    goto :goto_b

    .line 489
    .line 490
    :cond_1c
    const/16 v1, 0x3a

    .line 491
    const/4 v6, -0x1

    .line 492
    .line 493
    .line 494
    invoke-virtual {v4, v1}, LEb/E;->g(C)V

    .line 495
    .line 496
    .line 497
    :cond_1d
    :goto_b
    invoke-virtual {v4}, LEb/E;->b()Z

    .line 498
    move-result v1

    .line 499
    .line 500
    if-eqz v1, :cond_22

    .line 501
    .line 502
    if-eqz v2, :cond_21

    .line 503
    .line 504
    iget v1, v0, LEb/B;->e:I

    .line 505
    .line 506
    if-ne v1, v6, :cond_1f

    .line 507
    .line 508
    iget v1, v4, LEb/E;->a:I

    .line 509
    .line 510
    if-nez v8, :cond_1e

    .line 511
    goto :goto_c

    .line 512
    .line 513
    :cond_1e
    const-string v2, "Unexpected leading comma"

    .line 514
    .line 515
    .line 516
    invoke-static {v4, v2, v1, v9, v7}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 517
    throw v9

    .line 518
    .line 519
    :cond_1f
    iget v1, v4, LEb/E;->a:I

    .line 520
    .line 521
    if-eqz v8, :cond_20

    .line 522
    goto :goto_c

    .line 523
    .line 524
    :cond_20
    const-string v2, "Expected comma after the key-value pair"

    .line 525
    .line 526
    .line 527
    invoke-static {v4, v2, v1, v9, v7}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 528
    throw v9

    .line 529
    .line 530
    :cond_21
    :goto_c
    iget v1, v0, LEb/B;->e:I

    .line 531
    .line 532
    add-int/lit8 v12, v1, 0x1

    .line 533
    .line 534
    iput v12, v0, LEb/B;->e:I

    .line 535
    goto :goto_d

    .line 536
    .line 537
    :cond_22
    if-nez v8, :cond_24

    .line 538
    move v12, v6

    .line 539
    .line 540
    :goto_d
    sget-object v1, LEb/I;->MAP:LEb/I;

    .line 541
    .line 542
    if-eq v3, v1, :cond_23

    .line 543
    .line 544
    iget-object v1, v13, LEb/p;->b:[I

    .line 545
    .line 546
    iget v2, v13, LEb/p;->c:I

    .line 547
    .line 548
    aput v12, v1, v2

    .line 549
    :cond_23
    return v12

    .line 550
    .line 551
    :cond_24
    iget-object v1, v11, LDb/b;->a:LDb/f;

    .line 552
    .line 553
    .line 554
    invoke-static {v4}, LEb/m;->g(LEb/E;)V

    .line 555
    throw v9
.end method

.method public final m(LAb/f;)LBb/e;
    .locals 2

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LEb/D;->a(LAb/f;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    new-instance p1, LEb/k;

    .line 13
    .line 14
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 15
    .line 16
    iget-object v1, p0, LEb/B;->a:LDb/b;

    .line 17
    .line 18
    invoke-direct {p1, v0, v1}, LEb/k;-><init>(LEb/E;LDb/b;)V

    .line 19
    .line 20
    .line 21
    return-object p1

    .line 22
    :cond_0
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return-object p0
.end method

.method public final n()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->i()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final q()J
    .locals 2

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->h()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final t(LAb/f;)I
    .locals 4

    .line 1
    const-string v0, "enumDescriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 7
    .line 8
    invoke-virtual {v0}, LEb/E;->i()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    new-instance v2, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, " at path "

    .line 15
    .line 16
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, v0, LEb/E;->b:LEb/p;

    .line 20
    .line 21
    invoke-virtual {v0}, LEb/p;->a()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iget-object v2, p0, LEb/B;->a:LDb/b;

    .line 33
    .line 34
    invoke-static {p1, v2, v1, v0}, LEb/o;->b(LAb/f;LDb/b;Ljava/lang/String;Ljava/lang/String;)I

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    return p1
.end method

.method public final v()Z
    .locals 11

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LEb/B;->h:LEb/l;

    .line 3
    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    iget-boolean v1, v1, LEb/l;->b:Z

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    move v1, v0

    .line 10
    :goto_0
    if-nez v1, :cond_6

    .line 11
    .line 12
    iget-object v1, p0, LEb/B;->c:LEb/E;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    invoke-virtual {v1}, LEb/E;->u()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1, v3}, LEb/E;->t(I)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, LEb/E;->p()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    sub-int/2addr v4, v3

    .line 32
    const/4 v5, 0x0

    .line 33
    const/4 v6, 0x4

    .line 34
    if-lt v4, v6, :cond_5

    .line 35
    .line 36
    const/4 v7, -0x1

    .line 37
    if-ne v3, v7, :cond_1

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_1
    move v7, v5

    .line 41
    :goto_1
    if-ge v7, v6, :cond_3

    .line 42
    .line 43
    const-string v8, "null"

    .line 44
    .line 45
    invoke-virtual {v8, v7}, Ljava/lang/String;->charAt(I)C

    .line 46
    .line 47
    .line 48
    move-result v8

    .line 49
    invoke-virtual {v1}, LEb/E;->p()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v9

    .line 53
    add-int v10, v3, v7

    .line 54
    .line 55
    invoke-virtual {v9, v10}, Ljava/lang/String;->charAt(I)C

    .line 56
    .line 57
    .line 58
    move-result v9

    .line 59
    if-eq v8, v9, :cond_2

    .line 60
    .line 61
    goto :goto_2

    .line 62
    :cond_2
    add-int/lit8 v7, v7, 0x1

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_3
    if-le v4, v6, :cond_4

    .line 66
    .line 67
    invoke-virtual {v1}, LEb/E;->p()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    add-int/lit8 v7, v3, 0x4

    .line 72
    .line 73
    invoke-virtual {v4, v7}, Ljava/lang/String;->charAt(I)C

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    invoke-static {v4}, LEb/a;->a(C)B

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    if-nez v4, :cond_4

    .line 82
    .line 83
    goto :goto_2

    .line 84
    :cond_4
    add-int/2addr v3, v6

    .line 85
    iput v3, v1, LEb/E;->a:I

    .line 86
    .line 87
    const/4 v5, 0x1

    .line 88
    :cond_5
    :goto_2
    if-nez v5, :cond_6

    .line 89
    .line 90
    return v2

    .line 91
    :cond_6
    return v0
.end method

.method public final y()B
    .locals 6

    .line 1
    iget-object v0, p0, LEb/B;->c:LEb/E;

    .line 2
    .line 3
    invoke-virtual {v0}, LEb/E;->h()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    long-to-int v3, v1

    .line 8
    int-to-byte v3, v3

    .line 9
    int-to-long v4, v3

    .line 10
    cmp-long v4, v1, v4

    .line 11
    .line 12
    if-nez v4, :cond_0

    .line 13
    .line 14
    return v3

    .line 15
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v4, "Failed to parse byte for input \'"

    .line 18
    .line 19
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const/16 v1, 0x27

    .line 26
    .line 27
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const/4 v2, 0x0

    .line 35
    const/4 v3, 0x0

    .line 36
    const/4 v4, 0x6

    .line 37
    invoke-static {v0, v1, v2, v3, v4}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 38
    .line 39
    .line 40
    throw v3
.end method

.method public final z(Lyb/a;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/a<",
            "+TT;>;)TT;"
        }
    .end annotation

    .line 1
    .line 2
    const/4 v0, 0x0

    sget-object v0, Landroidx/appcompat/view/menu/OLmF/yuvNGsNizz;->dpwMvmjIOHcdmQn:Ljava/lang/String;

    .line 3
    .line 4
    iget-object v1, p0, LEb/B;->a:LDb/b;

    .line 5
    .line 6
    iget-object v2, p0, LEb/B;->c:LEb/E;

    .line 7
    .line 8
    iget-object v3, v2, LEb/E;->b:LEb/p;

    .line 9
    .line 10
    const-string v4, "Expected "

    .line 11
    .line 12
    const-string v5, "deserializer"

    .line 13
    .line 14
    .line 15
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    const/4 v5, 0x0

    .line 17
    .line 18
    :try_start_0
    instance-of v6, p1, LCb/b;

    .line 19
    .line 20
    if-eqz v6, :cond_7

    .line 21
    .line 22
    iget-object v6, v1, LDb/b;->a:LDb/f;

    .line 23
    move-object v6, p1

    .line 24
    .line 25
    check-cast v6, LCb/b;

    .line 26
    .line 27
    .line 28
    invoke-interface {v6}, Lyb/g;->b()LAb/f;

    .line 29
    move-result-object v6

    .line 30
    .line 31
    .line 32
    invoke-static {v6, v1}, LEb/z;->a(LAb/f;LDb/b;)Ljava/lang/String;

    .line 33
    move-result-object v6

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, v6}, LEb/E;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    move-result-object v7

    .line 38
    const/4 v8, 0x0

    .line 39
    .line 40
    if-nez v7, :cond_6

    .line 41
    .line 42
    if-eqz p1, :cond_5

    .line 43
    .line 44
    iget-object v2, v1, LDb/b;->a:LDb/f;

    .line 45
    move-object v2, p1

    .line 46
    .line 47
    check-cast v2, LCb/b;

    .line 48
    .line 49
    .line 50
    invoke-interface {v2}, Lyb/g;->b()LAb/f;

    .line 51
    move-result-object v2

    .line 52
    .line 53
    .line 54
    invoke-static {v2, v1}, LEb/z;->a(LAb/f;LDb/b;)Ljava/lang/String;

    .line 55
    move-result-object v2

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0}, LEb/B;->j()Lkotlinx/serialization/json/JsonElement;

    .line 59
    move-result-object v6

    .line 60
    move-object v7, p1

    .line 61
    .line 62
    check-cast v7, LCb/b;

    .line 63
    .line 64
    .line 65
    invoke-interface {v7}, Lyb/g;->b()LAb/f;

    .line 66
    move-result-object v7

    .line 67
    .line 68
    .line 69
    invoke-interface {v7}, LAb/f;->j()Ljava/lang/String;

    .line 70
    move-result-object v7

    .line 71
    .line 72
    instance-of v9, v6, Lkotlinx/serialization/json/JsonObject;

    .line 73
    const/4 v10, -0x1

    .line 74
    .line 75
    if-eqz v9, :cond_4

    .line 76
    .line 77
    check-cast v6, Lkotlinx/serialization/json/JsonObject;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v6, v2}, Lkotlinx/serialization/json/JsonObject;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    move-result-object v4

    .line 82
    .line 83
    check-cast v4, Lkotlinx/serialization/json/JsonElement;

    .line 84
    .line 85
    if-eqz v4, :cond_3

    .line 86
    .line 87
    sget-object v7, LDb/h;->a:LCb/E;

    .line 88
    .line 89
    .line 90
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    instance-of v7, v4, Lkotlinx/serialization/json/JsonPrimitive;

    .line 93
    .line 94
    if-eqz v7, :cond_0

    .line 95
    move-object v7, v4

    .line 96
    .line 97
    check-cast v7, Lkotlinx/serialization/json/JsonPrimitive;

    .line 98
    goto :goto_0

    .line 99
    :cond_0
    move-object v7, v8

    .line 100
    .line 101
    :goto_0
    if-eqz v7, :cond_2

    .line 102
    .line 103
    .line 104
    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .line 106
    instance-of v0, v7, Lkotlinx/serialization/json/a;

    .line 107
    .line 108
    if-eqz v0, :cond_1

    .line 109
    goto :goto_1

    .line 110
    .line 111
    .line 112
    :cond_1
    invoke-virtual {v7}, Lkotlinx/serialization/json/JsonPrimitive;->h()Ljava/lang/String;

    .line 113
    move-result-object v8

    .line 114
    goto :goto_1

    .line 115
    .line 116
    :cond_2
    const-string p1, "JsonPrimitive"

    .line 117
    .line 118
    .line 119
    invoke-static {v4, p1}, LDb/h;->a(Lkotlinx/serialization/json/JsonElement;Ljava/lang/String;)V

    .line 120
    throw v8
    :try_end_0
    .catch Lkotlinx/serialization/MissingFieldException; {:try_start_0 .. :try_end_0} :catch_0

    .line 121
    .line 122
    :cond_3
    :goto_1
    :try_start_1
    check-cast p1, LCb/b;

    .line 123
    .line 124
    .line 125
    invoke-static {p1, p0, v8}, Lyb/e;->a(LCb/b;LBb/c;Ljava/lang/String;)Lyb/a;

    .line 126
    move-result-object p1
    :try_end_1
    .catch Lkotlinx/serialization/SerializationException; {:try_start_1 .. :try_end_1} :catch_1

    .line 127
    .line 128
    :try_start_2
    const-string v0, "null cannot be cast to non-null type kotlinx.serialization.DeserializationStrategy<T of kotlinx.serialization.json.internal.PolymorphicKt.decodeSerializableValuePolymorphic>"

    .line 129
    .line 130
    .line 131
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v1, v2, v6, p1}, LEb/H;->a(LDb/b;Ljava/lang/String;Lkotlinx/serialization/json/JsonObject;Lyb/a;)Ljava/lang/Object;

    .line 135
    move-result-object p1

    .line 136
    return-object p1

    .line 137
    :catch_0
    move-exception p1

    .line 138
    .line 139
    goto/16 :goto_2

    .line 140
    :catch_1
    move-exception p1

    .line 141
    .line 142
    .line 143
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 144
    move-result-object p1

    .line 145
    .line 146
    .line 147
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v6}, Lkotlinx/serialization/json/JsonObject;->toString()Ljava/lang/String;

    .line 151
    move-result-object v0

    .line 152
    .line 153
    .line 154
    invoke-static {v10, p1, v0}, LEb/m;->e(ILjava/lang/String;Ljava/lang/CharSequence;)Lkotlinx/serialization/json/internal/JsonDecodingException;

    .line 155
    move-result-object p1

    .line 156
    throw p1

    .line 157
    .line 158
    :cond_4
    new-instance p1, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    .line 161
    invoke-direct {p1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    const-class v0, Lkotlinx/serialization/json/JsonObject;

    .line 164
    .line 165
    sget-object v1, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v1, v0}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 169
    move-result-object v0

    .line 170
    .line 171
    .line 172
    invoke-interface {v0}, LZ9/d;->p()Ljava/lang/String;

    .line 173
    move-result-object v0

    .line 174
    .line 175
    .line 176
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 177
    .line 178
    const-string v0, ", but had "

    .line 179
    .line 180
    .line 181
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    .line 183
    .line 184
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    move-result-object v0

    .line 186
    .line 187
    .line 188
    invoke-virtual {v1, v0}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 189
    move-result-object v0

    .line 190
    .line 191
    .line 192
    invoke-interface {v0}, LZ9/d;->p()Ljava/lang/String;

    .line 193
    move-result-object v0

    .line 194
    .line 195
    .line 196
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    const-string v0, " as the serialized body of "

    .line 199
    .line 200
    .line 201
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    const-string v0, " at element: "

    .line 207
    .line 208
    .line 209
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    invoke-virtual {v3}, LEb/p;->a()Ljava/lang/String;

    .line 213
    move-result-object v0

    .line 214
    .line 215
    .line 216
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 220
    move-result-object p1

    .line 221
    .line 222
    .line 223
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 224
    move-result-object v0

    .line 225
    .line 226
    .line 227
    invoke-static {v10, p1, v0}, LEb/m;->e(ILjava/lang/String;Ljava/lang/CharSequence;)Lkotlinx/serialization/json/internal/JsonDecodingException;

    .line 228
    move-result-object p1

    .line 229
    throw p1

    .line 230
    .line 231
    :cond_5
    check-cast p1, LCb/b;

    .line 232
    .line 233
    .line 234
    invoke-virtual {p1, p0}, LCb/b;->c(LBb/e;)Ljava/lang/Object;

    .line 235
    move-result-object p1
    :try_end_2
    .catch Lkotlinx/serialization/MissingFieldException; {:try_start_2 .. :try_end_2} :catch_0

    .line 236
    return-object p1

    .line 237
    .line 238
    :cond_6
    :try_start_3
    check-cast p1, LCb/b;

    .line 239
    .line 240
    .line 241
    invoke-static {p1, p0, v7}, Lyb/e;->a(LCb/b;LBb/c;Ljava/lang/String;)Lyb/a;

    .line 242
    move-result-object p1
    :try_end_3
    .catch Lkotlinx/serialization/SerializationException; {:try_start_3 .. :try_end_3} :catch_2

    .line 243
    .line 244
    :try_start_4
    const-string v0, "null cannot be cast to non-null type kotlinx.serialization.DeserializationStrategy<T of kotlinx.serialization.json.internal.StreamingJsonDecoder.decodeSerializableValue>"

    .line 245
    .line 246
    .line 247
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 248
    .line 249
    new-instance v0, LEb/B$a;

    .line 250
    .line 251
    .line 252
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 253
    .line 254
    iput-object v6, v0, LEb/B$a;->a:Ljava/lang/String;

    .line 255
    .line 256
    iput-object v0, p0, LEb/B;->f:LEb/B$a;

    .line 257
    .line 258
    .line 259
    invoke-interface {p1, p0}, Lyb/a;->c(LBb/e;)Ljava/lang/Object;

    .line 260
    move-result-object p1

    .line 261
    return-object p1

    .line 262
    :catch_2
    move-exception p1

    .line 263
    .line 264
    .line 265
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 266
    move-result-object v0

    .line 267
    .line 268
    .line 269
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 270
    .line 271
    const/16 v1, 0xa

    .line 272
    .line 273
    .line 274
    invoke-static {v0, v1}, Lkotlin/text/StringsKt;->Q(Ljava/lang/String;C)Ljava/lang/String;

    .line 275
    move-result-object v0

    .line 276
    .line 277
    const-string v4, "."

    .line 278
    .line 279
    .line 280
    invoke-static {v0, v4}, Lkotlin/text/StringsKt;->J(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 281
    move-result-object v0

    .line 282
    .line 283
    .line 284
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 285
    move-result-object p1

    .line 286
    .line 287
    .line 288
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 289
    .line 290
    const-string v4, ""

    .line 291
    .line 292
    .line 293
    invoke-static {v1, p1, v4}, Lkotlin/text/StringsKt;->N(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 294
    move-result-object p1

    .line 295
    const/4 v1, 0x2

    .line 296
    .line 297
    .line 298
    invoke-static {v2, v0, v5, p1, v1}, LEb/E;->m(LEb/E;Ljava/lang/String;ILjava/lang/String;I)V

    .line 299
    throw v8

    .line 300
    .line 301
    .line 302
    :cond_7
    invoke-interface {p1, p0}, Lyb/a;->c(LBb/e;)Ljava/lang/Object;

    .line 303
    move-result-object p1
    :try_end_4
    .catch Lkotlinx/serialization/MissingFieldException; {:try_start_4 .. :try_end_4} :catch_0

    .line 304
    return-object p1

    .line 305
    .line 306
    .line 307
    :goto_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 308
    move-result-object v0

    .line 309
    .line 310
    .line 311
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 312
    .line 313
    const-string v1, "at path"

    .line 314
    .line 315
    .line 316
    invoke-static {v0, v1, v5}, Lkotlin/text/StringsKt;->x(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 317
    move-result v0

    .line 318
    .line 319
    if-eqz v0, :cond_8

    .line 320
    throw p1

    .line 321
    .line 322
    :cond_8
    new-instance v0, Lkotlinx/serialization/MissingFieldException;

    .line 323
    .line 324
    new-instance v1, Ljava/lang/StringBuilder;

    .line 325
    .line 326
    .line 327
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 328
    .line 329
    .line 330
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 331
    move-result-object v2

    .line 332
    .line 333
    .line 334
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 335
    .line 336
    const-string v2, " at path: "

    .line 337
    .line 338
    .line 339
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 340
    .line 341
    .line 342
    invoke-virtual {v3}, LEb/p;->a()Ljava/lang/String;

    .line 343
    move-result-object v2

    .line 344
    .line 345
    .line 346
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 350
    move-result-object v1

    .line 351
    .line 352
    iget-object v2, p1, Lkotlinx/serialization/MissingFieldException;->a:Ljava/util/ArrayList;

    .line 353
    .line 354
    .line 355
    invoke-direct {v0, v2, v1, p1}, Lkotlinx/serialization/MissingFieldException;-><init>(Ljava/util/ArrayList;Ljava/lang/String;Lkotlinx/serialization/MissingFieldException;)V

    .line 356
    throw v0
.end method
