.class public final enum LEb/I;
.super Ljava/lang/Enum;
.source "WriteMode.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LEb/I;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u000c\n\u0002\u0008\n\u0008\u0080\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0019\u0008\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0005\u0010\u0006R\u0014\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0003\u0010\u0007R\u0014\u0010\u0004\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0004\u0010\u0007j\u0002\u0008\u0008j\u0002\u0008\tj\u0002\u0008\nj\u0002\u0008\u000b\u00a8\u0006\u000c"
    }
    d2 = {
        "LEb/I;",
        "",
        "",
        "begin",
        "end",
        "<init>",
        "(Ljava/lang/String;ICC)V",
        "C",
        "OBJ",
        "LIST",
        "MAP",
        "POLY_OBJ",
        "kotlinx-serialization-json"
    }
    k = 0x1
    mv = {
        0x2,
        0x0,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:LN9/a;

.field private static final synthetic $VALUES:[LEb/I;

.field public static final enum LIST:LEb/I;

.field public static final enum MAP:LEb/I;

.field public static final enum OBJ:LEb/I;

.field public static final enum POLY_OBJ:LEb/I;


# instance fields
.field public final begin:C

.field public final end:C


# direct methods
.method private static final synthetic $values()[LEb/I;
    .locals 4

    .line 1
    sget-object v0, LEb/I;->OBJ:LEb/I;

    .line 2
    .line 3
    sget-object v1, LEb/I;->LIST:LEb/I;

    .line 4
    .line 5
    sget-object v2, LEb/I;->MAP:LEb/I;

    .line 6
    .line 7
    sget-object v3, LEb/I;->POLY_OBJ:LEb/I;

    .line 8
    .line 9
    filled-new-array {v0, v1, v2, v3}, [LEb/I;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, LEb/I;

    .line 2
    .line 3
    const-string v1, "OBJ"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/16 v3, 0x7b

    .line 7
    .line 8
    const/16 v4, 0x7d

    .line 9
    .line 10
    invoke-direct {v0, v1, v2, v3, v4}, LEb/I;-><init>(Ljava/lang/String;ICC)V

    .line 11
    .line 12
    .line 13
    sput-object v0, LEb/I;->OBJ:LEb/I;

    .line 14
    .line 15
    new-instance v0, LEb/I;

    .line 16
    .line 17
    const-string v1, "LIST"

    .line 18
    .line 19
    const/4 v2, 0x1

    .line 20
    const/16 v5, 0x5b

    .line 21
    .line 22
    const/16 v6, 0x5d

    .line 23
    .line 24
    invoke-direct {v0, v1, v2, v5, v6}, LEb/I;-><init>(Ljava/lang/String;ICC)V

    .line 25
    .line 26
    .line 27
    sput-object v0, LEb/I;->LIST:LEb/I;

    .line 28
    .line 29
    new-instance v0, LEb/I;

    .line 30
    .line 31
    const-string v1, "MAP"

    .line 32
    .line 33
    const/4 v2, 0x2

    .line 34
    invoke-direct {v0, v1, v2, v3, v4}, LEb/I;-><init>(Ljava/lang/String;ICC)V

    .line 35
    .line 36
    .line 37
    sput-object v0, LEb/I;->MAP:LEb/I;

    .line 38
    .line 39
    new-instance v0, LEb/I;

    .line 40
    .line 41
    const-string v1, "POLY_OBJ"

    .line 42
    .line 43
    const/4 v2, 0x3

    .line 44
    invoke-direct {v0, v1, v2, v5, v6}, LEb/I;-><init>(Ljava/lang/String;ICC)V

    .line 45
    .line 46
    .line 47
    sput-object v0, LEb/I;->POLY_OBJ:LEb/I;

    .line 48
    .line 49
    invoke-static {}, LEb/I;->$values()[LEb/I;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    sput-object v0, LEb/I;->$VALUES:[LEb/I;

    .line 54
    .line 55
    invoke-static {v0}, LN9/b;->a([Ljava/lang/Enum;)LN9/c;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sput-object v0, LEb/I;->$ENTRIES:LN9/a;

    .line 60
    .line 61
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ICC)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(CC)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-char p3, p0, LEb/I;->begin:C

    .line 5
    .line 6
    iput-char p4, p0, LEb/I;->end:C

    .line 7
    .line 8
    return-void
.end method

.method public static getEntries()LN9/a;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LN9/a<",
            "LEb/I;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, LEb/I;->$ENTRIES:LN9/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LEb/I;
    .locals 1

    .line 1
    const-class v0, LEb/I;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LEb/I;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LEb/I;
    .locals 1

    .line 1
    sget-object v0, LEb/I;->$VALUES:[LEb/I;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LEb/I;

    .line 8
    .line 9
    return-object v0
.end method
