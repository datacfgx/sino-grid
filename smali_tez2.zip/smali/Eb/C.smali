.class public final LEb/C;
.super LBb/b;
.source "StreamingJsonEncoder.kt"

# interfaces
.implements LDb/r;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LEb/C$a;
    }
.end annotation


# instance fields
.field public final a:LEb/g;

.field public final b:LDb/b;

.field public final c:LEb/I;

.field public final d:[LDb/r;

.field public final e:LFb/c;

.field public final f:LDb/f;

.field public g:Z

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;


# direct methods
.method public constructor <init>(LEb/g;LDb/b;LEb/I;[LDb/r;)V
    .locals 1

    .line 1
    const-string v0, "composer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "json"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "mode"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, LEb/C;->a:LEb/g;

    .line 20
    .line 21
    iput-object p2, p0, LEb/C;->b:LDb/b;

    .line 22
    .line 23
    iput-object p3, p0, LEb/C;->c:LEb/I;

    .line 24
    .line 25
    iput-object p4, p0, LEb/C;->d:[LDb/r;

    .line 26
    .line 27
    iget-object p1, p2, LDb/b;->b:LFb/c;

    .line 28
    .line 29
    iput-object p1, p0, LEb/C;->e:LFb/c;

    .line 30
    .line 31
    iget-object p1, p2, LDb/b;->a:LDb/f;

    .line 32
    .line 33
    iput-object p1, p0, LEb/C;->f:LDb/f;

    .line 34
    .line 35
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-eqz p4, :cond_1

    .line 40
    .line 41
    aget-object p2, p4, p1

    .line 42
    .line 43
    if-nez p2, :cond_0

    .line 44
    .line 45
    if-eq p2, p0, :cond_1

    .line 46
    .line 47
    :cond_0
    aput-object p0, p4, p1

    .line 48
    .line 49
    :cond_1
    return-void
.end method


# virtual methods
.method public final B(J)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 14
    .line 15
    invoke-virtual {v0, p1, p2}, LEb/g;->e(J)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final C(Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, LEb/g;->h(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final E(LAb/f;I)V
    .locals 7

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, LEb/C$a;->a:[I

    .line 7
    .line 8
    iget-object v1, p0, LEb/C;->c:LEb/I;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    aget v0, v0, v1

    .line 15
    .line 16
    const/16 v1, 0x2c

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    iget-object v3, p0, LEb/C;->a:LEb/g;

    .line 20
    .line 21
    if-eq v0, v2, :cond_7

    .line 22
    .line 23
    const/16 v4, 0x3a

    .line 24
    .line 25
    const/4 v5, 0x0

    .line 26
    const/4 v6, 0x2

    .line 27
    if-eq v0, v6, :cond_4

    .line 28
    .line 29
    const/4 v6, 0x3

    .line 30
    if-eq v0, v6, :cond_1

    .line 31
    .line 32
    iget-boolean v0, v3, LEb/g;->b:Z

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    invoke-virtual {v3, v1}, LEb/g;->c(C)V

    .line 37
    .line 38
    .line 39
    :cond_0
    invoke-virtual {v3}, LEb/g;->a()V

    .line 40
    .line 41
    .line 42
    const-string v0, "<this>"

    .line 43
    .line 44
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    iget-object v0, p0, LEb/C;->b:LDb/b;

    .line 48
    .line 49
    const-string v1, "json"

    .line 50
    .line 51
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-static {p1, v0}, LEb/o;->c(LAb/f;LDb/b;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {p1, p2}, LAb/f;->n(I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v3, v4}, LEb/g;->c(C)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v3}, LEb/g;->i()V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_1
    if-nez p2, :cond_2

    .line 72
    .line 73
    iput-boolean v2, p0, LEb/C;->g:Z

    .line 74
    .line 75
    :cond_2
    if-ne p2, v2, :cond_3

    .line 76
    .line 77
    invoke-virtual {v3, v1}, LEb/g;->c(C)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v3}, LEb/g;->i()V

    .line 81
    .line 82
    .line 83
    iput-boolean v5, p0, LEb/C;->g:Z

    .line 84
    .line 85
    :cond_3
    return-void

    .line 86
    :cond_4
    iget-boolean p1, v3, LEb/g;->b:Z

    .line 87
    .line 88
    if-nez p1, :cond_6

    .line 89
    .line 90
    rem-int/2addr p2, v6

    .line 91
    if-nez p2, :cond_5

    .line 92
    .line 93
    invoke-virtual {v3, v1}, LEb/g;->c(C)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v3}, LEb/g;->a()V

    .line 97
    .line 98
    .line 99
    goto :goto_0

    .line 100
    :cond_5
    invoke-virtual {v3, v4}, LEb/g;->c(C)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v3}, LEb/g;->i()V

    .line 104
    .line 105
    .line 106
    move v2, v5

    .line 107
    :goto_0
    iput-boolean v2, p0, LEb/C;->g:Z

    .line 108
    .line 109
    return-void

    .line 110
    :cond_6
    iput-boolean v2, p0, LEb/C;->g:Z

    .line 111
    .line 112
    invoke-virtual {v3}, LEb/g;->a()V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :cond_7
    iget-boolean p1, v3, LEb/g;->b:Z

    .line 117
    .line 118
    if-nez p1, :cond_8

    .line 119
    .line 120
    invoke-virtual {v3, v1}, LEb/g;->c(C)V

    .line 121
    .line 122
    .line 123
    :cond_8
    invoke-virtual {v3}, LEb/g;->a()V

    .line 124
    .line 125
    .line 126
    return-void
.end method

.method public final a(LAb/f;)LBb/d;
    .locals 5

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/C;->b:LDb/b;

    .line 7
    .line 8
    invoke-static {p1, v0}, LEb/J;->b(LAb/f;LDb/b;)LEb/I;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-char v2, v1, LEb/I;->begin:C

    .line 13
    .line 14
    iget-object v3, p0, LEb/C;->a:LEb/g;

    .line 15
    .line 16
    if-eqz v2, :cond_0

    .line 17
    .line 18
    invoke-virtual {v3, v2}, LEb/g;->c(C)V

    .line 19
    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    iput-boolean v2, v3, LEb/g;->b:Z

    .line 23
    .line 24
    :cond_0
    iget-object v2, p0, LEb/C;->h:Ljava/lang/String;

    .line 25
    .line 26
    if-eqz v2, :cond_2

    .line 27
    .line 28
    iget-object v4, p0, LEb/C;->i:Ljava/lang/String;

    .line 29
    .line 30
    if-nez v4, :cond_1

    .line 31
    .line 32
    invoke-interface {p1}, LAb/f;->j()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    :cond_1
    invoke-virtual {v3}, LEb/g;->a()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0, v2}, LEb/C;->C(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const/16 p1, 0x3a

    .line 43
    .line 44
    invoke-virtual {v3, p1}, LEb/g;->c(C)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    invoke-virtual {p0, v4}, LEb/C;->C(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const/4 p1, 0x0

    .line 54
    iput-object p1, p0, LEb/C;->h:Ljava/lang/String;

    .line 55
    .line 56
    iput-object p1, p0, LEb/C;->i:Ljava/lang/String;

    .line 57
    .line 58
    :cond_2
    iget-object p1, p0, LEb/C;->c:LEb/I;

    .line 59
    .line 60
    if-ne p1, v1, :cond_3

    .line 61
    .line 62
    return-object p0

    .line 63
    :cond_3
    iget-object p1, p0, LEb/C;->d:[LDb/r;

    .line 64
    .line 65
    if-eqz p1, :cond_4

    .line 66
    .line 67
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    aget-object v2, p1, v2

    .line 72
    .line 73
    if-eqz v2, :cond_4

    .line 74
    .line 75
    return-object v2

    .line 76
    :cond_4
    new-instance v2, LEb/C;

    .line 77
    .line 78
    invoke-direct {v2, v3, v0, v1, p1}, LEb/C;-><init>(LEb/g;LDb/b;LEb/I;[LDb/r;)V

    .line 79
    .line 80
    .line 81
    return-object v2
.end method

.method public final b()LFb/c;
    .locals 1

    .line 1
    iget-object v0, p0, LEb/C;->e:LFb/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c(LAb/f;)V
    .locals 2

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LEb/C;->c:LEb/I;

    .line 7
    .line 8
    iget-char v0, p1, LEb/I;->end:C

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    iput-boolean v1, v0, LEb/g;->b:Z

    .line 19
    .line 20
    iget-char p1, p1, LEb/I;->end:C

    .line 21
    .line 22
    invoke-virtual {v0, p1}, LEb/g;->c(C)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method

.method public final f()V
    .locals 2

    .line 1
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 2
    .line 3
    const-string v1, "null"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LEb/g;->f(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final g(LAb/f;I)V
    .locals 1

    .line 1
    const-string v0, "enumDescriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1, p2}, LAb/f;->n(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final j(D)V
    .locals 3

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    iget-object v1, p0, LEb/C;->a:LEb/g;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p0, v0}, LEb/C;->C(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    iget-object v0, v1, LEb/g;->a:LEb/s;

    .line 16
    .line 17
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v0, v2}, LEb/s;->c(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    invoke-static {p1, p2}, Ljava/lang/Double;->isInfinite(D)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    invoke-static {p1, p2}, Ljava/lang/Double;->isNaN(D)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    iget-object p2, v1, LEb/g;->a:LEb/s;

    .line 42
    .line 43
    invoke-virtual {p2}, LEb/s;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    invoke-static {p1, p2}, LEb/m;->b(Ljava/lang/Number;Ljava/lang/String;)Lkotlinx/serialization/json/internal/JsonEncodingException;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    throw p1
.end method

.method public final k(S)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, LEb/g;->g(S)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final l(B)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, LEb/g;->b(B)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final m(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 14
    .line 15
    iget-object v0, v0, LEb/g;->a:LEb/s;

    .line 16
    .line 17
    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {v0, p1}, LEb/s;->c(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final r(F)V
    .locals 3

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    iget-object v1, p0, LEb/C;->a:LEb/g;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p0, v0}, LEb/C;->C(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    iget-object v0, v1, LEb/g;->a:LEb/s;

    .line 16
    .line 17
    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v0, v2}, LEb/s;->c(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    invoke-static {p1}, Ljava/lang/Float;->isInfinite(F)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_1

    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    iget-object v0, v1, LEb/g;->a:LEb/s;

    .line 42
    .line 43
    invoke-virtual {v0}, LEb/s;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-static {p1, v0}, LEb/m;->b(Ljava/lang/Number;Ljava/lang/String;)Lkotlinx/serialization/json/internal/JsonEncodingException;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    throw p1
.end method

.method public final s(Lyb/g;Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation

    .line 1
    const-string v0, "serializer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LEb/C;->b:LDb/b;

    .line 7
    .line 8
    iget-object v1, v0, LDb/b;->a:LDb/f;

    .line 9
    .line 10
    instance-of v2, p1, LCb/b;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    iget-object v1, v1, LDb/f;->f:LDb/a;

    .line 16
    .line 17
    sget-object v4, LDb/a;->NONE:LDb/a;

    .line 18
    .line 19
    if-eq v1, v4, :cond_3

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    iget-object v1, v1, LDb/f;->f:LDb/a;

    .line 23
    .line 24
    sget-object v4, LEb/z$a;->a:[I

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    aget v1, v4, v1

    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    if-eq v1, v4, :cond_3

    .line 34
    .line 35
    const/4 v4, 0x2

    .line 36
    if-eq v1, v4, :cond_3

    .line 37
    .line 38
    const/4 v4, 0x3

    .line 39
    if-ne v1, v4, :cond_2

    .line 40
    .line 41
    invoke-interface {p1}, Lyb/g;->b()LAb/f;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-interface {v1}, LAb/f;->f()LAb/n;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    sget-object v4, LAb/o$a;->a:LAb/o$a;

    .line 50
    .line 51
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v4

    .line 55
    if-nez v4, :cond_1

    .line 56
    .line 57
    sget-object v4, LAb/o$d;->a:LAb/o$d;

    .line 58
    .line 59
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_3

    .line 64
    .line 65
    :cond_1
    :goto_0
    invoke-interface {p1}, Lyb/g;->b()LAb/f;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-static {v1, v0}, LEb/z;->a(LAb/f;LDb/b;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    new-instance p1, Lkotlin/NoWhenBranchMatchedException;

    .line 75
    .line 76
    invoke-direct {p1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 77
    .line 78
    .line 79
    throw p1

    .line 80
    :cond_3
    move-object v0, v3

    .line 81
    :goto_1
    if-eqz v2, :cond_b

    .line 82
    .line 83
    move-object v1, p1

    .line 84
    check-cast v1, LCb/b;

    .line 85
    .line 86
    if-eqz p2, :cond_a

    .line 87
    .line 88
    invoke-static {v1, p0, p2}, Lyb/e;->b(LCb/b;LBb/b;Ljava/lang/Object;)Lyb/g;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    if-eqz v0, :cond_6

    .line 93
    .line 94
    instance-of v2, p1, Lyb/f;

    .line 95
    .line 96
    if-nez v2, :cond_4

    .line 97
    .line 98
    goto :goto_2

    .line 99
    :cond_4
    invoke-interface {v1}, Lyb/g;->b()LAb/f;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    const-string v4, "<this>"

    .line 104
    .line 105
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    invoke-static {v2}, LCb/a0;->a(LAb/f;)Ljava/util/Set;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-interface {v2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    if-nez v2, :cond_5

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_5
    check-cast p1, Lyb/f;

    .line 120
    .line 121
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 122
    .line 123
    .line 124
    throw v3

    .line 125
    :cond_6
    :goto_2
    invoke-interface {v1}, Lyb/g;->b()LAb/f;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    invoke-interface {p1}, LAb/f;->f()LAb/n;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    const-string v2, "kind"

    .line 134
    .line 135
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    instance-of v2, p1, LAb/n$b;

    .line 139
    .line 140
    if-nez v2, :cond_9

    .line 141
    .line 142
    instance-of v2, p1, LAb/e;

    .line 143
    .line 144
    if-nez v2, :cond_8

    .line 145
    .line 146
    instance-of p1, p1, LAb/d;

    .line 147
    .line 148
    if-nez p1, :cond_7

    .line 149
    .line 150
    const-string p1, "null cannot be cast to non-null type kotlinx.serialization.SerializationStrategy<T of kotlinx.serialization.json.internal.PolymorphicKt.encodePolymorphically>"

    .line 151
    .line 152
    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    move-object p1, v1

    .line 156
    goto :goto_3

    .line 157
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 158
    .line 159
    const-string p2, "Actual serializer for polymorphic cannot be polymorphic itself"

    .line 160
    .line 161
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw p1

    .line 165
    :cond_8
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 166
    .line 167
    const-string p2, "Primitives cannot be serialized polymorphically with \'type\' parameter. You can use \'JsonBuilder.useArrayPolymorphism\' instead"

    .line 168
    .line 169
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    throw p1

    .line 173
    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 174
    .line 175
    const-string p2, "Enums cannot be serialized polymorphically with \'type\' parameter. You can use \'JsonBuilder.useArrayPolymorphism\' instead"

    .line 176
    .line 177
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    throw p1

    .line 181
    :cond_a
    new-instance p1, Ljava/lang/StringBuilder;

    .line 182
    .line 183
    const-string p2, "Value for serializer "

    .line 184
    .line 185
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    invoke-interface {v1}, Lyb/g;->b()LAb/f;

    .line 189
    .line 190
    .line 191
    move-result-object p2

    .line 192
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    const-string p2, " should always be non-null. Please report issue to the kotlinx.serialization tracker."

    .line 196
    .line 197
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 198
    .line 199
    .line 200
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 205
    .line 206
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    throw p2

    .line 214
    :cond_b
    :goto_3
    if-eqz v0, :cond_c

    .line 215
    .line 216
    invoke-interface {p1}, Lyb/g;->b()LAb/f;

    .line 217
    .line 218
    .line 219
    move-result-object v1

    .line 220
    invoke-interface {v1}, LAb/f;->j()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    iput-object v0, p0, LEb/C;->h:Ljava/lang/String;

    .line 225
    .line 226
    iput-object v1, p0, LEb/C;->i:Ljava/lang/String;

    .line 227
    .line 228
    :cond_c
    invoke-interface {p1, p0, p2}, Lyb/g;->e(LBb/b;Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    return-void
.end method

.method public final t(C)V
    .locals 0

    .line 1
    invoke-static {p1}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final u(LAb/f;ILyb/g;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "LAb/f;",
            "I",
            "Lyb/g<",
            "-TT;>;TT;)V"
        }
    .end annotation

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "serializer"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    if-nez p4, :cond_1

    .line 12
    .line 13
    iget-object v0, p0, LEb/C;->f:LDb/f;

    .line 14
    .line 15
    iget-boolean v0, v0, LDb/f;->b:Z

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    return-void

    .line 21
    :cond_1
    :goto_0
    invoke-super {p0, p1, p2, p3, p4}, LBb/b;->u(LAb/f;ILyb/g;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final v(LAb/f;)Z
    .locals 1

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return p1
.end method

.method public final w(LAb/f;)LBb/f;
    .locals 6

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, LEb/D;->a(LAb/f;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    iget-object v3, p0, LEb/C;->c:LEb/I;

    .line 12
    .line 13
    iget-object v4, p0, LEb/C;->b:LDb/b;

    .line 14
    .line 15
    iget-object v5, p0, LEb/C;->a:LEb/g;

    .line 16
    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    instance-of p1, v5, LEb/i;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    iget-object p1, v5, LEb/g;->a:LEb/s;

    .line 25
    .line 26
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 27
    .line 28
    new-instance v5, LEb/i;

    .line 29
    .line 30
    invoke-direct {v5, p1, v0}, LEb/i;-><init>(LEb/s;Z)V

    .line 31
    .line 32
    .line 33
    :goto_0
    new-instance p1, LEb/C;

    .line 34
    .line 35
    invoke-direct {p1, v5, v4, v3, v2}, LEb/C;-><init>(LEb/g;LDb/b;LEb/I;[LDb/r;)V

    .line 36
    .line 37
    .line 38
    return-object p1

    .line 39
    :cond_1
    const-string v1, "<this>"

    .line 40
    .line 41
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1}, LAb/f;->i()Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_3

    .line 49
    .line 50
    sget-object v1, LDb/h;->a:LCb/E;

    .line 51
    .line 52
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_3

    .line 57
    .line 58
    instance-of p1, v5, LEb/h;

    .line 59
    .line 60
    if-eqz p1, :cond_2

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_2
    iget-object p1, v5, LEb/g;->a:LEb/s;

    .line 64
    .line 65
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 66
    .line 67
    new-instance v5, LEb/h;

    .line 68
    .line 69
    invoke-direct {v5, p1, v0}, LEb/h;-><init>(LEb/s;Z)V

    .line 70
    .line 71
    .line 72
    :goto_1
    new-instance p1, LEb/C;

    .line 73
    .line 74
    invoke-direct {p1, v5, v4, v3, v2}, LEb/C;-><init>(LEb/g;LDb/b;LEb/I;[LDb/r;)V

    .line 75
    .line 76
    .line 77
    return-object p1

    .line 78
    :cond_3
    iget-object v1, p0, LEb/C;->h:Ljava/lang/String;

    .line 79
    .line 80
    if-eqz v1, :cond_4

    .line 81
    .line 82
    invoke-interface {p1}, LAb/f;->j()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    iput-object p1, p0, LEb/C;->i:Ljava/lang/String;

    .line 87
    .line 88
    return-object p0

    .line 89
    :cond_4
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    return-object p0
.end method

.method public final x(I)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LEb/C;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LEb/C;->C(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-object v0, p0, LEb/C;->a:LEb/g;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, LEb/g;->d(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
