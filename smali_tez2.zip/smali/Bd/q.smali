.class public final synthetic LBd/q;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements LC1/c$a;
.implements Lq7/e;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/q;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/q;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LBd/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LBd/q;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LUc/m;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LUc/m;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LBd/q;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LLc/T0;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LLc/T0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :pswitch_1
    iget-object v0, p0, LBd/q;->b:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LBd/p;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, LBd/p;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public b(Lq7/t;)Ljava/lang/Object;
    .locals 6

    .line 1
    new-instance v0, LQ7/e;

    .line 2
    .line 3
    const-class v1, Landroid/content/Context;

    .line 4
    .line 5
    invoke-virtual {p1, v1}, Lq7/t;->a(Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Landroid/content/Context;

    .line 10
    .line 11
    const-class v2, Le7/f;

    .line 12
    .line 13
    invoke-virtual {p1, v2}, Lq7/t;->a(Ljava/lang/Class;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Le7/f;

    .line 18
    .line 19
    invoke-virtual {v2}, Le7/f;->d()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const-class v3, LQ7/f;

    .line 24
    .line 25
    invoke-static {v3}, Lq7/s;->a(Ljava/lang/Class;)Lq7/s;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-virtual {p1, v3}, Lq7/t;->f(Lq7/s;)Ljava/util/Set;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    const-class v4, Lb8/g;

    .line 34
    .line 35
    invoke-virtual {p1, v4}, Lq7/t;->c(Ljava/lang/Class;)LS7/b;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    iget-object v5, p0, LBd/q;->b:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v5, Lq7/s;

    .line 42
    .line 43
    invoke-virtual {p1, v5}, Lq7/t;->g(Lq7/s;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    move-object v5, p1

    .line 48
    check-cast v5, Ljava/util/concurrent/Executor;

    .line 49
    .line 50
    invoke-direct/range {v0 .. v5}, LQ7/e;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;LS7/b;Ljava/util/concurrent/Executor;)V

    .line 51
    .line 52
    .line 53
    return-object v0
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    if-eqz p2, :cond_1

    .line 2
    .line 3
    iget-object p2, p0, LBd/q;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p2, LOc/r1;

    .line 6
    .line 7
    invoke-virtual {p2}, LOc/r1;->K()LOc/a2;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {v0}, LOc/a2;->x()Lorg/tezza/domain/gallery/LutsAdjustments;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget-object v0, v0, Lorg/tezza/domain/gallery/LutsAdjustments;->f:Lorg/tezza/domain/gallery/UltragloLutAdjustments;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    int-to-float p1, p1

    .line 24
    const/high16 v1, 0x42c80000    # 100.0f

    .line 25
    .line 26
    div-float/2addr p1, v1

    .line 27
    invoke-virtual {v0, p1}, Lorg/tezza/domain/gallery/UltragloLutAdjustments;->a(F)V

    .line 28
    .line 29
    .line 30
    :cond_0
    invoke-virtual {p2}, LOc/r1;->k0()V

    .line 31
    .line 32
    .line 33
    :cond_1
    return-void
.end method
