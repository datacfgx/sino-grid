.class public final synthetic LBd/j;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroidx/lifecycle/A;


# instance fields
.field public final synthetic a:LBd/k;


# direct methods
.method public synthetic constructor <init>(LBd/k;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBd/j;->a:LBd/k;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Landroidx/lifecycle/s;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    iget-object v0, p0, LBd/j;->a:LBd/k;

    .line 7
    .line 8
    iput-object p1, v0, LBd/k;->c:Lx2/a;

    .line 9
    .line 10
    :cond_0
    return-void
.end method
