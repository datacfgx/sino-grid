.class public final synthetic LBd/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lorg/tezza/domain/gallery/GalleryItemAdjustments;

.field public final synthetic b:Z

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(ILorg/tezza/domain/gallery/GalleryItemAdjustments;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LBd/d;->a:Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 5
    .line 6
    iput-boolean p3, p0, LBd/d;->b:Z

    .line 7
    .line 8
    iput p1, p0, LBd/d;->c:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Ljava/lang/Boolean;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 8
    .line 9
    .line 10
    move-result v4

    .line 11
    sget-object v1, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 12
    .line 13
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const-string v2, "Tezza"

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const-string v2, "ratingCountKey"

    .line 25
    .line 26
    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    const/4 v2, 0x1

    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    move v1, v3

    .line 34
    move v3, v2

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    move v1, v3

    .line 37
    :goto_0
    iget-object v5, v0, LBd/d;->a:Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 38
    .line 39
    iget-object v6, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->a:Lorg/tezza/domain/gallery/LutsAdjustments;

    .line 40
    .line 41
    iget-object v6, v6, Lorg/tezza/domain/gallery/LutsAdjustments;->c:Lvc/K;

    .line 42
    .line 43
    sget-object v7, Lvc/K;->EMPTY:Lvc/K;

    .line 44
    .line 45
    if-eq v6, v7, :cond_1

    .line 46
    .line 47
    move v7, v2

    .line 48
    goto :goto_1

    .line 49
    :cond_1
    move v7, v1

    .line 50
    :goto_1
    const-string v8, ""

    .line 51
    .line 52
    if-eqz v7, :cond_2

    .line 53
    .line 54
    invoke-virtual {v6}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    goto :goto_2

    .line 59
    :cond_2
    move-object v6, v8

    .line 60
    :goto_2
    iget-object v9, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->b:Ljava/util/List;

    .line 61
    .line 62
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 63
    .line 64
    .line 65
    move-result v9

    .line 66
    if-le v9, v2, :cond_3

    .line 67
    .line 68
    move v9, v2

    .line 69
    goto :goto_3

    .line 70
    :cond_3
    move v9, v1

    .line 71
    :goto_3
    iget-object v10, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 72
    .line 73
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 74
    .line 75
    .line 76
    move-result v10

    .line 77
    if-lez v10, :cond_4

    .line 78
    .line 79
    iget-object v10, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 80
    .line 81
    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v10

    .line 85
    check-cast v10, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 86
    .line 87
    iget-object v10, v10, Lorg/tezza/domain/gallery/LayersAdjustments;->c:Lvc/F;

    .line 88
    .line 89
    sget-object v11, Lvc/F;->EMPTY:Lvc/F;

    .line 90
    .line 91
    if-eq v10, v11, :cond_4

    .line 92
    .line 93
    move v12, v2

    .line 94
    goto :goto_4

    .line 95
    :cond_4
    move v12, v1

    .line 96
    :goto_4
    if-eqz v12, :cond_d

    .line 97
    .line 98
    iget-object v10, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 99
    .line 100
    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v10

    .line 104
    check-cast v10, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 105
    .line 106
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    instance-of v11, v10, Lorg/tezza/domain/gallery/DustsAdjustments;

    .line 110
    .line 111
    if-eqz v11, :cond_5

    .line 112
    .line 113
    check-cast v10, Lorg/tezza/domain/gallery/DustsAdjustments;

    .line 114
    .line 115
    iget-object v10, v10, Lorg/tezza/domain/gallery/DustsAdjustments;->m:Lvc/k;

    .line 116
    .line 117
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v10

    .line 121
    goto :goto_5

    .line 122
    :cond_5
    instance-of v11, v10, Lorg/tezza/domain/gallery/PaperAdjustments;

    .line 123
    .line 124
    if-eqz v11, :cond_6

    .line 125
    .line 126
    check-cast v10, Lorg/tezza/domain/gallery/PaperAdjustments;

    .line 127
    .line 128
    iget-object v10, v10, Lorg/tezza/domain/gallery/PaperAdjustments;->m:Lvc/N;

    .line 129
    .line 130
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v10

    .line 134
    goto :goto_5

    .line 135
    :cond_6
    instance-of v11, v10, Lorg/tezza/domain/gallery/LightAdjustments;

    .line 136
    .line 137
    if-eqz v11, :cond_7

    .line 138
    .line 139
    check-cast v10, Lorg/tezza/domain/gallery/LightAdjustments;

    .line 140
    .line 141
    iget-object v10, v10, Lorg/tezza/domain/gallery/LightAdjustments;->m:Lvc/J;

    .line 142
    .line 143
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v10

    .line 147
    goto :goto_5

    .line 148
    :cond_7
    instance-of v11, v10, Lorg/tezza/domain/gallery/GlassAdjustments;

    .line 149
    .line 150
    if-eqz v11, :cond_8

    .line 151
    .line 152
    check-cast v10, Lorg/tezza/domain/gallery/GlassAdjustments;

    .line 153
    .line 154
    iget-object v10, v10, Lorg/tezza/domain/gallery/GlassAdjustments;->m:Lvc/A;

    .line 155
    .line 156
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v10

    .line 160
    goto :goto_5

    .line 161
    :cond_8
    instance-of v11, v10, Lorg/tezza/domain/gallery/PlasticAdjustments;

    .line 162
    .line 163
    if-eqz v11, :cond_9

    .line 164
    .line 165
    check-cast v10, Lorg/tezza/domain/gallery/PlasticAdjustments;

    .line 166
    .line 167
    iget-object v10, v10, Lorg/tezza/domain/gallery/PlasticAdjustments;->m:Lvc/Q;

    .line 168
    .line 169
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v10

    .line 173
    goto :goto_5

    .line 174
    :cond_9
    instance-of v11, v10, Lorg/tezza/domain/gallery/PosterAdjustments;

    .line 175
    .line 176
    if-eqz v11, :cond_a

    .line 177
    .line 178
    check-cast v10, Lorg/tezza/domain/gallery/PosterAdjustments;

    .line 179
    .line 180
    iget-object v10, v10, Lorg/tezza/domain/gallery/PosterAdjustments;->m:Lvc/U;

    .line 181
    .line 182
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v10

    .line 186
    goto :goto_5

    .line 187
    :cond_a
    instance-of v11, v10, Lorg/tezza/domain/gallery/ShadowAdjustments;

    .line 188
    .line 189
    if-eqz v11, :cond_b

    .line 190
    .line 191
    check-cast v10, Lorg/tezza/domain/gallery/ShadowAdjustments;

    .line 192
    .line 193
    iget-object v10, v10, Lorg/tezza/domain/gallery/ShadowAdjustments;->m:Lvc/b0;

    .line 194
    .line 195
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v10

    .line 199
    goto :goto_5

    .line 200
    :cond_b
    instance-of v11, v10, Lorg/tezza/domain/gallery/PrideAdjustments;

    .line 201
    .line 202
    if-eqz v11, :cond_c

    .line 203
    .line 204
    check-cast v10, Lorg/tezza/domain/gallery/PrideAdjustments;

    .line 205
    .line 206
    iget-object v10, v10, Lorg/tezza/domain/gallery/PrideAdjustments;->m:Lvc/X;

    .line 207
    .line 208
    invoke-virtual {v10}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v10

    .line 212
    goto :goto_5

    .line 213
    :cond_c
    move-object v10, v8

    .line 214
    :goto_5
    move-object v13, v10

    .line 215
    goto :goto_6

    .line 216
    :cond_d
    move-object v13, v8

    .line 217
    :goto_6
    iget-object v10, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 218
    .line 219
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 220
    .line 221
    .line 222
    move-result v10

    .line 223
    if-lez v10, :cond_10

    .line 224
    .line 225
    iget-object v10, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 226
    .line 227
    check-cast v10, Ljava/lang/Iterable;

    .line 228
    .line 229
    instance-of v11, v10, Ljava/util/Collection;

    .line 230
    .line 231
    if-eqz v11, :cond_e

    .line 232
    .line 233
    move-object v11, v10

    .line 234
    check-cast v11, Ljava/util/Collection;

    .line 235
    .line 236
    invoke-interface {v11}, Ljava/util/Collection;->isEmpty()Z

    .line 237
    .line 238
    .line 239
    move-result v11

    .line 240
    if-eqz v11, :cond_e

    .line 241
    .line 242
    goto :goto_7

    .line 243
    :cond_e
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 244
    .line 245
    .line 246
    move-result-object v10

    .line 247
    :cond_f
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 248
    .line 249
    .line 250
    move-result v11

    .line 251
    if-eqz v11, :cond_10

    .line 252
    .line 253
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v11

    .line 257
    check-cast v11, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 258
    .line 259
    invoke-virtual {v11}, Lorg/tezza/domain/gallery/EffectsAdjustments;->m()Z

    .line 260
    .line 261
    .line 262
    move-result v11

    .line 263
    if-nez v11, :cond_f

    .line 264
    .line 265
    move v14, v2

    .line 266
    goto :goto_8

    .line 267
    :cond_10
    :goto_7
    move v14, v1

    .line 268
    :goto_8
    if-eqz v14, :cond_14

    .line 269
    .line 270
    iget-object v11, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 271
    .line 272
    check-cast v11, Ljava/lang/Iterable;

    .line 273
    .line 274
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 275
    .line 276
    .line 277
    move-result-object v11

    .line 278
    :cond_11
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 279
    .line 280
    .line 281
    move-result v15

    .line 282
    if-eqz v15, :cond_12

    .line 283
    .line 284
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object v15

    .line 288
    move-object/from16 v16, v15

    .line 289
    .line 290
    check-cast v16, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 291
    .line 292
    invoke-virtual/range {v16 .. v16}, Lorg/tezza/domain/gallery/EffectsAdjustments;->m()Z

    .line 293
    .line 294
    .line 295
    move-result v16

    .line 296
    if-nez v16, :cond_11

    .line 297
    .line 298
    goto :goto_9

    .line 299
    :cond_12
    const/4 v15, 0x0

    .line 300
    :goto_9
    check-cast v15, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 301
    .line 302
    if-eqz v15, :cond_14

    .line 303
    .line 304
    iget-object v11, v15, Lorg/tezza/domain/gallery/EffectsAdjustments;->c:Lvc/m;

    .line 305
    .line 306
    if-eqz v11, :cond_14

    .line 307
    .line 308
    invoke-virtual {v11}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object v11

    .line 312
    if-nez v11, :cond_13

    .line 313
    .line 314
    goto :goto_a

    .line 315
    :cond_13
    move-object v15, v11

    .line 316
    goto :goto_b

    .line 317
    :cond_14
    :goto_a
    move-object v15, v8

    .line 318
    :goto_b
    iget-object v11, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 319
    .line 320
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 321
    .line 322
    .line 323
    move-result v11

    .line 324
    if-lez v11, :cond_17

    .line 325
    .line 326
    iget-object v11, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 327
    .line 328
    check-cast v11, Ljava/lang/Iterable;

    .line 329
    .line 330
    new-instance v1, Ljava/util/ArrayList;

    .line 331
    .line 332
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 333
    .line 334
    .line 335
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 336
    .line 337
    .line 338
    move-result-object v11

    .line 339
    :goto_c
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 340
    .line 341
    .line 342
    move-result v16

    .line 343
    if-eqz v16, :cond_16

    .line 344
    .line 345
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    move-result-object v2

    .line 349
    instance-of v10, v2, Lorg/tezza/domain/gallery/UniversalAdjustments;

    .line 350
    .line 351
    if-eqz v10, :cond_15

    .line 352
    .line 353
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    :cond_15
    const/4 v2, 0x1

    .line 357
    goto :goto_c

    .line 358
    :cond_16
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 359
    .line 360
    .line 361
    move-result v1

    .line 362
    if-nez v1, :cond_17

    .line 363
    .line 364
    const/4 v10, 0x1

    .line 365
    goto :goto_d

    .line 366
    :cond_17
    const/4 v10, 0x0

    .line 367
    :goto_d
    if-eqz v10, :cond_1b

    .line 368
    .line 369
    iget-object v1, v5, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 370
    .line 371
    check-cast v1, Ljava/lang/Iterable;

    .line 372
    .line 373
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 374
    .line 375
    .line 376
    move-result-object v1

    .line 377
    :cond_18
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 378
    .line 379
    .line 380
    move-result v2

    .line 381
    if-eqz v2, :cond_19

    .line 382
    .line 383
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 384
    .line 385
    .line 386
    move-result-object v2

    .line 387
    move-object v5, v2

    .line 388
    check-cast v5, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 389
    .line 390
    invoke-virtual {v5}, Lorg/tezza/domain/gallery/EffectsAdjustments;->m()Z

    .line 391
    .line 392
    .line 393
    move-result v5

    .line 394
    if-eqz v5, :cond_18

    .line 395
    .line 396
    move-object/from16 v17, v2

    .line 397
    .line 398
    goto :goto_e

    .line 399
    :cond_19
    const/16 v17, 0x0

    .line 400
    .line 401
    :goto_e
    move-object/from16 v1, v17

    .line 402
    .line 403
    check-cast v1, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 404
    .line 405
    if-eqz v1, :cond_1b

    .line 406
    .line 407
    iget-object v1, v1, Lorg/tezza/domain/gallery/EffectsAdjustments;->c:Lvc/m;

    .line 408
    .line 409
    if-eqz v1, :cond_1b

    .line 410
    .line 411
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    if-nez v1, :cond_1a

    .line 416
    .line 417
    goto :goto_f

    .line 418
    :cond_1a
    move-object v11, v1

    .line 419
    goto :goto_10

    .line 420
    :cond_1b
    :goto_f
    move-object v11, v8

    .line 421
    :goto_10
    new-instance v2, LBd/f;

    .line 422
    .line 423
    iget-boolean v5, v0, LBd/d;->b:Z

    .line 424
    .line 425
    move-object v8, v6

    .line 426
    iget v6, v0, LBd/d;->c:I

    .line 427
    .line 428
    invoke-direct/range {v2 .. v15}, LBd/f;-><init>(ZZZIZLjava/lang/String;ZZLjava/lang/String;ZLjava/lang/String;ZLjava/lang/String;)V

    .line 429
    .line 430
    .line 431
    new-instance v1, Ljava/util/HashMap;

    .line 432
    .line 433
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v2, v1}, LBd/f;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    new-instance v2, Ljava/lang/StringBuilder;

    .line 440
    .line 441
    const-string v3, "sendEvent() called with: eventName = Edit Started, properties = "

    .line 442
    .line 443
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 447
    .line 448
    .line 449
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 450
    .line 451
    .line 452
    move-result-object v2

    .line 453
    const-string v3, "CleverTap"

    .line 454
    .line 455
    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 456
    .line 457
    .line 458
    sget-object v2, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 459
    .line 460
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 461
    .line 462
    .line 463
    move-result-object v2

    .line 464
    invoke-static {v2}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 465
    .line 466
    .line 467
    move-result-object v2

    .line 468
    if-eqz v2, :cond_1c

    .line 469
    .line 470
    const-string v3, "Edit Started"

    .line 471
    .line 472
    invoke-virtual {v2, v3, v1}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 473
    .line 474
    .line 475
    :cond_1c
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 476
    .line 477
    return-object v1
.end method
