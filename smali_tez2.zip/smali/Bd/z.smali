.class public final synthetic LBd/z;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements LC1/c$a;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, LBd/z;->a:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/z;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LBd/y;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LBd/y;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    iget-object v0, p0, LBd/z;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LOc/r1;

    .line 4
    .line 5
    invoke-virtual {v0}, LOc/r1;->K()LOc/a2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-virtual {v1}, LOc/a2;->d()LOc/f2;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    invoke-virtual {v1}, LOc/a2;->E()Lorg/tezza/domain/gallery/SplitToneAdjustments;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v1, 0x0

    .line 27
    :goto_0
    if-eqz v1, :cond_1

    .line 28
    .line 29
    int-to-float p1, p1

    .line 30
    const/high16 p2, 0x42c80000    # 100.0f

    .line 31
    .line 32
    div-float/2addr p1, p2

    .line 33
    iput p1, v1, Lorg/tezza/domain/gallery/SplitToneAdjustments;->h:F

    .line 34
    .line 35
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 36
    .line 37
    invoke-virtual {v0}, LOc/r1;->k0()V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
.end method
