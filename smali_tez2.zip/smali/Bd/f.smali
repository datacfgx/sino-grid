.class public final synthetic LBd/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic D:Ljava/lang/String;

.field public final synthetic E:Z

.field public final synthetic F:Ljava/lang/String;

.field public final synthetic G:Z

.field public final synthetic H:Ljava/lang/String;

.field public final synthetic a:Z

.field public final synthetic b:Z

.field public final synthetic c:Z

.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic i:Ljava/lang/String;

.field public final synthetic v:Z

.field public final synthetic w:Z


# direct methods
.method public synthetic constructor <init>(ZZZIZLjava/lang/String;ZZLjava/lang/String;ZLjava/lang/String;ZLjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, LBd/f;->a:Z

    .line 5
    .line 6
    iput-boolean p2, p0, LBd/f;->b:Z

    .line 7
    .line 8
    iput-boolean p3, p0, LBd/f;->c:Z

    .line 9
    .line 10
    iput p4, p0, LBd/f;->d:I

    .line 11
    .line 12
    iput-boolean p5, p0, LBd/f;->e:Z

    .line 13
    .line 14
    iput-object p6, p0, LBd/f;->i:Ljava/lang/String;

    .line 15
    .line 16
    iput-boolean p7, p0, LBd/f;->v:Z

    .line 17
    .line 18
    iput-boolean p8, p0, LBd/f;->w:Z

    .line 19
    .line 20
    iput-object p9, p0, LBd/f;->D:Ljava/lang/String;

    .line 21
    .line 22
    iput-boolean p10, p0, LBd/f;->E:Z

    .line 23
    .line 24
    iput-object p11, p0, LBd/f;->F:Ljava/lang/String;

    .line 25
    .line 26
    iput-boolean p12, p0, LBd/f;->G:Z

    .line 27
    .line 28
    iput-object p13, p0, LBd/f;->H:Ljava/lang/String;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    .line 2
    check-cast p1, Ljava/util/HashMap;

    .line 3
    .line 4
    const-string v0, "it"

    .line 5
    .line 6
    .line 7
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    iget-boolean v0, p0, LBd/f;->a:Z

    .line 10
    .line 11
    .line 12
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 13
    move-result-object v0

    .line 14
    .line 15
    const-string v1, "First Edit?"

    .line 16
    .line 17
    .line 18
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 21
    .line 22
    const-string v1, "Edit Completed?"

    .line 23
    .line 24
    .line 25
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    iget-boolean v0, p0, LBd/f;->b:Z

    .line 28
    .line 29
    .line 30
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 31
    move-result-object v0

    .line 32
    .line 33
    const-string v1, "User subscribed?"

    .line 34
    .line 35
    .line 36
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 39
    .line 40
    const-string v1, "Free trial?"

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    iget-boolean v0, p0, LBd/f;->c:Z

    .line 46
    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    const-string v0, "Photo"

    .line 50
    goto :goto_0

    .line 51
    .line 52
    :cond_0
    const-string v0, "Video"

    .line 53
    .line 54
    :goto_0
    const-string v1, "Media Type"

    .line 55
    .line 56
    .line 57
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    iget v0, p0, LBd/f;->d:I

    .line 60
    .line 61
    .line 62
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 63
    move-result-object v0

    .line 64
    .line 65
    const-string v1, "Edit duration (seconds)"

    .line 66
    .line 67
    .line 68
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    iget-boolean v0, p0, LBd/f;->e:Z

    .line 71
    .line 72
    .line 73
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 74
    move-result-object v0

    .line 75
    .line 76
    const-string v1, "Preset flag"

    .line 77
    .line 78
    .line 79
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    const/4 v0, 0x0

    sget-object v0, LT6/JNR/KyVqlUCyxczhWd;->YLWicCVokiIEA:Ljava/lang/String;

    .line 82
    .line 83
    iget-object v1, p0, LBd/f;->i:Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    iget-boolean v0, p0, LBd/f;->v:Z

    .line 89
    .line 90
    .line 91
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 92
    move-result-object v0

    .line 93
    .line 94
    const-string v1, "Tweak flag"

    .line 95
    .line 96
    .line 97
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    iget-boolean v0, p0, LBd/f;->w:Z

    .line 100
    .line 101
    .line 102
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 103
    move-result-object v0

    .line 104
    .line 105
    const-string v1, "Film effects flag"

    .line 106
    .line 107
    .line 108
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    iget-object v0, p0, LBd/f;->D:Ljava/lang/String;

    .line 111
    .line 112
    const-string v1, "Film effects name"

    .line 113
    .line 114
    .line 115
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    iget-boolean v0, p0, LBd/f;->E:Z

    .line 118
    .line 119
    .line 120
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 121
    move-result-object v0

    .line 122
    .line 123
    const-string v1, "Overlay flag"

    .line 124
    .line 125
    .line 126
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    const-string v0, "Overlay name"

    .line 129
    .line 130
    iget-object v1, p0, LBd/f;->F:Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    .line 135
    iget-boolean v0, p0, LBd/f;->G:Z

    .line 136
    .line 137
    .line 138
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 139
    move-result-object v0

    .line 140
    .line 141
    const-string v1, "FX flag"

    .line 142
    .line 143
    .line 144
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    .line 146
    iget-object v0, p0, LBd/f;->H:Ljava/lang/String;

    .line 147
    .line 148
    const-string v1, "Fx name"

    .line 149
    .line 150
    .line 151
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 154
    return-object p1
.end method
