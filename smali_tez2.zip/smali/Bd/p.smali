.class public final synthetic LBd/p;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lkotlin/jvm/functions/Function0;

.field public final synthetic b:LBd/v$a;

.field public final synthetic c:Landroidx/fragment/app/Fragment;

.field public final synthetic d:Lkotlin/jvm/functions/Function0;

.field public final synthetic e:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;LBd/v$a;Landroidx/fragment/app/Fragment;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBd/p;->a:Lkotlin/jvm/functions/Function0;

    .line 5
    .line 6
    iput-object p2, p0, LBd/p;->b:LBd/v$a;

    .line 7
    .line 8
    iput-object p3, p0, LBd/p;->c:Landroidx/fragment/app/Fragment;

    .line 9
    .line 10
    iput-object p4, p0, LBd/p;->d:Lkotlin/jvm/functions/Function0;

    .line 11
    .line 12
    iput-object p5, p0, LBd/p;->e:Lkotlin/jvm/functions/Function0;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    check-cast p1, LO8/e;

    .line 2
    .line 3
    iget-boolean v0, p1, LO8/e;->b:Z

    .line 4
    .line 5
    iget-object v1, p0, LBd/p;->a:Lkotlin/jvm/functions/Function0;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    goto/16 :goto_1

    .line 13
    .line 14
    :cond_0
    sget-object v0, LBd/v$a;->PHOTO_LIBRARY:LBd/v$a;

    .line 15
    .line 16
    sget-object v2, LBd/v;->a:LBd/v;

    .line 17
    .line 18
    iget-object v3, p0, LBd/p;->b:LBd/v$a;

    .line 19
    .line 20
    iget-object v4, p0, LBd/p;->c:Landroidx/fragment/app/Fragment;

    .line 21
    .line 22
    if-ne v3, v0, :cond_2

    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->p()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 35
    .line 36
    const/16 v6, 0x22

    .line 37
    .line 38
    if-lt v5, v6, :cond_2

    .line 39
    .line 40
    const-string v5, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    .line 41
    .line 42
    invoke-static {v0, v5}, Li1/b;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-nez v0, :cond_2

    .line 47
    .line 48
    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    goto/16 :goto_1

    .line 52
    .line 53
    :cond_2
    :goto_0
    iget-boolean p1, p1, LO8/e;->c:Z

    .line 54
    .line 55
    if-eqz p1, :cond_3

    .line 56
    .line 57
    iget-object p1, p0, LBd/p;->d:Lkotlin/jvm/functions/Function0;

    .line 58
    .line 59
    if-eqz p1, :cond_3

    .line 60
    .line 61
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    goto/16 :goto_1

    .line 65
    .line 66
    :cond_3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->p()Landroid/content/Context;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    iget-object v0, p0, LBd/p;->e:Lkotlin/jvm/functions/Function0;

    .line 74
    .line 75
    if-nez p1, :cond_4

    .line 76
    .line 77
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    goto/16 :goto_1

    .line 81
    .line 82
    :cond_4
    sget-object v1, LBd/v$b;->a:[I

    .line 83
    .line 84
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    aget v1, v1, v3

    .line 89
    .line 90
    const/4 v3, 0x1

    .line 91
    const/4 v4, 0x0

    .line 92
    const v5, 0x7f120237

    .line 93
    .line 94
    .line 95
    const v6, 0x7f12023d

    .line 96
    .line 97
    .line 98
    const v7, 0x7f12023a

    .line 99
    .line 100
    .line 101
    const v8, 0x7f130002

    .line 102
    .line 103
    .line 104
    if-eq v1, v3, :cond_6

    .line 105
    .line 106
    const/4 v3, 0x2

    .line 107
    if-ne v1, v3, :cond_5

    .line 108
    .line 109
    new-instance v1, Lw6/b;

    .line 110
    .line 111
    invoke-direct {v1, p1, v8}, Lw6/b;-><init>(Landroid/content/Context;I)V

    .line 112
    .line 113
    .line 114
    invoke-static {v7, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    iget-object v7, v1, Landroidx/appcompat/app/b$a;->a:Landroidx/appcompat/app/AlertController$b;

    .line 119
    .line 120
    iput-object v3, v7, Landroidx/appcompat/app/AlertController$b;->d:Ljava/lang/CharSequence;

    .line 121
    .line 122
    const v3, 0x7f120236

    .line 123
    .line 124
    .line 125
    invoke-static {v3, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    iput-object v3, v7, Landroidx/appcompat/app/AlertController$b;->f:Ljava/lang/String;

    .line 130
    .line 131
    invoke-static {v6, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    new-instance v6, LBd/t;

    .line 136
    .line 137
    invoke-direct {v6, p1, v0}, LBd/t;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v1, v3, v6}, Lw6/b;->d(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 141
    .line 142
    .line 143
    invoke-static {v5, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    new-instance v2, LBd/u;

    .line 148
    .line 149
    invoke-direct {v2, v0}, LBd/u;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1, p1, v2}, Lw6/b;->c(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 153
    .line 154
    .line 155
    iput-boolean v4, v7, Landroidx/appcompat/app/AlertController$b;->m:Z

    .line 156
    .line 157
    invoke-virtual {v1}, Landroidx/appcompat/app/b$a;->b()V

    .line 158
    .line 159
    .line 160
    goto :goto_1

    .line 161
    :cond_5
    new-instance p1, Lkotlin/NoWhenBranchMatchedException;

    .line 162
    .line 163
    invoke-direct {p1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 164
    .line 165
    .line 166
    throw p1

    .line 167
    :cond_6
    new-instance v1, Lw6/b;

    .line 168
    .line 169
    invoke-direct {v1, p1, v8}, Lw6/b;-><init>(Landroid/content/Context;I)V

    .line 170
    .line 171
    .line 172
    invoke-static {v7, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    iget-object v7, v1, Landroidx/appcompat/app/b$a;->a:Landroidx/appcompat/app/AlertController$b;

    .line 177
    .line 178
    iput-object v3, v7, Landroidx/appcompat/app/AlertController$b;->d:Ljava/lang/CharSequence;

    .line 179
    .line 180
    const v3, 0x7f12023b

    .line 181
    .line 182
    .line 183
    invoke-static {v3, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    iput-object v3, v7, Landroidx/appcompat/app/AlertController$b;->f:Ljava/lang/String;

    .line 188
    .line 189
    invoke-static {v6, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    new-instance v6, LBd/r;

    .line 194
    .line 195
    invoke-direct {v6, p1}, LBd/r;-><init>(Landroid/content/Context;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v1, v3, v6}, Lw6/b;->d(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 199
    .line 200
    .line 201
    invoke-static {v5, v2}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    new-instance v2, LBd/s;

    .line 206
    .line 207
    invoke-direct {v2, v0}, LBd/s;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v1, p1, v2}, Lw6/b;->c(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 211
    .line 212
    .line 213
    iput-boolean v4, v7, Landroidx/appcompat/app/AlertController$b;->m:Z

    .line 214
    .line 215
    invoke-virtual {v1}, Landroidx/appcompat/app/b$a;->b()V

    .line 216
    .line 217
    .line 218
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 219
    .line 220
    return-object p1
.end method
