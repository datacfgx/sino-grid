.class public final LBd/h;
.super Ljava/lang/Object;
.source "CleverTap.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LBd/h$a;
    }
.end annotation


# direct methods
.method public static a()V
    .locals 3

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "it"

    .line 7
    .line 8
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 12
    .line 13
    const-string v2, "Connection Successful"

    .line 14
    .line 15
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 19
    .line 20
    new-instance v1, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v2, "sendEvent() called with: eventName = Connect Instagram, properties = "

    .line 23
    .line 24
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v2, "CleverTap"

    .line 35
    .line 36
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    sget-object v1, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 40
    .line 41
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-static {v1}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    if-eqz v1, :cond_0

    .line 50
    .line 51
    const-string v2, "Connect Instagram"

    .line 52
    .line 53
    invoke-virtual {v1, v2, v0}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 54
    .line 55
    .line 56
    :cond_0
    return-void
.end method

.method public static b(ILorg/tezza/domain/gallery/GalleryItemAdjustments;Z)V
    .locals 12

    .line 1
    const-string v0, "adjusts"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 7
    .line 8
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v1, "Tezza"

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-string v1, "ratingCountKey"

    .line 20
    .line 21
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    const/4 v1, 0x1

    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    move v4, v1

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    move v4, v2

    .line 31
    :goto_0
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->a:Lorg/tezza/domain/gallery/LutsAdjustments;

    .line 32
    .line 33
    iget-object v0, v0, Lorg/tezza/domain/gallery/LutsAdjustments;->c:Lvc/K;

    .line 34
    .line 35
    sget-object v3, Lvc/K;->EMPTY:Lvc/K;

    .line 36
    .line 37
    if-eq v0, v3, :cond_1

    .line 38
    .line 39
    move v7, v1

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    move v7, v2

    .line 42
    :goto_1
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->b:Ljava/util/List;

    .line 43
    .line 44
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-le v0, v1, :cond_2

    .line 49
    .line 50
    move v8, v1

    .line 51
    goto :goto_2

    .line 52
    :cond_2
    move v8, v2

    .line 53
    :goto_2
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 54
    .line 55
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-lez v0, :cond_3

    .line 60
    .line 61
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 62
    .line 63
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 68
    .line 69
    iget-object v0, v0, Lorg/tezza/domain/gallery/LayersAdjustments;->c:Lvc/F;

    .line 70
    .line 71
    sget-object v3, Lvc/F;->EMPTY:Lvc/F;

    .line 72
    .line 73
    if-eq v0, v3, :cond_3

    .line 74
    .line 75
    move v10, v1

    .line 76
    goto :goto_3

    .line 77
    :cond_3
    move v10, v2

    .line 78
    :goto_3
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 79
    .line 80
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-lez v0, :cond_6

    .line 85
    .line 86
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 87
    .line 88
    check-cast v0, Ljava/lang/Iterable;

    .line 89
    .line 90
    instance-of v3, v0, Ljava/util/Collection;

    .line 91
    .line 92
    if-eqz v3, :cond_4

    .line 93
    .line 94
    move-object v3, v0

    .line 95
    check-cast v3, Ljava/util/Collection;

    .line 96
    .line 97
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 98
    .line 99
    .line 100
    move-result v3

    .line 101
    if-eqz v3, :cond_4

    .line 102
    .line 103
    goto :goto_4

    .line 104
    :cond_4
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    :cond_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 109
    .line 110
    .line 111
    move-result v3

    .line 112
    if-eqz v3, :cond_6

    .line 113
    .line 114
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    check-cast v3, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 119
    .line 120
    invoke-virtual {v3}, Lorg/tezza/domain/gallery/EffectsAdjustments;->m()Z

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    if-nez v3, :cond_5

    .line 125
    .line 126
    move v11, v1

    .line 127
    goto :goto_5

    .line 128
    :cond_6
    :goto_4
    move v11, v2

    .line 129
    :goto_5
    iget-object v0, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 130
    .line 131
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    if-lez v0, :cond_9

    .line 136
    .line 137
    iget-object p1, p1, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->d:Ljava/util/List;

    .line 138
    .line 139
    check-cast p1, Ljava/lang/Iterable;

    .line 140
    .line 141
    instance-of v0, p1, Ljava/util/Collection;

    .line 142
    .line 143
    if-eqz v0, :cond_7

    .line 144
    .line 145
    move-object v0, p1

    .line 146
    check-cast v0, Ljava/util/Collection;

    .line 147
    .line 148
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-eqz v0, :cond_7

    .line 153
    .line 154
    goto :goto_6

    .line 155
    :cond_7
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    :cond_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_9

    .line 164
    .line 165
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Lorg/tezza/domain/gallery/EffectsAdjustments;

    .line 170
    .line 171
    invoke-virtual {v0}, Lorg/tezza/domain/gallery/EffectsAdjustments;->m()Z

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    if-eqz v0, :cond_8

    .line 176
    .line 177
    move v9, v1

    .line 178
    goto :goto_7

    .line 179
    :cond_9
    :goto_6
    move v9, v2

    .line 180
    :goto_7
    new-instance v3, LBd/g;

    .line 181
    .line 182
    move v6, p0

    .line 183
    move v5, p2

    .line 184
    invoke-direct/range {v3 .. v11}, LBd/g;-><init>(ZZIZZZZZ)V

    .line 185
    .line 186
    .line 187
    const-string p0, "Content Save"

    .line 188
    .line 189
    invoke-static {p0, v3}, LBd/h;->c(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 190
    .line 191
    .line 192
    return-void
.end method

.method public static c(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    new-instance p1, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    const-string v1, "sendEvent() called with: eventName = "

    .line 12
    .line 13
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string v1, ", properties = "

    .line 20
    .line 21
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const-string v1, "CleverTap"

    .line 32
    .line 33
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    sget-object p1, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 37
    .line 38
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-static {p1}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    if-eqz p1, :cond_0

    .line 47
    .line 48
    invoke-virtual {p1, p0, v0}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 49
    .line 50
    .line 51
    :cond_0
    return-void
.end method

.method public static d()V
    .locals 3

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "it"

    .line 7
    .line 8
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 12
    .line 13
    const-string v2, "Open Instagram Feed"

    .line 14
    .line 15
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 19
    .line 20
    new-instance v1, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v2, "sendEvent() called with: eventName = Instagram Feed Opened, properties = "

    .line 23
    .line 24
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v2, "CleverTap"

    .line 35
    .line 36
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    sget-object v1, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 40
    .line 41
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-static {v1}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    if-eqz v1, :cond_0

    .line 50
    .line 51
    const-string v2, "Instagram Feed Opened"

    .line 52
    .line 53
    invoke-virtual {v1, v2, v0}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 54
    .line 55
    .line 56
    :cond_0
    return-void
.end method
