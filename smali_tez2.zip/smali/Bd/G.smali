.class public final synthetic LBd/G;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/a;
.implements LF5/n$b;
.implements Le9/i;


# direct methods
.method public static a(IIII)I
    .locals 0

    .line 1
    invoke-static {p0}, Lcom/google/android/gms/internal/play_billing/N0;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    add-int/2addr p0, p1

    .line 6
    add-int/2addr p0, p2

    .line 7
    add-int/2addr p0, p3

    .line 8
    return p0
.end method


# virtual methods
.method public b(Ljava/lang/Object;LF5/j;)V
    .locals 0

    .line 1
    check-cast p1, LU4/b;

    .line 2
    .line 3
    return-void
.end method

.method public c(Lo9/j$a;)V
    .locals 0

    .line 1
    invoke-static {p1}, Lorg/tezza/data/user/source/persistence/UserPersistenceSource;->c(Lo9/j$a;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public run()V
    .locals 2

    .line 1
    sget-object v0, LBd/N;->a:LBd/N;

    .line 2
    .line 3
    const-string v1, "Rx complete: "

    .line 4
    .line 5
    invoke-static {v0, v1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
