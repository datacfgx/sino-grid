.class public final synthetic LBd/x;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Le9/k;
.implements LF5/n$a;


# direct methods
.method public static a(Ljava/lang/StringBuilder;ZC)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method


# virtual methods
.method public b(Le9/g;)Le9/j;
    .locals 5

    .line 1
    const-string v0, "upstream"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lf9/a;->a()Lf9/b;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const-string v1, "mainThread(...)"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1, v0}, Le9/g;->l(Le9/m;)Lo9/D;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-static {}, Lf9/a;->a()Lf9/b;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1, v0}, Le9/g;->j(Le9/m;)Lo9/z;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    new-instance v0, LBd/E;

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-direct {v0, v1}, LBd/E;-><init>(I)V

    .line 34
    .line 35
    .line 36
    new-instance v1, LBd/F;

    .line 37
    .line 38
    const/4 v2, 0x0

    .line 39
    invoke-direct {v1, v2, v0}, LBd/F;-><init>(ILjava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    sget-object v0, Lk9/a;->d:Lk9/a$c;

    .line 43
    .line 44
    sget-object v2, Lk9/a;->c:Lk9/a$b;

    .line 45
    .line 46
    new-instance v3, Lo9/m;

    .line 47
    .line 48
    invoke-direct {v3, p1, v1, v0, v2}, Lo9/m;-><init>(Le9/g;Li9/c;Li9/c;Li9/a;)V

    .line 49
    .line 50
    .line 51
    new-instance p1, LBd/G;

    .line 52
    .line 53
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 54
    .line 55
    .line 56
    new-instance v1, Lo9/m;

    .line 57
    .line 58
    invoke-direct {v1, v3, v0, v0, p1}, Lo9/m;-><init>(Le9/g;Li9/c;Li9/c;Li9/a;)V

    .line 59
    .line 60
    .line 61
    new-instance p1, LBd/H;

    .line 62
    .line 63
    const/4 v3, 0x0

    .line 64
    invoke-direct {p1, v3}, LBd/H;-><init>(I)V

    .line 65
    .line 66
    .line 67
    new-instance v3, LBd/I;

    .line 68
    .line 69
    const/4 v4, 0x0

    .line 70
    invoke-direct {v3, v4, p1}, LBd/I;-><init>(ILjava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    new-instance p1, Lo9/n;

    .line 74
    .line 75
    invoke-direct {p1, v1, v3, v2}, Lo9/n;-><init>(Le9/g;Li9/c;Li9/a;)V

    .line 76
    .line 77
    .line 78
    new-instance v1, LBd/J;

    .line 79
    .line 80
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 81
    .line 82
    .line 83
    new-instance v3, Lo9/n;

    .line 84
    .line 85
    invoke-direct {v3, p1, v0, v1}, Lo9/n;-><init>(Le9/g;Li9/c;Li9/a;)V

    .line 86
    .line 87
    .line 88
    new-instance p1, LBd/K;

    .line 89
    .line 90
    const/4 v1, 0x0

    .line 91
    invoke-direct {p1, v1}, LBd/K;-><init>(I)V

    .line 92
    .line 93
    .line 94
    new-instance v1, LBd/L;

    .line 95
    .line 96
    const/4 v4, 0x0

    .line 97
    invoke-direct {v1, v4, p1}, LBd/L;-><init>(ILjava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    new-instance p1, Lo9/m;

    .line 101
    .line 102
    invoke-direct {p1, v3, v0, v1, v2}, Lo9/m;-><init>(Le9/g;Li9/c;Li9/c;Li9/a;)V

    .line 103
    .line 104
    .line 105
    return-object p1
.end method

.method public invoke(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, LU4/b;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-void
.end method
