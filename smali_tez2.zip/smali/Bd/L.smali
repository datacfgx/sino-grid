.class public final synthetic LBd/L;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements LC1/c$a;
.implements LF5/n$a;
.implements Lcom/appsflyer/internal/AFd1ySDK$AFa1vSDK;
.implements Lio/realm/x0$a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/L;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/L;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LBd/L;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LM/M0;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/user/UserRepositoryImpl;->u(LM/M0;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LBd/K;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LBd/K;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LOc/r1;

    .line 4
    .line 5
    invoke-virtual {v0}, LOc/r1;->K()LOc/a2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-virtual {v1}, LOc/a2;->d()LOc/f2;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    invoke-virtual {v1}, LOc/a2;->q()Lorg/tezza/domain/gallery/HazeAdjustments;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v1, 0x0

    .line 27
    :goto_0
    if-eqz v1, :cond_1

    .line 28
    .line 29
    int-to-float p1, p1

    .line 30
    const/high16 p2, 0x42c80000    # 100.0f

    .line 31
    .line 32
    div-float/2addr p1, p2

    .line 33
    iput p1, v1, Lorg/tezza/domain/gallery/HazeAdjustments;->i:F

    .line 34
    .line 35
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 36
    .line 37
    invoke-virtual {v0}, LOc/r1;->k0()V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
.end method

.method public f(Lio/realm/x0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/realm/U0;

    .line 4
    .line 5
    invoke-static {v0, p1}, Lorg/tezza/data/user/source/persistence/UserPersistenceSource;->e(Lio/realm/U0;Lio/realm/x0;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public invoke(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/google/android/exoplayer2/Player$c;

    .line 2
    .line 3
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, LT4/i0;

    .line 6
    .line 7
    invoke-virtual {v0}, LT4/i0;->k()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-interface {p1, v0}, Lcom/google/android/exoplayer2/Player$c;->onIsPlayingChanged(Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public onConfigurationChanged(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/L;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/appsflyer/internal/AFa1uSDK;

    .line 4
    .line 5
    invoke-static {v0, p1}, Lcom/appsflyer/internal/AFa1uSDK;->a(Lcom/appsflyer/internal/AFa1uSDK;Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
