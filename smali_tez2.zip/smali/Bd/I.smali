.class public final synthetic LBd/I;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements Li9/d;
.implements Lg3/k$a;
.implements Lio/realm/x0$a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/I;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/I;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LBd/H;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LBd/H;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LBd/I;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :pswitch_0
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LBd/H;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/user/UserRepositoryImpl;->X(LBd/H;Ljava/lang/Object;)Le9/j;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_1
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lec/a;

    .line 18
    .line 19
    invoke-static {v0, p1}, Lorg/tezza/data/flow/FlowRepositoryImpl;->L(Lec/a;Ljava/lang/Object;)Le9/j;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :pswitch_2
    const-string v0, "p0"

    .line 25
    .line 26
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, LBd/H;

    .line 32
    .line 33
    invoke-virtual {v0, p1}, LBd/H;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Le9/j;

    .line 38
    .line 39
    return-object p1

    .line 40
    :pswitch_3
    const-string v0, "p0"

    .line 41
    .line 42
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v0, LBd/H;

    .line 48
    .line 49
    invoke-virtual {v0, p1}, LBd/H;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Ljava/util/ArrayList;

    .line 54
    .line 55
    return-object p1

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public b(Lcom/android/volley/VolleyError;)V
    .locals 10

    .line 1
    const-string v0, "Error"

    .line 2
    .line 3
    sget-object v1, LUc/y;->A0:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v2, "error:"

    .line 10
    .line 11
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object v1, p0, LBd/I;->b:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, LUc/y;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    const-string v2, "IG"

    .line 25
    .line 26
    const-string v3, "Tezza Exception"

    .line 27
    .line 28
    const-string v4, "Tezza"

    .line 29
    .line 30
    const-string v5, "throwable"

    .line 31
    .line 32
    const-string v6, "Instagram error with message = "

    .line 33
    .line 34
    const-string v7, "Instagram error with responseBody = "

    .line 35
    .line 36
    const-string v8, "error"

    .line 37
    .line 38
    invoke-static {p1, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :try_start_0
    const-string v8, "Something went wrong. Instagram connection not available"

    .line 42
    .line 43
    invoke-virtual {v1, v8}, LJc/e;->z0(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    iget-object p1, p1, Lcom/android/volley/VolleyError;->a:Lg3/h;

    .line 47
    .line 48
    iget-object p1, p1, Lg3/h;->a:[B

    .line 49
    .line 50
    const-string v8, "data"

    .line 51
    .line 52
    invoke-static {p1, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    sget-object v8, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 56
    .line 57
    new-instance v9, Ljava/lang/String;

    .line 58
    .line 59
    invoke-direct {v9, p1, v8}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v7, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 67
    .line 68
    .line 69
    new-instance p1, Lorg/json/JSONObject;

    .line 70
    .line 71
    invoke-direct {p1, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    const-string v7, "errors"

    .line 75
    .line 76
    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    const/4 v7, 0x0

    .line 81
    invoke-virtual {p1, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    const-string v7, "message"

    .line 86
    .line 87
    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    new-instance v7, Ljava/lang/StringBuilder;

    .line 92
    .line 93
    invoke-direct {v7, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 104
    .line 105
    .line 106
    goto :goto_3

    .line 107
    :catch_0
    move-exception p1

    .line 108
    goto :goto_0

    .line 109
    :catch_1
    move-exception p1

    .line 110
    goto :goto_1

    .line 111
    :catch_2
    move-exception p1

    .line 112
    goto :goto_2

    .line 113
    :goto_0
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    invoke-static {v4, v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 117
    .line 118
    .line 119
    sget-object v2, LGc/l;->a:LGc/l;

    .line 120
    .line 121
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 122
    .line 123
    .line 124
    invoke-static {v0, p1}, LGc/l;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 125
    .line 126
    .line 127
    goto :goto_3

    .line 128
    :goto_1
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-static {v4, v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 132
    .line 133
    .line 134
    sget-object v2, LGc/l;->a:LGc/l;

    .line 135
    .line 136
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    .line 138
    .line 139
    invoke-static {v0, p1}, LGc/l;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 140
    .line 141
    .line 142
    goto :goto_3

    .line 143
    :goto_2
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    invoke-static {v4, v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 147
    .line 148
    .line 149
    sget-object v2, LGc/l;->a:LGc/l;

    .line 150
    .line 151
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 152
    .line 153
    .line 154
    invoke-static {v0, p1}, LGc/l;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 155
    .line 156
    .line 157
    :goto_3
    invoke-virtual {v1}, LUc/y;->A0()V

    .line 158
    .line 159
    .line 160
    return-void
.end method

.method public c(Lv1/f;ILandroid/os/Bundle;)Z
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x19

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-lt v0, v1, :cond_1

    .line 7
    .line 8
    and-int/2addr p2, v2

    .line 9
    if-eqz p2, :cond_1

    .line 10
    .line 11
    :try_start_0
    iget-object p2, p1, Lv1/f;->a:Lv1/f$c;

    .line 12
    .line 13
    invoke-interface {p2}, Lv1/f$c;->c()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 14
    .line 15
    .line 16
    iget-object p2, p1, Lv1/f;->a:Lv1/f$c;

    .line 17
    .line 18
    invoke-interface {p2}, Lv1/f$c;->e()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    check-cast p2, Landroid/os/Parcelable;

    .line 23
    .line 24
    if-nez p3, :cond_0

    .line 25
    .line 26
    new-instance p3, Landroid/os/Bundle;

    .line 27
    .line 28
    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    new-instance v1, Landroid/os/Bundle;

    .line 33
    .line 34
    invoke-direct {v1, p3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 35
    .line 36
    .line 37
    move-object p3, v1

    .line 38
    :goto_0
    const-string v1, "androidx.core.view.extra.INPUT_CONTENT_INFO"

    .line 39
    .line 40
    invoke-virtual {p3, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :catch_0
    move-exception p1

    .line 45
    const-string p2, "InputConnectionCompat"

    .line 46
    .line 47
    const-string p3, "Can\'t insert content from IME; requestPermission() failed"

    .line 48
    .line 49
    invoke-static {p2, p3, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 50
    .line 51
    .line 52
    goto :goto_3

    .line 53
    :cond_1
    :goto_1
    new-instance p2, Landroid/content/ClipData;

    .line 54
    .line 55
    iget-object v1, p1, Lv1/f;->a:Lv1/f$c;

    .line 56
    .line 57
    invoke-interface {v1}, Lv1/f$c;->a()Landroid/content/ClipDescription;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    new-instance v3, Landroid/content/ClipData$Item;

    .line 62
    .line 63
    iget-object p1, p1, Lv1/f;->a:Lv1/f$c;

    .line 64
    .line 65
    invoke-interface {p1}, Lv1/f$c;->b()Landroid/net/Uri;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-direct {v3, v4}, Landroid/content/ClipData$Item;-><init>(Landroid/net/Uri;)V

    .line 70
    .line 71
    .line 72
    invoke-direct {p2, v1, v3}, Landroid/content/ClipData;-><init>(Landroid/content/ClipDescription;Landroid/content/ClipData$Item;)V

    .line 73
    .line 74
    .line 75
    const/16 v1, 0x1f

    .line 76
    .line 77
    const/4 v3, 0x2

    .line 78
    if-lt v0, v1, :cond_2

    .line 79
    .line 80
    new-instance v0, Lt1/d$a;

    .line 81
    .line 82
    invoke-direct {v0, p2, v3}, Lt1/d$a;-><init>(Landroid/content/ClipData;I)V

    .line 83
    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_2
    new-instance v0, Lt1/d$c;

    .line 87
    .line 88
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 89
    .line 90
    .line 91
    iput-object p2, v0, Lt1/d$c;->a:Landroid/content/ClipData;

    .line 92
    .line 93
    iput v3, v0, Lt1/d$c;->b:I

    .line 94
    .line 95
    :goto_2
    invoke-interface {p1}, Lv1/f$c;->d()Landroid/net/Uri;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    invoke-interface {v0, p1}, Lt1/d$b;->b(Landroid/net/Uri;)V

    .line 100
    .line 101
    .line 102
    invoke-interface {v0, p3}, Lt1/d$b;->a(Landroid/os/Bundle;)V

    .line 103
    .line 104
    .line 105
    invoke-interface {v0}, Lt1/d$b;->c()Lt1/d;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    iget-object p2, p0, LBd/I;->b:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast p2, Landroidx/appcompat/widget/AppCompatEditText;

    .line 112
    .line 113
    invoke-static {p2, p1}, Lt1/N;->j(Landroid/view/View;Lt1/d;)Lt1/d;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    if-nez p1, :cond_3

    .line 118
    .line 119
    return v2

    .line 120
    :cond_3
    :goto_3
    const/4 p1, 0x0

    .line 121
    return p1
.end method

.method public f(Lio/realm/x0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/I;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/realm/U0;

    .line 4
    .line 5
    invoke-static {v0, p1}, Lorg/tezza/data/flow/source/persistence/FlowPersistenceSource;->n(Lio/realm/U0;Lio/realm/x0;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
