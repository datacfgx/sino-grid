.class public final synthetic LBd/F;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements Li9/b;
.implements Li9/d;
.implements Lg0/i;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/F;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/F;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/F;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LBd/E;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LBd/E;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LBd/F;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LBd/F;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LTc/n;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/flow/source/network/FlowNetworkSource;->c(LTc/n;Ljava/lang/Object;)Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_0
    const-string v0, "p0"

    .line 16
    .line 17
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, LBd/F;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, LBd/E;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, LBd/E;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Le9/j;

    .line 29
    .line 30
    return-object p1

    .line 31
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public b(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LBd/F;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LLc/T;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, LLc/T;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public g(D)D
    .locals 1

    .line 1
    iget-object v0, p0, LBd/F;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/graphics/ColorSpace;

    .line 4
    .line 5
    invoke-static {v0}, Lf0/w0;->a(Ljava/lang/Object;)Landroid/graphics/ColorSpace$Rgb;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {v0}, LG2/e;->b(Landroid/graphics/ColorSpace$Rgb;)Ljava/util/function/DoubleUnaryOperator;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-interface {v0, p1, p2}, Ljava/util/function/DoubleUnaryOperator;->applyAsDouble(D)D

    .line 14
    .line 15
    .line 16
    move-result-wide p1

    .line 17
    return-wide p1
.end method
