.class public final synthetic LBd/B;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/c;
.implements Li9/d;
.implements LC1/c$a;
.implements LY4/a$d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/B;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/B;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LBd/B;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LBd/B;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LKc/a;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/flow/source/persistence/FlowPersistenceSource;->q(LKc/a;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LBd/B;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LBd/A;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LBd/A;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "p0"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LBd/B;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LLc/S;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LLc/S;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Le9/j;

    .line 15
    .line 16
    return-object p1
.end method

.method public b(J)J
    .locals 9

    .line 1
    iget-object v0, p0, LBd/B;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LY4/p;

    .line 4
    .line 5
    iget v1, v0, LY4/p;->e:I

    .line 6
    .line 7
    int-to-long v1, v1

    .line 8
    mul-long/2addr p1, v1

    .line 9
    const-wide/32 v1, 0xf4240

    .line 10
    .line 11
    .line 12
    div-long v3, p1, v1

    .line 13
    .line 14
    iget-wide p1, v0, LY4/p;->j:J

    .line 15
    .line 16
    const-wide/16 v0, 0x1

    .line 17
    .line 18
    sub-long v7, p1, v0

    .line 19
    .line 20
    const-wide/16 v5, 0x0

    .line 21
    .line 22
    invoke-static/range {v3 .. v8}, LF5/L;->j(JJJ)J

    .line 23
    .line 24
    .line 25
    move-result-wide p1

    .line 26
    return-wide p1
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    if-eqz p2, :cond_1

    .line 2
    .line 3
    iget-object p2, p0, LBd/B;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p2, LOc/r1;

    .line 6
    .line 7
    invoke-virtual {p2}, LOc/r1;->K()LOc/a2;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {v0}, LOc/a2;->x()Lorg/tezza/domain/gallery/LutsAdjustments;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget-object v0, v0, Lorg/tezza/domain/gallery/LutsAdjustments;->h:Lorg/tezza/domain/gallery/ValleyLutAdjustments;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    int-to-float p1, p1

    .line 24
    const/high16 v1, 0x42c80000    # 100.0f

    .line 25
    .line 26
    div-float/2addr p1, v1

    .line 27
    iput p1, v0, Lorg/tezza/domain/gallery/ValleyLutAdjustments;->b:F

    .line 28
    .line 29
    :cond_0
    invoke-virtual {p2}, LOc/r1;->k0()V

    .line 30
    .line 31
    .line 32
    :cond_1
    return-void
.end method
