.class public final synthetic LBd/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lcd/d;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lcd/d;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBd/c;->a:Lcd/d;

    .line 5
    .line 6
    iput p2, p0, LBd/c;->b:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    .line 2
    check-cast p1, Ljava/lang/Boolean;

    .line 3
    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 11
    move-result-object v0

    .line 12
    .line 13
    const-string v1, "Tezza"

    .line 14
    const/4 v2, 0x0

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 18
    move-result-object v0

    .line 19
    .line 20
    const-string v3, "isFirstTemplateKey"

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    move v0, v2

    .line 24
    goto :goto_0

    .line 25
    .line 26
    .line 27
    :cond_0
    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 28
    move-result v0

    .line 29
    :goto_0
    const/4 v4, 0x1

    .line 30
    xor-int/2addr v0, v4

    .line 31
    .line 32
    .line 33
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 34
    move-result-object v5

    .line 35
    .line 36
    .line 37
    invoke-virtual {v5, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 38
    move-result-object v1

    .line 39
    .line 40
    if-nez v1, :cond_1

    .line 41
    goto :goto_1

    .line 42
    .line 43
    .line 44
    :cond_1
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 45
    move-result-object v1

    .line 46
    .line 47
    .line 48
    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 49
    .line 50
    .line 51
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 52
    .line 53
    :goto_1
    iget-object v1, p0, LBd/c;->a:Lcd/d;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 57
    move-result-object v3

    .line 58
    .line 59
    const/4 v5, 0x0

    sget-object v5, LH4/Md/MuznlSNgHCp;->McEKHnwfewHAbP:Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    invoke-static {v3, v5}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 63
    move-result v3

    .line 64
    .line 65
    const-string v5, ""

    .line 66
    .line 67
    const-string v6, "REVOLVEFESTIVAL"

    .line 68
    .line 69
    if-eqz v3, :cond_2

    .line 70
    .line 71
    const-string v3, "Floral"

    .line 72
    .line 73
    goto/16 :goto_2

    .line 74
    .line 75
    .line 76
    :cond_2
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 77
    move-result-object v3

    .line 78
    .line 79
    const-string v7, "HYPERVISUAL"

    .line 80
    .line 81
    .line 82
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 83
    move-result v3

    .line 84
    .line 85
    if-eqz v3, :cond_3

    .line 86
    .line 87
    const-string v3, "Hypervisual"

    .line 88
    .line 89
    goto/16 :goto_2

    .line 90
    .line 91
    .line 92
    :cond_3
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 93
    move-result-object v3

    .line 94
    .line 95
    const-string v7, "EDITORIAL"

    .line 96
    .line 97
    .line 98
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 99
    move-result v3

    .line 100
    .line 101
    if-eqz v3, :cond_4

    .line 102
    .line 103
    const-string v3, "Editorial"

    .line 104
    .line 105
    goto/16 :goto_2

    .line 106
    .line 107
    .line 108
    :cond_4
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 109
    move-result-object v3

    .line 110
    .line 111
    const-string v7, "CLEAN2"

    .line 112
    .line 113
    .line 114
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 115
    move-result v3

    .line 116
    .line 117
    if-eqz v3, :cond_5

    .line 118
    .line 119
    const-string v3, "Clean 2"

    .line 120
    .line 121
    goto/16 :goto_2

    .line 122
    .line 123
    .line 124
    :cond_5
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 125
    move-result-object v3

    .line 126
    .line 127
    const-string v7, "CLEAN"

    .line 128
    .line 129
    .line 130
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 131
    move-result v3

    .line 132
    .line 133
    if-eqz v3, :cond_6

    .line 134
    .line 135
    const-string v3, "Clean 1"

    .line 136
    .line 137
    goto/16 :goto_2

    .line 138
    .line 139
    .line 140
    :cond_6
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 141
    move-result-object v3

    .line 142
    .line 143
    const-string v7, "FILMBLACK"

    .line 144
    .line 145
    .line 146
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 147
    move-result v3

    .line 148
    .line 149
    if-eqz v3, :cond_7

    .line 150
    .line 151
    const-string v3, "Film Black"

    .line 152
    .line 153
    goto/16 :goto_2

    .line 154
    .line 155
    .line 156
    :cond_7
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 157
    move-result-object v3

    .line 158
    .line 159
    const-string v7, "FILMWHITE"

    .line 160
    .line 161
    .line 162
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 163
    move-result v3

    .line 164
    .line 165
    if-eqz v3, :cond_8

    .line 166
    .line 167
    const-string v3, "Film White"

    .line 168
    .line 169
    goto/16 :goto_2

    .line 170
    .line 171
    .line 172
    :cond_8
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 173
    move-result-object v3

    .line 174
    .line 175
    const-string v7, "CYBER"

    .line 176
    .line 177
    .line 178
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 179
    move-result v3

    .line 180
    .line 181
    if-eqz v3, :cond_9

    .line 182
    .line 183
    const-string v3, "Cyber"

    .line 184
    .line 185
    goto/16 :goto_2

    .line 186
    .line 187
    .line 188
    :cond_9
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 189
    move-result-object v3

    .line 190
    .line 191
    const-string v7, "ZINE"

    .line 192
    .line 193
    .line 194
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 195
    move-result v3

    .line 196
    .line 197
    if-eqz v3, :cond_a

    .line 198
    .line 199
    const-string v3, "Zine"

    .line 200
    .line 201
    goto/16 :goto_2

    .line 202
    .line 203
    .line 204
    :cond_a
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 205
    move-result-object v3

    .line 206
    .line 207
    const-string v7, "LOVE_LETTERS"

    .line 208
    .line 209
    .line 210
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 211
    move-result v3

    .line 212
    .line 213
    if-eqz v3, :cond_b

    .line 214
    .line 215
    const-string v3, "Love Letters"

    .line 216
    .line 217
    goto/16 :goto_2

    .line 218
    .line 219
    .line 220
    :cond_b
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 221
    move-result-object v3

    .line 222
    .line 223
    const-string v7, "MOTHERS"

    .line 224
    .line 225
    .line 226
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 227
    move-result v3

    .line 228
    .line 229
    if-eqz v3, :cond_c

    .line 230
    .line 231
    const-string v3, "Mama"

    .line 232
    .line 233
    goto/16 :goto_2

    .line 234
    .line 235
    .line 236
    :cond_c
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 237
    move-result-object v3

    .line 238
    .line 239
    const-string v7, "SOUVENIRS"

    .line 240
    .line 241
    .line 242
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 243
    move-result v3

    .line 244
    .line 245
    if-eqz v3, :cond_d

    .line 246
    .line 247
    const-string v3, "Souvenirs"

    .line 248
    .line 249
    goto/16 :goto_2

    .line 250
    .line 251
    .line 252
    :cond_d
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 253
    move-result-object v3

    .line 254
    .line 255
    const-string v7, "SUNBATH"

    .line 256
    .line 257
    .line 258
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 259
    move-result v3

    .line 260
    .line 261
    if-eqz v3, :cond_e

    .line 262
    .line 263
    const-string v3, "Sunbath"

    .line 264
    .line 265
    goto/16 :goto_2

    .line 266
    .line 267
    .line 268
    :cond_e
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 269
    move-result-object v3

    .line 270
    .line 271
    const-string v7, "FINDMENOW"

    .line 272
    .line 273
    .line 274
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 275
    move-result v3

    .line 276
    .line 277
    if-eqz v3, :cond_f

    .line 278
    .line 279
    const-string v3, "Find Me Now"

    .line 280
    .line 281
    goto/16 :goto_2

    .line 282
    .line 283
    .line 284
    :cond_f
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 285
    move-result-object v3

    .line 286
    .line 287
    const-string v7, "HAPPILYGREY"

    .line 288
    .line 289
    .line 290
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 291
    move-result v3

    .line 292
    .line 293
    if-eqz v3, :cond_10

    .line 294
    .line 295
    const-string v3, "Happily Grey"

    .line 296
    goto :goto_2

    .line 297
    .line 298
    .line 299
    :cond_10
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 300
    move-result-object v3

    .line 301
    .line 302
    const-string v7, "LINE"

    .line 303
    .line 304
    .line 305
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 306
    move-result v3

    .line 307
    .line 308
    if-eqz v3, :cond_11

    .line 309
    .line 310
    const-string v3, "Line"

    .line 311
    goto :goto_2

    .line 312
    .line 313
    .line 314
    :cond_11
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 315
    move-result-object v3

    .line 316
    .line 317
    const-string v7, "PRIDE"

    .line 318
    .line 319
    .line 320
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 321
    move-result v3

    .line 322
    .line 323
    if-eqz v3, :cond_12

    .line 324
    .line 325
    const-string v3, "Pride"

    .line 326
    goto :goto_2

    .line 327
    .line 328
    .line 329
    :cond_12
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 330
    move-result-object v3

    .line 331
    .line 332
    const-string v7, "ANGEL"

    .line 333
    .line 334
    .line 335
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 336
    move-result v3

    .line 337
    .line 338
    if-eqz v3, :cond_13

    .line 339
    .line 340
    const-string v3, "Angel"

    .line 341
    goto :goto_2

    .line 342
    .line 343
    .line 344
    :cond_13
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 345
    move-result-object v3

    .line 346
    .line 347
    const-string v7, "SKETCH"

    .line 348
    .line 349
    .line 350
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 351
    move-result v3

    .line 352
    .line 353
    if-eqz v3, :cond_14

    .line 354
    .line 355
    const-string v3, "Sketch"

    .line 356
    goto :goto_2

    .line 357
    .line 358
    .line 359
    :cond_14
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 360
    move-result-object v3

    .line 361
    .line 362
    const-string v7, "FILMLINE"

    .line 363
    .line 364
    .line 365
    invoke-static {v3, v7}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 366
    move-result v3

    .line 367
    .line 368
    if-eqz v3, :cond_15

    .line 369
    .line 370
    const-string v3, "Film Line"

    .line 371
    goto :goto_2

    .line 372
    .line 373
    .line 374
    :cond_15
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 375
    move-result-object v3

    .line 376
    .line 377
    .line 378
    invoke-static {v3, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 379
    move-result v3

    .line 380
    .line 381
    if-eqz v3, :cond_16

    .line 382
    .line 383
    const-string v3, "Revolve Festival"

    .line 384
    goto :goto_2

    .line 385
    :cond_16
    move-object v3, v5

    .line 386
    .line 387
    :goto_2
    new-instance v7, Lkotlin/jvm/internal/T;

    .line 388
    .line 389
    .line 390
    invoke-direct {v7}, Lkotlin/jvm/internal/T;-><init>()V

    .line 391
    .line 392
    .line 393
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 394
    move-result-object v8

    .line 395
    .line 396
    const-string v9, "_"

    .line 397
    .line 398
    .line 399
    filled-new-array {v9}, [Ljava/lang/String;

    .line 400
    move-result-object v9

    .line 401
    const/4 v10, 0x6

    .line 402
    .line 403
    .line 404
    invoke-static {v8, v9, v2, v10}, Lkotlin/text/StringsKt;->K(Ljava/lang/CharSequence;[Ljava/lang/String;II)Ljava/util/List;

    .line 405
    move-result-object v2

    .line 406
    .line 407
    .line 408
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 409
    move-result-object v2

    .line 410
    .line 411
    new-instance v4, Ljava/lang/StringBuilder;

    .line 412
    .line 413
    .line 414
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 415
    .line 416
    .line 417
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 418
    .line 419
    const-string v8, " "

    .line 420
    .line 421
    .line 422
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 423
    .line 424
    .line 425
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 426
    .line 427
    .line 428
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 429
    move-result-object v2

    .line 430
    .line 431
    iput-object v2, v7, Lkotlin/jvm/internal/T;->a:Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 435
    move-result-object v2

    .line 436
    .line 437
    .line 438
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 439
    move-result v2

    .line 440
    .line 441
    if-eqz v2, :cond_17

    .line 442
    .line 443
    sget-object v2, LBd/h$a;->a:[I

    .line 444
    .line 445
    .line 446
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 447
    move-result v1

    .line 448
    .line 449
    aget v1, v2, v1

    .line 450
    .line 451
    .line 452
    packed-switch v1, :pswitch_data_0

    .line 453
    goto :goto_3

    .line 454
    .line 455
    :pswitch_0
    const-string v5, "12"

    .line 456
    goto :goto_3

    .line 457
    .line 458
    :pswitch_1
    const-string v5, "11"

    .line 459
    goto :goto_3

    .line 460
    .line 461
    :pswitch_2
    const-string v5, "10"

    .line 462
    goto :goto_3

    .line 463
    .line 464
    :pswitch_3
    const-string v5, "9"

    .line 465
    goto :goto_3

    .line 466
    .line 467
    :pswitch_4
    const-string v5, "8"

    .line 468
    goto :goto_3

    .line 469
    .line 470
    :pswitch_5
    const-string v5, "7"

    .line 471
    goto :goto_3

    .line 472
    .line 473
    :pswitch_6
    const-string v5, "6"

    .line 474
    goto :goto_3

    .line 475
    .line 476
    :pswitch_7
    const-string v5, "5"

    .line 477
    goto :goto_3

    .line 478
    .line 479
    :pswitch_8
    const-string v5, "4"

    .line 480
    goto :goto_3

    .line 481
    .line 482
    :pswitch_9
    const/4 v5, 0x0

    sget-object v5, Lcom/google/common/cache/ZlXn/ZlxFemCoW;->SUqBEq:Ljava/lang/String;

    .line 483
    goto :goto_3

    .line 484
    .line 485
    :pswitch_a
    const-string v5, "2"

    .line 486
    goto :goto_3

    .line 487
    .line 488
    :pswitch_b
    const-string v5, "1"

    .line 489
    .line 490
    .line 491
    :goto_3
    invoke-static {v3, v8, v5}, LT4/Q;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 492
    move-result-object v1

    .line 493
    .line 494
    iput-object v1, v7, Lkotlin/jvm/internal/T;->a:Ljava/lang/Object;

    .line 495
    .line 496
    :cond_17
    new-instance v1, Ljava/util/HashMap;

    .line 497
    .line 498
    .line 499
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 500
    .line 501
    const-string v2, "it"

    .line 502
    .line 503
    .line 504
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 505
    .line 506
    const-string v2, "Template Name"

    .line 507
    .line 508
    iget-object v4, v7, Lkotlin/jvm/internal/T;->a:Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    invoke-virtual {v1, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 512
    .line 513
    const-string v2, "Template Category"

    .line 514
    .line 515
    .line 516
    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 520
    move-result-object v0

    .line 521
    .line 522
    const-string v2, "First template?"

    .line 523
    .line 524
    .line 525
    invoke-virtual {v1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 526
    .line 527
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 528
    .line 529
    const-string v2, "Edit saved?"

    .line 530
    .line 531
    .line 532
    invoke-virtual {v1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 533
    .line 534
    const-string v0, "User subscribed?"

    .line 535
    .line 536
    .line 537
    invoke-virtual {v1, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 538
    .line 539
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 540
    .line 541
    const-string v0, "Free trial?"

    .line 542
    .line 543
    .line 544
    invoke-virtual {v1, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 545
    .line 546
    iget p1, p0, LBd/c;->b:I

    .line 547
    .line 548
    .line 549
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 550
    move-result-object p1

    .line 551
    .line 552
    const-string v0, "Save speed"

    .line 553
    .line 554
    .line 555
    invoke-virtual {v1, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 556
    .line 557
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 558
    .line 559
    new-instance p1, Ljava/lang/StringBuilder;

    .line 560
    .line 561
    const-string v0, "sendEvent() called with: eventName = Template started, properties = "

    .line 562
    .line 563
    .line 564
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 565
    .line 566
    .line 567
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 568
    .line 569
    .line 570
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 571
    move-result-object p1

    .line 572
    .line 573
    const-string v0, "CleverTap"

    .line 574
    .line 575
    .line 576
    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 577
    .line 578
    .line 579
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 580
    move-result-object p1

    .line 581
    .line 582
    .line 583
    invoke-static {p1}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 584
    move-result-object p1

    .line 585
    .line 586
    if-eqz p1, :cond_18

    .line 587
    .line 588
    const-string v0, "Template started"

    .line 589
    .line 590
    .line 591
    invoke-virtual {p1, v0, v1}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 592
    .line 593
    :cond_18
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 594
    return-object p1

    .line 595
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
