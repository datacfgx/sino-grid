.class public final LBd/v;
.super Ljava/lang/Object;
.source "PermissionManager.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LBd/v$a;,
        LBd/v$b;
    }
.end annotation


# static fields
.field public static final a:LBd/v;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LBd/v;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LBd/v;->a:LBd/v;

    .line 7
    .line 8
    return-void
.end method

.method public static a(Landroidx/fragment/app/Fragment;Lg9/a;[Ljava/lang/String;LBd/v$a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 6

    .line 1
    new-instance v0, LO8/i;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->n()Landroidx/fragment/app/FragmentManager;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    new-instance v2, LO8/f;

    .line 11
    .line 12
    invoke-direct {v2, v0, v1}, LO8/f;-><init>(LO8/i;Landroidx/fragment/app/FragmentManager;)V

    .line 13
    .line 14
    .line 15
    iput-object v2, v0, LO8/i;->a:LO8/f;

    .line 16
    .line 17
    array-length v1, p2

    .line 18
    invoke-static {p2, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    check-cast p2, [Ljava/lang/String;

    .line 23
    .line 24
    sget-object v1, LO8/i;->b:Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {v1}, Le9/g;->i(Ljava/lang/Object;)Lo9/x;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    new-instance v2, LO8/g;

    .line 31
    .line 32
    invoke-direct {v2, v0, p2}, LO8/g;-><init>(LO8/i;[Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, v2}, Le9/g;->e(Le9/k;)Le9/g;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    new-instance v0, LBd/p;

    .line 40
    .line 41
    move-object v3, p0

    .line 42
    move-object v2, p3

    .line 43
    move-object v1, p4

    .line 44
    move-object v5, p5

    .line 45
    move-object v4, p6

    .line 46
    invoke-direct/range {v0 .. v5}, LBd/p;-><init>(Lkotlin/jvm/functions/Function0;LBd/v$a;Landroidx/fragment/app/Fragment;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 47
    .line 48
    .line 49
    new-instance p0, LBd/q;

    .line 50
    .line 51
    const/4 p3, 0x0

    .line 52
    invoke-direct {p0, p3, v0}, LBd/q;-><init>(ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    sget-object p3, Lk9/a;->e:Lk9/a$g;

    .line 56
    .line 57
    sget-object p4, Lk9/a;->c:Lk9/a$b;

    .line 58
    .line 59
    new-instance p5, Lm9/h;

    .line 60
    .line 61
    invoke-direct {p5, p0, p3, p4}, Lm9/h;-><init>(Li9/c;Li9/c;Li9/a;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p2, p5}, Le9/g;->b(Le9/l;)V

    .line 65
    .line 66
    .line 67
    if-eqz p1, :cond_0

    .line 68
    .line 69
    invoke-static {p5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    invoke-static {p5, p1}, Lv9/a;->a(Lg9/b;Lg9/a;)V

    .line 73
    .line 74
    .line 75
    :cond_0
    return-void
.end method

.method public static b(Landroidx/fragment/app/Fragment;Lg9/a;LGc/q;Lkotlin/jvm/functions/Function0;LLc/u1;)V
    .locals 10

    .line 1
    const-string v0, "fragment"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "onGranted"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "onDenied"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 17
    .line 18
    const/16 v2, 0x1e

    .line 19
    .line 20
    const/4 v3, 0x2

    .line 21
    const-string v4, "android.permission.RECORD_AUDIO"

    .line 22
    .line 23
    const/4 v7, 0x1

    .line 24
    const-string v8, "android.permission.CAMERA"

    .line 25
    .line 26
    const/4 v9, 0x0

    .line 27
    if-ge v0, v2, :cond_0

    .line 28
    .line 29
    const/4 v0, 0x4

    .line 30
    new-array v0, v0, [Ljava/lang/String;

    .line 31
    .line 32
    aput-object v8, v0, v9

    .line 33
    .line 34
    aput-object v4, v0, v7

    .line 35
    .line 36
    const-string v2, "android.permission.READ_EXTERNAL_STORAGE"

    .line 37
    .line 38
    aput-object v2, v0, v3

    .line 39
    .line 40
    const/4 v2, 0x3

    .line 41
    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 42
    .line 43
    aput-object v3, v0, v2

    .line 44
    .line 45
    :goto_0
    move-object v3, v0

    .line 46
    goto :goto_1

    .line 47
    :cond_0
    new-array v0, v3, [Ljava/lang/String;

    .line 48
    .line 49
    aput-object v8, v0, v9

    .line 50
    .line 51
    aput-object v4, v0, v7

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :goto_1
    sget-object v4, LBd/v$a;->CAMERA:LBd/v$a;

    .line 55
    .line 56
    move-object v1, p0

    .line 57
    move-object v2, p1

    .line 58
    move-object v5, p2

    .line 59
    move-object v6, p3

    .line 60
    move-object v7, p4

    .line 61
    invoke-static/range {v1 .. v7}, LBd/v;->a(Landroidx/fragment/app/Fragment;Lg9/a;[Ljava/lang/String;LBd/v$a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public static c(Landroidx/fragment/app/Fragment;Lg9/a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 12

    .line 1
    .line 2
    const-string v0, "fragment"

    .line 3
    .line 4
    .line 5
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    const-string v0, "onGranted"

    .line 8
    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    const-string v0, "onDenied"

    .line 13
    .line 14
    .line 15
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 18
    .line 19
    const/16 v2, 0x22

    .line 20
    .line 21
    const-string v3, "android.permission.READ_MEDIA_VIDEO"

    .line 22
    .line 23
    const-string v4, "android.permission.READ_MEDIA_IMAGES"

    .line 24
    .line 25
    const-string v7, "android.permission.ACCESS_MEDIA_LOCATION"

    .line 26
    const/4 v8, 0x3

    .line 27
    const/4 v9, 0x2

    .line 28
    const/4 v10, 0x1

    .line 29
    const/4 v11, 0x0

    .line 30
    .line 31
    if-lt v0, v2, :cond_0

    .line 32
    const/4 v0, 0x4

    .line 33
    .line 34
    new-array v0, v0, [Ljava/lang/String;

    .line 35
    .line 36
    aput-object v4, v0, v11

    .line 37
    .line 38
    aput-object v3, v0, v10

    .line 39
    .line 40
    const/4 v2, 0x0

    sget-object v2, Lkotlin/collections/unsigned/caG/DqyFKfzAtTJT;->lXvrS:Ljava/lang/String;

    .line 41
    .line 42
    aput-object v2, v0, v9

    .line 43
    .line 44
    aput-object v7, v0, v8

    .line 45
    :goto_0
    move-object v3, v0

    .line 46
    goto :goto_1

    .line 47
    .line 48
    :cond_0
    const/16 v2, 0x21

    .line 49
    .line 50
    if-lt v0, v2, :cond_1

    .line 51
    .line 52
    new-array v0, v8, [Ljava/lang/String;

    .line 53
    .line 54
    aput-object v4, v0, v11

    .line 55
    .line 56
    aput-object v3, v0, v10

    .line 57
    .line 58
    aput-object v7, v0, v9

    .line 59
    goto :goto_0

    .line 60
    .line 61
    :cond_1
    const/16 v2, 0x1d

    .line 62
    .line 63
    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 64
    .line 65
    const-string v4, "android.permission.READ_EXTERNAL_STORAGE"

    .line 66
    .line 67
    if-lt v0, v2, :cond_2

    .line 68
    .line 69
    new-array v0, v8, [Ljava/lang/String;

    .line 70
    .line 71
    aput-object v4, v0, v11

    .line 72
    .line 73
    aput-object v3, v0, v10

    .line 74
    .line 75
    aput-object v7, v0, v9

    .line 76
    goto :goto_0

    .line 77
    .line 78
    :cond_2
    new-array v0, v9, [Ljava/lang/String;

    .line 79
    .line 80
    aput-object v4, v0, v11

    .line 81
    .line 82
    aput-object v3, v0, v10

    .line 83
    goto :goto_0

    .line 84
    .line 85
    :goto_1
    sget-object v4, LBd/v$a;->PHOTO_LIBRARY:LBd/v$a;

    .line 86
    move-object v1, p0

    .line 87
    move-object v2, p1

    .line 88
    move-object v5, p2

    .line 89
    move-object v6, p3

    .line 90
    .line 91
    move-object/from16 v7, p4

    .line 92
    .line 93
    .line 94
    invoke-static/range {v1 .. v7}, LBd/v;->a(Landroidx/fragment/app/Fragment;Lg9/a;[Ljava/lang/String;LBd/v$a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 95
    return-void
.end method
