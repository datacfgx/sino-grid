.class public final LBd/o;
.super Ljava/lang/Object;
.source "MemoryInfo.kt"


# static fields
.field public static a:Ljava/lang/Long;
