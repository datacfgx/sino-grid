.class public final LBd/k$a;
.super Ljava/lang/Object;
.source "FragmentViewBindingDelegate.kt"

# interfaces
.implements Landroidx/lifecycle/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LBd/k;-><init>(Landroidx/fragment/app/Fragment;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final a:LBd/j;

.field public final synthetic b:LBd/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LBd/k<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LBd/k;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LBd/k<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LBd/k$a;->b:LBd/k;

    .line 5
    .line 6
    new-instance v0, LBd/j;

    .line 7
    .line 8
    invoke-direct {v0, p1}, LBd/j;-><init>(LBd/k;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, LBd/k$a;->a:LBd/j;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final i(Landroidx/lifecycle/s;)V
    .locals 1

    .line 1
    const-string v0, "owner"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LBd/k$a;->b:LBd/k;

    .line 7
    .line 8
    iget-object p1, p1, LBd/k;->a:Landroidx/fragment/app/Fragment;

    .line 9
    .line 10
    iget-object p1, p1, Landroidx/fragment/app/Fragment;->o0:Landroidx/lifecycle/z;

    .line 11
    .line 12
    iget-object v0, p0, LBd/k$a;->a:LBd/j;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Landroidx/lifecycle/x;->f(Landroidx/lifecycle/A;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final onDestroy(Landroidx/lifecycle/s;)V
    .locals 1

    .line 1
    const-string v0, "owner"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LBd/k$a;->b:LBd/k;

    .line 7
    .line 8
    iget-object p1, p1, LBd/k;->a:Landroidx/fragment/app/Fragment;

    .line 9
    .line 10
    iget-object p1, p1, Landroidx/fragment/app/Fragment;->o0:Landroidx/lifecycle/z;

    .line 11
    .line 12
    iget-object v0, p0, LBd/k$a;->a:LBd/j;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Landroidx/lifecycle/x;->i(Landroidx/lifecycle/A;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
