.class public final synthetic LBd/e;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LBd/e;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LBd/e;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x1

    .line 4
    const/4 v3, 0x0

    .line 5
    .line 6
    const-string v4, "it"

    .line 7
    .line 8
    iget-object v5, p0, LBd/e;->b:Ljava/lang/Object;

    .line 9
    .line 10
    iget v6, p0, LBd/e;->a:I

    .line 11
    .line 12
    .line 13
    packed-switch v6, :pswitch_data_0

    .line 14
    .line 15
    check-cast p1, Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 19
    move-result p1

    .line 20
    .line 21
    check-cast v5, Lorg/tezza/gpu_video/gpu/egl/filter_custom/GlStarglowFilter;

    .line 22
    .line 23
    .line 24
    invoke-static {v5, p1}, Lorg/tezza/gpu_video/gpu/egl/filter_custom/GlStarglowFilter;->c(Lorg/tezza/gpu_video/gpu/egl/filter_custom/GlStarglowFilter;I)Lkotlin/Unit;

    .line 25
    move-result-object p1

    .line 26
    return-object p1

    .line 27
    .line 28
    :pswitch_0
    check-cast p1, Ljava/lang/Integer;

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    check-cast v5, LAd/y;

    .line 34
    .line 35
    iget-object p1, v5, LAd/y;->c:Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-static {p1}, LHc/a;->c(Ljava/lang/String;)Landroid/graphics/Bitmap;

    .line 42
    move-result-object p1

    .line 43
    return-object p1

    .line 44
    .line 45
    :pswitch_1
    check-cast p1, Lorg/tezza/domain/gallery/a;

    .line 46
    .line 47
    .line 48
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    check-cast v5, Lbd/I;

    .line 51
    .line 52
    if-eqz p1, :cond_8

    .line 53
    .line 54
    iget-object v0, p1, Lorg/tezza/domain/gallery/a;->h:Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0}, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->a()Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 58
    move-result-object v0

    .line 59
    .line 60
    iget-object v1, v0, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->b:Ljava/util/List;

    .line 61
    move-object v2, v1

    .line 62
    .line 63
    check-cast v2, Ljava/util/Collection;

    .line 64
    move-object v4, v1

    .line 65
    .line 66
    check-cast v4, Ljava/lang/Iterable;

    .line 67
    .line 68
    .line 69
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 70
    move-result-object v6

    .line 71
    .line 72
    .line 73
    :cond_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    move-result v7

    .line 75
    .line 76
    if-eqz v7, :cond_1

    .line 77
    .line 78
    .line 79
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    move-result-object v7

    .line 81
    move-object v8, v7

    .line 82
    .line 83
    check-cast v8, Lorg/tezza/domain/gallery/TweaksAdjustments;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v8}, Lorg/tezza/domain/gallery/Adjustments;->a()Z

    .line 87
    move-result v8

    .line 88
    .line 89
    if-eqz v8, :cond_0

    .line 90
    move-object v3, v7

    .line 91
    .line 92
    :cond_1
    check-cast v2, Ljava/util/Collection;

    .line 93
    .line 94
    .line 95
    invoke-static {v2}, Lkotlin/jvm/internal/a0;->a(Ljava/util/Collection;)Ljava/util/Collection;

    .line 96
    move-result-object v2

    .line 97
    .line 98
    .line 99
    invoke-interface {v2, v3}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    .line 100
    .line 101
    new-instance v2, Ljava/util/ArrayList;

    .line 102
    .line 103
    .line 104
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 105
    .line 106
    .line 107
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 108
    move-result-object v3

    .line 109
    .line 110
    .line 111
    :cond_2
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    move-result v4

    .line 113
    .line 114
    if-eqz v4, :cond_3

    .line 115
    .line 116
    .line 117
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    move-result-object v4

    .line 119
    move-object v6, v4

    .line 120
    .line 121
    check-cast v6, Lorg/tezza/domain/gallery/TweaksAdjustments;

    .line 122
    .line 123
    instance-of v7, v6, Lorg/tezza/domain/gallery/FlipXYAdjustments;

    .line 124
    .line 125
    if-eqz v7, :cond_2

    .line 126
    .line 127
    check-cast v6, Lorg/tezza/domain/gallery/FlipXYAdjustments;

    .line 128
    .line 129
    iget-boolean v6, v6, Lorg/tezza/domain/gallery/FlipXYAdjustments;->h:Z

    .line 130
    .line 131
    if-eqz v6, :cond_2

    .line 132
    .line 133
    .line 134
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 135
    goto :goto_0

    .line 136
    .line 137
    .line 138
    :cond_3
    invoke-interface {v1, v2}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    .line 139
    .line 140
    sget-object v1, LDd/t;->a:Lorg/tezza/presentation/utils/media/Size;

    .line 141
    .line 142
    iget-object v1, p1, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 143
    .line 144
    iget-boolean v2, p1, Lorg/tezza/domain/gallery/a;->d:Z

    .line 145
    .line 146
    .line 147
    invoke-static {v1, v2}, LDd/t;->b(Ljava/lang/String;Z)Lorg/tezza/presentation/utils/media/Size;

    .line 148
    move-result-object v1

    .line 149
    .line 150
    iget-object v2, v0, Lorg/tezza/domain/gallery/GalleryItemAdjustments;->c:Ljava/util/List;

    .line 151
    .line 152
    check-cast v2, Ljava/lang/Iterable;

    .line 153
    .line 154
    .line 155
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 156
    move-result-object v2

    .line 157
    .line 158
    .line 159
    :cond_4
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 160
    move-result v3

    .line 161
    .line 162
    if-eqz v3, :cond_7

    .line 163
    .line 164
    .line 165
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 166
    move-result-object v3

    .line 167
    .line 168
    check-cast v3, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 169
    .line 170
    instance-of v4, v3, Lorg/tezza/domain/gallery/DustsAdjustments;

    .line 171
    .line 172
    if-eqz v4, :cond_5

    .line 173
    .line 174
    .line 175
    invoke-virtual {v3, v1}, Lorg/tezza/domain/gallery/LayersAdjustments;->l(Lorg/tezza/presentation/utils/media/Size;)V

    .line 176
    goto :goto_1

    .line 177
    .line 178
    :cond_5
    instance-of v4, v3, Lorg/tezza/domain/gallery/LightAdjustments;

    .line 179
    .line 180
    if-eqz v4, :cond_6

    .line 181
    .line 182
    .line 183
    invoke-virtual {v3, v1}, Lorg/tezza/domain/gallery/LayersAdjustments;->l(Lorg/tezza/presentation/utils/media/Size;)V

    .line 184
    goto :goto_1

    .line 185
    .line 186
    :cond_6
    instance-of v4, v3, Lorg/tezza/domain/gallery/PaperAdjustments;

    .line 187
    .line 188
    if-eqz v4, :cond_4

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3, v1}, Lorg/tezza/domain/gallery/LayersAdjustments;->l(Lorg/tezza/presentation/utils/media/Size;)V

    .line 192
    goto :goto_1

    .line 193
    .line 194
    :cond_7
    iget-object v1, v5, Lbd/I;->j:Landroidx/lifecycle/z;

    .line 195
    .line 196
    iget-object p1, p1, Lorg/tezza/domain/gallery/a;->a:Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    invoke-static {p1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 200
    move-result-object p1

    .line 201
    .line 202
    .line 203
    invoke-virtual {v1, p1}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 204
    .line 205
    iget-object p1, v5, Lbd/I;->C:Landroidx/lifecycle/z;

    .line 206
    .line 207
    .line 208
    invoke-static {p1}, LBd/P;->a(Landroidx/lifecycle/z;)V

    .line 209
    .line 210
    :cond_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 211
    return-object p1

    .line 212
    .line 213
    :pswitch_2
    check-cast p1, LUc/k;

    .line 214
    .line 215
    sget v4, LUc/j;->E0:I

    .line 216
    .line 217
    const-string v4, "item"

    .line 218
    .line 219
    .line 220
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    .line 222
    iget-object v6, p1, LUc/k;->c:LUc/l;

    .line 223
    .line 224
    sget-object v7, LUc/l;->EMPTY_CELL:LUc/l;

    .line 225
    .line 226
    if-ne v6, v7, :cond_9

    .line 227
    .line 228
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 229
    .line 230
    goto/16 :goto_a

    .line 231
    .line 232
    :cond_9
    sget-object v7, LUc/l;->INSTAGRAM_CELL:LUc/l;

    .line 233
    .line 234
    check-cast v5, LUc/j;

    .line 235
    .line 236
    if-ne v6, v7, :cond_a

    .line 237
    .line 238
    .line 239
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 240
    move-result-object v6

    .line 241
    .line 242
    check-cast v6, LUc/o;

    .line 243
    .line 244
    iget-object v6, v6, LUc/o;->i:Landroidx/lifecycle/z;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v6}, Landroidx/lifecycle/x;->d()Ljava/lang/Object;

    .line 248
    move-result-object v6

    .line 249
    .line 250
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 251
    .line 252
    .line 253
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 254
    move-result v6

    .line 255
    .line 256
    if-nez v6, :cond_a

    .line 257
    .line 258
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 259
    .line 260
    goto/16 :goto_a

    .line 261
    .line 262
    .line 263
    :cond_a
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 264
    move-result-object v6

    .line 265
    .line 266
    check-cast v6, LUc/o;

    .line 267
    .line 268
    iget-object v6, v6, LUc/o;->i:Landroidx/lifecycle/z;

    .line 269
    .line 270
    .line 271
    invoke-virtual {v6}, Landroidx/lifecycle/x;->d()Ljava/lang/Object;

    .line 272
    move-result-object v6

    .line 273
    .line 274
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 275
    .line 276
    .line 277
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 278
    move-result v6

    .line 279
    .line 280
    if-eqz v6, :cond_b

    .line 281
    .line 282
    .line 283
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 284
    move-result-object v0

    .line 285
    .line 286
    check-cast v0, LUc/o;

    .line 287
    .line 288
    .line 289
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 290
    .line 291
    .line 292
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 293
    .line 294
    iget-object v1, v0, LUc/o;->s:Ljava/util/List;

    .line 295
    .line 296
    .line 297
    invoke-interface {v1, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 298
    .line 299
    iget-object v1, v0, LUc/o;->m:Ljava/util/ArrayList;

    .line 300
    .line 301
    .line 302
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 303
    .line 304
    iget-object v1, v0, LUc/o;->t:Ljava/util/List;

    .line 305
    .line 306
    iget v2, p1, LUc/k;->j:F

    .line 307
    .line 308
    .line 309
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 310
    move-result-object v2

    .line 311
    .line 312
    .line 313
    invoke-static {v2, p1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 314
    move-result-object p1

    .line 315
    .line 316
    .line 317
    invoke-interface {v1, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 318
    .line 319
    iget-object p1, v0, LUc/o;->k:Landroidx/lifecycle/z;

    .line 320
    .line 321
    iget-object v1, v0, LUc/o;->t:Ljava/util/List;

    .line 322
    .line 323
    .line 324
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 325
    move-result v1

    .line 326
    .line 327
    .line 328
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 329
    move-result-object v1

    .line 330
    .line 331
    new-instance v2, LCd/b;

    .line 332
    .line 333
    .line 334
    invoke-direct {v2, v1}, LCd/b;-><init>(Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {p1, v2}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 338
    .line 339
    iget-object p1, v0, LUc/o;->j:Landroidx/lifecycle/z;

    .line 340
    .line 341
    .line 342
    invoke-static {p1}, LBd/P;->a(Landroidx/lifecycle/z;)V

    .line 343
    .line 344
    goto/16 :goto_9

    .line 345
    .line 346
    :cond_b
    iget-boolean v4, p1, LUc/k;->d:Z

    .line 347
    xor-int/2addr v4, v2

    .line 348
    .line 349
    iput-boolean v4, p1, LUc/k;->d:Z

    .line 350
    .line 351
    iget-object p1, v5, LUc/j;->B0:LUc/c;

    .line 352
    .line 353
    if-eqz p1, :cond_c

    .line 354
    .line 355
    .line 356
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$f;->G()V

    .line 357
    .line 358
    .line 359
    :cond_c
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 360
    move-result-object p1

    .line 361
    .line 362
    check-cast p1, LUc/o;

    .line 363
    .line 364
    iget-object p1, p1, LUc/o;->m:Ljava/util/ArrayList;

    .line 365
    .line 366
    if-eqz p1, :cond_e

    .line 367
    .line 368
    .line 369
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 370
    move-result v4

    .line 371
    .line 372
    if-eqz v4, :cond_e

    .line 373
    :cond_d
    move p1, v1

    .line 374
    goto :goto_2

    .line 375
    .line 376
    .line 377
    :cond_e
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 378
    move-result-object p1

    .line 379
    .line 380
    .line 381
    :cond_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 382
    move-result v4

    .line 383
    .line 384
    if-eqz v4, :cond_d

    .line 385
    .line 386
    .line 387
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 388
    move-result-object v4

    .line 389
    .line 390
    check-cast v4, LUc/k;

    .line 391
    .line 392
    iget-boolean v4, v4, LUc/k;->d:Z

    .line 393
    .line 394
    if-eqz v4, :cond_f

    .line 395
    move p1, v2

    .line 396
    .line 397
    .line 398
    :goto_2
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 399
    move-result-object v4

    .line 400
    .line 401
    check-cast v4, LUc/o;

    .line 402
    .line 403
    iget-object v4, v4, LUc/o;->m:Ljava/util/ArrayList;

    .line 404
    .line 405
    new-instance v6, Ljava/util/ArrayList;

    .line 406
    .line 407
    .line 408
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 412
    move-result-object v4

    .line 413
    .line 414
    .line 415
    :cond_10
    :goto_3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 416
    move-result v7

    .line 417
    .line 418
    if-eqz v7, :cond_11

    .line 419
    .line 420
    .line 421
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 422
    move-result-object v7

    .line 423
    move-object v8, v7

    .line 424
    .line 425
    check-cast v8, LUc/k;

    .line 426
    .line 427
    iget-boolean v8, v8, LUc/k;->d:Z

    .line 428
    .line 429
    if-eqz v8, :cond_10

    .line 430
    .line 431
    .line 432
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 433
    goto :goto_3

    .line 434
    .line 435
    .line 436
    :cond_11
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 437
    move-result v4

    .line 438
    .line 439
    if-ne v4, v0, :cond_12

    .line 440
    move v0, v2

    .line 441
    goto :goto_4

    .line 442
    :cond_12
    move v0, v1

    .line 443
    .line 444
    .line 445
    :goto_4
    invoke-virtual {v5}, LJc/e;->q0()LJc/f;

    .line 446
    move-result-object v4

    .line 447
    .line 448
    check-cast v4, LUc/o;

    .line 449
    .line 450
    iget-object v4, v4, LUc/o;->m:Ljava/util/ArrayList;

    .line 451
    .line 452
    new-instance v6, Ljava/util/ArrayList;

    .line 453
    .line 454
    .line 455
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 456
    .line 457
    .line 458
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 459
    move-result-object v4

    .line 460
    .line 461
    .line 462
    :cond_13
    :goto_5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 463
    move-result v7

    .line 464
    .line 465
    if-eqz v7, :cond_14

    .line 466
    .line 467
    .line 468
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 469
    move-result-object v7

    .line 470
    move-object v8, v7

    .line 471
    .line 472
    check-cast v8, LUc/k;

    .line 473
    .line 474
    iget-boolean v9, v8, LUc/k;->d:Z

    .line 475
    .line 476
    if-eqz v9, :cond_13

    .line 477
    .line 478
    sget-object v9, LUc/l;->USER_CELL:LUc/l;

    .line 479
    .line 480
    iget-object v8, v8, LUc/k;->c:LUc/l;

    .line 481
    .line 482
    if-ne v8, v9, :cond_13

    .line 483
    .line 484
    .line 485
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 486
    goto :goto_5

    .line 487
    .line 488
    .line 489
    :cond_14
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 490
    move-result v4

    .line 491
    .line 492
    if-ne v4, v2, :cond_15

    .line 493
    move v1, v2

    .line 494
    .line 495
    :cond_15
    iget-object v2, v5, Landroidx/fragment/app/Fragment;->S:Landroidx/fragment/app/Fragment;

    .line 496
    .line 497
    instance-of v4, v2, LVc/r;

    .line 498
    .line 499
    if-eqz v4, :cond_16

    .line 500
    .line 501
    check-cast v2, LVc/r;

    .line 502
    goto :goto_6

    .line 503
    :cond_16
    move-object v2, v3

    .line 504
    .line 505
    :goto_6
    if-eqz v2, :cond_17

    .line 506
    .line 507
    .line 508
    invoke-virtual {v2}, LJc/e;->n0()LB1/g;

    .line 509
    move-result-object v2

    .line 510
    .line 511
    check-cast v2, Lrc/s1;

    .line 512
    .line 513
    iget-object v2, v2, Lrc/s1;->u:Landroid/widget/ImageView;

    .line 514
    .line 515
    if-eqz v2, :cond_17

    .line 516
    .line 517
    .line 518
    invoke-static {v2, p1}, LBd/n;->i(Landroid/view/View;Z)V

    .line 519
    .line 520
    :cond_17
    iget-object p1, v5, Landroidx/fragment/app/Fragment;->S:Landroidx/fragment/app/Fragment;

    .line 521
    .line 522
    instance-of v2, p1, LVc/r;

    .line 523
    .line 524
    if-eqz v2, :cond_18

    .line 525
    .line 526
    check-cast p1, LVc/r;

    .line 527
    goto :goto_7

    .line 528
    :cond_18
    move-object p1, v3

    .line 529
    .line 530
    :goto_7
    if-eqz p1, :cond_19

    .line 531
    .line 532
    .line 533
    invoke-virtual {p1}, LJc/e;->n0()LB1/g;

    .line 534
    move-result-object p1

    .line 535
    .line 536
    check-cast p1, Lrc/s1;

    .line 537
    .line 538
    iget-object p1, p1, Lrc/s1;->C:Landroid/widget/ImageView;

    .line 539
    .line 540
    if-eqz p1, :cond_19

    .line 541
    .line 542
    .line 543
    invoke-static {p1, v0}, LBd/n;->i(Landroid/view/View;Z)V

    .line 544
    .line 545
    :cond_19
    iget-object p1, v5, Landroidx/fragment/app/Fragment;->S:Landroidx/fragment/app/Fragment;

    .line 546
    .line 547
    instance-of v0, p1, LVc/r;

    .line 548
    .line 549
    if-eqz v0, :cond_1a

    .line 550
    move-object v3, p1

    .line 551
    .line 552
    check-cast v3, LVc/r;

    .line 553
    .line 554
    :cond_1a
    if-eqz v3, :cond_1c

    .line 555
    .line 556
    .line 557
    invoke-virtual {v3}, LJc/e;->n0()LB1/g;

    .line 558
    move-result-object p1

    .line 559
    .line 560
    check-cast p1, Lrc/s1;

    .line 561
    .line 562
    iget-object p1, p1, Lrc/s1;->S:Landroid/widget/ImageView;

    .line 563
    .line 564
    if-eqz v1, :cond_1b

    .line 565
    .line 566
    if-eqz p1, :cond_1c

    .line 567
    .line 568
    .line 569
    const v0, 0x7f0703d0

    .line 570
    .line 571
    .line 572
    :goto_8
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 573
    goto :goto_9

    .line 574
    .line 575
    :cond_1b
    if-eqz p1, :cond_1c

    .line 576
    .line 577
    .line 578
    const v0, 0x7f0703cf

    .line 579
    goto :goto_8

    .line 580
    .line 581
    :cond_1c
    :goto_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 582
    :goto_a
    return-object p1

    .line 583
    .line 584
    :pswitch_3
    check-cast p1, Ljava/lang/Boolean;

    .line 585
    .line 586
    .line 587
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 588
    .line 589
    check-cast v5, LOc/r1;

    .line 590
    .line 591
    iget-object v0, v5, LOc/r1;->l:Landroidx/lifecycle/z;

    .line 592
    .line 593
    .line 594
    invoke-virtual {v0, p1}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 595
    .line 596
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 597
    return-object p1

    .line 598
    .line 599
    :pswitch_4
    check-cast p1, Ljava/lang/Integer;

    .line 600
    .line 601
    sget-object v0, LLc/c2;->q1:Lorg/tezza/presentation/utils/media/Size;

    .line 602
    .line 603
    check-cast v5, LLc/c2;

    .line 604
    .line 605
    .line 606
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 607
    .line 608
    if-eqz p1, :cond_1d

    .line 609
    .line 610
    .line 611
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 612
    move-result p1

    .line 613
    .line 614
    .line 615
    invoke-virtual {v5}, LJc/e;->n0()LB1/g;

    .line 616
    move-result-object v0

    .line 617
    .line 618
    check-cast v0, Lrc/I8;

    .line 619
    .line 620
    iget-object v0, v0, Lrc/I8;->P:Lrc/e9;

    .line 621
    .line 622
    iget-object v0, v0, Lrc/e9;->t:Landroid/widget/TextView;

    .line 623
    .line 624
    .line 625
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 626
    move-result-object p1

    .line 627
    .line 628
    .line 629
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 630
    .line 631
    :cond_1d
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 632
    return-object p1

    .line 633
    .line 634
    :pswitch_5
    check-cast p1, Lorg/tezza/data/common/RepoResult;

    .line 635
    .line 636
    check-cast v5, LIc/y;

    .line 637
    .line 638
    iget-object v0, v5, LIc/y;->f:Landroidx/lifecycle/z;

    .line 639
    .line 640
    .line 641
    invoke-virtual {v0, p1}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 642
    .line 643
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 644
    return-object p1

    .line 645
    .line 646
    :pswitch_6
    check-cast p1, Ljava/util/HashMap;

    .line 647
    .line 648
    .line 649
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 650
    .line 651
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 652
    .line 653
    const-string v4, "Flow saved"

    .line 654
    .line 655
    .line 656
    invoke-interface {p1, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 657
    .line 658
    check-cast v5, Ljava/util/ArrayList;

    .line 659
    .line 660
    .line 661
    invoke-static {v5, v1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 662
    move-result-object v1

    .line 663
    .line 664
    check-cast v1, LTc/m;

    .line 665
    .line 666
    const-string v3, ""

    .line 667
    .line 668
    if-eqz v1, :cond_1e

    .line 669
    .line 670
    iget-object v1, v1, LTc/m;->a:Ljava/lang/String;

    .line 671
    .line 672
    if-nez v1, :cond_1f

    .line 673
    :cond_1e
    move-object v1, v3

    .line 674
    .line 675
    :cond_1f
    const-string v4, "Flow Edit 1"

    .line 676
    .line 677
    .line 678
    invoke-interface {p1, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 679
    .line 680
    .line 681
    invoke-static {v5, v2}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 682
    move-result-object v1

    .line 683
    .line 684
    check-cast v1, LTc/m;

    .line 685
    .line 686
    if-eqz v1, :cond_20

    .line 687
    .line 688
    iget-object v1, v1, LTc/m;->a:Ljava/lang/String;

    .line 689
    .line 690
    if-nez v1, :cond_21

    .line 691
    :cond_20
    move-object v1, v3

    .line 692
    .line 693
    :cond_21
    const-string v2, "Flow Edit 2"

    .line 694
    .line 695
    .line 696
    invoke-interface {p1, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 700
    move-result-object v0

    .line 701
    .line 702
    check-cast v0, LTc/m;

    .line 703
    .line 704
    if-eqz v0, :cond_22

    .line 705
    .line 706
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 707
    .line 708
    if-nez v0, :cond_23

    .line 709
    :cond_22
    move-object v0, v3

    .line 710
    .line 711
    :cond_23
    const/4 v1, 0x0

    sget-object v1, LM5/xX/xHHGBcdQxAnhp;->SUgBv:Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 715
    const/4 v0, 0x3

    .line 716
    .line 717
    .line 718
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 719
    move-result-object v0

    .line 720
    .line 721
    check-cast v0, LTc/m;

    .line 722
    .line 723
    if-eqz v0, :cond_24

    .line 724
    .line 725
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 726
    .line 727
    if-nez v0, :cond_25

    .line 728
    :cond_24
    move-object v0, v3

    .line 729
    .line 730
    :cond_25
    const-string v1, "Flow Edit 4"

    .line 731
    .line 732
    .line 733
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 734
    const/4 v0, 0x4

    .line 735
    .line 736
    .line 737
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 738
    move-result-object v0

    .line 739
    .line 740
    check-cast v0, LTc/m;

    .line 741
    .line 742
    if-eqz v0, :cond_26

    .line 743
    .line 744
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 745
    .line 746
    if-nez v0, :cond_27

    .line 747
    :cond_26
    move-object v0, v3

    .line 748
    .line 749
    :cond_27
    const-string v1, "Flow Edit 5"

    .line 750
    .line 751
    .line 752
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 753
    const/4 v0, 0x5

    .line 754
    .line 755
    .line 756
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 757
    move-result-object v0

    .line 758
    .line 759
    check-cast v0, LTc/m;

    .line 760
    .line 761
    if-eqz v0, :cond_28

    .line 762
    .line 763
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 764
    .line 765
    if-nez v0, :cond_29

    .line 766
    :cond_28
    move-object v0, v3

    .line 767
    .line 768
    :cond_29
    const-string v1, "Flow Edit 6"

    .line 769
    .line 770
    .line 771
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 772
    const/4 v0, 0x6

    .line 773
    .line 774
    .line 775
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 776
    move-result-object v0

    .line 777
    .line 778
    check-cast v0, LTc/m;

    .line 779
    .line 780
    if-eqz v0, :cond_2a

    .line 781
    .line 782
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 783
    .line 784
    if-nez v0, :cond_2b

    .line 785
    :cond_2a
    move-object v0, v3

    .line 786
    .line 787
    :cond_2b
    const-string v1, "Flow Edit 7"

    .line 788
    .line 789
    .line 790
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 791
    const/4 v0, 0x7

    .line 792
    .line 793
    .line 794
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 795
    move-result-object v0

    .line 796
    .line 797
    check-cast v0, LTc/m;

    .line 798
    .line 799
    if-eqz v0, :cond_2c

    .line 800
    .line 801
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 802
    .line 803
    if-nez v0, :cond_2d

    .line 804
    :cond_2c
    move-object v0, v3

    .line 805
    .line 806
    :cond_2d
    const-string v1, "Flow Edit 8"

    .line 807
    .line 808
    .line 809
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 810
    .line 811
    const/16 v0, 0x8

    .line 812
    .line 813
    .line 814
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 815
    move-result-object v0

    .line 816
    .line 817
    check-cast v0, LTc/m;

    .line 818
    .line 819
    if-eqz v0, :cond_2e

    .line 820
    .line 821
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 822
    .line 823
    if-nez v0, :cond_2f

    .line 824
    :cond_2e
    move-object v0, v3

    .line 825
    .line 826
    :cond_2f
    const/4 v1, 0x0

    sget-object v1, Lva/ks/RWEdaNcGoAgPq;->NwVSkdbCtxJpLFm:Ljava/lang/String;

    .line 827
    .line 828
    .line 829
    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 830
    .line 831
    const/16 v0, 0x9

    .line 832
    .line 833
    .line 834
    invoke-static {v5, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 835
    move-result-object v0

    .line 836
    .line 837
    check-cast v0, LTc/m;

    .line 838
    .line 839
    if-eqz v0, :cond_31

    .line 840
    .line 841
    iget-object v0, v0, LTc/m;->a:Ljava/lang/String;

    .line 842
    .line 843
    if-nez v0, :cond_30

    .line 844
    goto :goto_b

    .line 845
    :cond_30
    move-object v3, v0

    .line 846
    .line 847
    :cond_31
    :goto_b
    const-string v0, "Flow Edit 10"

    .line 848
    .line 849
    .line 850
    invoke-interface {p1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 851
    .line 852
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 853
    return-object p1

    .line 854
    nop

    .line 855
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
