.class public final synthetic LBc/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:[I


# direct methods
.method public synthetic constructor <init>(II[I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, LBc/f;->a:I

    .line 5
    .line 6
    iput p2, p0, LBc/f;->b:I

    .line 7
    .line 8
    iput-object p3, p0, LBc/f;->c:[I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LBc/f;->c:[I

    .line 2
    .line 3
    iget v1, p0, LBc/f;->a:I

    .line 4
    .line 5
    iget v2, p0, LBc/f;->b:I

    .line 6
    .line 7
    invoke-static {v1, v2, v0}, Lorg/tezza/gpu_video/gpu/egl/filter_custom/coregraphics/GLESLog$Companion;->c(II[I)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method
