.class public abstract LAa/e;
.super LAa/f;
.source "AbstractBinaryClassAnnotationAndConstantLoader.kt"

# interfaces
.implements LUa/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        ">",
        "LAa/f<",
        "TA;",
        "LAa/i<",
        "+TA;+TC;>;>;",
        "LUa/e<",
        "TA;TC;>;"
    }
.end annotation


# instance fields
.field public final b:LXa/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LXa/h<",
            "LAa/x;",
            "LAa/i<",
            "TA;TC;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LXa/d;Lna/g;)V
    .locals 1

    .line 1
    const-string v0, "storageManager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "kotlinClassFinder"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0, p2}, LAa/f;-><init>(Lna/g;)V

    .line 12
    .line 13
    .line 14
    new-instance p2, LAa/a;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    invoke-direct {p2, v0, p0}, LAa/a;-><init>(ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1, p2}, LXa/d;->e(Lkotlin/jvm/functions/Function1;)LXa/d$k;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, LAa/e;->b:LXa/h;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final b(LUa/M;LCa/n;LYa/M;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            "LYa/M;",
            ")TC;"
        }
    .end annotation

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "expectedType"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget-object v4, LUa/d;->PROPERTY:LUa/d;

    .line 17
    .line 18
    sget-object v6, LAa/c;->a:LAa/c;

    .line 19
    .line 20
    move-object v1, p0

    .line 21
    move-object v2, p1

    .line 22
    move-object v3, p2

    .line 23
    move-object v5, p3

    .line 24
    invoke-virtual/range {v1 .. v6}, LAa/e;->s(LUa/M;LCa/n;LUa/d;LYa/M;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1
.end method

.method public final e(LUa/M;LCa/n;LYa/M;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            "LYa/M;",
            ")TC;"
        }
    .end annotation

    .line 1
    .line 2
    const/4 v0, 0x0

    sget-object v0, Lcom/google/android/play/core/common/bK/FTkQLWBMb;->IvqFPs:Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    const-string v0, "proto"

    .line 8
    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    const-string v0, "expectedType"

    .line 13
    .line 14
    .line 15
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    sget-object v4, LUa/d;->PROPERTY_GETTER:LUa/d;

    .line 18
    .line 19
    sget-object v6, LAa/b;->a:LAa/b;

    .line 20
    move-object v1, p0

    .line 21
    move-object v2, p1

    .line 22
    move-object v3, p2

    .line 23
    move-object v5, p3

    .line 24
    .line 25
    .line 26
    invoke-virtual/range {v1 .. v6}, LAa/e;->s(LUa/M;LCa/n;LUa/d;LYa/M;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 27
    move-result-object p1

    .line 28
    return-object p1
.end method

.method public final s(LUa/M;LCa/n;LUa/d;LYa/M;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            "LUa/d;",
            "LYa/M;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "LAa/i<",
            "+TA;+TC;>;-",
            "LAa/A;",
            "+TC;>;)TC;"
        }
    .end annotation

    .line 1
    sget-object v0, LEa/b;->B:LEa/b$a;

    .line 2
    .line 3
    iget v1, p2, LCa/n;->d:I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LEa/b$a;->c(I)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    invoke-static {p2}, LGa/g;->d(LCa/n;)Z

    .line 10
    .line 11
    .line 12
    move-result v6

    .line 13
    move-object v0, p0

    .line 14
    check-cast v0, LAa/j;

    .line 15
    .line 16
    iget-object v8, v0, LAa/j;->f:LEa/c;

    .line 17
    .line 18
    iget-object v7, p0, LAa/f;->a:Lna/g;

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    const/4 v4, 0x1

    .line 22
    move-object v2, p1

    .line 23
    invoke-static/range {v2 .. v8}, LAa/f$b;->a(LUa/M;ZZLjava/lang/Boolean;ZLna/g;LEa/c;)LAa/x;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    const-string v0, "container"

    .line 28
    .line 29
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    if-nez p1, :cond_2

    .line 34
    .line 35
    instance-of p1, v2, LUa/M$a;

    .line 36
    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    move-object p1, v2

    .line 40
    check-cast p1, LUa/M$a;

    .line 41
    .line 42
    iget-object p1, p1, LUa/M;->c:Lia/a0;

    .line 43
    .line 44
    instance-of v1, p1, LAa/z;

    .line 45
    .line 46
    if-eqz v1, :cond_0

    .line 47
    .line 48
    check-cast p1, LAa/z;

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move-object p1, v0

    .line 52
    :goto_0
    if-eqz p1, :cond_1

    .line 53
    .line 54
    iget-object p1, p1, LAa/z;->b:LAa/x;

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_1
    move-object p1, v0

    .line 58
    :cond_2
    :goto_1
    if-nez p1, :cond_3

    .line 59
    .line 60
    goto :goto_2

    .line 61
    :cond_3
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    iget-object v1, v1, LBa/a;->b:LEa/c;

    .line 66
    .line 67
    sget-object v3, LAa/p;->e:LEa/c;

    .line 68
    .line 69
    const-string v4, "version"

    .line 70
    .line 71
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    iget v4, v3, LEa/a;->b:I

    .line 75
    .line 76
    iget v5, v3, LEa/a;->c:I

    .line 77
    .line 78
    iget v3, v3, LEa/a;->d:I

    .line 79
    .line 80
    invoke-virtual {v1, v4, v5, v3}, LEa/a;->a(III)Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    iget-object v3, v2, LUa/M;->b:LEa/h;

    .line 85
    .line 86
    iget-object v2, v2, LUa/M;->a:LEa/d;

    .line 87
    .line 88
    invoke-static {p2, v2, v3, p3, v1}, LAa/f;->n(LIa/g$d;LEa/d;LEa/h;LUa/d;Z)LAa/A;

    .line 89
    .line 90
    .line 91
    move-result-object p2

    .line 92
    if-nez p2, :cond_4

    .line 93
    .line 94
    goto :goto_2

    .line 95
    :cond_4
    iget-object p3, p0, LAa/e;->b:LXa/h;

    .line 96
    .line 97
    check-cast p3, LXa/d$k;

    .line 98
    .line 99
    invoke-virtual {p3, p1}, LXa/d$k;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-interface {p5, p1, p2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    if-nez p1, :cond_5

    .line 108
    .line 109
    :goto_2
    return-object v0

    .line 110
    :cond_5
    invoke-static {p4}, Lfa/t;->a(LYa/M;)Z

    .line 111
    .line 112
    .line 113
    move-result p2

    .line 114
    if-eqz p2, :cond_9

    .line 115
    .line 116
    check-cast p1, LMa/g;

    .line 117
    .line 118
    const-string p2, "constant"

    .line 119
    .line 120
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    instance-of p2, p1, LMa/d;

    .line 124
    .line 125
    if-eqz p2, :cond_6

    .line 126
    .line 127
    new-instance p2, LMa/C;

    .line 128
    .line 129
    check-cast p1, LMa/d;

    .line 130
    .line 131
    iget-object p1, p1, LMa/g;->a:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast p1, Ljava/lang/Number;

    .line 134
    .line 135
    invoke-virtual {p1}, Ljava/lang/Number;->byteValue()B

    .line 136
    .line 137
    .line 138
    move-result p1

    .line 139
    invoke-direct {p2, p1}, LMa/C;-><init>(B)V

    .line 140
    .line 141
    .line 142
    return-object p2

    .line 143
    :cond_6
    instance-of p2, p1, LMa/y;

    .line 144
    .line 145
    if-eqz p2, :cond_7

    .line 146
    .line 147
    new-instance p2, LMa/F;

    .line 148
    .line 149
    check-cast p1, LMa/y;

    .line 150
    .line 151
    iget-object p1, p1, LMa/g;->a:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast p1, Ljava/lang/Number;

    .line 154
    .line 155
    invoke-virtual {p1}, Ljava/lang/Number;->shortValue()S

    .line 156
    .line 157
    .line 158
    move-result p1

    .line 159
    invoke-direct {p2, p1}, LMa/F;-><init>(S)V

    .line 160
    .line 161
    .line 162
    return-object p2

    .line 163
    :cond_7
    instance-of p2, p1, LMa/n;

    .line 164
    .line 165
    if-eqz p2, :cond_8

    .line 166
    .line 167
    new-instance p2, LMa/D;

    .line 168
    .line 169
    check-cast p1, LMa/n;

    .line 170
    .line 171
    iget-object p1, p1, LMa/g;->a:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast p1, Ljava/lang/Number;

    .line 174
    .line 175
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 176
    .line 177
    .line 178
    move-result p1

    .line 179
    invoke-direct {p2, p1}, LMa/D;-><init>(I)V

    .line 180
    .line 181
    .line 182
    return-object p2

    .line 183
    :cond_8
    instance-of p2, p1, LMa/w;

    .line 184
    .line 185
    if-eqz p2, :cond_9

    .line 186
    .line 187
    new-instance p2, LMa/E;

    .line 188
    .line 189
    check-cast p1, LMa/w;

    .line 190
    .line 191
    iget-object p1, p1, LMa/g;->a:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast p1, Ljava/lang/Number;

    .line 194
    .line 195
    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    .line 196
    .line 197
    .line 198
    move-result-wide p3

    .line 199
    invoke-direct {p2, p3, p4}, LMa/E;-><init>(J)V

    .line 200
    .line 201
    .line 202
    return-object p2

    .line 203
    :cond_9
    return-object p1
.end method
