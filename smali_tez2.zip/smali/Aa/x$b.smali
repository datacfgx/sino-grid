.class public interface abstract LAa/x$b;
.super Ljava/lang/Object;
.source "KotlinJvmBinaryClass.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b(LHa/b;LHa/f;)V
.end method

.method public abstract c(Ljava/lang/Object;)V
.end method

.method public abstract d(LHa/b;)LAa/x$a;
.end method

.method public abstract e(LMa/f;)V
.end method
