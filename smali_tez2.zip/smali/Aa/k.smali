.class public final LAa/k;
.super LAa/j$a;
.source "BinaryClassAnnotationAndConstantLoaderImpl.kt"


# instance fields
.field public final b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "LHa/f;",
            "LMa/g<",
            "*>;>;"
        }
    .end annotation
.end field

.field public final synthetic c:LAa/j;

.field public final synthetic d:Lia/e;

.field public final synthetic e:LHa/b;

.field public final synthetic f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lja/c;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic g:Lia/a0;


# direct methods
.method public constructor <init>(LAa/j;Lia/e;LHa/b;Ljava/util/List;Lia/a0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAa/j;",
            "Lia/e;",
            "LHa/b;",
            "Ljava/util/List<",
            "Lja/c;",
            ">;",
            "Lia/a0;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, LAa/k;->c:LAa/j;

    .line 2
    .line 3
    iput-object p2, p0, LAa/k;->d:Lia/e;

    .line 4
    .line 5
    iput-object p3, p0, LAa/k;->e:LHa/b;

    .line 6
    .line 7
    iput-object p4, p0, LAa/k;->f:Ljava/util/List;

    .line 8
    .line 9
    iput-object p5, p0, LAa/k;->g:Lia/a0;

    .line 10
    .line 11
    invoke-direct {p0, p1}, LAa/j$a;-><init>(LAa/j;)V

    .line 12
    .line 13
    .line 14
    new-instance p1, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, LAa/k;->b:Ljava/util/HashMap;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 7

    .line 1
    iget-object v0, p0, LAa/k;->b:Ljava/util/HashMap;

    .line 2
    .line 3
    iget-object v1, p0, LAa/k;->c:LAa/j;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v2, p0, LAa/k;->e:LHa/b;

    .line 9
    .line 10
    const-string v3, "annotationClassId"

    .line 11
    .line 12
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v3, "arguments"

    .line 16
    .line 17
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget-object v3, Lea/b;->b:LHa/b;

    .line 21
    .line 22
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    const/4 v4, 0x0

    .line 27
    if-nez v3, :cond_0

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_0
    const-string v3, "value"

    .line 31
    .line 32
    invoke-static {v3}, LHa/f;->m(Ljava/lang/String;)LHa/f;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    instance-of v5, v3, LMa/v;

    .line 41
    .line 42
    const/4 v6, 0x0

    .line 43
    if-eqz v5, :cond_1

    .line 44
    .line 45
    check-cast v3, LMa/v;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    move-object v3, v6

    .line 49
    :goto_0
    if-nez v3, :cond_2

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_2
    iget-object v3, v3, LMa/g;->a:Ljava/lang/Object;

    .line 53
    .line 54
    instance-of v5, v3, LMa/v$a$b;

    .line 55
    .line 56
    if-eqz v5, :cond_3

    .line 57
    .line 58
    move-object v6, v3

    .line 59
    check-cast v6, LMa/v$a$b;

    .line 60
    .line 61
    :cond_3
    if-nez v6, :cond_4

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_4
    iget-object v3, v6, LMa/v$a$b;->a:LMa/f;

    .line 65
    .line 66
    iget-object v3, v3, LMa/f;->a:LHa/b;

    .line 67
    .line 68
    invoke-virtual {v1, v3}, LAa/f;->o(LHa/b;)Z

    .line 69
    .line 70
    .line 71
    move-result v4

    .line 72
    :goto_1
    if-eqz v4, :cond_5

    .line 73
    .line 74
    goto :goto_2

    .line 75
    :cond_5
    invoke-virtual {v1, v2}, LAa/f;->o(LHa/b;)Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    if-eqz v1, :cond_6

    .line 80
    .line 81
    :goto_2
    return-void

    .line 82
    :cond_6
    new-instance v1, Lja/d;

    .line 83
    .line 84
    iget-object v2, p0, LAa/k;->d:Lia/e;

    .line 85
    .line 86
    invoke-interface {v2}, Lia/e;->s()LYa/W;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    iget-object v3, p0, LAa/k;->g:Lia/a0;

    .line 91
    .line 92
    invoke-direct {v1, v2, v0, v3}, Lja/d;-><init>(LYa/W;Ljava/util/Map;Lia/a0;)V

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, LAa/k;->f:Ljava/util/List;

    .line 96
    .line 97
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    return-void
.end method

.method public final g(LHa/f;LMa/g;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LHa/f;",
            "LMa/g<",
            "*>;)V"
        }
    .end annotation

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/k;->b:Ljava/util/HashMap;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    return-void
.end method
