.class public interface abstract LAa/v;
.super Ljava/lang/Object;
.source "KotlinClassFinder.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAa/v$a;
    }
.end annotation


# virtual methods
.method public abstract a(LHa/b;LEa/c;)LAa/v$a$b;
.end method
