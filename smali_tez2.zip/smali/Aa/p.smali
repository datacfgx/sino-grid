.class public final LAa/p;
.super Ljava/lang/Object;
.source "DeserializedDescriptorResolver.kt"


# static fields
.field public static final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LBa/a$a;",
            ">;"
        }
    .end annotation
.end field

.field public static final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LBa/a$a;",
            ">;"
        }
    .end annotation
.end field

.field public static final d:LEa/c;

.field public static final e:LEa/c;


# instance fields
.field public a:LUa/n;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    sget-object v0, LBa/a$a;->CLASS:LBa/a$a;

    .line 2
    .line 3
    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, LAa/p;->b:Ljava/util/Set;

    .line 8
    .line 9
    sget-object v0, LBa/a$a;->FILE_FACADE:LBa/a$a;

    .line 10
    .line 11
    sget-object v1, LBa/a$a;->MULTIFILE_CLASS_PART:LBa/a$a;

    .line 12
    .line 13
    filled-new-array {v0, v1}, [LBa/a$a;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, LAa/p;->c:Ljava/util/Set;

    .line 22
    .line 23
    new-instance v0, LEa/c;

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    const/4 v2, 0x2

    .line 27
    filled-new-array {v1, v1, v2}, [I

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-direct {v0, v2}, LEa/c;-><init>([I)V

    .line 32
    .line 33
    .line 34
    new-instance v0, LEa/c;

    .line 35
    .line 36
    const/16 v2, 0xb

    .line 37
    .line 38
    filled-new-array {v1, v1, v2}, [I

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-direct {v0, v2}, LEa/c;-><init>([I)V

    .line 43
    .line 44
    .line 45
    sput-object v0, LAa/p;->d:LEa/c;

    .line 46
    .line 47
    new-instance v0, LEa/c;

    .line 48
    .line 49
    const/16 v2, 0xd

    .line 50
    .line 51
    filled-new-array {v1, v1, v2}, [I

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    invoke-direct {v0, v1}, LEa/c;-><init>([I)V

    .line 56
    .line 57
    .line 58
    sput-object v0, LAa/p;->e:LEa/c;

    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final a(Lia/I;LAa/x;)LWa/D;
    .locals 11

    .line 1
    .line 2
    const-string v1, "Could not read data from "

    .line 3
    .line 4
    const-string v0, "descriptor"

    .line 5
    .line 6
    .line 7
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    const-string v0, "kotlinClass"

    .line 10
    .line 11
    .line 12
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p2}, LAa/x;->c()LBa/a;

    .line 16
    move-result-object v0

    .line 17
    .line 18
    iget-object v2, v0, LBa/a;->c:[Ljava/lang/String;

    .line 19
    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    iget-object v2, v0, LBa/a;->d:[Ljava/lang/String;

    .line 23
    :cond_0
    const/4 v3, 0x0

    .line 24
    .line 25
    if-eqz v2, :cond_1

    .line 26
    .line 27
    iget-object v0, v0, LBa/a;->a:LBa/a$a;

    .line 28
    .line 29
    sget-object v4, LAa/p;->c:Ljava/util/Set;

    .line 30
    .line 31
    .line 32
    invoke-interface {v4, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 33
    move-result v0

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    move-object v2, v3

    .line 38
    .line 39
    :goto_0
    if-nez v2, :cond_2

    .line 40
    goto :goto_3

    .line 41
    .line 42
    .line 43
    :cond_2
    invoke-interface {p2}, LAa/x;->c()LBa/a;

    .line 44
    move-result-object v0

    .line 45
    .line 46
    iget-object v0, v0, LBa/a;->e:[Ljava/lang/String;

    .line 47
    .line 48
    if-nez v0, :cond_3

    .line 49
    goto :goto_3

    .line 50
    .line 51
    .line 52
    :cond_3
    :try_start_0
    invoke-static {v2, v0}, LGa/g;->h([Ljava/lang/String;[Ljava/lang/String;)Lkotlin/Pair;

    .line 53
    move-result-object v0
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 54
    goto :goto_2

    .line 55
    :catchall_0
    move-exception v0

    .line 56
    goto :goto_1

    .line 57
    :catch_0
    move-exception v0

    .line 58
    .line 59
    :try_start_1
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 60
    .line 61
    new-instance v4, Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-interface {p2}, LAa/x;->getLocation()Ljava/lang/String;

    .line 68
    move-result-object v1

    .line 69
    .line 70
    .line 71
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    move-result-object v1

    .line 76
    .line 77
    .line 78
    invoke-direct {v2, v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 79
    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 80
    .line 81
    .line 82
    :goto_1
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 83
    move-result-object v1

    .line 84
    .line 85
    iget-object v1, v1, LUa/n;->c:LUa/o;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-interface {p2}, LAa/x;->c()LBa/a;

    .line 92
    move-result-object v1

    .line 93
    .line 94
    iget-object v1, v1, LBa/a;->b:LEa/c;

    .line 95
    .line 96
    .line 97
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 98
    move-result-object v2

    .line 99
    .line 100
    iget-object v2, v2, LUa/n;->c:LUa/o;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 104
    .line 105
    sget-object v2, LEa/c;->g:LEa/c;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v1, v2}, LEa/c;->b(LEa/c;)Z

    .line 109
    move-result v1

    .line 110
    .line 111
    if-nez v1, :cond_5

    .line 112
    move-object v0, v3

    .line 113
    .line 114
    :goto_2
    if-nez v0, :cond_4

    .line 115
    :goto_3
    return-object v3

    .line 116
    .line 117
    .line 118
    :cond_4
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    .line 119
    move-result-object v1

    .line 120
    move-object v5, v1

    .line 121
    .line 122
    check-cast v5, LGa/e;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    .line 126
    move-result-object v0

    .line 127
    move-object v4, v0

    .line 128
    .line 129
    check-cast v4, LCa/l;

    .line 130
    .line 131
    new-instance v7, LAa/s;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p0, p2}, LAa/p;->d(LAa/x;)LUa/y;

    .line 135
    .line 136
    .line 137
    invoke-virtual {p0, p2}, LAa/p;->e(LAa/x;)Z

    .line 138
    .line 139
    .line 140
    invoke-virtual {p0, p2}, LAa/p;->b(LAa/x;)LWa/s;

    .line 141
    move-result-object v0

    .line 142
    .line 143
    .line 144
    invoke-direct {v7, p2, v4, v5, v0}, LAa/s;-><init>(LAa/x;LCa/l;LGa/e;LWa/s;)V

    .line 145
    .line 146
    new-instance v2, LWa/D;

    .line 147
    .line 148
    .line 149
    invoke-interface {p2}, LAa/x;->c()LBa/a;

    .line 150
    move-result-object p2

    .line 151
    .line 152
    iget-object v6, p2, LBa/a;->b:LEa/c;

    .line 153
    .line 154
    .line 155
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 156
    move-result-object v8

    .line 157
    .line 158
    new-instance p2, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    const/4 v0, 0x0

    sget-object v0, Lt2/wQbq/xYDNK;->DsnaXbb:Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    const-string v0, " in "

    .line 169
    .line 170
    .line 171
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    move-result-object v9

    .line 179
    .line 180
    sget-object v10, LAa/o;->a:LAa/o;

    .line 181
    move-object v3, p1

    .line 182
    .line 183
    .line 184
    invoke-direct/range {v2 .. v10}, LWa/D;-><init>(Lia/I;LCa/l;LEa/d;LEa/a;LAa/s;LUa/n;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 185
    return-object v2

    .line 186
    :cond_5
    throw v0
.end method

.method public final b(LAa/x;)LWa/s;
    .locals 1

    .line 1
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget p1, p1, LBa/a;->g:I

    .line 15
    .line 16
    and-int/lit8 v0, p1, 0x10

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    and-int/lit8 p1, p1, 0x20

    .line 21
    .line 22
    if-eqz p1, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    sget-object p1, LWa/s;->UNSTABLE:LWa/s;

    .line 26
    .line 27
    return-object p1

    .line 28
    :cond_1
    :goto_0
    sget-object p1, LWa/s;->STABLE:LWa/s;

    .line 29
    .line 30
    return-object p1
.end method

.method public final c()LUa/n;
    .locals 1

    .line 1
    iget-object v0, p0, LAa/p;->a:LUa/n;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    const-string v0, "components"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0
.end method

.method public final d(LAa/x;)LUa/y;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAa/x;",
            ")",
            "LUa/y<",
            "LEa/c;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v0, v0, LBa/a;->b:LEa/c;

    .line 15
    .line 16
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    iget-object v1, v1, LUa/n;->c:LUa/o;

    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    sget-object v4, LEa/c;->g:LEa/c;

    .line 26
    .line 27
    invoke-virtual {v0, v4}, LEa/c;->b(LEa/c;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    const/4 p1, 0x0

    .line 34
    return-object p1

    .line 35
    :cond_0
    new-instance v2, LUa/y;

    .line 36
    .line 37
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iget-object v3, v0, LBa/a;->b:LEa/c;

    .line 42
    .line 43
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-object v0, v0, LBa/a;->b:LEa/c;

    .line 66
    .line 67
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-boolean v0, v0, LEa/c;->f:Z

    .line 71
    .line 72
    if-eqz v0, :cond_1

    .line 73
    .line 74
    move-object v0, v4

    .line 75
    goto :goto_0

    .line 76
    :cond_1
    sget-object v0, LEa/c;->h:LEa/c;

    .line 77
    .line 78
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    .line 80
    .line 81
    iget v1, v4, LEa/a;->b:I

    .line 82
    .line 83
    iget v5, v0, LEa/a;->b:I

    .line 84
    .line 85
    if-le v5, v1, :cond_2

    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_2
    if-ge v5, v1, :cond_3

    .line 89
    .line 90
    goto :goto_2

    .line 91
    :cond_3
    iget v1, v0, LEa/a;->c:I

    .line 92
    .line 93
    iget v5, v4, LEa/a;->c:I

    .line 94
    .line 95
    if-le v1, v5, :cond_4

    .line 96
    .line 97
    :goto_1
    move-object v6, v0

    .line 98
    goto :goto_3

    .line 99
    :cond_4
    :goto_2
    move-object v6, v4

    .line 100
    :goto_3
    invoke-interface {p1}, LAa/x;->getLocation()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v7

    .line 104
    invoke-interface {p1}, LAa/x;->b()LHa/b;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    move-object v5, v4

    .line 109
    invoke-direct/range {v2 .. v8}, LUa/y;-><init>(LEa/c;LEa/c;LEa/c;LEa/c;Ljava/lang/String;LHa/b;)V

    .line 110
    .line 111
    .line 112
    return-object v2
.end method

.method public final e(LAa/x;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v0, v0, LUa/n;->c:LUa/o;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget v0, v0, LBa/a;->g:I

    .line 24
    .line 25
    and-int/lit8 v0, v0, 0x2

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iget-object p1, p1, LBa/a;->b:LEa/c;

    .line 34
    .line 35
    sget-object v0, LAa/p;->d:LEa/c;

    .line 36
    .line 37
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_0

    .line 42
    .line 43
    const/4 p1, 0x1

    .line 44
    return p1

    .line 45
    :cond_0
    const/4 p1, 0x0

    .line 46
    return p1
.end method

.method public final f(LAa/x;)LUa/i;
    .locals 5

    .line 1
    const-string v0, "Could not read data from "

    .line 2
    .line 3
    const-string v1, "kotlinClass"

    .line 4
    .line 5
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v2, v1, LBa/a;->c:[Ljava/lang/String;

    .line 13
    .line 14
    if-nez v2, :cond_0

    .line 15
    .line 16
    iget-object v2, v1, LBa/a;->d:[Ljava/lang/String;

    .line 17
    .line 18
    :cond_0
    const/4 v3, 0x0

    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    iget-object v1, v1, LBa/a;->a:LBa/a$a;

    .line 22
    .line 23
    sget-object v4, LAa/p;->b:Ljava/util/Set;

    .line 24
    .line 25
    invoke-interface {v4, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    move-object v2, v3

    .line 33
    :goto_0
    if-nez v2, :cond_2

    .line 34
    .line 35
    goto :goto_3

    .line 36
    :cond_2
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    iget-object v1, v1, LBa/a;->e:[Ljava/lang/String;

    .line 41
    .line 42
    if-nez v1, :cond_3

    .line 43
    .line 44
    goto :goto_3

    .line 45
    :cond_3
    :try_start_0
    invoke-static {v2, v1}, LGa/g;->f([Ljava/lang/String;[Ljava/lang/String;)Lkotlin/Pair;

    .line 46
    .line 47
    .line 48
    move-result-object v0
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    goto :goto_2

    .line 50
    :catchall_0
    move-exception v0

    .line 51
    goto :goto_1

    .line 52
    :catch_0
    move-exception v1

    .line 53
    :try_start_1
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 54
    .line 55
    new-instance v4, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-interface {p1}, LAa/x;->getLocation()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-direct {v2, v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 72
    .line 73
    .line 74
    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 75
    :goto_1
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    iget-object v1, v1, LUa/n;->c:LUa/o;

    .line 80
    .line 81
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    iget-object v1, v1, LBa/a;->b:LEa/c;

    .line 89
    .line 90
    invoke-virtual {p0}, LAa/p;->c()LUa/n;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    iget-object v2, v2, LUa/n;->c:LUa/o;

    .line 95
    .line 96
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    sget-object v2, LEa/c;->g:LEa/c;

    .line 100
    .line 101
    invoke-virtual {v1, v2}, LEa/c;->b(LEa/c;)Z

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    if-nez v1, :cond_5

    .line 106
    .line 107
    move-object v0, v3

    .line 108
    :goto_2
    if-nez v0, :cond_4

    .line 109
    .line 110
    :goto_3
    return-object v3

    .line 111
    :cond_4
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    check-cast v1, LGa/e;

    .line 116
    .line 117
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    check-cast v0, LCa/b;

    .line 122
    .line 123
    new-instance v2, LAa/z;

    .line 124
    .line 125
    invoke-virtual {p0, p1}, LAa/p;->d(LAa/x;)LUa/y;

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0, p1}, LAa/p;->e(LAa/x;)Z

    .line 129
    .line 130
    .line 131
    invoke-virtual {p0, p1}, LAa/p;->b(LAa/x;)LWa/s;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    invoke-direct {v2, p1, v3}, LAa/z;-><init>(LAa/x;LWa/s;)V

    .line 136
    .line 137
    .line 138
    new-instance v3, LUa/i;

    .line 139
    .line 140
    invoke-interface {p1}, LAa/x;->c()LBa/a;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    iget-object p1, p1, LBa/a;->b:LEa/c;

    .line 145
    .line 146
    invoke-direct {v3, v1, v0, p1, v2}, LUa/i;-><init>(LEa/d;LCa/b;LEa/a;Lia/a0;)V

    .line 147
    .line 148
    .line 149
    return-object v3

    .line 150
    :cond_5
    throw v0
.end method
