.class public final LAa/f$b;
.super Ljava/lang/Object;
.source "AbstractBinaryClassAnnotationLoader.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(LUa/M;ZZLjava/lang/Boolean;ZLna/g;LEa/c;)LAa/x;
    .locals 3

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "kotlinClassFinder"

    .line 7
    .line 8
    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "metadataVersion"

    .line 12
    .line 13
    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    if-eqz p1, :cond_4

    .line 18
    .line 19
    if-eqz p3, :cond_3

    .line 20
    .line 21
    instance-of p1, p0, LUa/M$a;

    .line 22
    .line 23
    if-eqz p1, :cond_0

    .line 24
    .line 25
    move-object p1, p0

    .line 26
    check-cast p1, LUa/M$a;

    .line 27
    .line 28
    iget-object v1, p1, LUa/M$a;->g:LCa/b$c;

    .line 29
    .line 30
    sget-object v2, LCa/b$c;->INTERFACE:LCa/b$c;

    .line 31
    .line 32
    if-ne v1, v2, :cond_0

    .line 33
    .line 34
    const-string p0, "DefaultImpls"

    .line 35
    .line 36
    invoke-static {p0}, LHa/f;->m(Ljava/lang/String;)LHa/f;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    const-string p2, "identifier(...)"

    .line 41
    .line 42
    invoke-static {p0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p1, LUa/M$a;->f:LHa/b;

    .line 46
    .line 47
    invoke-virtual {p1, p0}, LHa/b;->d(LHa/f;)LHa/b;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-static {p5, p0, p6}, LAa/w;->a(LAa/v;LHa/b;LEa/c;)LAa/x;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :cond_0
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    if-eqz p1, :cond_4

    .line 61
    .line 62
    instance-of p1, p0, LUa/M$b;

    .line 63
    .line 64
    if-eqz p1, :cond_4

    .line 65
    .line 66
    iget-object p1, p0, LUa/M;->c:Lia/a0;

    .line 67
    .line 68
    instance-of p3, p1, LAa/s;

    .line 69
    .line 70
    if-eqz p3, :cond_1

    .line 71
    .line 72
    check-cast p1, LAa/s;

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_1
    move-object p1, v0

    .line 76
    :goto_0
    if-eqz p1, :cond_2

    .line 77
    .line 78
    iget-object p1, p1, LAa/s;->c:LPa/d;

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_2
    move-object p1, v0

    .line 82
    :goto_1
    if-eqz p1, :cond_4

    .line 83
    .line 84
    new-instance p0, LHa/c;

    .line 85
    .line 86
    invoke-virtual {p1}, LPa/d;->d()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    const-string p2, "getInternalName(...)"

    .line 91
    .line 92
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    const/16 p2, 0x2f

    .line 96
    .line 97
    const/16 p3, 0x2e

    .line 98
    .line 99
    invoke-static {p1, p2, p3}, Lkotlin/text/o;->k(Ljava/lang/String;CC)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-direct {p0, p1}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    const-string p1, "topLevelFqName"

    .line 107
    .line 108
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    new-instance p1, LHa/b;

    .line 112
    .line 113
    invoke-virtual {p0}, LHa/c;->b()LHa/c;

    .line 114
    .line 115
    .line 116
    move-result-object p2

    .line 117
    iget-object p0, p0, LHa/c;->a:LHa/d;

    .line 118
    .line 119
    invoke-virtual {p0}, LHa/d;->f()LHa/f;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    invoke-direct {p1, p2, p0}, LHa/b;-><init>(LHa/c;LHa/f;)V

    .line 124
    .line 125
    .line 126
    invoke-static {p5, p1, p6}, LAa/w;->a(LAa/v;LHa/b;LEa/c;)LAa/x;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    return-object p0

    .line 131
    :cond_3
    new-instance p1, Ljava/lang/StringBuilder;

    .line 132
    .line 133
    const-string p2, "isConst should not be null for property (container="

    .line 134
    .line 135
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    const/16 p0, 0x29

    .line 142
    .line 143
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object p0

    .line 150
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 151
    .line 152
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object p0

    .line 156
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw p1

    .line 160
    :cond_4
    if-eqz p2, :cond_7

    .line 161
    .line 162
    instance-of p1, p0, LUa/M$a;

    .line 163
    .line 164
    if-eqz p1, :cond_7

    .line 165
    .line 166
    move-object p1, p0

    .line 167
    check-cast p1, LUa/M$a;

    .line 168
    .line 169
    iget-object p2, p1, LUa/M$a;->g:LCa/b$c;

    .line 170
    .line 171
    sget-object p3, LCa/b$c;->COMPANION_OBJECT:LCa/b$c;

    .line 172
    .line 173
    if-ne p2, p3, :cond_7

    .line 174
    .line 175
    iget-object p1, p1, LUa/M$a;->e:LUa/M$a;

    .line 176
    .line 177
    if-eqz p1, :cond_7

    .line 178
    .line 179
    sget-object p2, LCa/b$c;->CLASS:LCa/b$c;

    .line 180
    .line 181
    iget-object p3, p1, LUa/M$a;->g:LCa/b$c;

    .line 182
    .line 183
    if-eq p3, p2, :cond_5

    .line 184
    .line 185
    sget-object p2, LCa/b$c;->ENUM_CLASS:LCa/b$c;

    .line 186
    .line 187
    if-eq p3, p2, :cond_5

    .line 188
    .line 189
    if-eqz p4, :cond_7

    .line 190
    .line 191
    sget-object p2, LCa/b$c;->INTERFACE:LCa/b$c;

    .line 192
    .line 193
    if-eq p3, p2, :cond_5

    .line 194
    .line 195
    sget-object p2, LCa/b$c;->ANNOTATION_CLASS:LCa/b$c;

    .line 196
    .line 197
    if-ne p3, p2, :cond_7

    .line 198
    .line 199
    :cond_5
    iget-object p0, p1, LUa/M;->c:Lia/a0;

    .line 200
    .line 201
    instance-of p1, p0, LAa/z;

    .line 202
    .line 203
    if-eqz p1, :cond_6

    .line 204
    .line 205
    check-cast p0, LAa/z;

    .line 206
    .line 207
    goto :goto_2

    .line 208
    :cond_6
    move-object p0, v0

    .line 209
    :goto_2
    if-eqz p0, :cond_9

    .line 210
    .line 211
    iget-object p0, p0, LAa/z;->b:LAa/x;

    .line 212
    .line 213
    return-object p0

    .line 214
    :cond_7
    instance-of p1, p0, LUa/M$b;

    .line 215
    .line 216
    if-eqz p1, :cond_9

    .line 217
    .line 218
    iget-object p0, p0, LUa/M;->c:Lia/a0;

    .line 219
    .line 220
    instance-of p1, p0, LAa/s;

    .line 221
    .line 222
    if-eqz p1, :cond_9

    .line 223
    .line 224
    const-string p1, "null cannot be cast to non-null type org.jetbrains.kotlin.load.kotlin.JvmPackagePartSource"

    .line 225
    .line 226
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    check-cast p0, LAa/s;

    .line 230
    .line 231
    iget-object p1, p0, LAa/s;->d:LAa/x;

    .line 232
    .line 233
    if-nez p1, :cond_8

    .line 234
    .line 235
    invoke-virtual {p0}, LAa/s;->c()LHa/b;

    .line 236
    .line 237
    .line 238
    move-result-object p0

    .line 239
    invoke-static {p5, p0, p6}, LAa/w;->a(LAa/v;LHa/b;LEa/c;)LAa/x;

    .line 240
    .line 241
    .line 242
    move-result-object p0

    .line 243
    return-object p0

    .line 244
    :cond_8
    return-object p1

    .line 245
    :cond_9
    return-object v0
.end method
