.class public final LAa/q;
.super Ljava/lang/Object;
.source "JavaClassDataFinder.kt"

# interfaces
.implements LUa/j;


# instance fields
.field public final a:Lna/g;

.field public final b:LAa/p;


# direct methods
.method public constructor <init>(LAa/p;Lna/g;)V
    .locals 1

    .line 1
    const-string v0, "kotlinClassFinder"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "deserializedDescriptorResolver"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p2, p0, LAa/q;->a:Lna/g;

    .line 15
    .line 16
    iput-object p1, p0, LAa/q;->b:LAa/p;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a(LHa/b;)LUa/i;
    .locals 3

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/q;->b:LAa/p;

    .line 7
    .line 8
    invoke-virtual {v0}, LAa/p;->c()LUa/n;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v1, v1, LUa/n;->c:LUa/o;

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    sget-object v1, LEa/c;->g:LEa/c;

    .line 18
    .line 19
    iget-object v2, p0, LAa/q;->a:Lna/g;

    .line 20
    .line 21
    invoke-static {v2, p1, v1}, LAa/w;->a(LAa/v;LHa/b;LEa/c;)LAa/x;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    const/4 p1, 0x0

    .line 28
    return-object p1

    .line 29
    :cond_0
    move-object v2, v1

    .line 30
    check-cast v2, Lna/f;

    .line 31
    .line 32
    iget-object v2, v2, Lna/f;->a:Ljava/lang/Class;

    .line 33
    .line 34
    invoke-static {v2}, Loa/f;->a(Ljava/lang/Class;)LHa/b;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {v2, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v1}, LAa/p;->f(LAa/x;)LUa/i;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    return-object p1
.end method
