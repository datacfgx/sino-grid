.class public final LAa/j$a$a;
.super Ljava/lang/Object;
.source "BinaryClassAnnotationAndConstantLoaderImpl.kt"

# interfaces
.implements LAa/x$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAa/j$a;->c(LHa/b;LHa/f;)LAa/x$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic a:LAa/k;

.field public final synthetic b:LAa/k;

.field public final synthetic c:LAa/j$a;

.field public final synthetic d:LHa/f;

.field public final synthetic e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lja/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LAa/k;LAa/j$a;LHa/f;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAa/j$a$a;->b:LAa/k;

    .line 5
    .line 6
    iput-object p2, p0, LAa/j$a$a;->c:LAa/j$a;

    .line 7
    .line 8
    iput-object p3, p0, LAa/j$a$a;->d:LHa/f;

    .line 9
    .line 10
    iput-object p4, p0, LAa/j$a$a;->e:Ljava/util/ArrayList;

    .line 11
    .line 12
    iput-object p1, p0, LAa/j$a$a;->a:LAa/k;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, LAa/j$a$a;->b:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0}, LAa/k;->a()V

    .line 4
    .line 5
    .line 6
    new-instance v0, LMa/a;

    .line 7
    .line 8
    iget-object v1, p0, LAa/j$a$a;->e:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->single(Ljava/util/List;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Lja/c;

    .line 15
    .line 16
    invoke-direct {v0, v1}, LMa/a;-><init>(Lja/c;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, LAa/j$a$a;->d:LHa/f;

    .line 20
    .line 21
    iget-object v2, p0, LAa/j$a$a;->c:LAa/j$a;

    .line 22
    .line 23
    invoke-virtual {v2, v1, v0}, LAa/j$a;->g(LHa/f;LMa/g;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final b(LHa/f;LMa/f;)V
    .locals 1

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/j$a$a;->a:LAa/k;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, LAa/j$a;->b(LHa/f;LMa/f;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final c(LHa/b;LHa/f;)LAa/x$a;
    .locals 1

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/j$a$a;->a:LAa/k;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, LAa/j$a;->c(LHa/b;LHa/f;)LAa/x$a;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public final d(LHa/f;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LAa/j$a$a;->a:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LAa/j$a;->d(LHa/f;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e(LHa/f;LHa/b;LHa/f;)V
    .locals 1

    .line 1
    const-string v0, "enumClassId"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "enumEntryName"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LAa/j$a$a;->a:LAa/k;

    .line 12
    .line 13
    invoke-virtual {v0, p1, p2, p3}, LAa/j$a;->e(LHa/f;LHa/b;LHa/f;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final f(LHa/f;)LAa/x$b;
    .locals 1

    .line 1
    iget-object v0, p0, LAa/j$a$a;->a:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LAa/j$a;->f(LHa/f;)LAa/x$b;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
