.class public final LAa/t$c;
.super LAa/t;
.source "methodSignatureMapping.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final i:LPa/e;


# direct methods
.method public constructor <init>(LPa/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LAa/t;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAa/t$c;->i:LPa/e;

    .line 5
    .line 6
    return-void
.end method
