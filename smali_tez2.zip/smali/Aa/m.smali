.class public final LAa/m;
.super Ljava/lang/Object;
.source "DeserializationComponentsForJava.kt"


# instance fields
.field public final a:LUa/n;


# direct methods
.method public constructor <init>(LXa/d;Lla/E;LAa/q;LAa/j;Lua/h;Lia/H;LZa/m;Lbb/a;)V
    .locals 17

    .line 1
    move-object/from16 v1, p1

    .line 2
    .line 3
    move-object/from16 v2, p2

    .line 4
    .line 5
    move-object/from16 v0, p8

    .line 6
    .line 7
    sget-object v3, LUa/o;->a:LUa/o;

    .line 8
    .line 9
    sget-object v6, Lna/i;->b:Lna/i;

    .line 10
    .line 11
    sget-object v4, Lqa/c;->a:Lqa/c;

    .line 12
    .line 13
    sget-object v5, LUa/m;->a:LUa/m$a;

    .line 14
    .line 15
    const-string v7, "storageManager"

    .line 16
    .line 17
    invoke-static {v1, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const-string v7, "moduleDescriptor"

    .line 21
    .line 22
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const-string v7, "configuration"

    .line 26
    .line 27
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string v3, "classDataFinder"

    .line 31
    .line 32
    move-object/from16 v7, p3

    .line 33
    .line 34
    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v3, "annotationAndConstantLoader"

    .line 38
    .line 39
    move-object/from16 v8, p4

    .line 40
    .line 41
    invoke-static {v8, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    const-string v3, "packageFragmentProvider"

    .line 45
    .line 46
    move-object/from16 v9, p5

    .line 47
    .line 48
    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    const-string v3, "notFoundClasses"

    .line 52
    .line 53
    move-object/from16 v10, p6

    .line 54
    .line 55
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    const-string v3, "errorReporter"

    .line 59
    .line 60
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const-string v3, "lookupTracker"

    .line 64
    .line 65
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string v3, "contractDeserializer"

    .line 69
    .line 70
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    const-string v3, "kotlinTypeChecker"

    .line 74
    .line 75
    move-object/from16 v13, p7

    .line 76
    .line 77
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    const-string v3, "typeAttributeTranslators"

    .line 81
    .line 82
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 86
    .line 87
    .line 88
    iget-object v3, v2, Lla/E;->d:Lfa/l;

    .line 89
    .line 90
    instance-of v4, v3, Lha/i;

    .line 91
    .line 92
    if-eqz v4, :cond_0

    .line 93
    .line 94
    check-cast v3, Lha/i;

    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_0
    const/4 v3, 0x0

    .line 98
    :goto_0
    new-instance v4, LUa/n;

    .line 99
    .line 100
    sget-object v7, LAa/r;->a:LAa/r;

    .line 101
    .line 102
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    check-cast v5, Ljava/lang/Iterable;

    .line 107
    .line 108
    if-eqz v3, :cond_1

    .line 109
    .line 110
    invoke-virtual {v3}, Lha/i;->L()Lha/o;

    .line 111
    .line 112
    .line 113
    move-result-object v11

    .line 114
    if-eqz v11, :cond_1

    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_1
    sget-object v11, Lka/a$a;->a:Lka/a$a;

    .line 118
    .line 119
    :goto_1
    if-eqz v3, :cond_2

    .line 120
    .line 121
    invoke-virtual {v3}, Lha/i;->L()Lha/o;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    if-eqz v3, :cond_2

    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_2
    sget-object v3, Lka/c$b;->a:Lka/c$b;

    .line 129
    .line 130
    :goto_2
    sget-object v12, LGa/g;->a:LIa/e;

    .line 131
    .line 132
    new-instance v14, LQa/a;

    .line 133
    .line 134
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 135
    .line 136
    .line 137
    move-result-object v15

    .line 138
    check-cast v15, Ljava/lang/Iterable;

    .line 139
    .line 140
    invoke-direct {v14, v1, v15}, LQa/a;-><init>(LXa/d;Ljava/lang/Iterable;)V

    .line 141
    .line 142
    .line 143
    sget-object v16, LUa/z;->a:LUa/z;

    .line 144
    .line 145
    iget-object v15, v0, Lbb/a;->a:Ljava/util/List;

    .line 146
    .line 147
    move-object v0, v4

    .line 148
    move-object v4, v8

    .line 149
    move-object v8, v5

    .line 150
    move-object v5, v9

    .line 151
    move-object v9, v10

    .line 152
    move-object v10, v11

    .line 153
    move-object v11, v3

    .line 154
    move-object/from16 v3, p3

    .line 155
    .line 156
    invoke-direct/range {v0 .. v16}, LUa/n;-><init>(LXa/d;Lia/D;LUa/j;LUa/e;Lia/O;LUa/w;LUa/x;Ljava/lang/Iterable;Lia/H;Lka/a;Lka/c;LIa/e;LZa/l;LQa/a;Ljava/util/List;LUa/v;)V

    .line 157
    .line 158
    .line 159
    move-object v1, v0

    .line 160
    move-object/from16 v0, p0

    .line 161
    .line 162
    iput-object v1, v0, LAa/m;->a:LUa/n;

    .line 163
    .line 164
    return-void
.end method
