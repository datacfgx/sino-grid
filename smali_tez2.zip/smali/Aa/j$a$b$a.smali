.class public final LAa/j$a$b$a;
.super Ljava/lang/Object;
.source "BinaryClassAnnotationAndConstantLoaderImpl.kt"

# interfaces
.implements LAa/x$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAa/j$a$b;->d(LHa/b;)LAa/x$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic a:LAa/k;

.field public final synthetic b:LAa/k;

.field public final synthetic c:LAa/j$a$b;

.field public final synthetic d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lja/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LAa/k;LAa/j$a$b;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAa/j$a$b$a;->b:LAa/k;

    .line 5
    .line 6
    iput-object p2, p0, LAa/j$a$b$a;->c:LAa/j$a$b;

    .line 7
    .line 8
    iput-object p3, p0, LAa/j$a$b$a;->d:Ljava/util/ArrayList;

    .line 9
    .line 10
    iput-object p1, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, LAa/j$a$b$a;->b:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0}, LAa/k;->a()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/j$a$b$a;->c:LAa/j$a$b;

    .line 7
    .line 8
    iget-object v0, v0, LAa/j$a$b;->a:Ljava/util/ArrayList;

    .line 9
    .line 10
    new-instance v1, LMa/a;

    .line 11
    .line 12
    iget-object v2, p0, LAa/j$a$b$a;->d:Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->single(Ljava/util/List;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    check-cast v2, Lja/c;

    .line 19
    .line 20
    invoke-direct {v1, v2}, LMa/a;-><init>(Lja/c;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final b(LHa/f;LMa/f;)V
    .locals 1

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, LAa/j$a;->b(LHa/f;LMa/f;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final c(LHa/b;LHa/f;)LAa/x$a;
    .locals 1

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, LAa/j$a;->c(LHa/b;LHa/f;)LAa/x$a;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public final d(LHa/f;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LAa/j$a;->d(LHa/f;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e(LHa/f;LHa/b;LHa/f;)V
    .locals 1

    .line 1
    const-string v0, "enumClassId"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "enumEntryName"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 12
    .line 13
    invoke-virtual {v0, p1, p2, p3}, LAa/j$a;->e(LHa/f;LHa/b;LHa/f;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final f(LHa/f;)LAa/x$b;
    .locals 1

    .line 1
    iget-object v0, p0, LAa/j$a$b$a;->a:LAa/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LAa/j$a;->f(LHa/f;)LAa/x$b;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
