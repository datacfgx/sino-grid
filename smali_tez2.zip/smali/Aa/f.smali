.class public abstract LAa/f;
.super Ljava/lang/Object;
.source "AbstractBinaryClassAnnotationLoader.kt"

# interfaces
.implements LUa/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAa/f$a;,
        LAa/f$b;,
        LAa/f$c;,
        LAa/f$d;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "S:",
        "LAa/f$a<",
        "+TA;>;>",
        "Ljava/lang/Object;",
        "LUa/h<",
        "TA;>;"
    }
.end annotation


# instance fields
.field public final a:Lna/g;


# direct methods
.method public constructor <init>(Lna/g;)V
    .locals 1

    .line 1
    const-string v0, "kotlinClassFinder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LAa/f;->a:Lna/g;

    .line 10
    .line 11
    return-void
.end method

.method public static synthetic m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;
    .locals 9

    .line 1
    and-int/lit8 v0, p5, 0x4

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move v5, v1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x1

    .line 9
    move v5, v0

    .line 10
    :goto_0
    and-int/lit8 v0, p5, 0x10

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    const/4 p3, 0x0

    .line 15
    :cond_1
    move-object v7, p3

    .line 16
    and-int/lit8 p3, p5, 0x20

    .line 17
    .line 18
    if-eqz p3, :cond_2

    .line 19
    .line 20
    move v8, v1

    .line 21
    goto :goto_1

    .line 22
    :cond_2
    move v8, p4

    .line 23
    :goto_1
    const/4 v6, 0x0

    .line 24
    move-object v2, p0

    .line 25
    move-object v3, p1

    .line 26
    move-object v4, p2

    .line 27
    invoke-virtual/range {v2 .. v8}, LAa/f;->l(LUa/M;LAa/A;ZZLjava/lang/Boolean;Z)Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0
.end method

.method public static n(LIa/g$d;LEa/d;LEa/h;LUa/d;Z)LAa/A;
    .locals 9

    .line 1
    const-string v0, "proto"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "nameResolver"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v1, "typeTable"

    .line 12
    .line 13
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v1, "kind"

    .line 17
    .line 18
    invoke-static {p3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    instance-of v1, p0, LCa/d;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    if-eqz v1, :cond_1

    .line 25
    .line 26
    sget-object p3, LGa/g;->a:LIa/e;

    .line 27
    .line 28
    check-cast p0, LCa/d;

    .line 29
    .line 30
    invoke-static {p0, p1, p2}, LGa/g;->a(LCa/d;LEa/d;LEa/h;)LGa/d$b;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    if-nez p0, :cond_0

    .line 35
    .line 36
    goto/16 :goto_0

    .line 37
    .line 38
    :cond_0
    invoke-static {p0}, LAa/A$a;->a(LGa/d;)LAa/A;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0

    .line 43
    :cond_1
    instance-of v1, p0, LCa/i;

    .line 44
    .line 45
    if-eqz v1, :cond_3

    .line 46
    .line 47
    sget-object p3, LGa/g;->a:LIa/e;

    .line 48
    .line 49
    check-cast p0, LCa/i;

    .line 50
    .line 51
    invoke-static {p0, p1, p2}, LGa/g;->c(LCa/i;LEa/d;LEa/h;)LGa/d$b;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    if-nez p0, :cond_2

    .line 56
    .line 57
    goto/16 :goto_0

    .line 58
    .line 59
    :cond_2
    invoke-static {p0}, LAa/A$a;->a(LGa/d;)LAa/A;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    return-object p0

    .line 64
    :cond_3
    instance-of v1, p0, LCa/n;

    .line 65
    .line 66
    if-eqz v1, :cond_9

    .line 67
    .line 68
    sget-object v1, LFa/a;->d:LIa/g$f;

    .line 69
    .line 70
    const-string v3, "propertySignature"

    .line 71
    .line 72
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-static {p0, v1}, LEa/f;->a(LIa/g$d;LIa/g$f;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, LFa/a$c;

    .line 80
    .line 81
    if-nez v1, :cond_4

    .line 82
    .line 83
    goto/16 :goto_0

    .line 84
    .line 85
    :cond_4
    sget-object v3, LAa/f$d;->a:[I

    .line 86
    .line 87
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 88
    .line 89
    .line 90
    move-result p3

    .line 91
    aget p3, v3, p3

    .line 92
    .line 93
    const/4 v3, 0x1

    .line 94
    const-string v4, "desc"

    .line 95
    .line 96
    const-string v5, "name"

    .line 97
    .line 98
    const-string v6, "signature"

    .line 99
    .line 100
    if-eq p3, v3, :cond_8

    .line 101
    .line 102
    const/4 v3, 0x2

    .line 103
    if-eq p3, v3, :cond_6

    .line 104
    .line 105
    const/4 v0, 0x3

    .line 106
    if-eq p3, v0, :cond_5

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_5
    move-object v3, p0

    .line 110
    check-cast v3, LCa/n;

    .line 111
    .line 112
    const/4 v6, 0x1

    .line 113
    const/4 v7, 0x1

    .line 114
    move-object v4, p1

    .line 115
    move-object v5, p2

    .line 116
    move v8, p4

    .line 117
    invoke-static/range {v3 .. v8}, LAa/h;->a(LCa/n;LEa/d;LEa/h;ZZZ)LAa/A;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    return-object p0

    .line 122
    :cond_6
    move-object p0, p1

    .line 123
    iget p1, v1, LFa/a$c;->b:I

    .line 124
    .line 125
    const/16 p2, 0x8

    .line 126
    .line 127
    and-int/2addr p1, p2

    .line 128
    if-ne p1, p2, :cond_7

    .line 129
    .line 130
    iget-object p1, v1, LFa/a$c;->i:LFa/a$b;

    .line 131
    .line 132
    const-string p2, "getSetter(...)"

    .line 133
    .line 134
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    iget p2, p1, LFa/a$b;->c:I

    .line 144
    .line 145
    invoke-interface {p0, p2}, LEa/d;->b(I)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object p2

    .line 149
    iget p1, p1, LFa/a$b;->d:I

    .line 150
    .line 151
    invoke-interface {p0, p1}, LEa/d;->b(I)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object p0

    .line 155
    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    invoke-static {p0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    new-instance p1, LAa/A;

    .line 162
    .line 163
    invoke-static {p2, p0}, LE0/x;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p0

    .line 167
    invoke-direct {p1, p0}, LAa/A;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    return-object p1

    .line 171
    :cond_7
    return-object v2

    .line 172
    :cond_8
    move-object p0, p1

    .line 173
    iget p1, v1, LFa/a$c;->b:I

    .line 174
    .line 175
    const/4 p2, 0x4

    .line 176
    and-int/2addr p1, p2

    .line 177
    if-ne p1, p2, :cond_9

    .line 178
    .line 179
    iget-object p1, v1, LFa/a$c;->e:LFa/a$b;

    .line 180
    .line 181
    const-string p2, "getGetter(...)"

    .line 182
    .line 183
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    iget p2, p1, LFa/a$b;->c:I

    .line 193
    .line 194
    invoke-interface {p0, p2}, LEa/d;->b(I)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p2

    .line 198
    iget p1, p1, LFa/a$b;->d:I

    .line 199
    .line 200
    invoke-interface {p0, p1}, LEa/d;->b(I)Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object p0

    .line 204
    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    invoke-static {p0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    new-instance p1, LAa/A;

    .line 211
    .line 212
    invoke-static {p2, p0}, LE0/x;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object p0

    .line 216
    invoke-direct {p1, p0}, LAa/A;-><init>(Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    return-object p1

    .line 220
    :cond_9
    :goto_0
    return-object v2
.end method


# virtual methods
.method public final a(LUa/M;LIa/g$d;LUa/d;ILCa/u;)Ljava/util/List;
    .locals 9

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "callableProto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "kind"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "proto"

    .line 17
    .line 18
    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object p5, p1, LUa/M;->b:LEa/h;

    .line 22
    .line 23
    iget-object v0, p1, LUa/M;->a:LEa/d;

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    invoke-static {p2, v0, p5, p3, v1}, LAa/f;->n(LIa/g$d;LEa/d;LEa/h;LUa/d;Z)LAa/A;

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    if-eqz p3, :cond_7

    .line 31
    .line 32
    instance-of p5, p2, LCa/i;

    .line 33
    .line 34
    const-string v0, "<this>"

    .line 35
    .line 36
    const/16 v2, 0x40

    .line 37
    .line 38
    const/16 v3, 0x20

    .line 39
    .line 40
    const/4 v4, 0x1

    .line 41
    if-eqz p5, :cond_1

    .line 42
    .line 43
    check-cast p2, LCa/i;

    .line 44
    .line 45
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget p2, p2, LCa/i;->c:I

    .line 49
    .line 50
    and-int/lit8 p5, p2, 0x20

    .line 51
    .line 52
    if-ne p5, v3, :cond_0

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_0
    and-int/2addr p2, v2

    .line 56
    if-ne p2, v2, :cond_5

    .line 57
    .line 58
    :goto_0
    move v1, v4

    .line 59
    goto :goto_2

    .line 60
    :cond_1
    instance-of p5, p2, LCa/n;

    .line 61
    .line 62
    if-eqz p5, :cond_3

    .line 63
    .line 64
    check-cast p2, LCa/n;

    .line 65
    .line 66
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    iget p2, p2, LCa/n;->c:I

    .line 70
    .line 71
    and-int/lit8 p5, p2, 0x20

    .line 72
    .line 73
    if-ne p5, v3, :cond_2

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_2
    and-int/2addr p2, v2

    .line 77
    if-ne p2, v2, :cond_5

    .line 78
    .line 79
    :goto_1
    goto :goto_0

    .line 80
    :cond_3
    instance-of p5, p2, LCa/d;

    .line 81
    .line 82
    if-eqz p5, :cond_6

    .line 83
    .line 84
    const-string p2, "null cannot be cast to non-null type org.jetbrains.kotlin.serialization.deserialization.ProtoContainer.Class"

    .line 85
    .line 86
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    move-object p2, p1

    .line 90
    check-cast p2, LUa/M$a;

    .line 91
    .line 92
    sget-object p5, LCa/b$c;->ENUM_CLASS:LCa/b$c;

    .line 93
    .line 94
    iget-object v0, p2, LUa/M$a;->g:LCa/b$c;

    .line 95
    .line 96
    if-ne v0, p5, :cond_4

    .line 97
    .line 98
    const/4 v1, 0x2

    .line 99
    goto :goto_2

    .line 100
    :cond_4
    iget-boolean p2, p2, LUa/M$a;->h:Z

    .line 101
    .line 102
    if-eqz p2, :cond_5

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_5
    :goto_2
    add-int/2addr p4, v1

    .line 106
    const-string p2, "signature"

    .line 107
    .line 108
    invoke-static {p3, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    new-instance v5, LAa/A;

    .line 112
    .line 113
    new-instance p2, Ljava/lang/StringBuilder;

    .line 114
    .line 115
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 116
    .line 117
    .line 118
    iget-object p3, p3, LAa/A;->a:Ljava/lang/String;

    .line 119
    .line 120
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 127
    .line 128
    .line 129
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    invoke-direct {v5, p2}, LAa/A;-><init>(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    const/4 v6, 0x0

    .line 137
    const/4 v7, 0x0

    .line 138
    const/16 v8, 0x3c

    .line 139
    .line 140
    move-object v3, p0

    .line 141
    move-object v4, p1

    .line 142
    invoke-static/range {v3 .. v8}, LAa/f;->m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    return-object p1

    .line 147
    :cond_6
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 148
    .line 149
    new-instance p3, Ljava/lang/StringBuilder;

    .line 150
    .line 151
    const-string p4, "Unsupported message: "

    .line 152
    .line 153
    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    move-result-object p2

    .line 160
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p2

    .line 167
    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    throw p1

    .line 171
    :cond_7
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    return-object p1
.end method

.method public final c(LCa/q;LEa/d;)Ljava/util/ArrayList;
    .locals 5

    .line 1
    const-string v0, "proto"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "nameResolver"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v2, LFa/a;->f:LIa/g$f;

    .line 12
    .line 13
    invoke-virtual {p1, v2}, LIa/g$d;->l(LIa/g$f;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string v2, "getExtension(...)"

    .line 18
    .line 19
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p1, Ljava/lang/Iterable;

    .line 23
    .line 24
    new-instance v2, Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 31
    .line 32
    .line 33
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_0

    .line 42
    .line 43
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, LCa/a;

    .line 48
    .line 49
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    move-object v4, p0

    .line 53
    check-cast v4, LAa/j;

    .line 54
    .line 55
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    iget-object v4, v4, LAa/j;->e:LUa/g;

    .line 62
    .line 63
    invoke-virtual {v4, v3, p2}, LUa/g;->a(LCa/a;LEa/d;)Lja/d;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_0
    return-object v2
.end method

.method public final d(LUa/M$a;)Ljava/util/ArrayList;
    .locals 3

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, LUa/M;->c:Lia/a0;

    .line 7
    .line 8
    instance-of v1, v0, LAa/z;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    check-cast v0, LAa/z;

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move-object v0, v2

    .line 17
    :goto_0
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget-object v2, v0, LAa/z;->b:LAa/x;

    .line 20
    .line 21
    :cond_1
    if-eqz v2, :cond_2

    .line 22
    .line 23
    new-instance p1, Ljava/util/ArrayList;

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 27
    .line 28
    .line 29
    new-instance v0, LAa/g;

    .line 30
    .line 31
    invoke-direct {v0, p0, p1}, LAa/g;-><init>(LAa/f;Ljava/util/ArrayList;)V

    .line 32
    .line 33
    .line 34
    const-string v1, "kotlinClass"

    .line 35
    .line 36
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-interface {v2, v0}, LAa/x;->e(LAa/x$c;)V

    .line 40
    .line 41
    .line 42
    return-object p1

    .line 43
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 44
    .line 45
    new-instance v1, Ljava/lang/StringBuilder;

    .line 46
    .line 47
    const-string v2, "Class for loading annotations is not found: "

    .line 48
    .line 49
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    iget-object p1, p1, LUa/M$a;->f:LHa/b;

    .line 53
    .line 54
    invoke-virtual {p1}, LHa/b;->a()LHa/c;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw v0
.end method

.method public final f(LUa/M;LCa/g;)Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/g;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p1, LUa/M;->a:LEa/d;

    .line 12
    .line 13
    iget p2, p2, LCa/g;->d:I

    .line 14
    .line 15
    invoke-interface {v0, p2}, LEa/d;->b(I)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    move-object v0, p1

    .line 20
    check-cast v0, LUa/M$a;

    .line 21
    .line 22
    iget-object v0, v0, LUa/M$a;->f:LHa/b;

    .line 23
    .line 24
    invoke-virtual {v0}, LHa/b;->b()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0}, LGa/b;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    const-string v1, "name"

    .line 33
    .line 34
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, "desc"

    .line 38
    .line 39
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    new-instance v4, LAa/A;

    .line 43
    .line 44
    new-instance v1, Ljava/lang/StringBuilder;

    .line 45
    .line 46
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    const/16 p2, 0x23

    .line 53
    .line 54
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    invoke-direct {v4, p2}, LAa/A;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    const/4 v5, 0x0

    .line 68
    const/4 v6, 0x0

    .line 69
    const/16 v7, 0x3c

    .line 70
    .line 71
    move-object v2, p0

    .line 72
    move-object v3, p1

    .line 73
    invoke-static/range {v2 .. v7}, LAa/f;->m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1
.end method

.method public final g(LUa/M;LCa/n;)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, LAa/f$c;->DELEGATE_FIELD:LAa/f$c;

    .line 12
    .line 13
    invoke-virtual {p0, p1, p2, v0}, LAa/f;->r(LUa/M;LCa/n;LAa/f$c;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final h(LUa/M;LCa/n;)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, LAa/f$c;->BACKING_FIELD:LAa/f$c;

    .line 12
    .line 13
    invoke-virtual {p0, p1, p2, v0}, LAa/f;->r(LUa/M;LCa/n;LAa/f$c;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final i(LUa/M;LIa/g$d;LUa/d;)Ljava/util/List;
    .locals 6

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "kind"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p1, LUa/M;->b:LEa/h;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    iget-object v2, p1, LUa/M;->a:LEa/d;

    .line 20
    .line 21
    invoke-static {p2, v2, v0, p3, v1}, LAa/f;->n(LIa/g$d;LEa/d;LEa/h;LUa/d;Z)LAa/A;

    .line 22
    .line 23
    .line 24
    move-result-object p2

    .line 25
    if-eqz p2, :cond_0

    .line 26
    .line 27
    const-string p3, "signature"

    .line 28
    .line 29
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    new-instance v2, LAa/A;

    .line 33
    .line 34
    new-instance p3, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    .line 37
    .line 38
    .line 39
    iget-object p2, p2, LAa/A;->a:Ljava/lang/String;

    .line 40
    .line 41
    const-string v0, "@0"

    .line 42
    .line 43
    invoke-static {p3, p2, v0}, LU4/k;->b(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    invoke-direct {v2, p2}, LAa/A;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const/4 v3, 0x0

    .line 51
    const/4 v4, 0x0

    .line 52
    const/16 v5, 0x3c

    .line 53
    .line 54
    move-object v0, p0

    .line 55
    move-object v1, p1

    .line 56
    invoke-static/range {v0 .. v5}, LAa/f;->m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    return-object p1

    .line 61
    :cond_0
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    return-object p1
.end method

.method public final j(LCa/s;LEa/d;)Ljava/util/ArrayList;
    .locals 5

    .line 1
    const-string v0, "proto"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "nameResolver"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v2, LFa/a;->h:LIa/g$f;

    .line 12
    .line 13
    invoke-virtual {p1, v2}, LIa/g$d;->l(LIa/g$f;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string v2, "getExtension(...)"

    .line 18
    .line 19
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p1, Ljava/lang/Iterable;

    .line 23
    .line 24
    new-instance v2, Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 31
    .line 32
    .line 33
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_0

    .line 42
    .line 43
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, LCa/a;

    .line 48
    .line 49
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    move-object v4, p0

    .line 53
    check-cast v4, LAa/j;

    .line 54
    .line 55
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    iget-object v4, v4, LAa/j;->e:LUa/g;

    .line 62
    .line 63
    invoke-virtual {v4, v3, p2}, LUa/g;->a(LCa/a;LEa/d;)Lja/d;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_0
    return-object v2
.end method

.method public final k(LUa/M;LIa/g$d;LUa/d;)Ljava/util/List;
    .locals 9

    .line 1
    const-string v0, "container"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "proto"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "kind"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, LUa/d;->PROPERTY:LUa/d;

    .line 17
    .line 18
    if-ne p3, v0, :cond_0

    .line 19
    .line 20
    check-cast p2, LCa/n;

    .line 21
    .line 22
    sget-object p3, LAa/f$c;->PROPERTY:LAa/f$c;

    .line 23
    .line 24
    invoke-virtual {p0, p1, p2, p3}, LAa/f;->r(LUa/M;LCa/n;LAa/f$c;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1

    .line 29
    :cond_0
    iget-object v0, p1, LUa/M;->b:LEa/h;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    iget-object v2, p1, LUa/M;->a:LEa/d;

    .line 33
    .line 34
    invoke-static {p2, v2, v0, p3, v1}, LAa/f;->n(LIa/g$d;LEa/d;LEa/h;LUa/d;Z)LAa/A;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    if-nez v5, :cond_1

    .line 39
    .line 40
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    return-object p1

    .line 45
    :cond_1
    const/4 v6, 0x0

    .line 46
    const/4 v7, 0x0

    .line 47
    const/16 v8, 0x3c

    .line 48
    .line 49
    move-object v3, p0

    .line 50
    move-object v4, p1

    .line 51
    invoke-static/range {v3 .. v8}, LAa/f;->m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    return-object p1
.end method

.method public final l(LUa/M;LAa/A;ZZLjava/lang/Boolean;Z)Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LAa/A;",
            "ZZ",
            "Ljava/lang/Boolean;",
            "Z)",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation

    .line 1
    move-object v0, p0

    .line 2
    check-cast v0, LAa/j;

    .line 3
    .line 4
    iget-object v7, v0, LAa/j;->f:LEa/c;

    .line 5
    .line 6
    iget-object v6, p0, LAa/f;->a:Lna/g;

    .line 7
    .line 8
    move-object v1, p1

    .line 9
    move v2, p3

    .line 10
    move v3, p4

    .line 11
    move-object v4, p5

    .line 12
    move v5, p6

    .line 13
    invoke-static/range {v1 .. v7}, LAa/f$b;->a(LUa/M;ZZLjava/lang/Boolean;ZLna/g;LEa/c;)LAa/x;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string p3, "container"

    .line 18
    .line 19
    invoke-static {v1, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    if-nez p1, :cond_2

    .line 23
    .line 24
    instance-of p1, v1, LUa/M$a;

    .line 25
    .line 26
    const/4 p3, 0x0

    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    move-object p1, v1

    .line 30
    check-cast p1, LUa/M$a;

    .line 31
    .line 32
    iget-object p1, p1, LUa/M;->c:Lia/a0;

    .line 33
    .line 34
    instance-of p4, p1, LAa/z;

    .line 35
    .line 36
    if-eqz p4, :cond_0

    .line 37
    .line 38
    check-cast p1, LAa/z;

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move-object p1, p3

    .line 42
    :goto_0
    if-eqz p1, :cond_1

    .line 43
    .line 44
    iget-object p1, p1, LAa/z;->b:LAa/x;

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    move-object p1, p3

    .line 48
    :cond_2
    :goto_1
    if-nez p1, :cond_3

    .line 49
    .line 50
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    return-object p1

    .line 55
    :cond_3
    move-object p3, p0

    .line 56
    check-cast p3, LAa/e;

    .line 57
    .line 58
    const-string p4, "binaryClass"

    .line 59
    .line 60
    invoke-static {p1, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    iget-object p3, p3, LAa/e;->b:LXa/h;

    .line 64
    .line 65
    check-cast p3, LXa/d$k;

    .line 66
    .line 67
    invoke-virtual {p3, p1}, LXa/d$k;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    check-cast p1, LAa/i;

    .line 72
    .line 73
    iget-object p1, p1, LAa/i;->a:Ljava/util/HashMap;

    .line 74
    .line 75
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Ljava/util/List;

    .line 80
    .line 81
    if-nez p1, :cond_4

    .line 82
    .line 83
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    :cond_4
    return-object p1
.end method

.method public final o(LHa/b;)Z
    .locals 2

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, LHa/b;->e()LHa/b;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {p1}, LHa/b;->f()LHa/f;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, LHa/f;->h()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const-string v1, "Container"

    .line 21
    .line 22
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    move-object v0, p0

    .line 30
    check-cast v0, LAa/j;

    .line 31
    .line 32
    iget-object v0, v0, LAa/j;->f:LEa/c;

    .line 33
    .line 34
    iget-object v1, p0, LAa/f;->a:Lna/g;

    .line 35
    .line 36
    invoke-static {v1, p1, v0}, LAa/w;->a(LAa/v;LHa/b;LEa/c;)LAa/x;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    if-eqz p1, :cond_1

    .line 41
    .line 42
    sget-object v0, Lea/b;->a:Ljava/util/LinkedHashSet;

    .line 43
    .line 44
    const-string v0, "klass"

    .line 45
    .line 46
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    new-instance v0, Lkotlin/jvm/internal/O;

    .line 50
    .line 51
    invoke-direct {v0}, Lkotlin/jvm/internal/O;-><init>()V

    .line 52
    .line 53
    .line 54
    new-instance v1, Lea/a;

    .line 55
    .line 56
    invoke-direct {v1, v0}, Lea/a;-><init>(Lkotlin/jvm/internal/O;)V

    .line 57
    .line 58
    .line 59
    check-cast p1, Lna/f;

    .line 60
    .line 61
    invoke-virtual {p1, v1}, Lna/f;->e(LAa/x$c;)V

    .line 62
    .line 63
    .line 64
    iget-boolean p1, v0, Lkotlin/jvm/internal/O;->a:Z

    .line 65
    .line 66
    if-eqz p1, :cond_1

    .line 67
    .line 68
    const/4 p1, 0x1

    .line 69
    return p1

    .line 70
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 71
    return p1
.end method

.method public abstract p(LHa/b;Lia/a0;Ljava/util/List;)LAa/k;
.end method

.method public final q(LHa/b;Lna/b;Ljava/util/List;)LAa/k;
    .locals 1

    .line 1
    const-string v0, "annotationClassId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "source"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "result"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, Lea/b;->a:Ljava/util/LinkedHashSet;

    .line 17
    .line 18
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    return-object p1

    .line 26
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, LAa/f;->p(LHa/b;Lia/a0;Ljava/util/List;)LAa/k;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    return-object p1
.end method

.method public final r(LUa/M;LCa/n;LAa/f$c;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LUa/M;",
            "LCa/n;",
            "LAa/f$c;",
            ")",
            "Ljava/util/List<",
            "TA;>;"
        }
    .end annotation

    .line 1
    sget-object v0, LEa/b;->B:LEa/b$a;

    .line 2
    .line 3
    iget v1, p2, LCa/n;->d:I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LEa/b$a;->c(I)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    const-string v0, "get(...)"

    .line 10
    .line 11
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-static {p2}, LGa/g;->d(LCa/n;)Z

    .line 15
    .line 16
    .line 17
    move-result v6

    .line 18
    sget-object v0, LAa/f$c;->PROPERTY:LAa/f$c;

    .line 19
    .line 20
    iget-object v1, p1, LUa/M;->b:LEa/h;

    .line 21
    .line 22
    iget-object v2, p1, LUa/M;->a:LEa/d;

    .line 23
    .line 24
    if-ne p3, v0, :cond_1

    .line 25
    .line 26
    const/16 p3, 0x28

    .line 27
    .line 28
    invoke-static {p2, v2, v1, p3}, LAa/h;->b(LCa/n;LEa/d;LEa/h;I)LAa/A;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    if-nez v4, :cond_0

    .line 33
    .line 34
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    return-object p1

    .line 39
    :cond_0
    const/16 v7, 0x8

    .line 40
    .line 41
    move-object v2, p0

    .line 42
    move-object v3, p1

    .line 43
    invoke-static/range {v2 .. v7}, LAa/f;->m(LAa/f;LUa/M;LAa/A;Ljava/lang/Boolean;ZI)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    return-object p1

    .line 48
    :cond_1
    move-object v3, p1

    .line 49
    const/16 p1, 0x30

    .line 50
    .line 51
    invoke-static {p2, v2, v1, p1}, LAa/h;->b(LCa/n;LEa/d;LEa/h;I)LAa/A;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    if-nez v4, :cond_2

    .line 56
    .line 57
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    return-object p1

    .line 62
    :cond_2
    iget-object p1, v4, LAa/A;->a:Ljava/lang/String;

    .line 63
    .line 64
    const-string p2, "$delegate"

    .line 65
    .line 66
    const/4 v0, 0x0

    .line 67
    invoke-static {p1, p2, v0}, Lkotlin/text/StringsKt;->x(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    sget-object p2, LAa/f$c;->DELEGATE_FIELD:LAa/f$c;

    .line 72
    .line 73
    if-ne p3, p2, :cond_3

    .line 74
    .line 75
    const/4 v0, 0x1

    .line 76
    :cond_3
    if-eq p1, v0, :cond_4

    .line 77
    .line 78
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    return-object p1

    .line 83
    :cond_4
    move-object v7, v5

    .line 84
    const/4 v5, 0x1

    .line 85
    move v8, v6

    .line 86
    const/4 v6, 0x1

    .line 87
    move-object v2, p0

    .line 88
    invoke-virtual/range {v2 .. v8}, LAa/f;->l(LUa/M;LAa/A;ZZLjava/lang/Boolean;Z)Ljava/util/List;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    return-object p1
.end method
