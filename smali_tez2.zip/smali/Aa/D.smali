.class public interface abstract LAa/D;
.super Ljava/lang/Object;
.source "PackagePartProvider.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAa/D$a;
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method
