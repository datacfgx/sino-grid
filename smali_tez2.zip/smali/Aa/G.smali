.class public final LAa/G;
.super Ljava/lang/Object;
.source "methodSignatureMapping.kt"


# static fields
.field public static final a:LAa/G;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LAa/G;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LAa/G;->a:LAa/G;

    .line 7
    .line 8
    return-void
.end method
