.class public final LAa/l;
.super Ljava/lang/Object;
.source "descriptorBasedTypeSignatureMapping.kt"


# direct methods
.method public static final a(Lia/e;LAa/G;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lia/e;",
            "LAa/G;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    .line 2
    const/4 v0, 0x0

    sget-object v0, Lad/bKJZ/CUnG;->CJDTU:Ljava/lang/String;

    .line 3
    .line 4
    const-string v1, "klass"

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    const-string v1, "typeMappingConfiguration"

    .line 10
    .line 11
    .line 12
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-interface {p0}, Lia/k;->e()Lia/k;

    .line 22
    move-result-object v1

    .line 23
    .line 24
    const-string v2, "getContainingDeclaration(...)"

    .line 25
    .line 26
    .line 27
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p0}, Lia/k;->getName()LHa/f;

    .line 31
    move-result-object v2

    .line 32
    .line 33
    if-eqz v2, :cond_0

    .line 34
    .line 35
    sget-object v3, LHa/h;->a:LHa/f;

    .line 36
    .line 37
    iget-boolean v3, v2, LHa/f;->b:Z

    .line 38
    .line 39
    if-nez v3, :cond_0

    .line 40
    goto :goto_0

    .line 41
    .line 42
    :cond_0
    sget-object v2, LHa/h;->c:LHa/f;

    .line 43
    .line 44
    .line 45
    :goto_0
    invoke-virtual {v2}, LHa/f;->k()Ljava/lang/String;

    .line 46
    move-result-object v2

    .line 47
    .line 48
    const-string v3, "getIdentifier(...)"

    .line 49
    .line 50
    .line 51
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    instance-of v3, v1, Lia/I;

    .line 54
    .line 55
    if-eqz v3, :cond_2

    .line 56
    .line 57
    check-cast v1, Lia/I;

    .line 58
    .line 59
    .line 60
    invoke-interface {v1}, Lia/I;->d()LHa/c;

    .line 61
    move-result-object p0

    .line 62
    .line 63
    iget-object p1, p0, LHa/c;->a:LHa/d;

    .line 64
    .line 65
    .line 66
    invoke-virtual {p1}, LHa/d;->c()Z

    .line 67
    move-result p1

    .line 68
    .line 69
    if-eqz p1, :cond_1

    .line 70
    return-object v2

    .line 71
    .line 72
    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 76
    .line 77
    iget-object p0, p0, LHa/c;->a:LHa/d;

    .line 78
    .line 79
    iget-object p0, p0, LHa/d;->a:Ljava/lang/String;

    .line 80
    .line 81
    const/16 v0, 0x2e

    .line 82
    .line 83
    const/16 v1, 0x2f

    .line 84
    .line 85
    .line 86
    invoke-static {p0, v0, v1}, Lkotlin/text/o;->k(Ljava/lang/String;CC)Ljava/lang/String;

    .line 87
    move-result-object p0

    .line 88
    .line 89
    .line 90
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    move-result-object p0

    .line 101
    return-object p0

    .line 102
    .line 103
    :cond_2
    instance-of v3, v1, Lia/e;

    .line 104
    .line 105
    if-eqz v3, :cond_3

    .line 106
    move-object v3, v1

    .line 107
    .line 108
    check-cast v3, Lia/e;

    .line 109
    goto :goto_1

    .line 110
    :cond_3
    const/4 v3, 0x0

    .line 111
    .line 112
    :goto_1
    if-eqz v3, :cond_4

    .line 113
    .line 114
    .line 115
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-static {v3, p1}, LAa/l;->a(Lia/e;LAa/G;)Ljava/lang/String;

    .line 119
    move-result-object p0

    .line 120
    .line 121
    new-instance p1, Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 128
    .line 129
    const/16 p0, 0x24

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 139
    move-result-object p0

    .line 140
    return-object p0

    .line 141
    .line 142
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 143
    .line 144
    new-instance v0, Ljava/lang/StringBuilder;

    .line 145
    .line 146
    const-string v2, "Unexpected container: "

    .line 147
    .line 148
    .line 149
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    const-string v1, " for "

    .line 155
    .line 156
    .line 157
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 164
    move-result-object p0

    .line 165
    .line 166
    .line 167
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 168
    throw p1
.end method

.method public static final b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;
    .locals 29

    .line 1
    .line 2
    move-object/from16 v0, p0

    .line 3
    .line 4
    move-object/from16 v1, p1

    .line 5
    .line 6
    move-object/from16 v2, p2

    .line 7
    const/4 v4, 0x0

    .line 8
    .line 9
    const-string v5, ", "

    .line 10
    .line 11
    const-string v6, "ClassicTypeSystemContext couldn\'t handle: "

    .line 12
    .line 13
    const-string v7, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor"

    .line 14
    .line 15
    const/4 v8, 0x0

    sget-object v8, LN/eMw/CpSDrsX;->TqirlzHFvIcAHer:Ljava/lang/String;

    .line 16
    .line 17
    sget-object v9, LAa/u;->a:LAa/u;

    .line 18
    .line 19
    sget-object v10, LAa/G;->a:LAa/G;

    .line 20
    .line 21
    const-string v11, "kotlinType"

    .line 22
    .line 23
    .line 24
    invoke-static {v0, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    const-string v12, "factory"

    .line 27
    .line 28
    .line 29
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    const-string v12, "mode"

    .line 32
    .line 33
    .line 34
    invoke-static {v1, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    const-string v13, "typeMappingConfiguration"

    .line 37
    .line 38
    .line 39
    invoke-static {v10, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    const-string v13, "writeGenericType"

    .line 42
    .line 43
    .line 44
    invoke-static {v2, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v0, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v0}, Lfa/i;->i(LYa/M;)Z

    .line 51
    move-result v13

    .line 52
    const/4 v14, 0x0

    .line 53
    .line 54
    const-string v15, "getType(...)"

    .line 55
    .line 56
    const-string v3, "<this>"

    .line 57
    .line 58
    if-eqz v13, :cond_1

    .line 59
    .line 60
    sget-object v5, Lfa/q;->a:Lla/F;

    .line 61
    .line 62
    const-string v5, "suspendFunType"

    .line 63
    .line 64
    .line 65
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-static {v0}, Lfa/i;->i(LYa/M;)Z

    .line 69
    .line 70
    .line 71
    invoke-static {v0}, Ldb/c;->e(LYa/M;)Lfa/l;

    .line 72
    move-result-object v6

    .line 73
    .line 74
    .line 75
    invoke-virtual {v0}, LYa/M;->getAnnotations()Lja/h;

    .line 76
    move-result-object v7

    .line 77
    .line 78
    .line 79
    invoke-static {v0}, Lfa/i;->f(LYa/M;)LYa/M;

    .line 80
    move-result-object v8

    .line 81
    .line 82
    .line 83
    invoke-static {v0}, Lfa/i;->d(LYa/M;)Ljava/util/List;

    .line 84
    move-result-object v9

    .line 85
    .line 86
    .line 87
    invoke-static {v0}, Lfa/i;->g(LYa/M;)Ljava/util/List;

    .line 88
    move-result-object v5

    .line 89
    .line 90
    check-cast v5, Ljava/lang/Iterable;

    .line 91
    .line 92
    new-instance v10, Ljava/util/ArrayList;

    .line 93
    .line 94
    .line 95
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 96
    move-result v11

    .line 97
    .line 98
    .line 99
    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    .line 100
    .line 101
    .line 102
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 103
    move-result-object v5

    .line 104
    .line 105
    .line 106
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 107
    move-result v11

    .line 108
    .line 109
    if-eqz v11, :cond_0

    .line 110
    .line 111
    .line 112
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 113
    move-result-object v11

    .line 114
    .line 115
    check-cast v11, LYa/v0;

    .line 116
    .line 117
    .line 118
    invoke-interface {v11}, LYa/v0;->a()LYa/M;

    .line 119
    move-result-object v11

    .line 120
    .line 121
    .line 122
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 123
    goto :goto_0

    .line 124
    .line 125
    :cond_0
    sget-object v5, LYa/m0;->b:LYa/m0$a;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    sget-object v5, LYa/m0;->c:LYa/m0;

    .line 131
    .line 132
    sget-object v11, Lfa/q;->a:Lla/F;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v11}, Lla/F;->k()LYa/p0;

    .line 136
    move-result-object v11

    .line 137
    .line 138
    const-string v12, "getTypeConstructor(...)"

    .line 139
    .line 140
    .line 141
    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-static {v0}, Lfa/i;->h(LYa/M;)Z

    .line 148
    .line 149
    .line 150
    invoke-virtual {v0}, LYa/M;->L0()Ljava/util/List;

    .line 151
    move-result-object v3

    .line 152
    .line 153
    .line 154
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 155
    move-result-object v3

    .line 156
    .line 157
    check-cast v3, LYa/v0;

    .line 158
    .line 159
    .line 160
    invoke-interface {v3}, LYa/v0;->a()LYa/M;

    .line 161
    move-result-object v3

    .line 162
    .line 163
    .line 164
    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    invoke-static {v3}, Ldb/c;->a(LYa/M;)LYa/x0;

    .line 168
    move-result-object v3

    .line 169
    .line 170
    .line 171
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    .line 172
    move-result-object v3

    .line 173
    .line 174
    .line 175
    invoke-static {v5, v11, v3, v4, v14}, LYa/P;->c(LYa/m0;LYa/p0;Ljava/util/List;ZLZa/g;)LYa/W;

    .line 176
    move-result-object v3

    .line 177
    .line 178
    .line 179
    invoke-static {v10, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    .line 180
    move-result-object v10

    .line 181
    .line 182
    .line 183
    invoke-static {v0}, Ldb/c;->e(LYa/M;)Lfa/l;

    .line 184
    move-result-object v3

    .line 185
    .line 186
    .line 187
    invoke-virtual {v3}, Lfa/l;->p()LYa/W;

    .line 188
    move-result-object v11

    .line 189
    .line 190
    const-string v3, "getNullableAnyType(...)"

    .line 191
    .line 192
    .line 193
    invoke-static {v11, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 194
    const/4 v12, 0x0

    .line 195
    .line 196
    .line 197
    invoke-static/range {v6 .. v12}, Lfa/i;->b(Lfa/l;Lja/h;LYa/M;Ljava/util/List;Ljava/util/List;LYa/M;Z)LYa/W;

    .line 198
    move-result-object v3

    .line 199
    .line 200
    .line 201
    invoke-virtual {v0}, LYa/M;->O0()Z

    .line 202
    move-result v0

    .line 203
    .line 204
    .line 205
    invoke-virtual {v3, v0}, LYa/W;->U0(Z)LYa/W;

    .line 206
    move-result-object v0

    .line 207
    .line 208
    .line 209
    invoke-static {v0, v1, v2}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 210
    move-result-object v0

    .line 211
    return-object v0

    .line 212
    .line 213
    :cond_1
    sget-object v13, LZa/p;->a:LZa/p;

    .line 214
    .line 215
    .line 216
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 217
    .line 218
    const-string v14, "type"

    .line 219
    .line 220
    .line 221
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    .line 223
    const-string v4, "typeFactory"

    .line 224
    .line 225
    .line 226
    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    invoke-static {v1, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v13, v0}, LZa/p;->a(Lcb/f;)LYa/p0;

    .line 233
    move-result-object v4

    .line 234
    .line 235
    .line 236
    invoke-static {v4}, LZa/b$a;->x(Lcb/k;)Z

    .line 237
    move-result v12

    .line 238
    .line 239
    move/from16 v16, v12

    .line 240
    .line 241
    const-string v12, "getInternalName(...)"

    .line 242
    .line 243
    move-object/from16 v17, v10

    .line 244
    .line 245
    const-string v10, "possiblyPrimitiveType"

    .line 246
    .line 247
    move-object/from16 v18, v15

    .line 248
    .line 249
    const-string v15, "internalName"

    .line 250
    .line 251
    move-object/from16 v19, v11

    .line 252
    .line 253
    const-string v11, "["

    .line 254
    .line 255
    if-nez v16, :cond_3

    .line 256
    :cond_2
    :goto_1
    const/4 v14, 0x0

    .line 257
    .line 258
    goto/16 :goto_8

    .line 259
    .line 260
    .line 261
    :cond_3
    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 262
    .line 263
    instance-of v2, v4, LYa/p0;

    .line 264
    .line 265
    if-eqz v2, :cond_25

    .line 266
    move-object v2, v4

    .line 267
    .line 268
    check-cast v2, LYa/p0;

    .line 269
    .line 270
    .line 271
    invoke-interface {v2}, LYa/p0;->p()Lia/h;

    .line 272
    move-result-object v2

    .line 273
    .line 274
    .line 275
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 276
    .line 277
    check-cast v2, Lia/e;

    .line 278
    .line 279
    .line 280
    invoke-static {v2}, Lfa/l;->u(Lia/e;)Lfa/m;

    .line 281
    move-result-object v2

    .line 282
    .line 283
    if-eqz v2, :cond_7

    .line 284
    .line 285
    const-string v4, "primitiveType"

    .line 286
    .line 287
    .line 288
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 289
    .line 290
    sget-object v4, LAa/u$a;->a:[I

    .line 291
    .line 292
    .line 293
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 294
    move-result v2

    .line 295
    .line 296
    aget v2, v4, v2

    .line 297
    .line 298
    .line 299
    packed-switch v2, :pswitch_data_0

    .line 300
    .line 301
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    .line 302
    .line 303
    .line 304
    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 305
    throw v0

    .line 306
    .line 307
    :pswitch_0
    sget-object v2, LAa/t;->h:LAa/t$c;

    .line 308
    goto :goto_2

    .line 309
    .line 310
    :pswitch_1
    sget-object v2, LAa/t;->g:LAa/t$c;

    .line 311
    goto :goto_2

    .line 312
    .line 313
    :pswitch_2
    sget-object v2, LAa/t;->f:LAa/t$c;

    .line 314
    goto :goto_2

    .line 315
    .line 316
    :pswitch_3
    sget-object v2, LAa/t;->e:LAa/t$c;

    .line 317
    goto :goto_2

    .line 318
    .line 319
    :pswitch_4
    sget-object v2, LAa/t;->d:LAa/t$c;

    .line 320
    goto :goto_2

    .line 321
    .line 322
    :pswitch_5
    sget-object v2, LAa/t;->c:LAa/t$c;

    .line 323
    goto :goto_2

    .line 324
    .line 325
    :pswitch_6
    sget-object v2, LAa/t;->b:LAa/t$c;

    .line 326
    goto :goto_2

    .line 327
    .line 328
    :pswitch_7
    sget-object v2, LAa/t;->a:LAa/t$c;

    .line 329
    .line 330
    .line 331
    :goto_2
    invoke-static {v0}, LZa/b$a;->G(Lcb/f;)Z

    .line 332
    move-result v4

    .line 333
    .line 334
    if-nez v4, :cond_5

    .line 335
    .line 336
    .line 337
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 338
    .line 339
    .line 340
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 341
    .line 342
    sget-object v4, Lra/D;->p:LHa/c;

    .line 343
    .line 344
    const-string v5, "ENHANCED_NULLABILITY_ANNOTATION"

    .line 345
    .line 346
    .line 347
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 348
    .line 349
    .line 350
    invoke-static {v0, v4}, LZa/b$a;->t(LYa/M;LHa/c;)Z

    .line 351
    move-result v4

    .line 352
    .line 353
    if-eqz v4, :cond_4

    .line 354
    goto :goto_3

    .line 355
    :cond_4
    const/4 v4, 0x0

    .line 356
    goto :goto_4

    .line 357
    :cond_5
    :goto_3
    const/4 v4, 0x1

    .line 358
    .line 359
    .line 360
    :goto_4
    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 364
    .line 365
    if-eqz v4, :cond_6

    .line 366
    .line 367
    .line 368
    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 369
    .line 370
    if-eqz v2, :cond_6

    .line 371
    .line 372
    iget-object v4, v2, LAa/t$c;->i:LPa/e;

    .line 373
    .line 374
    if-eqz v4, :cond_6

    .line 375
    .line 376
    .line 377
    invoke-virtual {v4}, LPa/e;->getWrapperFqName()LHa/c;

    .line 378
    move-result-object v2

    .line 379
    .line 380
    .line 381
    invoke-static {v2}, LPa/d;->b(LHa/c;)LPa/d;

    .line 382
    move-result-object v2

    .line 383
    .line 384
    .line 385
    invoke-virtual {v2}, LPa/d;->d()Ljava/lang/String;

    .line 386
    move-result-object v2

    .line 387
    .line 388
    .line 389
    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 393
    .line 394
    new-instance v4, LAa/t$b;

    .line 395
    .line 396
    .line 397
    invoke-direct {v4, v2}, LAa/t$b;-><init>(Ljava/lang/String;)V

    .line 398
    move-object v14, v4

    .line 399
    .line 400
    goto/16 :goto_8

    .line 401
    :cond_6
    move-object v14, v2

    .line 402
    .line 403
    goto/16 :goto_8

    .line 404
    .line 405
    .line 406
    :cond_7
    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    .line 408
    instance-of v2, v4, LYa/p0;

    .line 409
    .line 410
    if-eqz v2, :cond_24

    .line 411
    move-object v2, v4

    .line 412
    .line 413
    check-cast v2, LYa/p0;

    .line 414
    .line 415
    .line 416
    invoke-interface {v2}, LYa/p0;->p()Lia/h;

    .line 417
    move-result-object v2

    .line 418
    .line 419
    .line 420
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 421
    .line 422
    check-cast v2, Lia/e;

    .line 423
    .line 424
    .line 425
    invoke-static {v2}, Lfa/l;->s(Lia/h;)Lfa/m;

    .line 426
    move-result-object v2

    .line 427
    .line 428
    if-eqz v2, :cond_8

    .line 429
    .line 430
    new-instance v4, Ljava/lang/StringBuilder;

    .line 431
    .line 432
    .line 433
    invoke-direct {v4, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    invoke-static {v2}, LPa/e;->get(Lfa/m;)LPa/e;

    .line 437
    move-result-object v2

    .line 438
    .line 439
    .line 440
    invoke-virtual {v2}, LPa/e;->getDesc()Ljava/lang/String;

    .line 441
    move-result-object v2

    .line 442
    .line 443
    .line 444
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 445
    .line 446
    .line 447
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 448
    move-result-object v2

    .line 449
    .line 450
    .line 451
    invoke-static {v2}, LAa/u;->a(Ljava/lang/String;)LAa/t;

    .line 452
    move-result-object v14

    .line 453
    .line 454
    goto/16 :goto_8

    .line 455
    .line 456
    .line 457
    :cond_8
    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 458
    .line 459
    instance-of v2, v4, LYa/p0;

    .line 460
    .line 461
    if-eqz v2, :cond_23

    .line 462
    move-object v2, v4

    .line 463
    .line 464
    check-cast v2, LYa/p0;

    .line 465
    .line 466
    .line 467
    invoke-interface {v2}, LYa/p0;->p()Lia/h;

    .line 468
    move-result-object v2

    .line 469
    .line 470
    if-eqz v2, :cond_9

    .line 471
    .line 472
    .line 473
    invoke-static {v2}, Lfa/l;->K(Lia/h;)Z

    .line 474
    move-result v2

    .line 475
    const/4 v14, 0x1

    .line 476
    .line 477
    if-ne v2, v14, :cond_9

    .line 478
    const/4 v2, 0x1

    .line 479
    goto :goto_5

    .line 480
    :cond_9
    const/4 v2, 0x0

    .line 481
    .line 482
    :goto_5
    if-eqz v2, :cond_2

    .line 483
    .line 484
    .line 485
    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 486
    .line 487
    instance-of v2, v4, LYa/p0;

    .line 488
    .line 489
    if-eqz v2, :cond_e

    .line 490
    .line 491
    check-cast v4, LYa/p0;

    .line 492
    .line 493
    .line 494
    invoke-interface {v4}, LYa/p0;->p()Lia/h;

    .line 495
    move-result-object v2

    .line 496
    .line 497
    .line 498
    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 499
    .line 500
    check-cast v2, Lia/e;

    .line 501
    .line 502
    .line 503
    invoke-static {v2}, LOa/d;->h(Lia/k;)LHa/d;

    .line 504
    move-result-object v2

    .line 505
    .line 506
    if-eqz v2, :cond_a

    .line 507
    .line 508
    sget-object v4, Lha/c;->a:Ljava/lang/String;

    .line 509
    .line 510
    .line 511
    invoke-static {v2}, Lha/c;->f(LHa/d;)LHa/b;

    .line 512
    move-result-object v2

    .line 513
    goto :goto_6

    .line 514
    :cond_a
    const/4 v2, 0x0

    .line 515
    .line 516
    :goto_6
    if-eqz v2, :cond_2

    .line 517
    .line 518
    iget-boolean v4, v1, LAa/H;->g:Z

    .line 519
    .line 520
    if-nez v4, :cond_d

    .line 521
    .line 522
    sget-object v4, Lha/c;->n:Ljava/util/List;

    .line 523
    .line 524
    check-cast v4, Ljava/lang/Iterable;

    .line 525
    .line 526
    instance-of v5, v4, Ljava/util/Collection;

    .line 527
    .line 528
    if-eqz v5, :cond_b

    .line 529
    move-object v5, v4

    .line 530
    .line 531
    check-cast v5, Ljava/util/Collection;

    .line 532
    .line 533
    .line 534
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 535
    move-result v5

    .line 536
    .line 537
    if-eqz v5, :cond_b

    .line 538
    goto :goto_7

    .line 539
    .line 540
    .line 541
    :cond_b
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 542
    move-result-object v4

    .line 543
    .line 544
    .line 545
    :cond_c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 546
    move-result v5

    .line 547
    .line 548
    if-eqz v5, :cond_d

    .line 549
    .line 550
    .line 551
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 552
    move-result-object v5

    .line 553
    .line 554
    check-cast v5, Lha/c$a;

    .line 555
    .line 556
    iget-object v5, v5, Lha/c$a;->a:LHa/b;

    .line 557
    .line 558
    .line 559
    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 560
    move-result v5

    .line 561
    .line 562
    if-eqz v5, :cond_c

    .line 563
    .line 564
    goto/16 :goto_1

    .line 565
    .line 566
    .line 567
    :cond_d
    :goto_7
    invoke-static {v2}, LPa/d;->e(LHa/b;)Ljava/lang/String;

    .line 568
    move-result-object v2

    .line 569
    .line 570
    const-string v4, "internalNameByClassId(...)"

    .line 571
    .line 572
    .line 573
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 574
    .line 575
    .line 576
    invoke-virtual {v9, v2}, LAa/u;->b(Ljava/lang/String;)LAa/t$b;

    .line 577
    move-result-object v14

    .line 578
    goto :goto_8

    .line 579
    .line 580
    :cond_e
    new-instance v0, Ljava/lang/StringBuilder;

    .line 581
    .line 582
    .line 583
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 584
    .line 585
    .line 586
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 587
    .line 588
    .line 589
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 590
    .line 591
    .line 592
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 593
    move-result-object v1

    .line 594
    .line 595
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 596
    .line 597
    .line 598
    invoke-static {v2, v1, v0}, LA7/c;->c(Lkotlin/jvm/internal/V;Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 599
    move-result-object v0

    .line 600
    .line 601
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 602
    .line 603
    .line 604
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 605
    move-result-object v0

    .line 606
    .line 607
    .line 608
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 609
    throw v1

    .line 610
    .line 611
    :goto_8
    if-eqz v14, :cond_10

    .line 612
    .line 613
    .line 614
    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 615
    .line 616
    .line 617
    invoke-static {v14, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 618
    .line 619
    iget-boolean v2, v1, LAa/H;->a:Z

    .line 620
    .line 621
    if-eqz v2, :cond_f

    .line 622
    .line 623
    .line 624
    invoke-static {v14, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 625
    .line 626
    instance-of v2, v14, LAa/t$c;

    .line 627
    .line 628
    if-eqz v2, :cond_f

    .line 629
    move-object v2, v14

    .line 630
    .line 631
    check-cast v2, LAa/t$c;

    .line 632
    .line 633
    iget-object v2, v2, LAa/t$c;->i:LPa/e;

    .line 634
    .line 635
    if-eqz v2, :cond_f

    .line 636
    .line 637
    .line 638
    invoke-virtual {v2}, LPa/e;->getWrapperFqName()LHa/c;

    .line 639
    move-result-object v2

    .line 640
    .line 641
    .line 642
    invoke-static {v2}, LPa/d;->b(LHa/c;)LPa/d;

    .line 643
    move-result-object v2

    .line 644
    .line 645
    .line 646
    invoke-virtual {v2}, LPa/d;->d()Ljava/lang/String;

    .line 647
    move-result-object v2

    .line 648
    .line 649
    .line 650
    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 654
    .line 655
    new-instance v14, LAa/t$b;

    .line 656
    .line 657
    .line 658
    invoke-direct {v14, v2}, LAa/t$b;-><init>(Ljava/lang/String;)V

    .line 659
    .line 660
    :cond_f
    move-object/from16 v2, p2

    .line 661
    .line 662
    .line 663
    invoke-interface {v2, v0, v14, v1}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 664
    return-object v14

    .line 665
    .line 666
    :cond_10
    move-object/from16 v2, p2

    .line 667
    .line 668
    .line 669
    invoke-virtual {v0}, LYa/M;->N0()LYa/p0;

    .line 670
    move-result-object v4

    .line 671
    .line 672
    instance-of v5, v4, LYa/L;

    .line 673
    .line 674
    if-eqz v5, :cond_12

    .line 675
    .line 676
    check-cast v4, LYa/L;

    .line 677
    .line 678
    iget-object v0, v4, LYa/L;->a:LYa/M;

    .line 679
    .line 680
    if-eqz v0, :cond_11

    .line 681
    .line 682
    .line 683
    invoke-static {v0}, Ldb/c;->l(LYa/M;)LYa/H0;

    .line 684
    move-result-object v0

    .line 685
    .line 686
    .line 687
    invoke-static {v0, v1, v2}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 688
    move-result-object v0

    .line 689
    return-object v0

    .line 690
    .line 691
    :cond_11
    iget-object v1, v4, LYa/L;->b:Ljava/util/LinkedHashSet;

    .line 692
    .line 693
    const-string v0, "types"

    .line 694
    .line 695
    .line 696
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 697
    .line 698
    new-instance v0, Ljava/lang/AssertionError;

    .line 699
    .line 700
    new-instance v7, Ljava/lang/StringBuilder;

    .line 701
    .line 702
    const-string v2, "There should be no intersection type in existing descriptors, but found: "

    .line 703
    .line 704
    .line 705
    invoke-direct {v7, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 706
    const/4 v3, 0x0

    .line 707
    .line 708
    const/16 v6, 0x3f

    .line 709
    const/4 v2, 0x0

    .line 710
    const/4 v4, 0x0

    .line 711
    const/4 v5, 0x0

    .line 712
    .line 713
    .line 714
    invoke-static/range {v1 .. v6}, Lkotlin/collections/CollectionsKt;->p(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;I)Ljava/lang/String;

    .line 715
    move-result-object v1

    .line 716
    .line 717
    .line 718
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 719
    .line 720
    .line 721
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 722
    move-result-object v1

    .line 723
    .line 724
    .line 725
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 726
    throw v0

    .line 727
    .line 728
    .line 729
    :cond_12
    invoke-interface {v4}, LYa/p0;->p()Lia/h;

    .line 730
    move-result-object v4

    .line 731
    .line 732
    if-eqz v4, :cond_22

    .line 733
    .line 734
    .line 735
    invoke-static {v4}, Lab/l;->f(Lia/k;)Z

    .line 736
    move-result v5

    .line 737
    .line 738
    if-eqz v5, :cond_13

    .line 739
    .line 740
    const-string v1, "error/NonExistentClass"

    .line 741
    .line 742
    .line 743
    invoke-virtual {v9, v1}, LAa/u;->b(Ljava/lang/String;)LAa/t$b;

    .line 744
    move-result-object v1

    .line 745
    .line 746
    check-cast v4, Lia/e;

    .line 747
    .line 748
    move-object/from16 v2, v19

    .line 749
    .line 750
    .line 751
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 752
    .line 753
    const-string v0, "descriptor"

    .line 754
    .line 755
    .line 756
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 757
    return-object v1

    .line 758
    .line 759
    :cond_13
    instance-of v5, v4, Lia/e;

    .line 760
    .line 761
    iget-boolean v6, v1, LAa/H;->c:Z

    .line 762
    .line 763
    if-eqz v5, :cond_1a

    .line 764
    .line 765
    .line 766
    invoke-static {v0}, Lfa/l;->z(LYa/M;)Z

    .line 767
    move-result v8

    .line 768
    .line 769
    if-eqz v8, :cond_1a

    .line 770
    .line 771
    .line 772
    invoke-virtual {v0}, LYa/M;->L0()Ljava/util/List;

    .line 773
    move-result-object v3

    .line 774
    .line 775
    .line 776
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 777
    move-result v3

    .line 778
    const/4 v14, 0x1

    .line 779
    .line 780
    if-ne v3, v14, :cond_19

    .line 781
    .line 782
    .line 783
    invoke-virtual {v0}, LYa/M;->L0()Ljava/util/List;

    .line 784
    move-result-object v0

    .line 785
    const/4 v3, 0x0

    .line 786
    .line 787
    .line 788
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 789
    move-result-object v0

    .line 790
    .line 791
    check-cast v0, LYa/v0;

    .line 792
    .line 793
    .line 794
    invoke-interface {v0}, LYa/v0;->a()LYa/M;

    .line 795
    move-result-object v3

    .line 796
    .line 797
    move-object/from16 v4, v18

    .line 798
    .line 799
    .line 800
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 801
    .line 802
    .line 803
    invoke-interface {v0}, LYa/v0;->c()LYa/I0;

    .line 804
    move-result-object v4

    .line 805
    .line 806
    sget-object v5, LYa/I0;->IN_VARIANCE:LYa/I0;

    .line 807
    .line 808
    if-ne v4, v5, :cond_14

    .line 809
    .line 810
    const-string v0, "java/lang/Object"

    .line 811
    .line 812
    .line 813
    invoke-virtual {v9, v0}, LAa/u;->b(Ljava/lang/String;)LAa/t$b;

    .line 814
    move-result-object v0

    .line 815
    goto :goto_a

    .line 816
    .line 817
    .line 818
    :cond_14
    invoke-interface {v0}, LYa/v0;->c()LYa/I0;

    .line 819
    move-result-object v0

    .line 820
    .line 821
    const-string v4, "getProjectionKind(...)"

    .line 822
    .line 823
    .line 824
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 825
    .line 826
    const-string v4, "effectiveVariance"

    .line 827
    .line 828
    .line 829
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 830
    .line 831
    if-eqz v6, :cond_15

    .line 832
    goto :goto_9

    .line 833
    .line 834
    :cond_15
    sget-object v4, LAa/H$a;->a:[I

    .line 835
    .line 836
    .line 837
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 838
    move-result v0

    .line 839
    .line 840
    aget v0, v4, v0

    .line 841
    const/4 v14, 0x1

    .line 842
    .line 843
    if-eq v0, v14, :cond_17

    .line 844
    const/4 v4, 0x2

    .line 845
    .line 846
    if-eq v0, v4, :cond_16

    .line 847
    .line 848
    iget-object v0, v1, LAa/H;->f:LAa/H;

    .line 849
    .line 850
    if-nez v0, :cond_18

    .line 851
    goto :goto_9

    .line 852
    .line 853
    :cond_16
    iget-object v0, v1, LAa/H;->i:LAa/H;

    .line 854
    .line 855
    if-nez v0, :cond_18

    .line 856
    goto :goto_9

    .line 857
    .line 858
    :cond_17
    iget-object v0, v1, LAa/H;->h:LAa/H;

    .line 859
    .line 860
    if-nez v0, :cond_18

    .line 861
    :goto_9
    move-object v0, v1

    .line 862
    .line 863
    .line 864
    :cond_18
    invoke-static {v3, v0, v2}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 865
    move-result-object v0

    .line 866
    .line 867
    :goto_a
    new-instance v1, Ljava/lang/StringBuilder;

    .line 868
    .line 869
    .line 870
    invoke-direct {v1, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 871
    .line 872
    check-cast v0, LAa/t;

    .line 873
    .line 874
    .line 875
    invoke-static {v0}, LAa/u;->c(LAa/t;)Ljava/lang/String;

    .line 876
    move-result-object v0

    .line 877
    .line 878
    .line 879
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 880
    .line 881
    .line 882
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 883
    move-result-object v0

    .line 884
    .line 885
    .line 886
    invoke-static {v0}, LAa/u;->a(Ljava/lang/String;)LAa/t;

    .line 887
    move-result-object v0

    .line 888
    return-object v0

    .line 889
    .line 890
    :cond_19
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 891
    .line 892
    const-string v1, "arrays must have one type argument"

    .line 893
    .line 894
    .line 895
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 896
    throw v0

    .line 897
    .line 898
    :cond_1a
    if-eqz v5, :cond_1e

    .line 899
    .line 900
    .line 901
    invoke-static {v4}, LKa/k;->b(Lia/k;)Z

    .line 902
    move-result v5

    .line 903
    .line 904
    if-eqz v5, :cond_1b

    .line 905
    .line 906
    iget-boolean v5, v1, LAa/H;->b:Z

    .line 907
    .line 908
    if-nez v5, :cond_1b

    .line 909
    .line 910
    .line 911
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 912
    .line 913
    const-string v3, "inlineClassType"

    .line 914
    .line 915
    .line 916
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 917
    .line 918
    new-instance v3, Ljava/util/HashSet;

    .line 919
    .line 920
    .line 921
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 922
    .line 923
    .line 924
    invoke-static {v0, v3}, LYa/C;->b(Lcb/f;Ljava/util/HashSet;)Lcb/f;

    .line 925
    move-result-object v3

    .line 926
    .line 927
    check-cast v3, LYa/M;

    .line 928
    .line 929
    if-eqz v3, :cond_1b

    .line 930
    .line 931
    new-instance v18, LAa/H;

    .line 932
    .line 933
    iget-object v0, v1, LAa/H;->h:LAa/H;

    .line 934
    .line 935
    const/16 v28, 0x200

    .line 936
    .line 937
    iget-boolean v4, v1, LAa/H;->a:Z

    .line 938
    .line 939
    const/16 v20, 0x1

    .line 940
    .line 941
    iget-boolean v5, v1, LAa/H;->c:Z

    .line 942
    .line 943
    iget-boolean v6, v1, LAa/H;->d:Z

    .line 944
    .line 945
    iget-boolean v7, v1, LAa/H;->e:Z

    .line 946
    .line 947
    iget-object v8, v1, LAa/H;->f:LAa/H;

    .line 948
    .line 949
    iget-boolean v9, v1, LAa/H;->g:Z

    .line 950
    .line 951
    iget-object v1, v1, LAa/H;->i:LAa/H;

    .line 952
    .line 953
    move-object/from16 v26, v0

    .line 954
    .line 955
    move-object/from16 v27, v1

    .line 956
    .line 957
    move/from16 v19, v4

    .line 958
    .line 959
    move/from16 v21, v5

    .line 960
    .line 961
    move/from16 v22, v6

    .line 962
    .line 963
    move/from16 v23, v7

    .line 964
    .line 965
    move-object/from16 v24, v8

    .line 966
    .line 967
    move/from16 v25, v9

    .line 968
    .line 969
    .line 970
    invoke-direct/range {v18 .. v28}, LAa/H;-><init>(ZZZZZLAa/H;ZLAa/H;LAa/H;I)V

    .line 971
    .line 972
    move-object/from16 v0, v18

    .line 973
    .line 974
    .line 975
    invoke-static {v3, v0, v2}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 976
    move-result-object v0

    .line 977
    return-object v0

    .line 978
    .line 979
    :cond_1b
    if-eqz v6, :cond_1c

    .line 980
    move-object v3, v4

    .line 981
    .line 982
    check-cast v3, Lia/e;

    .line 983
    .line 984
    sget-object v5, Lfa/l;->e:LHa/f;

    .line 985
    .line 986
    sget-object v5, Lfa/p$a;->Q:LHa/d;

    .line 987
    .line 988
    .line 989
    invoke-static {v3, v5}, Lfa/l;->b(Lia/e;LHa/d;)Z

    .line 990
    move-result v3

    .line 991
    .line 992
    if-eqz v3, :cond_1c

    .line 993
    .line 994
    const/4 v3, 0x0

    sget-object v3, Lkotlin/collections/unsigned/caG/DqyFKfzAtTJT;->Khd:Ljava/lang/String;

    .line 995
    .line 996
    .line 997
    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 998
    .line 999
    new-instance v4, LAa/t$b;

    .line 1000
    .line 1001
    .line 1002
    invoke-direct {v4, v3}, LAa/t$b;-><init>(Ljava/lang/String;)V

    .line 1003
    goto :goto_b

    .line 1004
    .line 1005
    :cond_1c
    check-cast v4, Lia/e;

    .line 1006
    .line 1007
    .line 1008
    invoke-interface {v4}, Lia/e;->b()Lia/e;

    .line 1009
    move-result-object v3

    .line 1010
    .line 1011
    const-string v5, "getOriginal(...)"

    .line 1012
    .line 1013
    .line 1014
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1015
    .line 1016
    const-string v6, "classDescriptor"

    .line 1017
    .line 1018
    .line 1019
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1020
    .line 1021
    .line 1022
    invoke-interface {v4}, Lia/e;->f()Lia/f;

    .line 1023
    move-result-object v3

    .line 1024
    .line 1025
    sget-object v6, Lia/f;->ENUM_ENTRY:Lia/f;

    .line 1026
    .line 1027
    if-ne v3, v6, :cond_1d

    .line 1028
    .line 1029
    .line 1030
    invoke-interface {v4}, Lia/k;->e()Lia/k;

    .line 1031
    move-result-object v3

    .line 1032
    .line 1033
    .line 1034
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1035
    move-object v4, v3

    .line 1036
    .line 1037
    check-cast v4, Lia/e;

    .line 1038
    .line 1039
    .line 1040
    :cond_1d
    invoke-interface {v4}, Lia/e;->b()Lia/e;

    .line 1041
    move-result-object v3

    .line 1042
    .line 1043
    .line 1044
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1045
    .line 1046
    move-object/from16 v4, v17

    .line 1047
    .line 1048
    .line 1049
    invoke-static {v3, v4}, LAa/l;->a(Lia/e;LAa/G;)Ljava/lang/String;

    .line 1050
    move-result-object v3

    .line 1051
    .line 1052
    .line 1053
    invoke-virtual {v9, v3}, LAa/u;->b(Ljava/lang/String;)LAa/t$b;

    .line 1054
    move-result-object v4

    .line 1055
    .line 1056
    .line 1057
    :goto_b
    invoke-interface {v2, v0, v4, v1}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1058
    return-object v4

    .line 1059
    .line 1060
    :cond_1e
    instance-of v3, v4, Lia/f0;

    .line 1061
    .line 1062
    if-eqz v3, :cond_20

    .line 1063
    .line 1064
    check-cast v4, Lia/f0;

    .line 1065
    .line 1066
    .line 1067
    invoke-static {v4}, Ldb/c;->f(Lia/f0;)LYa/M;

    .line 1068
    move-result-object v2

    .line 1069
    .line 1070
    .line 1071
    invoke-virtual {v0}, LYa/M;->O0()Z

    .line 1072
    move-result v0

    .line 1073
    .line 1074
    if-eqz v0, :cond_1f

    .line 1075
    .line 1076
    .line 1077
    invoke-static {v2}, Ldb/c;->j(LYa/M;)LYa/H0;

    .line 1078
    move-result-object v2

    .line 1079
    .line 1080
    :cond_1f
    sget-object v0, Lib/e;->a:Lib/e;

    .line 1081
    .line 1082
    .line 1083
    invoke-static {v2, v1, v0}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 1084
    move-result-object v0

    .line 1085
    return-object v0

    .line 1086
    .line 1087
    :cond_20
    instance-of v3, v4, Lia/e0;

    .line 1088
    .line 1089
    if-eqz v3, :cond_21

    .line 1090
    .line 1091
    iget-boolean v3, v1, LAa/H;->j:Z

    .line 1092
    .line 1093
    if-eqz v3, :cond_21

    .line 1094
    .line 1095
    check-cast v4, Lia/e0;

    .line 1096
    .line 1097
    .line 1098
    invoke-interface {v4}, Lia/e0;->U()LYa/W;

    .line 1099
    move-result-object v0

    .line 1100
    .line 1101
    .line 1102
    invoke-static {v0, v1, v2}, LAa/l;->b(LYa/M;LAa/H;Lkotlin/jvm/functions/Function3;)Ljava/lang/Object;

    .line 1103
    move-result-object v0

    .line 1104
    return-object v0

    .line 1105
    .line 1106
    :cond_21
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1107
    .line 1108
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1109
    .line 1110
    const-string v3, "Unknown type "

    .line 1111
    .line 1112
    .line 1113
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1114
    .line 1115
    .line 1116
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1117
    .line 1118
    .line 1119
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1120
    move-result-object v0

    .line 1121
    .line 1122
    .line 1123
    invoke-direct {v1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1124
    throw v1

    .line 1125
    .line 1126
    :cond_22
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1127
    .line 1128
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1129
    .line 1130
    const-string v3, "no descriptor for type constructor of "

    .line 1131
    .line 1132
    .line 1133
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1134
    .line 1135
    .line 1136
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1137
    .line 1138
    .line 1139
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1140
    move-result-object v0

    .line 1141
    .line 1142
    .line 1143
    invoke-direct {v1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1144
    throw v1

    .line 1145
    .line 1146
    :cond_23
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1147
    .line 1148
    .line 1149
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1150
    .line 1151
    .line 1152
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1153
    .line 1154
    .line 1155
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1156
    .line 1157
    .line 1158
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1159
    move-result-object v1

    .line 1160
    .line 1161
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 1162
    .line 1163
    .line 1164
    invoke-static {v2, v1, v0}, LA7/c;->c(Lkotlin/jvm/internal/V;Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1165
    move-result-object v0

    .line 1166
    .line 1167
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 1168
    .line 1169
    .line 1170
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1171
    move-result-object v0

    .line 1172
    .line 1173
    .line 1174
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1175
    throw v1

    .line 1176
    .line 1177
    :cond_24
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1178
    .line 1179
    .line 1180
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1181
    .line 1182
    .line 1183
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1184
    .line 1185
    .line 1186
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1187
    .line 1188
    .line 1189
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1190
    move-result-object v1

    .line 1191
    .line 1192
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 1193
    .line 1194
    .line 1195
    invoke-static {v2, v1, v0}, LA7/c;->c(Lkotlin/jvm/internal/V;Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1196
    move-result-object v0

    .line 1197
    .line 1198
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 1199
    .line 1200
    .line 1201
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1202
    move-result-object v0

    .line 1203
    .line 1204
    .line 1205
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1206
    throw v1

    .line 1207
    .line 1208
    :cond_25
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1209
    .line 1210
    .line 1211
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1212
    .line 1213
    .line 1214
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1215
    .line 1216
    .line 1217
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1218
    .line 1219
    .line 1220
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1221
    move-result-object v1

    .line 1222
    .line 1223
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 1224
    .line 1225
    .line 1226
    invoke-static {v2, v1, v0}, LA7/c;->c(Lkotlin/jvm/internal/V;Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1227
    move-result-object v0

    .line 1228
    .line 1229
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 1230
    .line 1231
    .line 1232
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1233
    move-result-object v0

    .line 1234
    .line 1235
    .line 1236
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1237
    throw v1

    .line 1238
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
