.class public final enum LAa/f$c;
.super Ljava/lang/Enum;
.source "AbstractBinaryClassAnnotationLoader.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LAa/f$c;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $ENTRIES:LN9/a;

.field private static final synthetic $VALUES:[LAa/f$c;

.field public static final enum BACKING_FIELD:LAa/f$c;

.field public static final enum DELEGATE_FIELD:LAa/f$c;

.field public static final enum PROPERTY:LAa/f$c;


# direct methods
.method private static final synthetic $values()[LAa/f$c;
    .locals 3

    .line 1
    sget-object v0, LAa/f$c;->PROPERTY:LAa/f$c;

    .line 2
    .line 3
    sget-object v1, LAa/f$c;->BACKING_FIELD:LAa/f$c;

    .line 4
    .line 5
    sget-object v2, LAa/f$c;->DELEGATE_FIELD:LAa/f$c;

    .line 6
    .line 7
    filled-new-array {v0, v1, v2}, [LAa/f$c;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 1
    .line 2
    new-instance v0, LAa/f$c;

    .line 3
    .line 4
    const/4 v1, 0x0

    sget-object v1, Lr4/YC/uiqNHAgPowg;->athtPgWkmmSn:Ljava/lang/String;

    .line 5
    const/4 v2, 0x0

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, v2}, LAa/f$c;-><init>(Ljava/lang/String;I)V

    .line 9
    .line 10
    sput-object v0, LAa/f$c;->PROPERTY:LAa/f$c;

    .line 11
    .line 12
    new-instance v0, LAa/f$c;

    .line 13
    .line 14
    const-string v1, "BACKING_FIELD"

    .line 15
    const/4 v2, 0x1

    .line 16
    .line 17
    .line 18
    invoke-direct {v0, v1, v2}, LAa/f$c;-><init>(Ljava/lang/String;I)V

    .line 19
    .line 20
    sput-object v0, LAa/f$c;->BACKING_FIELD:LAa/f$c;

    .line 21
    .line 22
    new-instance v0, LAa/f$c;

    .line 23
    .line 24
    const-string v1, "DELEGATE_FIELD"

    .line 25
    const/4 v2, 0x2

    .line 26
    .line 27
    .line 28
    invoke-direct {v0, v1, v2}, LAa/f$c;-><init>(Ljava/lang/String;I)V

    .line 29
    .line 30
    sput-object v0, LAa/f$c;->DELEGATE_FIELD:LAa/f$c;

    .line 31
    .line 32
    .line 33
    invoke-static {}, LAa/f$c;->$values()[LAa/f$c;

    .line 34
    move-result-object v0

    .line 35
    .line 36
    sput-object v0, LAa/f$c;->$VALUES:[LAa/f$c;

    .line 37
    .line 38
    .line 39
    invoke-static {v0}, LN9/b;->a([Ljava/lang/Enum;)LN9/c;

    .line 40
    move-result-object v0

    .line 41
    .line 42
    sput-object v0, LAa/f$c;->$ENTRIES:LN9/a;

    .line 43
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LAa/f$c;
    .locals 1

    .line 1
    const-class v0, LAa/f$c;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LAa/f$c;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LAa/f$c;
    .locals 1

    .line 1
    sget-object v0, LAa/f$c;->$VALUES:[LAa/f$c;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LAa/f$c;

    .line 8
    .line 9
    return-object v0
.end method
