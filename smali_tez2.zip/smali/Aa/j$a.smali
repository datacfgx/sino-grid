.class public abstract LAa/j$a;
.super Ljava/lang/Object;
.source "BinaryClassAnnotationAndConstantLoaderImpl.kt"

# interfaces
.implements LAa/x$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:LAa/j;


# direct methods
.method public constructor <init>(LAa/j;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAa/j$a;->a:LAa/j;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final b(LHa/f;LMa/f;)V
    .locals 1

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, LMa/v;

    .line 7
    .line 8
    invoke-direct {v0, p2}, LMa/v;-><init>(LMa/f;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, v0}, LAa/j$a;->g(LHa/f;LMa/g;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final c(LHa/b;LHa/f;)LAa/x$a;
    .locals 3

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    sget-object v1, Lia/a0;->a:Lia/a0$a;

    .line 12
    .line 13
    const-string v2, "NO_SOURCE"

    .line 14
    .line 15
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v2, p0, LAa/j$a;->a:LAa/j;

    .line 19
    .line 20
    invoke-virtual {v2, p1, v1, v0}, LAa/j;->p(LHa/b;Lia/a0;Ljava/util/List;)LAa/k;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v1, LAa/j$a$a;

    .line 28
    .line 29
    invoke-direct {v1, p1, p0, p2, v0}, LAa/j$a$a;-><init>(LAa/k;LAa/j$a;LHa/f;Ljava/util/ArrayList;)V

    .line 30
    .line 31
    .line 32
    return-object v1
.end method

.method public final d(LHa/f;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LAa/j$a;->a:LAa/j;

    .line 2
    .line 3
    invoke-static {v0, p1, p2}, LAa/j;->t(LAa/j;LHa/f;Ljava/lang/Object;)LMa/g;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    invoke-virtual {p0, p1, p2}, LAa/j$a;->g(LHa/f;LMa/g;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final e(LHa/f;LHa/b;LHa/f;)V
    .locals 1

    .line 1
    const-string v0, "enumClassId"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "enumEntryName"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, LMa/k;

    .line 12
    .line 13
    invoke-direct {v0, p2, p3}, LMa/k;-><init>(LHa/b;LHa/f;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, p1, v0}, LAa/j$a;->g(LHa/f;LMa/g;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final f(LHa/f;)LAa/x$b;
    .locals 2

    .line 1
    new-instance v0, LAa/j$a$b;

    .line 2
    .line 3
    iget-object v1, p0, LAa/j$a;->a:LAa/j;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1, p0}, LAa/j$a$b;-><init>(LAa/j;LHa/f;LAa/j$a;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public abstract g(LHa/f;LMa/g;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LHa/f;",
            "LMa/g<",
            "*>;)V"
        }
    .end annotation
.end method
