.class public final LAa/t$a;
.super LAa/t;
.source "methodSignatureMapping.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAa/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final i:LAa/t;


# direct methods
.method public constructor <init>(LAa/t;)V
    .locals 1

    .line 1
    const-string v0, "elementType"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, LAa/t;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LAa/t$a;->i:LAa/t;

    .line 10
    .line 11
    return-void
.end method
