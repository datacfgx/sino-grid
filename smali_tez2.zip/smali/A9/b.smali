.class public final LA9/b;
.super Ljava/lang/Object;
.source "ISO8601Utils.java"


# static fields
.field public static final a:Ljava/util/TimeZone;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "UTC"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, LA9/b;->a:Ljava/util/TimeZone;

    .line 8
    .line 9
    return-void
.end method

.method public static a(Ljava/lang/String;IC)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-ge p1, v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    if-ne p0, p2, :cond_0

    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    return p0

    .line 15
    :cond_0
    const/4 p0, 0x0

    .line 16
    return p0
.end method

.method public static b(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;
    .locals 17
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/text/ParseException;
        }
    .end annotation

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    const-string v3, "\'"

    .line 6
    .line 7
    :try_start_0
    invoke-virtual {v2}, Ljava/text/ParsePosition;->getIndex()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    add-int/lit8 v4, v0, 0x4

    .line 12
    .line 13
    invoke-static {v1, v0, v4}, LA9/b;->c(Ljava/lang/String;II)I

    .line 14
    .line 15
    .line 16
    move-result v5

    .line 17
    const/16 v6, 0x2d

    .line 18
    .line 19
    invoke-static {v1, v4, v6}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 20
    .line 21
    .line 22
    move-result v7

    .line 23
    const/4 v8, 0x5

    .line 24
    if-eqz v7, :cond_0

    .line 25
    .line 26
    add-int/lit8 v4, v0, 0x5

    .line 27
    .line 28
    :cond_0
    add-int/lit8 v0, v4, 0x2

    .line 29
    .line 30
    invoke-static {v1, v4, v0}, LA9/b;->c(Ljava/lang/String;II)I

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    invoke-static {v1, v0, v6}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 35
    .line 36
    .line 37
    move-result v9

    .line 38
    const/4 v10, 0x3

    .line 39
    if-eqz v9, :cond_1

    .line 40
    .line 41
    add-int/lit8 v0, v4, 0x3

    .line 42
    .line 43
    :cond_1
    add-int/lit8 v4, v0, 0x2

    .line 44
    .line 45
    invoke-static {v1, v0, v4}, LA9/b;->c(Ljava/lang/String;II)I

    .line 46
    .line 47
    .line 48
    move-result v9

    .line 49
    const/16 v11, 0x54

    .line 50
    .line 51
    invoke-static {v1, v4, v11}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 52
    .line 53
    .line 54
    move-result v11

    .line 55
    const/4 v12, 0x1

    .line 56
    if-nez v11, :cond_2

    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 59
    .line 60
    .line 61
    move-result v13

    .line 62
    if-gt v13, v4, :cond_2

    .line 63
    .line 64
    new-instance v0, Ljava/util/GregorianCalendar;

    .line 65
    .line 66
    sub-int/2addr v7, v12

    .line 67
    invoke-direct {v0, v5, v7, v9}, Ljava/util/GregorianCalendar;-><init>(III)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v2, v4}, Ljava/text/ParsePosition;->setIndex(I)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    return-object v0

    .line 78
    :cond_2
    const/4 v13, 0x2

    .line 79
    const/16 v14, 0x2b

    .line 80
    .line 81
    const/16 v15, 0x5a

    .line 82
    .line 83
    if-eqz v11, :cond_d

    .line 84
    .line 85
    add-int/lit8 v4, v0, 0x3

    .line 86
    .line 87
    add-int/lit8 v11, v0, 0x5

    .line 88
    .line 89
    invoke-static {v1, v4, v11}, LA9/b;->c(Ljava/lang/String;II)I

    .line 90
    .line 91
    .line 92
    move-result v4

    .line 93
    const/16 v8, 0x3a

    .line 94
    .line 95
    invoke-static {v1, v11, v8}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 96
    .line 97
    .line 98
    move-result v16

    .line 99
    if-eqz v16, :cond_3

    .line 100
    .line 101
    add-int/lit8 v11, v0, 0x6

    .line 102
    .line 103
    :cond_3
    add-int/lit8 v0, v11, 0x2

    .line 104
    .line 105
    invoke-static {v1, v11, v0}, LA9/b;->c(Ljava/lang/String;II)I

    .line 106
    .line 107
    .line 108
    move-result v16

    .line 109
    invoke-static {v1, v0, v8}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 110
    .line 111
    .line 112
    move-result v8

    .line 113
    if-eqz v8, :cond_4

    .line 114
    .line 115
    add-int/2addr v11, v10

    .line 116
    move v0, v11

    .line 117
    :cond_4
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 118
    .line 119
    .line 120
    move-result v8

    .line 121
    if-le v8, v0, :cond_c

    .line 122
    .line 123
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 124
    .line 125
    .line 126
    move-result v8

    .line 127
    if-eq v8, v15, :cond_c

    .line 128
    .line 129
    if-eq v8, v14, :cond_c

    .line 130
    .line 131
    if-eq v8, v6, :cond_c

    .line 132
    .line 133
    add-int/lit8 v8, v0, 0x2

    .line 134
    .line 135
    invoke-static {v1, v0, v8}, LA9/b;->c(Ljava/lang/String;II)I

    .line 136
    .line 137
    .line 138
    move-result v11

    .line 139
    const/16 v10, 0x3b

    .line 140
    .line 141
    if-le v11, v10, :cond_5

    .line 142
    .line 143
    const/16 v10, 0x3f

    .line 144
    .line 145
    if-ge v11, v10, :cond_5

    .line 146
    .line 147
    const/16 v11, 0x3b

    .line 148
    .line 149
    :cond_5
    const/16 v10, 0x2e

    .line 150
    .line 151
    invoke-static {v1, v8, v10}, LA9/b;->a(Ljava/lang/String;IC)Z

    .line 152
    .line 153
    .line 154
    move-result v10

    .line 155
    if-eqz v10, :cond_b

    .line 156
    .line 157
    add-int/lit8 v8, v0, 0x3

    .line 158
    .line 159
    add-int/lit8 v10, v0, 0x4

    .line 160
    .line 161
    :goto_0
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 162
    .line 163
    .line 164
    move-result v6

    .line 165
    if-ge v10, v6, :cond_8

    .line 166
    .line 167
    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    .line 168
    .line 169
    .line 170
    move-result v6

    .line 171
    const/16 v14, 0x30

    .line 172
    .line 173
    if-lt v6, v14, :cond_7

    .line 174
    .line 175
    const/16 v14, 0x39

    .line 176
    .line 177
    if-le v6, v14, :cond_6

    .line 178
    .line 179
    goto :goto_1

    .line 180
    :cond_6
    add-int/lit8 v10, v10, 0x1

    .line 181
    .line 182
    const/16 v14, 0x2b

    .line 183
    .line 184
    goto :goto_0

    .line 185
    :cond_7
    :goto_1
    move v6, v10

    .line 186
    goto :goto_2

    .line 187
    :cond_8
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 188
    .line 189
    .line 190
    move-result v6

    .line 191
    :goto_2
    add-int/lit8 v0, v0, 0x6

    .line 192
    .line 193
    invoke-static {v6, v0}, Ljava/lang/Math;->min(II)I

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    invoke-static {v1, v8, v0}, LA9/b;->c(Ljava/lang/String;II)I

    .line 198
    .line 199
    .line 200
    move-result v10

    .line 201
    sub-int/2addr v0, v8

    .line 202
    if-eq v0, v12, :cond_a

    .line 203
    .line 204
    if-eq v0, v13, :cond_9

    .line 205
    .line 206
    goto :goto_3

    .line 207
    :cond_9
    mul-int/lit8 v10, v10, 0xa

    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_a
    mul-int/lit8 v10, v10, 0x64

    .line 211
    .line 212
    :goto_3
    move v0, v4

    .line 213
    move v4, v6

    .line 214
    move/from16 v6, v16

    .line 215
    .line 216
    goto :goto_5

    .line 217
    :catch_0
    move-exception v0

    .line 218
    goto/16 :goto_8

    .line 219
    .line 220
    :catch_1
    move-exception v0

    .line 221
    goto/16 :goto_8

    .line 222
    .line 223
    :catch_2
    move-exception v0

    .line 224
    goto/16 :goto_8

    .line 225
    .line 226
    :cond_b
    move v0, v4

    .line 227
    move v4, v8

    .line 228
    move/from16 v6, v16

    .line 229
    .line 230
    const/4 v10, 0x0

    .line 231
    goto :goto_5

    .line 232
    :cond_c
    move v6, v4

    .line 233
    move v4, v0

    .line 234
    move v0, v6

    .line 235
    move/from16 v6, v16

    .line 236
    .line 237
    :goto_4
    const/4 v10, 0x0

    .line 238
    const/4 v11, 0x0

    .line 239
    goto :goto_5

    .line 240
    :cond_d
    const/4 v0, 0x0

    .line 241
    const/4 v6, 0x0

    .line 242
    goto :goto_4

    .line 243
    :goto_5
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 244
    .line 245
    .line 246
    move-result v8

    .line 247
    if-le v8, v4, :cond_15

    .line 248
    .line 249
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    .line 250
    .line 251
    .line 252
    move-result v8
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 253
    sget-object v14, LA9/b;->a:Ljava/util/TimeZone;

    .line 254
    .line 255
    if-ne v8, v15, :cond_e

    .line 256
    .line 257
    add-int/2addr v4, v12

    .line 258
    goto/16 :goto_7

    .line 259
    .line 260
    :cond_e
    const/16 v15, 0x2b

    .line 261
    .line 262
    if-eq v8, v15, :cond_10

    .line 263
    .line 264
    const/16 v15, 0x2d

    .line 265
    .line 266
    if-ne v8, v15, :cond_f

    .line 267
    .line 268
    goto :goto_6

    .line 269
    :cond_f
    :try_start_1
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 270
    .line 271
    new-instance v4, Ljava/lang/StringBuilder;

    .line 272
    .line 273
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 274
    .line 275
    .line 276
    const-string v5, "Invalid time zone indicator \'"

    .line 277
    .line 278
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 279
    .line 280
    .line 281
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 282
    .line 283
    .line 284
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 285
    .line 286
    .line 287
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v4

    .line 291
    invoke-direct {v0, v4}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    throw v0

    .line 295
    :cond_10
    :goto_6
    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v8

    .line 299
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 300
    .line 301
    .line 302
    move-result v15

    .line 303
    add-int/2addr v4, v15

    .line 304
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 305
    .line 306
    .line 307
    move-result v15

    .line 308
    const/4 v13, 0x3

    .line 309
    if-ne v15, v13, :cond_11

    .line 310
    .line 311
    new-instance v13, Ljava/lang/StringBuilder;

    .line 312
    .line 313
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 317
    .line 318
    .line 319
    const-string v8, "00"

    .line 320
    .line 321
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 322
    .line 323
    .line 324
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v8

    .line 328
    :cond_11
    const-string v13, "+0000"

    .line 329
    .line 330
    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move-result v13

    .line 334
    if-nez v13, :cond_14

    .line 335
    .line 336
    const-string v13, "+00:00"

    .line 337
    .line 338
    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 339
    .line 340
    .line 341
    move-result v13

    .line 342
    if-eqz v13, :cond_12

    .line 343
    .line 344
    goto :goto_7

    .line 345
    :cond_12
    new-instance v13, Ljava/lang/StringBuilder;

    .line 346
    .line 347
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 348
    .line 349
    .line 350
    const-string v14, "GMT"

    .line 351
    .line 352
    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 353
    .line 354
    .line 355
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v8

    .line 362
    invoke-static {v8}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    .line 363
    .line 364
    .line 365
    move-result-object v14

    .line 366
    invoke-virtual {v14}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v13

    .line 370
    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v15

    .line 374
    if-nez v15, :cond_14

    .line 375
    .line 376
    const-string v15, ":"

    .line 377
    .line 378
    const-string v12, ""

    .line 379
    .line 380
    invoke-virtual {v13, v15, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 381
    .line 382
    .line 383
    move-result-object v12

    .line 384
    invoke-virtual {v12, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 385
    .line 386
    .line 387
    move-result v12

    .line 388
    if-eqz v12, :cond_13

    .line 389
    .line 390
    goto :goto_7

    .line 391
    :cond_13
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 392
    .line 393
    new-instance v4, Ljava/lang/StringBuilder;

    .line 394
    .line 395
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 396
    .line 397
    .line 398
    const-string v5, "Mismatching time zone indicator: "

    .line 399
    .line 400
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 401
    .line 402
    .line 403
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 404
    .line 405
    .line 406
    const-string v5, " given, resolves to "

    .line 407
    .line 408
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 409
    .line 410
    .line 411
    invoke-virtual {v14}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    .line 412
    .line 413
    .line 414
    move-result-object v5

    .line 415
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 416
    .line 417
    .line 418
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v4

    .line 422
    invoke-direct {v0, v4}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 423
    .line 424
    .line 425
    throw v0

    .line 426
    :cond_14
    :goto_7
    new-instance v8, Ljava/util/GregorianCalendar;

    .line 427
    .line 428
    invoke-direct {v8, v14}, Ljava/util/GregorianCalendar;-><init>(Ljava/util/TimeZone;)V

    .line 429
    .line 430
    .line 431
    const/4 v12, 0x0

    .line 432
    invoke-virtual {v8, v12}, Ljava/util/Calendar;->setLenient(Z)V

    .line 433
    .line 434
    .line 435
    const/4 v12, 0x1

    .line 436
    invoke-virtual {v8, v12, v5}, Ljava/util/Calendar;->set(II)V

    .line 437
    .line 438
    .line 439
    sub-int/2addr v7, v12

    .line 440
    const/4 v5, 0x2

    .line 441
    invoke-virtual {v8, v5, v7}, Ljava/util/Calendar;->set(II)V

    .line 442
    .line 443
    .line 444
    const/4 v5, 0x5

    .line 445
    invoke-virtual {v8, v5, v9}, Ljava/util/Calendar;->set(II)V

    .line 446
    .line 447
    .line 448
    const/16 v5, 0xb

    .line 449
    .line 450
    invoke-virtual {v8, v5, v0}, Ljava/util/Calendar;->set(II)V

    .line 451
    .line 452
    .line 453
    const/16 v0, 0xc

    .line 454
    .line 455
    invoke-virtual {v8, v0, v6}, Ljava/util/Calendar;->set(II)V

    .line 456
    .line 457
    .line 458
    const/16 v0, 0xd

    .line 459
    .line 460
    invoke-virtual {v8, v0, v11}, Ljava/util/Calendar;->set(II)V

    .line 461
    .line 462
    .line 463
    const/16 v0, 0xe

    .line 464
    .line 465
    invoke-virtual {v8, v0, v10}, Ljava/util/Calendar;->set(II)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {v2, v4}, Ljava/text/ParsePosition;->setIndex(I)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v8}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    .line 472
    .line 473
    .line 474
    move-result-object v0

    .line 475
    return-object v0

    .line 476
    :cond_15
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 477
    .line 478
    const-string v4, "No time zone indicator"

    .line 479
    .line 480
    invoke-direct {v0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 481
    .line 482
    .line 483
    throw v0
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 484
    :goto_8
    if-nez v1, :cond_16

    .line 485
    .line 486
    const/4 v1, 0x0

    .line 487
    goto :goto_9

    .line 488
    :cond_16
    const-string v4, "\""

    .line 489
    .line 490
    invoke-static {v4, v1, v3}, LM/r;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v1

    .line 494
    :goto_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object v3

    .line 498
    if-eqz v3, :cond_17

    .line 499
    .line 500
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 501
    .line 502
    .line 503
    move-result v4

    .line 504
    if-eqz v4, :cond_18

    .line 505
    .line 506
    :cond_17
    new-instance v3, Ljava/lang/StringBuilder;

    .line 507
    .line 508
    const-string v4, "("

    .line 509
    .line 510
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 514
    .line 515
    .line 516
    move-result-object v4

    .line 517
    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object v4

    .line 521
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 522
    .line 523
    .line 524
    const-string v4, ")"

    .line 525
    .line 526
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 527
    .line 528
    .line 529
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 530
    .line 531
    .line 532
    move-result-object v3

    .line 533
    :cond_18
    new-instance v4, Ljava/text/ParseException;

    .line 534
    .line 535
    const-string v5, "Failed to parse date ["

    .line 536
    .line 537
    const-string v6, "]: "

    .line 538
    .line 539
    invoke-static {v5, v1, v6, v3}, LG/j0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 540
    .line 541
    .line 542
    move-result-object v1

    .line 543
    invoke-virtual {v2}, Ljava/text/ParsePosition;->getIndex()I

    .line 544
    .line 545
    .line 546
    move-result v2

    .line 547
    invoke-direct {v4, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 548
    .line 549
    .line 550
    invoke-virtual {v4, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 551
    .line 552
    .line 553
    throw v4
.end method

.method public static c(Ljava/lang/String;II)I
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NumberFormatException;
        }
    .end annotation

    .line 1
    if-ltz p1, :cond_4

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-gt p2, v0, :cond_4

    .line 8
    .line 9
    if-gt p1, p2, :cond_4

    .line 10
    .line 11
    const-string v0, "Invalid number: "

    .line 12
    .line 13
    const/16 v1, 0xa

    .line 14
    .line 15
    if-ge p1, p2, :cond_1

    .line 16
    .line 17
    add-int/lit8 v2, p1, 0x1

    .line 18
    .line 19
    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    invoke-static {v3, v1}, Ljava/lang/Character;->digit(CI)I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    if-ltz v3, :cond_0

    .line 28
    .line 29
    neg-int v3, v3

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance v1, Ljava/lang/NumberFormatException;

    .line 32
    .line 33
    new-instance v2, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    invoke-direct {v1, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v1

    .line 53
    :cond_1
    const/4 v3, 0x0

    .line 54
    move v2, p1

    .line 55
    :goto_0
    if-ge v2, p2, :cond_3

    .line 56
    .line 57
    add-int/lit8 v4, v2, 0x1

    .line 58
    .line 59
    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    invoke-static {v2, v1}, Ljava/lang/Character;->digit(CI)I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-ltz v2, :cond_2

    .line 68
    .line 69
    mul-int/lit8 v3, v3, 0xa

    .line 70
    .line 71
    sub-int/2addr v3, v2

    .line 72
    move v2, v4

    .line 73
    goto :goto_0

    .line 74
    :cond_2
    new-instance v1, Ljava/lang/NumberFormatException;

    .line 75
    .line 76
    new-instance v2, Ljava/lang/StringBuilder;

    .line 77
    .line 78
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    invoke-direct {v1, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw v1

    .line 96
    :cond_3
    neg-int p0, v3

    .line 97
    return p0

    .line 98
    :cond_4
    new-instance p1, Ljava/lang/NumberFormatException;

    .line 99
    .line 100
    invoke-direct {p1, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw p1
.end method
