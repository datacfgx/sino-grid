.class public final LE9/d;
.super Ljava/lang/Object;
.source "RealmObservableFactory.java"

# interfaces
.implements Le9/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Le9/i<",
        "LE9/a<",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lio/realm/internal/RealmObjectProxy;

.field public final synthetic b:Lio/realm/H0;

.field public final synthetic c:LE9/h;


# direct methods
.method public constructor <init>(LE9/h;Lio/realm/internal/RealmObjectProxy;Lio/realm/H0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE9/d;->c:LE9/h;

    .line 5
    .line 6
    iput-object p2, p0, LE9/d;->a:Lio/realm/internal/RealmObjectProxy;

    .line 7
    .line 8
    iput-object p3, p0, LE9/d;->b:Lio/realm/H0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Lo9/j$a;)V
    .locals 5

    .line 1
    iget-object v0, p0, LE9/d;->a:Lio/realm/internal/RealmObjectProxy;

    .line 2
    .line 3
    invoke-static {v0}, Lio/realm/RealmObject;->isValid(Lio/realm/M0;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    sget-object v1, Lio/realm/x0;->G:Ljava/lang/Object;

    .line 11
    .line 12
    iget-object v1, p0, LE9/d;->b:Lio/realm/H0;

    .line 13
    .line 14
    if-eqz v1, :cond_2

    .line 15
    .line 16
    sget-object v2, Lio/realm/F0;->e:Ljava/util/ArrayList;

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    iget-object v3, v1, Lio/realm/H0;->c:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v3, v2}, Lio/realm/F0;->b(Ljava/lang/String;Z)Lio/realm/F0;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    sget-object v3, Lio/realm/internal/OsSharedRealm$a;->c:Lio/realm/internal/OsSharedRealm$a;

    .line 26
    .line 27
    const-class v4, Lio/realm/x0;

    .line 28
    .line 29
    invoke-virtual {v2, v1, v4, v3}, Lio/realm/F0;->a(Lio/realm/H0;Ljava/lang/Class;Lio/realm/internal/OsSharedRealm$a;)Lio/realm/a;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Lio/realm/x0;

    .line 34
    .line 35
    iget-object v2, p0, LE9/d;->c:LE9/h;

    .line 36
    .line 37
    iget-object v3, v2, LE9/h;->b:LE9/h$c;

    .line 38
    .line 39
    invoke-virtual {v3}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, LE9/h$d;

    .line 44
    .line 45
    invoke-virtual {v3, v0}, LE9/h$d;->a(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    new-instance v3, LE9/b;

    .line 49
    .line 50
    invoke-direct {v3, p0, p1}, LE9/b;-><init>(LE9/d;Lo9/j$a;)V

    .line 51
    .line 52
    .line 53
    invoke-static {v0, v3}, Lio/realm/RealmObject;->addChangeListener(Lio/realm/M0;Lio/realm/S0;)V

    .line 54
    .line 55
    .line 56
    new-instance v4, LE9/c;

    .line 57
    .line 58
    invoke-direct {v4, p0, v1, v3}, LE9/c;-><init>(LE9/d;Lio/realm/x0;LE9/b;)V

    .line 59
    .line 60
    .line 61
    new-instance v1, Lg9/c;

    .line 62
    .line 63
    invoke-direct {v1, v4}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-static {p1, v1}, Lj9/b;->set(Ljava/util/concurrent/atomic/AtomicReference;Lg9/b;)Z

    .line 67
    .line 68
    .line 69
    new-instance v1, LE9/a;

    .line 70
    .line 71
    iget-boolean v2, v2, LE9/h;->a:Z

    .line 72
    .line 73
    if-eqz v2, :cond_1

    .line 74
    .line 75
    invoke-static {v0}, Lio/realm/RealmObject;->freeze(Lio/realm/M0;)Lio/realm/M0;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    :cond_1
    const/4 v2, 0x0

    .line 80
    invoke-direct {v1, v0, v2}, LE9/a;-><init>(Lio/realm/M0;Lio/realm/internal/OsObject$b;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, v1}, Lo9/j$a;->d(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 88
    .line 89
    const-string v0, "A non-null RealmConfiguration must be provided"

    .line 90
    .line 91
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    throw p1
.end method
