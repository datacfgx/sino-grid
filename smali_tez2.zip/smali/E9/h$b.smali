.class public final LE9/h$b;
.super Ljava/lang/ThreadLocal;
.source "RealmObservableFactory.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE9/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal<",
        "LE9/h$d<",
        "Lio/realm/J0;",
        ">;>;"
    }
.end annotation


# virtual methods
.method public final initialValue()Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, LE9/h$d;

    .line 2
    .line 3
    invoke-direct {v0}, LE9/h$d;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
