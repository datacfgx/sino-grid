.class public final LE9/c;
.super Ljava/lang/Object;
.source "RealmObservableFactory.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lio/realm/x0;

.field public final synthetic b:LE9/b;

.field public final synthetic c:LE9/d;


# direct methods
.method public constructor <init>(LE9/d;Lio/realm/x0;LE9/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE9/c;->c:LE9/d;

    .line 5
    .line 6
    iput-object p2, p0, LE9/c;->a:Lio/realm/x0;

    .line 7
    .line 8
    iput-object p3, p0, LE9/c;->b:LE9/b;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget-object v0, p0, LE9/c;->a:Lio/realm/x0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/realm/a;->z()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    iget-object v2, p0, LE9/c;->c:LE9/d;

    .line 8
    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    iget-object v1, v2, LE9/d;->a:Lio/realm/internal/RealmObjectProxy;

    .line 12
    .line 13
    iget-object v3, p0, LE9/c;->b:LE9/b;

    .line 14
    .line 15
    invoke-static {v1, v3}, Lio/realm/RealmObject;->removeChangeListener(Lio/realm/M0;Lio/realm/S0;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lio/realm/a;->close()V

    .line 19
    .line 20
    .line 21
    :cond_0
    iget-object v0, v2, LE9/d;->c:LE9/h;

    .line 22
    .line 23
    iget-object v0, v0, LE9/h;->b:LE9/h$c;

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, LE9/h$d;

    .line 30
    .line 31
    iget-object v1, v2, LE9/d;->a:Lio/realm/internal/RealmObjectProxy;

    .line 32
    .line 33
    invoke-virtual {v0, v1}, LE9/h$d;->b(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method
