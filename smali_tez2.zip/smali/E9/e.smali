.class public final LE9/e;
.super Ljava/lang/Object;
.source "RealmObservableFactory.java"

# interfaces
.implements Lio/realm/S0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lio/realm/S0<",
        "Lio/realm/DynamicRealmObject;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lo9/j$a;

.field public final synthetic b:LE9/g;


# direct methods
.method public constructor <init>(LE9/g;Lo9/j$a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE9/e;->b:LE9/g;

    .line 5
    .line 6
    iput-object p2, p0, LE9/e;->a:Lo9/j$a;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lio/realm/M0;Lio/realm/internal/OsObject$b;)V
    .locals 3

    .line 1
    check-cast p1, Lio/realm/DynamicRealmObject;

    .line 2
    .line 3
    iget-object v0, p0, LE9/e;->a:Lo9/j$a;

    .line 4
    .line 5
    invoke-virtual {v0}, Lo9/j$a;->b()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_1

    .line 10
    .line 11
    new-instance v1, LE9/a;

    .line 12
    .line 13
    iget-object v2, p0, LE9/e;->b:LE9/g;

    .line 14
    .line 15
    iget-object v2, v2, LE9/g;->c:LE9/h;

    .line 16
    .line 17
    iget-boolean v2, v2, LE9/h;->a:Z

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    invoke-static {p1}, Lio/realm/RealmObject;->freeze(Lio/realm/M0;)Lio/realm/M0;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Lio/realm/DynamicRealmObject;

    .line 26
    .line 27
    :cond_0
    invoke-direct {v1, p1, p2}, LE9/a;-><init>(Lio/realm/M0;Lio/realm/internal/OsObject$b;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Lo9/j$a;->d(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    return-void
.end method
