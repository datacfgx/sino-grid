.class public final LE9/b;
.super Ljava/lang/Object;
.source "RealmObservableFactory.java"

# interfaces
.implements Lio/realm/S0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lio/realm/S0<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lo9/j$a;

.field public final synthetic b:LE9/d;


# direct methods
.method public constructor <init>(LE9/d;Lo9/j$a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE9/b;->b:LE9/d;

    .line 5
    .line 6
    iput-object p2, p0, LE9/b;->a:Lo9/j$a;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lio/realm/M0;Lio/realm/internal/OsObject$b;)V
    .locals 3

    .line 1
    iget-object v0, p0, LE9/b;->a:Lo9/j$a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lo9/j$a;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_1

    .line 8
    .line 9
    new-instance v1, LE9/a;

    .line 10
    .line 11
    iget-object v2, p0, LE9/b;->b:LE9/d;

    .line 12
    .line 13
    iget-object v2, v2, LE9/d;->c:LE9/h;

    .line 14
    .line 15
    iget-boolean v2, v2, LE9/h;->a:Z

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, Lio/realm/RealmObject;->freeze(Lio/realm/M0;)Lio/realm/M0;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    :cond_0
    invoke-direct {v1, p1, p2}, LE9/a;-><init>(Lio/realm/M0;Lio/realm/internal/OsObject$b;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0, v1}, Lo9/j$a;->d(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :cond_1
    return-void
.end method
