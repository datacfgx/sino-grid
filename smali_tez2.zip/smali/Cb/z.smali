.class public final LCb/z;
.super Ljava/lang/Object;
.source "Enums.kt"


# direct methods
.method public static final a(Ljava/lang/String;[Ljava/lang/Enum;[Ljava/lang/String;[[Ljava/lang/annotation/Annotation;)LCb/y;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    const-string v4, "serialName"

    .line 10
    .line 11
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v5, "values"

    .line 15
    .line 16
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-string v6, "names"

    .line 20
    .line 21
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string v6, "entryAnnotations"

    .line 25
    .line 26
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    new-instance v6, LCb/w;

    .line 30
    .line 31
    array-length v7, v1

    .line 32
    invoke-direct {v6, v0, v7}, LCb/w;-><init>(Ljava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    array-length v7, v1

    .line 36
    const/4 v8, 0x0

    .line 37
    move v9, v8

    .line 38
    move v10, v9

    .line 39
    :goto_0
    if-ge v9, v7, :cond_3

    .line 40
    .line 41
    aget-object v11, v1, v9

    .line 42
    .line 43
    add-int/lit8 v12, v10, 0x1

    .line 44
    .line 45
    invoke-static {v2, v10}, Lkotlin/collections/ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v13

    .line 49
    check-cast v13, Ljava/lang/String;

    .line 50
    .line 51
    if-nez v13, :cond_0

    .line 52
    .line 53
    invoke-virtual {v11}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v13

    .line 57
    :cond_0
    invoke-virtual {v6, v13, v8}, LCb/g0;->b(Ljava/lang/String;Z)V

    .line 58
    .line 59
    .line 60
    invoke-static {v3, v10}, Lkotlin/collections/ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    check-cast v10, [Ljava/lang/annotation/Annotation;

    .line 65
    .line 66
    if-eqz v10, :cond_2

    .line 67
    .line 68
    array-length v11, v10

    .line 69
    move v13, v8

    .line 70
    :goto_1
    if-ge v13, v11, :cond_2

    .line 71
    .line 72
    aget-object v14, v10, v13

    .line 73
    .line 74
    const-string v15, "annotation"

    .line 75
    .line 76
    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    iget v15, v6, LCb/g0;->d:I

    .line 80
    .line 81
    iget-object v8, v6, LCb/g0;->f:[Ljava/util/List;

    .line 82
    .line 83
    aget-object v15, v8, v15

    .line 84
    .line 85
    if-nez v15, :cond_1

    .line 86
    .line 87
    new-instance v15, Ljava/util/ArrayList;

    .line 88
    .line 89
    const/4 v2, 0x1

    .line 90
    invoke-direct {v15, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 91
    .line 92
    .line 93
    iget v2, v6, LCb/g0;->d:I

    .line 94
    .line 95
    aput-object v15, v8, v2

    .line 96
    .line 97
    :cond_1
    invoke-interface {v15, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    add-int/lit8 v13, v13, 0x1

    .line 101
    .line 102
    move-object/from16 v2, p2

    .line 103
    .line 104
    const/4 v8, 0x0

    .line 105
    goto :goto_1

    .line 106
    :cond_2
    add-int/lit8 v9, v9, 0x1

    .line 107
    .line 108
    move-object/from16 v2, p2

    .line 109
    .line 110
    move v10, v12

    .line 111
    const/4 v8, 0x0

    .line 112
    goto :goto_0

    .line 113
    :cond_3
    new-instance v2, LCb/y;

    .line 114
    .line 115
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    const-string v3, "descriptor"

    .line 122
    .line 123
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    invoke-direct {v2, v0, v1}, LCb/y;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 127
    .line 128
    .line 129
    iput-object v6, v2, LCb/y;->b:LCb/w;

    .line 130
    .line 131
    return-object v2
.end method

.method public static final b(Ljava/lang/String;[Ljava/lang/Enum;)LCb/y;
    .locals 1

    .line 1
    const-string v0, "serialName"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "values"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, LCb/y;

    .line 12
    .line 13
    invoke-direct {v0, p0, p1}, LCb/y;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method
