.class public final synthetic LCb/X;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LCb/X;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LCb/X;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, LCb/X;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v3, p0, LCb/X;->a:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v2, Lcd/N;

    .line 11
    .line 12
    iput-boolean v1, v2, Lcd/N;->H0:Z

    .line 13
    .line 14
    invoke-virtual {v2}, LJc/e;->q0()LJc/f;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcd/W;

    .line 19
    .line 20
    iget-object v0, v0, Lcd/W;->g:Landroidx/lifecycle/z;

    .line 21
    .line 22
    new-instance v1, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0, v1}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, Lcd/N;->E0()Lcd/x;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v1, v0, Lcd/x;->m:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$f;->G()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v2}, LJc/e;->r0()V

    .line 43
    .line 44
    .line 45
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 46
    .line 47
    return-object v0

    .line 48
    :pswitch_0
    sget v0, Lbd/n;->F0:I

    .line 49
    .line 50
    check-cast v2, Lbd/n;

    .line 51
    .line 52
    invoke-virtual {v2}, LJc/e;->q0()LJc/f;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    check-cast v0, Lbd/I;

    .line 57
    .line 58
    iget-object v2, v0, Lbd/I;->l:Lkotlin/Pair;

    .line 59
    .line 60
    if-nez v2, :cond_0

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_0
    iget-object v3, v0, Lbd/I;->i:Landroidx/lifecycle/z;

    .line 64
    .line 65
    invoke-virtual {v3}, Landroidx/lifecycle/x;->d()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    check-cast v3, Ljava/util/List;

    .line 70
    .line 71
    if-eqz v3, :cond_4

    .line 72
    .line 73
    check-cast v3, Ljava/lang/Iterable;

    .line 74
    .line 75
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    if-eqz v4, :cond_2

    .line 84
    .line 85
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v4

    .line 89
    move-object v5, v4

    .line 90
    check-cast v5, Lorg/tezza/domain/gallery/a;

    .line 91
    .line 92
    iget-object v5, v5, Lorg/tezza/domain/gallery/a;->a:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {v2}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v6

    .line 98
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    if-eqz v5, :cond_1

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_2
    const/4 v4, 0x0

    .line 106
    :goto_0
    check-cast v4, Lorg/tezza/domain/gallery/a;

    .line 107
    .line 108
    if-nez v4, :cond_3

    .line 109
    .line 110
    goto :goto_1

    .line 111
    :cond_3
    iget-object v3, v0, LJc/f;->d:Landroidx/lifecycle/z;

    .line 112
    .line 113
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 114
    .line 115
    invoke-virtual {v3, v5}, Landroidx/lifecycle/z;->k(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    sget-object v3, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 119
    .line 120
    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    check-cast v2, Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 125
    .line 126
    new-instance v3, Lbd/v;

    .line 127
    .line 128
    invoke-direct {v3, v4, v2, v0}, Lbd/v;-><init>(Lorg/tezza/domain/gallery/a;Lorg/tezza/domain/gallery/GalleryItemAdjustments;Lbd/I;)V

    .line 129
    .line 130
    .line 131
    new-instance v2, Lo9/j;

    .line 132
    .line 133
    invoke-direct {v2, v3}, Lo9/j;-><init>(Le9/i;)V

    .line 134
    .line 135
    .line 136
    const-string v3, "create(...)"

    .line 137
    .line 138
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    invoke-static {v2}, Lzc/c;->a(Le9/g;)Le9/g;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    new-instance v3, LOc/x;

    .line 146
    .line 147
    invoke-direct {v3, v1, v0}, LOc/x;-><init>(ILjava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    new-instance v1, LLc/L;

    .line 151
    .line 152
    const/4 v4, 0x4

    .line 153
    invoke-direct {v1, v4, v0}, LLc/L;-><init>(ILjava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    const/4 v0, 0x2

    .line 157
    invoke-static {v2, v3, v1, v0}, Lv9/b;->c(Le9/g;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;I)Lm9/h;

    .line 158
    .line 159
    .line 160
    :cond_4
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 161
    .line 162
    return-object v0

    .line 163
    :pswitch_1
    check-cast v2, LM/t0;

    .line 164
    .line 165
    invoke-interface {v2}, LM/p1;->getValue()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 170
    .line 171
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    check-cast v0, Ljava/lang/Boolean;

    .line 176
    .line 177
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 178
    .line 179
    .line 180
    return-object v0

    .line 181
    :pswitch_2
    sget-object v1, LAb/o$d;->a:LAb/o$d;

    .line 182
    .line 183
    new-array v3, v0, [LAb/f;

    .line 184
    .line 185
    new-instance v4, LCb/Y;

    .line 186
    .line 187
    check-cast v2, LCb/Z;

    .line 188
    .line 189
    invoke-direct {v4, v0, v2}, LCb/Y;-><init>(ILjava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    const-string v0, "kotlin.Unit"

    .line 193
    .line 194
    invoke-static {v0, v1, v3, v4}, LAb/m;->a(Ljava/lang/String;LAb/n;[LAb/f;Lkotlin/jvm/functions/Function1;)LAb/i;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    return-object v0

    .line 199
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
