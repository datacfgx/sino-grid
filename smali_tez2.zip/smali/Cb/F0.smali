.class public final LCb/F0;
.super Ljava/lang/Object;
.source "Primitives.kt"

# interfaces
.implements Lyb/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lyb/b<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:LCb/F0;


# instance fields
.field public final synthetic a:LCb/Z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LCb/Z<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LCb/F0;

    .line 2
    .line 3
    invoke-direct {v0}, LCb/F0;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCb/F0;->b:LCb/F0;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LCb/Z;

    .line 5
    .line 6
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 7
    .line 8
    invoke-direct {v0, v1}, LCb/Z;-><init>(Lkotlin/Unit;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, LCb/F0;->a:LCb/Z;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final b()LAb/f;
    .locals 1

    .line 1
    iget-object v0, p0, LCb/F0;->a:LCb/Z;

    .line 2
    .line 3
    invoke-virtual {v0}, LCb/Z;->b()LAb/f;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final c(LBb/e;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "decoder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LCb/F0;->a:LCb/Z;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, LCb/Z;->c(LBb/e;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    return-object p1
.end method

.method public final e(LBb/b;Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p2, Lkotlin/Unit;

    .line 2
    .line 3
    const-string v0, "encoder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "value"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LCb/F0;->a:LCb/Z;

    .line 14
    .line 15
    invoke-virtual {v0, p1, p2}, LCb/Z;->e(LBb/b;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
