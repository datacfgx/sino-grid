.class public final synthetic LCb/f0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:LCb/g0;


# direct methods
.method public synthetic constructor <init>(LCb/g0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LCb/f0;->a:LCb/g0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LCb/f0;->a:LCb/g0;

    .line 2
    .line 3
    iget-object v1, v0, LCb/g0;->j:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-interface {v1}, LI9/j;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, [LAb/f;

    .line 10
    .line 11
    invoke-static {v0, v1}, LCb/h0;->a(LAb/f;[LAb/f;)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
