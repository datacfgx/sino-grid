.class public final synthetic LCb/Y;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LCb/Y;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LCb/Y;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    .line 4
    const-string v2, "it"

    .line 5
    .line 6
    iget-object v3, p0, LCb/Y;->b:Ljava/lang/Object;

    .line 7
    .line 8
    iget v4, p0, LCb/Y;->a:I

    .line 9
    .line 10
    .line 11
    packed-switch v4, :pswitch_data_0

    .line 12
    .line 13
    check-cast v3, Lorg/tezza/data/user/source/network/UserEntity;

    .line 14
    .line 15
    check-cast p1, LOd/H;

    .line 16
    .line 17
    .line 18
    invoke-static {v3, p1}, Lorg/tezza/data/user/UserRepositoryImpl;->s(Lorg/tezza/data/user/source/network/UserEntity;LOd/H;)Le9/j;

    .line 19
    move-result-object p1

    .line 20
    return-object p1

    .line 21
    .line 22
    :pswitch_0
    check-cast p1, Lcd/c;

    .line 23
    .line 24
    sget v4, Lcd/O;->C0:I

    .line 25
    .line 26
    .line 27
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    check-cast v3, Lcd/O;

    .line 30
    .line 31
    iget-object v2, v3, Lcd/O;->A0:Lcd/D;

    .line 32
    .line 33
    if-eqz v2, :cond_0

    .line 34
    goto :goto_0

    .line 35
    .line 36
    :cond_0
    const-string v2, "thumbnailsAdapter"

    .line 37
    .line 38
    .line 39
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 40
    move-object v2, v1

    .line 41
    .line 42
    :goto_0
    iget-boolean v2, v2, Lcd/D;->g:Z

    .line 43
    .line 44
    if-nez v2, :cond_18

    .line 45
    .line 46
    iget-boolean v2, p1, Lcd/c;->c:Z

    .line 47
    .line 48
    if-eqz v2, :cond_1

    .line 49
    .line 50
    goto/16 :goto_4

    .line 51
    .line 52
    :cond_1
    iget-object p1, p1, Lcd/c;->a:Lcd/d;

    .line 53
    .line 54
    .line 55
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 56
    move-result-object v2

    .line 57
    .line 58
    const-string v4, "FLORAL"

    .line 59
    .line 60
    .line 61
    invoke-static {v2, v4}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 62
    move-result v2

    .line 63
    .line 64
    const-string v4, ""

    .line 65
    .line 66
    const-string v5, "REVOLVEFESTIVAL"

    .line 67
    .line 68
    if-eqz v2, :cond_2

    .line 69
    .line 70
    const-string v2, "Floral"

    .line 71
    .line 72
    goto/16 :goto_1

    .line 73
    .line 74
    .line 75
    :cond_2
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 76
    move-result-object v2

    .line 77
    .line 78
    const-string v6, "HYPERVISUAL"

    .line 79
    .line 80
    .line 81
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 82
    move-result v2

    .line 83
    .line 84
    if-eqz v2, :cond_3

    .line 85
    .line 86
    const-string v2, "Hypervisual"

    .line 87
    .line 88
    goto/16 :goto_1

    .line 89
    .line 90
    .line 91
    :cond_3
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 92
    move-result-object v2

    .line 93
    .line 94
    const-string v6, "EDITORIAL"

    .line 95
    .line 96
    .line 97
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 98
    move-result v2

    .line 99
    .line 100
    if-eqz v2, :cond_4

    .line 101
    .line 102
    const-string v2, "Editorial"

    .line 103
    .line 104
    goto/16 :goto_1

    .line 105
    .line 106
    .line 107
    :cond_4
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 108
    move-result-object v2

    .line 109
    .line 110
    const-string v6, "CLEAN2"

    .line 111
    .line 112
    .line 113
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 114
    move-result v2

    .line 115
    .line 116
    if-eqz v2, :cond_5

    .line 117
    .line 118
    const-string v2, "Clean 2"

    .line 119
    .line 120
    goto/16 :goto_1

    .line 121
    .line 122
    .line 123
    :cond_5
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 124
    move-result-object v2

    .line 125
    .line 126
    const-string v6, "CLEAN"

    .line 127
    .line 128
    .line 129
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 130
    move-result v2

    .line 131
    .line 132
    if-eqz v2, :cond_6

    .line 133
    .line 134
    const-string v2, "Clean 1"

    .line 135
    .line 136
    goto/16 :goto_1

    .line 137
    .line 138
    .line 139
    :cond_6
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 140
    move-result-object v2

    .line 141
    .line 142
    const-string v6, "FILMBLACK"

    .line 143
    .line 144
    .line 145
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 146
    move-result v2

    .line 147
    .line 148
    if-eqz v2, :cond_7

    .line 149
    .line 150
    const-string v2, "Film Black"

    .line 151
    .line 152
    goto/16 :goto_1

    .line 153
    .line 154
    .line 155
    :cond_7
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 156
    move-result-object v2

    .line 157
    .line 158
    const-string v6, "FILMWHITE"

    .line 159
    .line 160
    .line 161
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 162
    move-result v2

    .line 163
    .line 164
    if-eqz v2, :cond_8

    .line 165
    .line 166
    const-string v2, "Film White"

    .line 167
    .line 168
    goto/16 :goto_1

    .line 169
    .line 170
    .line 171
    :cond_8
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 172
    move-result-object v2

    .line 173
    .line 174
    const-string v6, "CYBER"

    .line 175
    .line 176
    .line 177
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 178
    move-result v2

    .line 179
    .line 180
    if-eqz v2, :cond_9

    .line 181
    .line 182
    const-string v2, "Cyber"

    .line 183
    .line 184
    goto/16 :goto_1

    .line 185
    .line 186
    .line 187
    :cond_9
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 188
    move-result-object v2

    .line 189
    .line 190
    const-string v6, "ZINE"

    .line 191
    .line 192
    .line 193
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 194
    move-result v2

    .line 195
    .line 196
    if-eqz v2, :cond_a

    .line 197
    .line 198
    const-string v2, "Zine"

    .line 199
    .line 200
    goto/16 :goto_1

    .line 201
    .line 202
    .line 203
    :cond_a
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 204
    move-result-object v2

    .line 205
    .line 206
    const-string v6, "LOVE_LETTERS"

    .line 207
    .line 208
    .line 209
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 210
    move-result v2

    .line 211
    .line 212
    if-eqz v2, :cond_b

    .line 213
    .line 214
    const-string v2, "Love Letters"

    .line 215
    .line 216
    goto/16 :goto_1

    .line 217
    .line 218
    .line 219
    :cond_b
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 220
    move-result-object v2

    .line 221
    .line 222
    const/4 v6, 0x0

    sget-object v6, Lcom/google/common/cache/ZlXn/ZlxFemCoW;->wajH:Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 226
    move-result v2

    .line 227
    .line 228
    if-eqz v2, :cond_c

    .line 229
    .line 230
    const-string v2, "Mama"

    .line 231
    .line 232
    goto/16 :goto_1

    .line 233
    .line 234
    .line 235
    :cond_c
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 236
    move-result-object v2

    .line 237
    .line 238
    const-string v6, "SUNBATH"

    .line 239
    .line 240
    .line 241
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 242
    move-result v2

    .line 243
    .line 244
    if-eqz v2, :cond_d

    .line 245
    .line 246
    const-string v2, "Sunbath"

    .line 247
    .line 248
    goto/16 :goto_1

    .line 249
    .line 250
    .line 251
    :cond_d
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 252
    move-result-object v2

    .line 253
    .line 254
    const-string v6, "FINDMENOW"

    .line 255
    .line 256
    .line 257
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 258
    move-result v2

    .line 259
    .line 260
    if-eqz v2, :cond_e

    .line 261
    .line 262
    const-string v2, "Find Me Now"

    .line 263
    .line 264
    goto/16 :goto_1

    .line 265
    .line 266
    .line 267
    :cond_e
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 268
    move-result-object v2

    .line 269
    .line 270
    const-string v6, "HAPPILYGREY"

    .line 271
    .line 272
    .line 273
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 274
    move-result v2

    .line 275
    .line 276
    if-eqz v2, :cond_f

    .line 277
    .line 278
    const-string v2, "Happily Grey"

    .line 279
    goto :goto_1

    .line 280
    .line 281
    .line 282
    :cond_f
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 283
    move-result-object v2

    .line 284
    .line 285
    const-string v6, "LINE"

    .line 286
    .line 287
    .line 288
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 289
    move-result v2

    .line 290
    .line 291
    if-eqz v2, :cond_10

    .line 292
    .line 293
    const-string v2, "Line"

    .line 294
    goto :goto_1

    .line 295
    .line 296
    .line 297
    :cond_10
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 298
    move-result-object v2

    .line 299
    .line 300
    const-string v6, "PRIDE"

    .line 301
    .line 302
    .line 303
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 304
    move-result v2

    .line 305
    .line 306
    if-eqz v2, :cond_11

    .line 307
    .line 308
    const-string v2, "Pride"

    .line 309
    goto :goto_1

    .line 310
    .line 311
    .line 312
    :cond_11
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 313
    move-result-object v2

    .line 314
    .line 315
    const-string v6, "ANGEL"

    .line 316
    .line 317
    .line 318
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 319
    move-result v2

    .line 320
    .line 321
    if-eqz v2, :cond_12

    .line 322
    .line 323
    const-string v2, "Angel"

    .line 324
    goto :goto_1

    .line 325
    .line 326
    .line 327
    :cond_12
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 328
    move-result-object v2

    .line 329
    .line 330
    const-string v6, "SKETCH"

    .line 331
    .line 332
    .line 333
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 334
    move-result v2

    .line 335
    .line 336
    if-eqz v2, :cond_13

    .line 337
    .line 338
    const-string v2, "Sketch"

    .line 339
    goto :goto_1

    .line 340
    .line 341
    .line 342
    :cond_13
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 343
    move-result-object v2

    .line 344
    .line 345
    const-string v6, "FILMLINE"

    .line 346
    .line 347
    .line 348
    invoke-static {v2, v6}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 349
    move-result v2

    .line 350
    .line 351
    if-eqz v2, :cond_14

    .line 352
    .line 353
    const-string v2, "Film Line"

    .line 354
    goto :goto_1

    .line 355
    .line 356
    .line 357
    :cond_14
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 358
    move-result-object v2

    .line 359
    .line 360
    .line 361
    invoke-static {v2, v5}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 362
    move-result v2

    .line 363
    .line 364
    if-eqz v2, :cond_15

    .line 365
    .line 366
    const-string v2, "Revolve Festival"

    .line 367
    goto :goto_1

    .line 368
    :cond_15
    move-object v2, v4

    .line 369
    .line 370
    .line 371
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 372
    move-result-object v6

    .line 373
    .line 374
    const-string v7, "_"

    .line 375
    .line 376
    .line 377
    filled-new-array {v7}, [Ljava/lang/String;

    .line 378
    move-result-object v7

    .line 379
    const/4 v8, 0x6

    .line 380
    .line 381
    .line 382
    invoke-static {v6, v7, v0, v8}, Lkotlin/text/StringsKt;->K(Ljava/lang/CharSequence;[Ljava/lang/String;II)Ljava/util/List;

    .line 383
    move-result-object v6

    .line 384
    const/4 v7, 0x1

    .line 385
    .line 386
    .line 387
    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 388
    move-result-object v6

    .line 389
    .line 390
    new-instance v8, Ljava/lang/StringBuilder;

    .line 391
    .line 392
    .line 393
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 394
    .line 395
    .line 396
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 397
    .line 398
    const-string v9, " "

    .line 399
    .line 400
    .line 401
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 402
    .line 403
    .line 404
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 405
    .line 406
    .line 407
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 408
    move-result-object v6

    .line 409
    .line 410
    .line 411
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 412
    move-result-object v8

    .line 413
    .line 414
    .line 415
    invoke-static {v8, v5}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 416
    move-result v5

    .line 417
    .line 418
    if-eqz v5, :cond_16

    .line 419
    .line 420
    sget-object v5, Lcd/O$a;->a:[I

    .line 421
    .line 422
    .line 423
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 424
    move-result p1

    .line 425
    .line 426
    aget p1, v5, p1

    .line 427
    .line 428
    .line 429
    packed-switch p1, :pswitch_data_1

    .line 430
    goto :goto_2

    .line 431
    .line 432
    :pswitch_1
    const-string v4, "12"

    .line 433
    goto :goto_2

    .line 434
    .line 435
    :pswitch_2
    const-string v4, "11"

    .line 436
    goto :goto_2

    .line 437
    .line 438
    :pswitch_3
    const-string v4, "10"

    .line 439
    goto :goto_2

    .line 440
    .line 441
    :pswitch_4
    const-string v4, "9"

    .line 442
    goto :goto_2

    .line 443
    .line 444
    :pswitch_5
    const-string v4, "8"

    .line 445
    goto :goto_2

    .line 446
    .line 447
    :pswitch_6
    const-string v4, "7"

    .line 448
    goto :goto_2

    .line 449
    .line 450
    :pswitch_7
    const-string v4, "6"

    .line 451
    goto :goto_2

    .line 452
    .line 453
    :pswitch_8
    const-string v4, "5"

    .line 454
    goto :goto_2

    .line 455
    .line 456
    :pswitch_9
    const-string v4, "4"

    .line 457
    goto :goto_2

    .line 458
    .line 459
    :pswitch_a
    const-string v4, "3"

    .line 460
    goto :goto_2

    .line 461
    .line 462
    :pswitch_b
    const-string v4, "2"

    .line 463
    goto :goto_2

    .line 464
    .line 465
    :pswitch_c
    const-string v4, "1"

    .line 466
    .line 467
    .line 468
    :goto_2
    invoke-static {v2, v9, v4}, LT4/Q;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 469
    move-result-object v6

    .line 470
    .line 471
    :cond_16
    new-instance p1, LBd/i;

    .line 472
    .line 473
    const-string v2, "Template: "

    .line 474
    .line 475
    .line 476
    invoke-static {v2, v6}, LT4/Q;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 477
    move-result-object v2

    .line 478
    .line 479
    .line 480
    invoke-direct {p1, v0, v2}, LBd/i;-><init>(ZLjava/lang/String;)V

    .line 481
    .line 482
    .line 483
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->m()LP1/h;

    .line 484
    move-result-object v0

    .line 485
    .line 486
    instance-of v2, v0, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 487
    .line 488
    if-nez v2, :cond_17

    .line 489
    goto :goto_3

    .line 490
    :cond_17
    move-object v1, v0

    .line 491
    .line 492
    :goto_3
    check-cast v1, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 493
    .line 494
    if-eqz v1, :cond_1a

    .line 495
    const/4 v0, 0x4

    .line 496
    .line 497
    .line 498
    invoke-static {v1, v7, p1, v0}, Lorg/tezza/presentation/ui/appmain/MainActivity;->k0(Lorg/tezza/presentation/ui/appmain/MainActivity;ZLBd/i;I)V

    .line 499
    goto :goto_6

    .line 500
    .line 501
    .line 502
    :cond_18
    :goto_4
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->m()LP1/h;

    .line 503
    move-result-object v2

    .line 504
    .line 505
    instance-of v3, v2, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 506
    .line 507
    if-nez v3, :cond_19

    .line 508
    goto :goto_5

    .line 509
    :cond_19
    move-object v1, v2

    .line 510
    :goto_5
    move-object v2, v1

    .line 511
    .line 512
    check-cast v2, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 513
    .line 514
    if-eqz v2, :cond_1a

    .line 515
    .line 516
    const-string v1, "templateItem"

    .line 517
    .line 518
    .line 519
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 520
    .line 521
    .line 522
    invoke-virtual {v2, v0}, Lorg/tezza/presentation/ui/appmain/MainActivity;->r0(Z)V

    .line 523
    .line 524
    const-string v0, "catalogTemplateItem"

    .line 525
    .line 526
    .line 527
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 528
    .line 529
    new-instance v3, Lcd/N;

    .line 530
    .line 531
    .line 532
    invoke-direct {v3}, Lcd/N;-><init>()V

    .line 533
    .line 534
    new-instance v0, Landroid/os/Bundle;

    .line 535
    .line 536
    .line 537
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 538
    .line 539
    iget-object p1, p1, Lcd/c;->a:Lcd/d;

    .line 540
    .line 541
    const-string v1, "INIT_TEMPLATE_TYPE"

    .line 542
    .line 543
    .line 544
    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 545
    .line 546
    .line 547
    invoke-virtual {v3, v0}, Landroidx/fragment/app/Fragment;->g0(Landroid/os/Bundle;)V

    .line 548
    const/4 v4, 0x0

    .line 549
    const/4 v5, 0x1

    .line 550
    const/4 v6, 0x1

    .line 551
    const/4 v7, 0x0

    .line 552
    .line 553
    .line 554
    invoke-virtual/range {v2 .. v7}, LJc/c;->c0(LJc/e;ZZZZ)V

    .line 555
    .line 556
    :cond_1a
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 557
    return-object p1

    .line 558
    .line 559
    :pswitch_d
    check-cast p1, Ljava/lang/String;

    .line 560
    .line 561
    sget v1, LZc/t;->B0:I

    .line 562
    .line 563
    const-string v1, "productId"

    .line 564
    .line 565
    .line 566
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 567
    .line 568
    check-cast v3, LZc/t;

    .line 569
    .line 570
    .line 571
    invoke-virtual {v3}, LJc/e;->n0()LB1/g;

    .line 572
    move-result-object v1

    .line 573
    .line 574
    check-cast v1, Lrc/G1;

    .line 575
    .line 576
    .line 577
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 578
    move-result v2

    .line 579
    .line 580
    if-nez v2, :cond_1b

    .line 581
    .line 582
    iget-object p1, v1, Lrc/G1;->D:Landroid/widget/TextView;

    .line 583
    .line 584
    if-eqz p1, :cond_1e

    .line 585
    .line 586
    .line 587
    invoke-static {p1}, LBd/n;->d(Landroid/view/View;)V

    .line 588
    goto :goto_8

    .line 589
    .line 590
    :cond_1b
    iget-object v2, v1, Lrc/G1;->D:Landroid/widget/TextView;

    .line 591
    .line 592
    if-eqz v2, :cond_1d

    .line 593
    .line 594
    const-string v3, "_yearly"

    .line 595
    .line 596
    .line 597
    invoke-static {p1, v3, v0}, Lkotlin/text/o;->g(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 598
    move-result p1

    .line 599
    .line 600
    if-eqz p1, :cond_1c

    .line 601
    .line 602
    const/4 p1, 0x0

    sget-object p1, Lcom/google/android/play/core/common/bK/FTkQLWBMb;->dWgkXKazj:Ljava/lang/String;

    .line 603
    goto :goto_7

    .line 604
    .line 605
    :cond_1c
    const-string p1, "MONTHLY"

    .line 606
    .line 607
    .line 608
    :goto_7
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 609
    .line 610
    :cond_1d
    iget-object p1, v1, Lrc/G1;->D:Landroid/widget/TextView;

    .line 611
    .line 612
    if-eqz p1, :cond_1e

    .line 613
    .line 614
    .line 615
    invoke-static {p1}, LBd/n;->l(Landroid/view/View;)V

    .line 616
    .line 617
    :cond_1e
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 618
    return-object p1

    .line 619
    .line 620
    :pswitch_e
    check-cast p1, Ljava/lang/Throwable;

    .line 621
    .line 622
    .line 623
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 624
    .line 625
    check-cast v3, LLc/X;

    .line 626
    .line 627
    .line 628
    invoke-virtual {v3}, LJc/f;->d()V

    .line 629
    .line 630
    .line 631
    invoke-virtual {v3, p1}, LJc/f;->e(Ljava/lang/Throwable;)V

    .line 632
    .line 633
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 634
    return-object p1

    .line 635
    .line 636
    :pswitch_f
    check-cast p1, Lorg/tezza/data/common/RepoResult;

    .line 637
    .line 638
    sget v0, LIc/w;->A0:I

    .line 639
    .line 640
    instance-of v0, p1, Lorg/tezza/data/common/RepoResult$Error;

    .line 641
    .line 642
    check-cast v3, LIc/w;

    .line 643
    .line 644
    if-eqz v0, :cond_1f

    .line 645
    .line 646
    check-cast p1, Lorg/tezza/data/common/RepoResult$Error;

    .line 647
    .line 648
    .line 649
    invoke-virtual {v3, p1}, LJc/e;->x0(Lorg/tezza/data/common/RepoResult$Error;)V

    .line 650
    goto :goto_a

    .line 651
    .line 652
    :cond_1f
    instance-of v0, p1, Lorg/tezza/data/common/RepoResult$Loading;

    .line 653
    .line 654
    if-eqz v0, :cond_20

    .line 655
    .line 656
    .line 657
    invoke-virtual {v3}, LJc/e;->t0()V

    .line 658
    goto :goto_a

    .line 659
    .line 660
    :cond_20
    instance-of v0, p1, Lorg/tezza/data/common/RepoResult$Success;

    .line 661
    .line 662
    if-eqz v0, :cond_22

    .line 663
    .line 664
    .line 665
    invoke-virtual {v3}, LJc/e;->q0()LJc/f;

    .line 666
    move-result-object p1

    .line 667
    .line 668
    check-cast p1, LIc/y;

    .line 669
    .line 670
    iget-object p1, p1, LIc/y;->f:Landroidx/lifecycle/z;

    .line 671
    .line 672
    .line 673
    invoke-virtual {p1, v1}, Landroidx/lifecycle/x;->j(Ljava/lang/Object;)V

    .line 674
    .line 675
    new-instance p1, Lorg/tezza/data/common/SessionManager;

    .line 676
    .line 677
    .line 678
    invoke-direct {p1}, Lorg/tezza/data/common/SessionManager;-><init>()V

    .line 679
    .line 680
    .line 681
    invoke-virtual {p1}, Lorg/tezza/data/common/SessionManager;->updateCleverTapProfileAfterLogin()V

    .line 682
    .line 683
    .line 684
    invoke-virtual {v3}, LJc/e;->s0()V

    .line 685
    .line 686
    .line 687
    invoke-virtual {v3}, LJc/e;->r0()V

    .line 688
    .line 689
    .line 690
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->m()LP1/h;

    .line 691
    move-result-object p1

    .line 692
    .line 693
    instance-of v0, p1, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 694
    .line 695
    if-nez v0, :cond_21

    .line 696
    goto :goto_9

    .line 697
    :cond_21
    move-object v1, p1

    .line 698
    .line 699
    :goto_9
    check-cast v1, Lorg/tezza/presentation/ui/appmain/MainActivity;

    .line 700
    .line 701
    if-eqz v1, :cond_23

    .line 702
    .line 703
    .line 704
    invoke-virtual {v1}, Lorg/tezza/presentation/ui/appmain/MainActivity;->n0()V

    .line 705
    goto :goto_a

    .line 706
    .line 707
    :cond_22
    if-nez p1, :cond_24

    .line 708
    .line 709
    :cond_23
    :goto_a
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 710
    return-object p1

    .line 711
    .line 712
    :cond_24
    new-instance p1, Lkotlin/NoWhenBranchMatchedException;

    .line 713
    .line 714
    .line 715
    invoke-direct {p1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 716
    throw p1

    .line 717
    .line 718
    :pswitch_10
    check-cast p1, LAb/a;

    .line 719
    .line 720
    const-string v0, "$this$buildSerialDescriptor"

    .line 721
    .line 722
    .line 723
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 724
    .line 725
    check-cast v3, LCb/Z;

    .line 726
    .line 727
    iget-object v0, v3, LCb/Z;->b:Ljava/util/List;

    .line 728
    .line 729
    .line 730
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 731
    .line 732
    const-string v1, "<set-?>"

    .line 733
    .line 734
    .line 735
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 736
    .line 737
    iput-object v0, p1, LAb/a;->b:Ljava/util/List;

    .line 738
    .line 739
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 740
    return-object p1

    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_0
    .end packed-switch

    .line 755
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
