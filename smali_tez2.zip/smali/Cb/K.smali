.class public final LCb/K;
.super LCb/Q;
.source "CollectionDescriptors.kt"
