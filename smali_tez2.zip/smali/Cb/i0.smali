.class public final LCb/i0;
.super Ljava/lang/Object;
.source "PluginHelperInterfaces.kt"


# static fields
.field public static final a:[Lyb/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lyb/b<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lyb/b;

    .line 3
    .line 4
    sput-object v0, LCb/i0;->a:[Lyb/b;

    .line 5
    .line 6
    return-void
.end method
