.class public final synthetic LCb/c0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LCb/c0;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LCb/c0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    .line 2
    const-string v0, "it"

    .line 3
    .line 4
    iget-object v1, p0, LCb/c0;->b:Ljava/lang/Object;

    .line 5
    .line 6
    iget v2, p0, LCb/c0;->a:I

    .line 7
    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    check-cast p1, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 12
    .line 13
    .line 14
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    iget-object p1, p1, Lorg/tezza/domain/gallery/LayersAdjustments;->c:Lvc/F;

    .line 17
    .line 18
    check-cast v1, Lorg/tezza/domain/gallery/Adjustments;

    .line 19
    .line 20
    check-cast v1, Lorg/tezza/domain/gallery/LayersAdjustments;

    .line 21
    .line 22
    iget-object v0, v1, Lorg/tezza/domain/gallery/LayersAdjustments;->c:Lvc/F;

    .line 23
    .line 24
    if-ne p1, v0, :cond_0

    .line 25
    const/4 p1, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 p1, 0x0

    .line 28
    .line 29
    .line 30
    :goto_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 31
    move-result-object p1

    .line 32
    return-object p1

    .line 33
    .line 34
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 35
    .line 36
    sget-object v0, LLc/c2;->q1:Lorg/tezza/presentation/utils/media/Size;

    .line 37
    .line 38
    check-cast v1, LLc/c2;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, p1}, LLc/c2;->T0(Ljava/lang/Boolean;)V

    .line 42
    .line 43
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 44
    return-object p1

    .line 45
    .line 46
    :pswitch_1
    check-cast p1, Lorg/tezza/domain/gallery/a;

    .line 47
    .line 48
    .line 49
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 50
    .line 51
    iget-object p1, p1, Lorg/tezza/domain/gallery/a;->g:Ljava/lang/String;

    .line 52
    .line 53
    check-cast v1, LLc/X;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    new-instance v0, Lxc/a;

    .line 59
    .line 60
    .line 61
    invoke-direct {v0}, Lzc/b;-><init>()V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0, p1}, Lxc/a;->a(Ljava/lang/String;)Le9/g;

    .line 65
    move-result-object p1

    .line 66
    .line 67
    .line 68
    invoke-static {p1}, Lzc/c;->b(Le9/g;)Le9/g;

    .line 69
    move-result-object p1

    .line 70
    return-object p1

    .line 71
    .line 72
    :pswitch_2
    check-cast p1, Ljava/lang/String;

    .line 73
    .line 74
    sget v0, LIc/w;->A0:I

    .line 75
    .line 76
    check-cast v1, LIc/w;

    .line 77
    .line 78
    const/4 v0, 0x0

    sget-object v0, Lh1/izW/yojbrzC;->TkxdRCbUu:Ljava/lang/String;

    .line 79
    .line 80
    if-nez p1, :cond_1

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1}, LJc/e;->n0()LB1/g;

    .line 84
    move-result-object p1

    .line 85
    .line 86
    check-cast p1, Lrc/E1;

    .line 87
    .line 88
    iget-object p1, p1, Lrc/E1;->z:Landroid/widget/TextView;

    .line 89
    .line 90
    .line 91
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    invoke-static {p1}, LBd/n;->l(Landroid/view/View;)V

    .line 95
    goto :goto_1

    .line 96
    .line 97
    .line 98
    :cond_1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 99
    move-result v2

    .line 100
    .line 101
    const/16 v3, 0x8

    .line 102
    .line 103
    if-lt v2, v3, :cond_2

    .line 104
    .line 105
    const-string v2, "(.*[a-z].*)"

    .line 106
    .line 107
    .line 108
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 109
    move-result-object v2

    .line 110
    .line 111
    .line 112
    invoke-virtual {v2, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 113
    move-result-object v2

    .line 114
    .line 115
    .line 116
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    .line 117
    move-result v2

    .line 118
    .line 119
    if-eqz v2, :cond_2

    .line 120
    .line 121
    const-string v2, "(.*[A-Z].*)"

    .line 122
    .line 123
    .line 124
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 125
    move-result-object v2

    .line 126
    .line 127
    .line 128
    invoke-virtual {v2, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 129
    move-result-object v2

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    .line 133
    move-result v2

    .line 134
    .line 135
    if-eqz v2, :cond_2

    .line 136
    .line 137
    const-string v2, "(.*[0-9].*)"

    .line 138
    .line 139
    .line 140
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 141
    move-result-object v2

    .line 142
    .line 143
    .line 144
    invoke-virtual {v2, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 145
    move-result-object p1

    .line 146
    .line 147
    .line 148
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->matches()Z

    .line 149
    move-result p1

    .line 150
    .line 151
    if-eqz p1, :cond_2

    .line 152
    .line 153
    .line 154
    invoke-virtual {v1}, LJc/e;->n0()LB1/g;

    .line 155
    move-result-object p1

    .line 156
    .line 157
    check-cast p1, Lrc/E1;

    .line 158
    .line 159
    iget-object p1, p1, Lrc/E1;->z:Landroid/widget/TextView;

    .line 160
    .line 161
    .line 162
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    invoke-static {p1}, LBd/n;->d(Landroid/view/View;)V

    .line 166
    goto :goto_1

    .line 167
    .line 168
    .line 169
    :cond_2
    invoke-virtual {v1}, LJc/e;->q0()LJc/f;

    .line 170
    move-result-object p1

    .line 171
    .line 172
    check-cast p1, LIc/y;

    .line 173
    .line 174
    iget-boolean p1, p1, LIc/y;->m:Z

    .line 175
    .line 176
    if-nez p1, :cond_3

    .line 177
    .line 178
    .line 179
    invoke-virtual {v1}, LJc/e;->n0()LB1/g;

    .line 180
    move-result-object p1

    .line 181
    .line 182
    check-cast p1, Lrc/E1;

    .line 183
    .line 184
    iget-object p1, p1, Lrc/E1;->z:Landroid/widget/TextView;

    .line 185
    .line 186
    .line 187
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    invoke-static {p1}, LBd/n;->d(Landroid/view/View;)V

    .line 191
    goto :goto_1

    .line 192
    .line 193
    .line 194
    :cond_3
    invoke-virtual {v1}, LJc/e;->n0()LB1/g;

    .line 195
    move-result-object p1

    .line 196
    .line 197
    check-cast p1, Lrc/E1;

    .line 198
    .line 199
    iget-object p1, p1, Lrc/E1;->z:Landroid/widget/TextView;

    .line 200
    .line 201
    .line 202
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    invoke-static {p1}, LBd/n;->l(Landroid/view/View;)V

    .line 206
    .line 207
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 208
    return-object p1

    .line 209
    .line 210
    :pswitch_3
    check-cast p1, Ljava/lang/Integer;

    .line 211
    .line 212
    .line 213
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 214
    move-result p1

    .line 215
    .line 216
    new-instance v0, Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 220
    .line 221
    check-cast v1, LCb/g0;

    .line 222
    .line 223
    iget-object v2, v1, LCb/g0;->e:[Ljava/lang/String;

    .line 224
    .line 225
    aget-object v2, v2, p1

    .line 226
    .line 227
    .line 228
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 229
    .line 230
    const-string v2, ": "

    .line 231
    .line 232
    .line 233
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v1, p1}, LCb/g0;->p(I)LAb/f;

    .line 237
    move-result-object p1

    .line 238
    .line 239
    .line 240
    invoke-interface {p1}, LAb/f;->j()Ljava/lang/String;

    .line 241
    move-result-object p1

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 248
    move-result-object p1

    .line 249
    return-object p1

    .line 250
    .line 251
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
