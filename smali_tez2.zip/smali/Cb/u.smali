.class public final LCb/u;
.super Ljava/lang/Object;
.source "ElementMarker.kt"


# static fields
.field public static final e:[J


# instance fields
.field public final a:LAb/f;

.field public final b:LEb/l$a;

.field public c:J

.field public final d:[J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [J

    .line 3
    .line 4
    sput-object v0, LCb/u;->e:[J

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(LAb/f;LEb/l$a;)V
    .locals 4

    .line 1
    const-string v0, "descriptor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "readIfAbsent"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, LCb/u;->a:LAb/f;

    .line 15
    .line 16
    iput-object p2, p0, LCb/u;->b:LEb/l$a;

    .line 17
    .line 18
    invoke-interface {p1}, LAb/f;->m()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    const-wide/16 v0, -0x1

    .line 23
    .line 24
    const-wide/16 v2, 0x0

    .line 25
    .line 26
    const/16 p2, 0x40

    .line 27
    .line 28
    if-gt p1, p2, :cond_1

    .line 29
    .line 30
    if-ne p1, p2, :cond_0

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    shl-long v2, v0, p1

    .line 34
    .line 35
    :goto_0
    iput-wide v2, p0, LCb/u;->c:J

    .line 36
    .line 37
    sget-object p1, LCb/u;->e:[J

    .line 38
    .line 39
    iput-object p1, p0, LCb/u;->d:[J

    .line 40
    .line 41
    return-void

    .line 42
    :cond_1
    iput-wide v2, p0, LCb/u;->c:J

    .line 43
    .line 44
    add-int/lit8 p2, p1, -0x1

    .line 45
    .line 46
    ushr-int/lit8 p2, p2, 0x6

    .line 47
    .line 48
    and-int/lit8 v2, p1, 0x3f

    .line 49
    .line 50
    new-array p2, p2, [J

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    invoke-static {p2}, Lkotlin/collections/ArraysKt;->getLastIndex([J)I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    shl-long/2addr v0, p1

    .line 59
    aput-wide v0, p2, v2

    .line 60
    .line 61
    :cond_2
    iput-object p2, p0, LCb/u;->d:[J

    .line 62
    .line 63
    return-void
.end method
