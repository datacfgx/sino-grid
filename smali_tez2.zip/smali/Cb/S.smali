.class public abstract LCb/S;
.super LCb/a;
.source "CollectionSerializers.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<Key:",
        "Ljava/lang/Object;",
        "Value:",
        "Ljava/lang/Object;",
        "Collection:",
        "Ljava/lang/Object;",
        "Builder::",
        "Ljava/util/Map<",
        "TKey;TValue;>;>",
        "LCb/a<",
        "Ljava/util/Map$Entry<",
        "+TKey;+TValue;>;TCollection;TBuilder;>;"
    }
.end annotation


# instance fields
.field public final a:LCb/s0;

.field public final b:Lyb/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lyb/b<",
            "TValue;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lyb/b;)V
    .locals 1

    .line 1
    sget-object v0, LCb/s0;->a:LCb/s0;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, LCb/S;->a:LCb/s0;

    .line 7
    .line 8
    iput-object p1, p0, LCb/S;->b:Lyb/b;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e(LBb/b;Ljava/lang/Object;)V
    .locals 6

    .line 1
    const-string v0, "encoder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p2}, LCb/a;->i(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-object v0, p0

    .line 10
    check-cast v0, LCb/L;

    .line 11
    .line 12
    iget-object v0, v0, LCb/L;->c:LCb/K;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, LBb/b;->D(LAb/f;)LBb/d;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {p0, p2}, LCb/a;->h(Ljava/lang/Object;)Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    const/4 v1, 0x0

    .line 23
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_0

    .line 28
    .line 29
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    check-cast v2, Ljava/util/Map$Entry;

    .line 34
    .line 35
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    add-int/lit8 v4, v1, 0x1

    .line 44
    .line 45
    iget-object v5, p0, LCb/S;->a:LCb/s0;

    .line 46
    .line 47
    invoke-interface {p1, v0, v1, v5, v3}, LBb/d;->o(LAb/f;ILyb/g;Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    add-int/lit8 v1, v1, 0x2

    .line 51
    .line 52
    iget-object v3, p0, LCb/S;->b:Lyb/b;

    .line 53
    .line 54
    check-cast v3, Lyb/g;

    .line 55
    .line 56
    invoke-interface {p1, v0, v4, v3, v2}, LBb/d;->o(LAb/f;ILyb/g;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    invoke-interface {p1, v0}, LBb/d;->c(LAb/f;)V

    .line 61
    .line 62
    .line 63
    return-void
.end method

.method public final k(LBb/c;ILjava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p3, Ljava/util/Map;

    .line 2
    .line 3
    const-string v0, "decoder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "builder"

    .line 9
    .line 10
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    move-object v0, p0

    .line 14
    check-cast v0, LCb/L;

    .line 15
    .line 16
    iget-object v0, v0, LCb/L;->c:LCb/K;

    .line 17
    .line 18
    iget-object v1, p0, LCb/S;->a:LCb/s0;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-interface {p1, v0, p2, v1, v2}, LBb/c;->f(LAb/f;ILyb/a;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-interface {p1, v0}, LBb/c;->l(LAb/f;)I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    add-int/lit8 v4, p2, 0x1

    .line 30
    .line 31
    if-ne v3, v4, :cond_1

    .line 32
    .line 33
    invoke-interface {p3, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    iget-object v4, p0, LCb/S;->b:Lyb/b;

    .line 38
    .line 39
    if-eqz p2, :cond_0

    .line 40
    .line 41
    invoke-interface {v4}, Lyb/g;->b()LAb/f;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    invoke-interface {p2}, LAb/f;->f()LAb/n;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    instance-of p2, p2, LAb/e;

    .line 50
    .line 51
    if-nez p2, :cond_0

    .line 52
    .line 53
    check-cast v4, Lyb/a;

    .line 54
    .line 55
    invoke-static {p3, v1}, Lkotlin/collections/MapsKt;->getValue(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p2

    .line 59
    invoke-interface {p1, v0, v3, v4, p2}, LBb/c;->f(LAb/f;ILyb/a;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    goto :goto_0

    .line 64
    :cond_0
    check-cast v4, Lyb/a;

    .line 65
    .line 66
    invoke-interface {p1, v0, v3, v4, v2}, LBb/c;->f(LAb/f;ILyb/a;Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    :goto_0
    invoke-interface {p3, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_1
    const-string p1, "Value must follow key in a map, index for key: "

    .line 75
    .line 76
    const-string p3, ", returned index for value: "

    .line 77
    .line 78
    invoke-static {p1, p2, v3, p3}, LG/j0;->b(Ljava/lang/String;IILjava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 83
    .line 84
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    throw p2
.end method
