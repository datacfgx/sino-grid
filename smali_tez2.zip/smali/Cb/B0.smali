.class public final LCb/B0;
.super Ljava/lang/Object;
.source "ValueClasses.kt"

# interfaces
.implements Lyb/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lyb/b<",
        "LI9/v;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:LCb/B0;

.field public static final b:LCb/E;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCb/B0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCb/B0;->a:LCb/B0;

    .line 7
    .line 8
    sget-object v0, Lkotlin/jvm/internal/A;->a:Lkotlin/jvm/internal/A;

    .line 9
    .line 10
    const-string v1, "<this>"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    sget-object v0, LCb/P;->a:LCb/P;

    .line 16
    .line 17
    const-string v1, "kotlin.ULong"

    .line 18
    .line 19
    invoke-static {v1, v0}, LCb/G;->a(Ljava/lang/String;Lyb/b;)LCb/E;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sput-object v0, LCb/B0;->b:LCb/E;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final b()LAb/f;
    .locals 1

    .line 1
    sget-object v0, LCb/B0;->b:LCb/E;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c(LBb/e;)Ljava/lang/Object;
    .locals 2

    .line 1
    const-string v0, "decoder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, LCb/B0;->b:LCb/E;

    .line 7
    .line 8
    invoke-interface {p1, v0}, LBb/e;->m(LAb/f;)LBb/e;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-interface {p1}, LBb/e;->q()J

    .line 13
    .line 14
    .line 15
    move-result-wide v0

    .line 16
    new-instance p1, LI9/v;

    .line 17
    .line 18
    invoke-direct {p1, v0, v1}, LI9/v;-><init>(J)V

    .line 19
    .line 20
    .line 21
    return-object p1
.end method

.method public final e(LBb/b;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, LI9/v;

    .line 2
    .line 3
    iget-wide v0, p2, LI9/v;->a:J

    .line 4
    .line 5
    const-string p2, "encoder"

    .line 6
    .line 7
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sget-object p2, LCb/B0;->b:LCb/E;

    .line 11
    .line 12
    invoke-interface {p1, p2}, LBb/f;->w(LAb/f;)LBb/f;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-interface {p1, v0, v1}, LBb/f;->B(J)V

    .line 17
    .line 18
    .line 19
    return-void
.end method
