.class public final LCb/n0;
.super Ljava/lang/Object;
.source "Primitives.kt"


# static fields
.field public static final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "LZ9/d<",
            "*>;",
            "Lyb/b<",
            "*>;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    invoke-static {}, Lkotlin/collections/MapsKt;->createMapBuilder()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 6
    .line 7
    const-class v2, Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    sget-object v3, Lkotlin/jvm/internal/Z;->a:Lkotlin/jvm/internal/Z;

    .line 14
    .line 15
    invoke-static {v3}, Lzb/a;->b(Lkotlin/jvm/internal/Z;)V

    .line 16
    .line 17
    .line 18
    sget-object v3, LCb/s0;->a:LCb/s0;

    .line 19
    .line 20
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    sget-object v2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    sget-object v3, Lkotlin/jvm/internal/o;->a:Lkotlin/jvm/internal/o;

    .line 30
    .line 31
    const-string v4, "<this>"

    .line 32
    .line 33
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    sget-object v3, LCb/o;->a:LCb/o;

    .line 37
    .line 38
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    const-class v2, [C

    .line 42
    .line 43
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    sget-object v3, LCb/n;->c:LCb/n;

    .line 48
    .line 49
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    sget-object v2, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    .line 53
    .line 54
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    sget-object v3, Lkotlin/jvm/internal/s;->a:Lkotlin/jvm/internal/s;

    .line 59
    .line 60
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    sget-object v3, LCb/s;->a:LCb/s;

    .line 64
    .line 65
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    const-class v2, [D

    .line 69
    .line 70
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    sget-object v3, LCb/r;->c:LCb/r;

    .line 75
    .line 76
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    sget-object v2, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 80
    .line 81
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    sget-object v3, Lkotlin/jvm/internal/t;->a:Lkotlin/jvm/internal/t;

    .line 86
    .line 87
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sget-object v3, LCb/C;->a:LCb/C;

    .line 91
    .line 92
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    const-class v2, [F

    .line 96
    .line 97
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    sget-object v3, LCb/B;->c:LCb/B;

    .line 102
    .line 103
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 107
    .line 108
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    sget-object v3, Lkotlin/jvm/internal/A;->a:Lkotlin/jvm/internal/A;

    .line 113
    .line 114
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    sget-object v3, LCb/P;->a:LCb/P;

    .line 118
    .line 119
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    const-class v2, [J

    .line 123
    .line 124
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    sget-object v3, LCb/O;->c:LCb/O;

    .line 129
    .line 130
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    const-class v2, LI9/v;

    .line 134
    .line 135
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    sget-object v3, LI9/v;->b:LI9/v$a;

    .line 140
    .line 141
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    sget-object v3, LCb/B0;->a:LCb/B0;

    .line 145
    .line 146
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 150
    .line 151
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    sget-object v3, Lkotlin/jvm/internal/y;->a:Lkotlin/jvm/internal/y;

    .line 156
    .line 157
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    sget-object v3, LCb/J;->a:LCb/J;

    .line 161
    .line 162
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    const-class v2, [I

    .line 166
    .line 167
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    sget-object v3, LCb/I;->c:LCb/I;

    .line 172
    .line 173
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    const-class v2, LI9/t;

    .line 177
    .line 178
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    sget-object v3, LI9/t;->b:LI9/t$a;

    .line 183
    .line 184
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    sget-object v3, LCb/y0;->a:LCb/y0;

    .line 188
    .line 189
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    sget-object v2, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    .line 193
    .line 194
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 195
    .line 196
    .line 197
    move-result-object v2

    .line 198
    sget-object v3, Lkotlin/jvm/internal/X;->a:Lkotlin/jvm/internal/X;

    .line 199
    .line 200
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    sget-object v3, LCb/r0;->a:LCb/r0;

    .line 204
    .line 205
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    const-class v2, [S

    .line 209
    .line 210
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    sget-object v3, LCb/q0;->c:LCb/q0;

    .line 215
    .line 216
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    const-class v2, LI9/y;

    .line 220
    .line 221
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    sget-object v3, LI9/y;->b:LI9/y$a;

    .line 226
    .line 227
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    sget-object v3, LCb/E0;->a:LCb/E0;

    .line 231
    .line 232
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    sget-object v2, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    .line 236
    .line 237
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 238
    .line 239
    .line 240
    move-result-object v2

    .line 241
    sget-object v3, Lkotlin/jvm/internal/m;->a:Lkotlin/jvm/internal/m;

    .line 242
    .line 243
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    sget-object v3, LCb/k;->a:LCb/k;

    .line 247
    .line 248
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    const-class v2, [B

    .line 252
    .line 253
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 254
    .line 255
    .line 256
    move-result-object v2

    .line 257
    sget-object v3, LCb/j;->c:LCb/j;

    .line 258
    .line 259
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    const-class v2, LI9/r;

    .line 263
    .line 264
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    sget-object v3, LI9/r;->b:LI9/r$a;

    .line 269
    .line 270
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    sget-object v3, LCb/v0;->a:LCb/v0;

    .line 274
    .line 275
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 279
    .line 280
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 281
    .line 282
    .line 283
    move-result-object v2

    .line 284
    sget-object v3, Lkotlin/jvm/internal/l;->a:Lkotlin/jvm/internal/l;

    .line 285
    .line 286
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    sget-object v3, LCb/h;->a:LCb/h;

    .line 290
    .line 291
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    const-class v2, [Z

    .line 295
    .line 296
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    sget-object v3, LCb/g;->c:LCb/g;

    .line 301
    .line 302
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    const-class v2, Lkotlin/Unit;

    .line 306
    .line 307
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 308
    .line 309
    .line 310
    move-result-object v2

    .line 311
    sget-object v3, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 312
    .line 313
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    sget-object v3, LCb/F0;->b:LCb/F0;

    .line 317
    .line 318
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    const-class v2, Ljava/lang/Void;

    .line 322
    .line 323
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 324
    .line 325
    .line 326
    move-result-object v2

    .line 327
    sget-object v3, LCb/V;->a:LCb/V;

    .line 328
    .line 329
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    :try_start_0
    const-class v2, Lkotlin/time/a;

    .line 333
    .line 334
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 335
    .line 336
    .line 337
    move-result-object v1

    .line 338
    sget-object v2, Lkotlin/time/a;->b:Lkotlin/time/a$a;

    .line 339
    .line 340
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    sget-object v2, LCb/t;->a:LCb/t;

    .line 344
    .line 345
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 346
    .line 347
    .line 348
    :catch_0
    :try_start_1
    const-class v1, LI9/w;

    .line 349
    .line 350
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 351
    .line 352
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 353
    .line 354
    .line 355
    move-result-object v1

    .line 356
    sget-object v2, LCb/A0;->c:LCb/A0;

    .line 357
    .line 358
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    .line 359
    .line 360
    .line 361
    :catch_1
    :try_start_2
    const-class v1, LI9/u;

    .line 362
    .line 363
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 364
    .line 365
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 366
    .line 367
    .line 368
    move-result-object v1

    .line 369
    sget-object v2, LCb/x0;->c:LCb/x0;

    .line 370
    .line 371
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    .line 372
    .line 373
    .line 374
    :catch_2
    :try_start_3
    const-class v1, LI9/z;

    .line 375
    .line 376
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 377
    .line 378
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 379
    .line 380
    .line 381
    move-result-object v1

    .line 382
    sget-object v2, LCb/D0;->c:LCb/D0;

    .line 383
    .line 384
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/ClassNotFoundException; {:try_start_3 .. :try_end_3} :catch_3

    .line 385
    .line 386
    .line 387
    :catch_3
    :try_start_4
    const-class v1, LI9/s;

    .line 388
    .line 389
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 390
    .line 391
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 392
    .line 393
    .line 394
    move-result-object v1

    .line 395
    sget-object v2, LCb/u0;->c:LCb/u0;

    .line 396
    .line 397
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/ClassNotFoundException; {:try_start_4 .. :try_end_4} :catch_4

    .line 398
    .line 399
    .line 400
    :catch_4
    :try_start_5
    const-class v1, Lmb/a;

    .line 401
    .line 402
    sget-object v2, Lkotlin/jvm/internal/U;->a:Lkotlin/jvm/internal/V;

    .line 403
    .line 404
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/V;->b(Ljava/lang/Class;)LZ9/d;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    sget-object v2, Lmb/a;->c:Lmb/a$a;

    .line 409
    .line 410
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 411
    .line 412
    .line 413
    sget-object v2, LCb/G0;->a:LCb/G0;

    .line 414
    .line 415
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_5 .. :try_end_5} :catch_5
    .catch Ljava/lang/ClassNotFoundException; {:try_start_5 .. :try_end_5} :catch_5

    .line 416
    .line 417
    .line 418
    :catch_5
    invoke-static {v0}, Lkotlin/collections/MapsKt;->build(Ljava/util/Map;)Ljava/util/Map;

    .line 419
    .line 420
    .line 421
    move-result-object v0

    .line 422
    sput-object v0, LCb/n0;->a:Ljava/util/Map;

    .line 423
    .line 424
    return-void
.end method
