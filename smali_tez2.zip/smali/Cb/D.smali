.class public interface abstract LCb/D;
.super Ljava/lang/Object;
.source "PluginHelperInterfaces.kt"

# interfaces
.implements Lyb/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lyb/b<",
        "TT;>;"
    }
.end annotation


# virtual methods
.method public abstract a()[Lyb/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "Lyb/b<",
            "*>;"
        }
    .end annotation
.end method

.method public abstract d()[Lyb/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[",
            "Lyb/b<",
            "*>;"
        }
    .end annotation
.end method
