.class public final LCb/d;
.super LCb/M;
.source "CollectionDescriptors.kt"


# virtual methods
.method public final j()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "kotlin.collections.ArrayList"

    .line 2
    .line 3
    return-object v0
.end method
