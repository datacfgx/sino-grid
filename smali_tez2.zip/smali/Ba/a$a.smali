.class public final enum LBa/a$a;
.super Ljava/lang/Enum;
.source "KotlinClassHeader.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LBa/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LBa/a$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LBa/a$a;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $ENTRIES:LN9/a;

.field private static final synthetic $VALUES:[LBa/a$a;

.field public static final enum CLASS:LBa/a$a;

.field public static final Companion:LBa/a$a$a;

.field public static final enum FILE_FACADE:LBa/a$a;

.field public static final enum MULTIFILE_CLASS:LBa/a$a;

.field public static final enum MULTIFILE_CLASS_PART:LBa/a$a;

.field public static final enum SYNTHETIC_CLASS:LBa/a$a;

.field public static final enum UNKNOWN:LBa/a$a;

.field private static final entryById:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "LBa/a$a;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final id:I


# direct methods
.method private static final synthetic $values()[LBa/a$a;
    .locals 6

    .line 1
    sget-object v0, LBa/a$a;->UNKNOWN:LBa/a$a;

    .line 2
    .line 3
    sget-object v1, LBa/a$a;->CLASS:LBa/a$a;

    .line 4
    .line 5
    sget-object v2, LBa/a$a;->FILE_FACADE:LBa/a$a;

    .line 6
    .line 7
    sget-object v3, LBa/a$a;->SYNTHETIC_CLASS:LBa/a$a;

    .line 8
    .line 9
    sget-object v4, LBa/a$a;->MULTIFILE_CLASS:LBa/a$a;

    .line 10
    .line 11
    sget-object v5, LBa/a$a;->MULTIFILE_CLASS_PART:LBa/a$a;

    .line 12
    .line 13
    filled-new-array/range {v0 .. v5}, [LBa/a$a;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LBa/a$a;

    .line 2
    .line 3
    const-string v1, "UNKNOWN"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2, v2}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LBa/a$a;->UNKNOWN:LBa/a$a;

    .line 10
    .line 11
    new-instance v0, LBa/a$a;

    .line 12
    .line 13
    const-string v1, "CLASS"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v0, v1, v3, v3}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 17
    .line 18
    .line 19
    sput-object v0, LBa/a$a;->CLASS:LBa/a$a;

    .line 20
    .line 21
    new-instance v0, LBa/a$a;

    .line 22
    .line 23
    const-string v1, "FILE_FACADE"

    .line 24
    .line 25
    const/4 v3, 0x2

    .line 26
    invoke-direct {v0, v1, v3, v3}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 27
    .line 28
    .line 29
    sput-object v0, LBa/a$a;->FILE_FACADE:LBa/a$a;

    .line 30
    .line 31
    new-instance v0, LBa/a$a;

    .line 32
    .line 33
    const-string v1, "SYNTHETIC_CLASS"

    .line 34
    .line 35
    const/4 v3, 0x3

    .line 36
    invoke-direct {v0, v1, v3, v3}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    sput-object v0, LBa/a$a;->SYNTHETIC_CLASS:LBa/a$a;

    .line 40
    .line 41
    new-instance v0, LBa/a$a;

    .line 42
    .line 43
    const-string v1, "MULTIFILE_CLASS"

    .line 44
    .line 45
    const/4 v3, 0x4

    .line 46
    invoke-direct {v0, v1, v3, v3}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 47
    .line 48
    .line 49
    sput-object v0, LBa/a$a;->MULTIFILE_CLASS:LBa/a$a;

    .line 50
    .line 51
    new-instance v0, LBa/a$a;

    .line 52
    .line 53
    const-string v1, "MULTIFILE_CLASS_PART"

    .line 54
    .line 55
    const/4 v3, 0x5

    .line 56
    invoke-direct {v0, v1, v3, v3}, LBa/a$a;-><init>(Ljava/lang/String;II)V

    .line 57
    .line 58
    .line 59
    sput-object v0, LBa/a$a;->MULTIFILE_CLASS_PART:LBa/a$a;

    .line 60
    .line 61
    invoke-static {}, LBa/a$a;->$values()[LBa/a$a;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    sput-object v0, LBa/a$a;->$VALUES:[LBa/a$a;

    .line 66
    .line 67
    invoke-static {v0}, LN9/b;->a([Ljava/lang/Enum;)LN9/c;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, LBa/a$a;->$ENTRIES:LN9/a;

    .line 72
    .line 73
    new-instance v0, LBa/a$a$a;

    .line 74
    .line 75
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 76
    .line 77
    .line 78
    sput-object v0, LBa/a$a;->Companion:LBa/a$a$a;

    .line 79
    .line 80
    invoke-static {}, LBa/a$a;->values()[LBa/a$a;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    array-length v1, v0

    .line 85
    invoke-static {v1}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    const/16 v3, 0x10

    .line 90
    .line 91
    if-ge v1, v3, :cond_0

    .line 92
    .line 93
    move v1, v3

    .line 94
    :cond_0
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 95
    .line 96
    invoke-direct {v3, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 97
    .line 98
    .line 99
    array-length v1, v0

    .line 100
    :goto_0
    if-ge v2, v1, :cond_1

    .line 101
    .line 102
    aget-object v4, v0, v2

    .line 103
    .line 104
    iget v5, v4, LBa/a$a;->id:I

    .line 105
    .line 106
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    invoke-interface {v3, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    add-int/lit8 v2, v2, 0x1

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_1
    sput-object v3, LBa/a$a;->entryById:Ljava/util/Map;

    .line 117
    .line 118
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, LBa/a$a;->id:I

    .line 5
    .line 6
    return-void
.end method

.method public static final synthetic access$getEntryById$cp()Ljava/util/Map;
    .locals 1

    .line 1
    sget-object v0, LBa/a$a;->entryById:Ljava/util/Map;

    .line 2
    .line 3
    return-object v0
.end method

.method public static final getById(I)LBa/a$a;
    .locals 1

    .line 1
    sget-object v0, LBa/a$a;->Companion:LBa/a$a$a;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {}, LBa/a$a;->access$getEntryById$cp()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    check-cast p0, LBa/a$a;

    .line 19
    .line 20
    if-nez p0, :cond_0

    .line 21
    .line 22
    sget-object p0, LBa/a$a;->UNKNOWN:LBa/a$a;

    .line 23
    .line 24
    :cond_0
    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)LBa/a$a;
    .locals 1

    .line 1
    const-class v0, LBa/a$a;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LBa/a$a;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LBa/a$a;
    .locals 1

    .line 1
    sget-object v0, LBa/a$a;->$VALUES:[LBa/a$a;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LBa/a$a;

    .line 8
    .line 9
    return-object v0
.end method
