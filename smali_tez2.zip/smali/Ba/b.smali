.class public final LBa/b;
.super Ljava/lang/Object;
.source "ReadKotlinClassHeaderAnnotationVisitor.java"

# interfaces
.implements LAa/x$c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LBa/b$a;,
        LBa/b$c;,
        LBa/b$d;,
        LBa/b$b;
    }
.end annotation


# static fields
.field public static final i:Z

.field public static final j:Ljava/util/HashMap;


# instance fields
.field public a:[I

.field public b:Ljava/lang/String;

.field public c:I

.field public d:[Ljava/lang/String;

.field public e:[Ljava/lang/String;

.field public f:[Ljava/lang/String;

.field public g:LBa/a$a;

.field public h:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    .line 2
    :try_start_0
    const-string v0, "true"

    .line 3
    .line 4
    const-string v1, "kotlin.ignore.old.metadata"

    .line 5
    .line 6
    .line 7
    invoke-static {v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    move-result-object v1

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    move-result v0

    .line 13
    .line 14
    sput-boolean v0, LBa/b;->i:Z
    :try_end_0
    .catch Ljava/security/AccessControlException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    goto :goto_0

    .line 16
    :catch_0
    const/4 v0, 0x0

    .line 17
    .line 18
    sput-boolean v0, LBa/b;->i:Z

    .line 19
    .line 20
    :goto_0
    new-instance v0, Ljava/util/HashMap;

    .line 21
    .line 22
    .line 23
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 24
    .line 25
    sput-object v0, LBa/b;->j:Ljava/util/HashMap;

    .line 26
    .line 27
    new-instance v1, LHa/c;

    .line 28
    .line 29
    const-string v2, "kotlin.jvm.internal.KotlinClass"

    .line 30
    .line 31
    .line 32
    invoke-direct {v1, v2}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v1}, LHa/b$a;->b(LHa/c;)LHa/b;

    .line 36
    move-result-object v1

    .line 37
    .line 38
    sget-object v2, LBa/a$a;->CLASS:LBa/a$a;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    new-instance v1, LHa/c;

    .line 44
    .line 45
    const/4 v2, 0x0

    sget-object v2, Lcom/adjust/sdk/tdc/XWvfGx;->SwpYMUOSN:Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    invoke-direct {v1, v2}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-static {v1}, LHa/b$a;->b(LHa/c;)LHa/b;

    .line 52
    move-result-object v1

    .line 53
    .line 54
    sget-object v2, LBa/a$a;->FILE_FACADE:LBa/a$a;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    new-instance v1, LHa/c;

    .line 60
    .line 61
    const-string v2, "kotlin.jvm.internal.KotlinMultifileClass"

    .line 62
    .line 63
    .line 64
    invoke-direct {v1, v2}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-static {v1}, LHa/b$a;->b(LHa/c;)LHa/b;

    .line 68
    move-result-object v1

    .line 69
    .line 70
    sget-object v2, LBa/a$a;->MULTIFILE_CLASS:LBa/a$a;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    new-instance v1, LHa/c;

    .line 76
    .line 77
    const-string v2, "kotlin.jvm.internal.KotlinMultifileClassPart"

    .line 78
    .line 79
    .line 80
    invoke-direct {v1, v2}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    invoke-static {v1}, LHa/b$a;->b(LHa/c;)LHa/b;

    .line 84
    move-result-object v1

    .line 85
    .line 86
    sget-object v2, LBa/a$a;->MULTIFILE_CLASS_PART:LBa/a$a;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    .line 91
    new-instance v1, LHa/c;

    .line 92
    .line 93
    const-string v2, "kotlin.jvm.internal.KotlinSyntheticClass"

    .line 94
    .line 95
    .line 96
    invoke-direct {v1, v2}, LHa/c;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    invoke-static {v1}, LHa/b$a;->b(LHa/c;)LHa/b;

    .line 100
    move-result-object v1

    .line 101
    .line 102
    sget-object v2, LBa/a$a;->SYNTHETIC_CLASS:LBa/a$a;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 106
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    return-void
.end method

.method public final b(LHa/b;Lna/b;)LAa/x$a;
    .locals 1

    .line 1
    invoke-virtual {p1}, LHa/b;->a()LHa/c;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    sget-object v0, Lra/D;->a:LHa/c;

    .line 6
    .line 7
    invoke-virtual {p2, v0}, LHa/c;->equals(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    new-instance p1, LBa/b$b;

    .line 14
    .line 15
    invoke-direct {p1, p0}, LBa/b$b;-><init>(LBa/b;)V

    .line 16
    .line 17
    .line 18
    return-object p1

    .line 19
    :cond_0
    sget-object v0, Lra/D;->o:LHa/c;

    .line 20
    .line 21
    invoke-virtual {p2, v0}, LHa/c;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    if-eqz p2, :cond_1

    .line 26
    .line 27
    new-instance p1, LBa/b$c;

    .line 28
    .line 29
    invoke-direct {p1, p0}, LBa/b$c;-><init>(LBa/b;)V

    .line 30
    .line 31
    .line 32
    return-object p1

    .line 33
    :cond_1
    sget-boolean p2, LBa/b;->i:Z

    .line 34
    .line 35
    if-eqz p2, :cond_2

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_2
    iget-object p2, p0, LBa/b;->g:LBa/a$a;

    .line 39
    .line 40
    if-eqz p2, :cond_3

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_3
    sget-object p2, LBa/b;->j:Ljava/util/HashMap;

    .line 44
    .line 45
    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    check-cast p1, LBa/a$a;

    .line 50
    .line 51
    if-eqz p1, :cond_4

    .line 52
    .line 53
    iput-object p1, p0, LBa/b;->g:LBa/a$a;

    .line 54
    .line 55
    new-instance p1, LBa/b$d;

    .line 56
    .line 57
    invoke-direct {p1, p0}, LBa/b$d;-><init>(LBa/b;)V

    .line 58
    .line 59
    .line 60
    return-object p1

    .line 61
    :cond_4
    :goto_0
    const/4 p1, 0x0

    .line 62
    return-object p1
.end method
