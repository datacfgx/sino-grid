.class public final synthetic LCc/c;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

.field public final synthetic b:Lkotlin/jvm/internal/P;

.field public final synthetic c:Lkotlin/jvm/internal/P;

.field public final synthetic d:F

.field public final synthetic e:F


# direct methods
.method public synthetic constructor <init>(Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;Lkotlin/jvm/internal/P;Lkotlin/jvm/internal/P;FF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LCc/c;->a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

    .line 5
    .line 6
    iput-object p2, p0, LCc/c;->b:Lkotlin/jvm/internal/P;

    .line 7
    .line 8
    iput-object p3, p0, LCc/c;->c:Lkotlin/jvm/internal/P;

    .line 9
    .line 10
    iput p4, p0, LCc/c;->d:F

    .line 11
    .line 12
    iput p5, p0, LCc/c;->e:F

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, Landroid/graphics/Canvas;

    .line 3
    .line 4
    iget-object v1, p0, LCc/c;->b:Lkotlin/jvm/internal/P;

    .line 5
    .line 6
    iget-object v2, p0, LCc/c;->c:Lkotlin/jvm/internal/P;

    .line 7
    .line 8
    iget v3, p0, LCc/c;->d:F

    .line 9
    .line 10
    iget-object v0, p0, LCc/c;->a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

    .line 11
    .line 12
    iget v4, p0, LCc/c;->e:F

    .line 13
    .line 14
    invoke-static/range {v0 .. v5}, Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalBitmap;->c(Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;Lkotlin/jvm/internal/P;Lkotlin/jvm/internal/P;FFLandroid/graphics/Canvas;)Lkotlin/Unit;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    return-object p1
.end method
