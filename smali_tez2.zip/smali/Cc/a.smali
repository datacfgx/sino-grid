.class public final synthetic LCc/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

.field public final synthetic b:I

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(IILorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, LCc/a;->a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

    .line 5
    .line 6
    iput p1, p0, LCc/a;->b:I

    .line 7
    .line 8
    iput p2, p0, LCc/a;->c:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    check-cast p1, Landroid/graphics/Canvas;

    .line 2
    .line 3
    iget-object v0, p0, LCc/a;->a:Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;

    .line 4
    .line 5
    iget v1, p0, LCc/a;->b:I

    .line 6
    .line 7
    iget v2, p0, LCc/a;->c:I

    .line 8
    .line 9
    invoke-static {v0, v1, v2, p1}, Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalBitmap;->b(Lorg/tezza/gpu_video/gpu/egl/filter_custom/universal/UniversalColor;IILandroid/graphics/Canvas;)Lkotlin/Unit;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method
