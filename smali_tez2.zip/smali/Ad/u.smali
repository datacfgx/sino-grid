.class public final synthetic LAd/u;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:LAd/x;

.field public final synthetic b:Landroid/view/ViewGroup;

.field public final synthetic c:Ljava/util/List;

.field public final synthetic d:Ljava/util/ArrayList;

.field public final synthetic e:LLc/C;


# direct methods
.method public synthetic constructor <init>(LAd/x;Landroid/view/ViewGroup;Ljava/util/List;Ljava/util/ArrayList;LLc/C;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAd/u;->a:LAd/x;

    .line 5
    .line 6
    iput-object p2, p0, LAd/u;->b:Landroid/view/ViewGroup;

    .line 7
    .line 8
    iput-object p3, p0, LAd/u;->c:Ljava/util/List;

    .line 9
    .line 10
    iput-object p4, p0, LAd/u;->d:Ljava/util/ArrayList;

    .line 11
    .line 12
    iput-object p5, p0, LAd/u;->e:LLc/C;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v1, p0, LAd/u;->a:LAd/x;

    .line 2
    .line 3
    invoke-virtual {v1}, LAd/x;->z0()Ljava/util/ArrayList;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Lorg/tezza/presentation/widgets/sticker/StickerTextView;

    .line 22
    .line 23
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/StickerTextView;->z()V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    iget-object v3, p0, LAd/u;->d:Ljava/util/ArrayList;

    .line 28
    .line 29
    iget-object v4, p0, LAd/u;->e:LLc/C;

    .line 30
    .line 31
    iget-object v6, p0, LAd/u;->b:Landroid/view/ViewGroup;

    .line 32
    .line 33
    iget-object v2, p0, LAd/u;->c:Ljava/util/List;

    .line 34
    .line 35
    if-eqz v6, :cond_1

    .line 36
    .line 37
    new-instance v0, LAd/w;

    .line 38
    .line 39
    const/4 v5, 0x0

    .line 40
    invoke-direct/range {v0 .. v5}, LAd/w;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v6, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    invoke-virtual {v1}, LAd/x;->x0()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v1, v3, v2}, LAd/x;->m0(Ljava/util/ArrayList;Ljava/util/List;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v1, v3}, LAd/x;->l0(Ljava/util/List;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v1, v3}, LAd/x;->P0(Ljava/util/ArrayList;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-lez v0, :cond_2

    .line 68
    .line 69
    invoke-virtual {v1}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v1, v0}, LAd/x;->w0(Landroid/view/View;)LAd/y;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    :cond_2
    new-instance v0, LAd/z;

    .line 81
    .line 82
    iget-object v2, v1, LAd/x;->E0:Lcd/B;

    .line 83
    .line 84
    invoke-virtual {v2}, Lcd/B;->getSize()Lorg/tezza/presentation/utils/media/Size;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    iget v1, v1, LAd/x;->D0:I

    .line 89
    .line 90
    invoke-direct {v0, v2, v1}, LAd/z;-><init>(Lorg/tezza/presentation/utils/media/Size;I)V

    .line 91
    .line 92
    .line 93
    invoke-static {v3, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-virtual {v4, v0}, LLc/C;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 101
    .line 102
    return-object v0
.end method
