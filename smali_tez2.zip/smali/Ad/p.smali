.class public final synthetic LAd/p;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnDragListener;


# instance fields
.field public final synthetic a:LAd/x;


# direct methods
.method public synthetic constructor <init>(LAd/x;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAd/p;->a:LAd/x;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onDrag(Landroid/view/View;Landroid/view/DragEvent;)Z
    .locals 13

    .line 1
    invoke-virtual {p2}, Landroid/view/DragEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, LAd/p;->a:LAd/x;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    packed-switch p1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return p1

    .line 13
    :pswitch_0
    invoke-virtual {p2}, Landroid/view/DragEvent;->getClipDescription()Landroid/content/ClipDescription;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p1}, Landroid/content/ClipDescription;->getLabel()Ljava/lang/CharSequence;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    return v1

    .line 25
    :pswitch_1
    invoke-virtual {p2}, Landroid/view/DragEvent;->getResult()Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_0

    .line 30
    .line 31
    const-string p1, "Dragging ended with success"

    .line 32
    .line 33
    invoke-static {v0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return v1

    .line 37
    :cond_0
    const-string p1, "Dragging ended with snap"

    .line 38
    .line 39
    invoke-static {v0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return v1

    .line 43
    :pswitch_2
    invoke-virtual {p2}, Landroid/view/DragEvent;->getClipDescription()Landroid/content/ClipDescription;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-virtual {p1}, Landroid/content/ClipDescription;->getLabel()Ljava/lang/CharSequence;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {v0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    const/4 v3, 0x0

    .line 60
    if-eqz v2, :cond_1

    .line 61
    .line 62
    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    goto :goto_0

    .line 67
    :cond_1
    move-object v2, v3

    .line 68
    :goto_0
    instance-of v4, v2, Landroid/view/ViewGroup;

    .line 69
    .line 70
    if-eqz v4, :cond_2

    .line 71
    .line 72
    check-cast v2, Landroid/view/ViewGroup;

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_2
    move-object v2, v3

    .line 76
    :goto_1
    if-eqz v2, :cond_4

    .line 77
    .line 78
    invoke-static {v2}, LAd/x;->y0(Landroid/view/View;)Ljava/util/ArrayList;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    new-instance v4, Ljava/util/ArrayList;

    .line 83
    .line 84
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    :cond_3
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    if-eqz v5, :cond_6

    .line 96
    .line 97
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    instance-of v6, v5, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 102
    .line 103
    if-eqz v6, :cond_3

    .line 104
    .line 105
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_2

    .line 109
    :cond_4
    invoke-virtual {v0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    invoke-static {v2}, LAd/x;->y0(Landroid/view/View;)Ljava/util/ArrayList;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    new-instance v4, Ljava/util/ArrayList;

    .line 118
    .line 119
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    :cond_5
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    if-eqz v5, :cond_6

    .line 131
    .line 132
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v5

    .line 136
    instance-of v6, v5, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 137
    .line 138
    if-eqz v6, :cond_5

    .line 139
    .line 140
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    goto :goto_3

    .line 144
    :cond_6
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->x(Ljava/util/ArrayList;)Ljava/util/List;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    check-cast v2, Ljava/lang/Iterable;

    .line 149
    .line 150
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    :cond_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 155
    .line 156
    .line 157
    move-result v4

    .line 158
    if-eqz v4, :cond_13

    .line 159
    .line 160
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    check-cast v4, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 165
    .line 166
    invoke-virtual {v0}, LAd/x;->C0()Ljava/util/List;

    .line 167
    .line 168
    .line 169
    move-result-object v5

    .line 170
    check-cast v5, Ljava/lang/Iterable;

    .line 171
    .line 172
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    :cond_8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 177
    .line 178
    .line 179
    move-result v6

    .line 180
    if-eqz v6, :cond_9

    .line 181
    .line 182
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v6

    .line 186
    move-object v7, v6

    .line 187
    check-cast v7, LAd/y;

    .line 188
    .line 189
    iget-object v7, v7, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 190
    .line 191
    if-eqz v7, :cond_8

    .line 192
    .line 193
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 194
    .line 195
    .line 196
    move-result v8

    .line 197
    invoke-virtual {v7}, Landroid/view/View;->getId()I

    .line 198
    .line 199
    .line 200
    move-result v7

    .line 201
    if-ne v8, v7, :cond_8

    .line 202
    .line 203
    goto :goto_4

    .line 204
    :cond_9
    move-object v6, v3

    .line 205
    :goto_4
    check-cast v6, LAd/y;

    .line 206
    .line 207
    invoke-virtual {v0, v6}, LAd/x;->K0(LAd/y;)Z

    .line 208
    .line 209
    .line 210
    move-result v5

    .line 211
    if-nez v5, :cond_7

    .line 212
    .line 213
    invoke-virtual {p2}, Landroid/view/DragEvent;->getX()F

    .line 214
    .line 215
    .line 216
    move-result v5

    .line 217
    invoke-virtual {p2}, Landroid/view/DragEvent;->getY()F

    .line 218
    .line 219
    .line 220
    move-result v6

    .line 221
    invoke-virtual {v4}, Landroid/view/View;->getX()F

    .line 222
    .line 223
    .line 224
    move-result v7

    .line 225
    invoke-virtual {v4}, Landroid/view/View;->getY()F

    .line 226
    .line 227
    .line 228
    move-result v8

    .line 229
    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    .line 230
    .line 231
    .line 232
    move-result v9

    .line 233
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 234
    .line 235
    .line 236
    move-result v10

    .line 237
    int-to-float v9, v9

    .line 238
    add-float/2addr v9, v7

    .line 239
    int-to-float v10, v10

    .line 240
    add-float/2addr v10, v8

    .line 241
    new-instance v11, Ljava/lang/StringBuilder;

    .line 242
    .line 243
    const-string v12, "isWithinViewBounds: view x1,x2= "

    .line 244
    .line 245
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 249
    .line 250
    .line 251
    const-string v12, " , "

    .line 252
    .line 253
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 254
    .line 255
    .line 256
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 257
    .line 258
    .line 259
    const-string v12, ", y1, y2= "

    .line 260
    .line 261
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 262
    .line 263
    .line 264
    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    const-string v12, " , $"

    .line 268
    .line 269
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 270
    .line 271
    .line 272
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 273
    .line 274
    .line 275
    const-string v12, " xPoint = "

    .line 276
    .line 277
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 278
    .line 279
    .line 280
    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 281
    .line 282
    .line 283
    const-string v12, ", yPoint = "

    .line 284
    .line 285
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 289
    .line 290
    .line 291
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 292
    .line 293
    .line 294
    move-result-object v11

    .line 295
    const-string v12, "vb"

    .line 296
    .line 297
    invoke-static {v12, v11}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 298
    .line 299
    .line 300
    cmpg-float v7, v5, v7

    .line 301
    .line 302
    if-ltz v7, :cond_7

    .line 303
    .line 304
    cmpl-float v5, v5, v9

    .line 305
    .line 306
    if-gtz v5, :cond_7

    .line 307
    .line 308
    cmpg-float v5, v6, v8

    .line 309
    .line 310
    if-ltz v5, :cond_7

    .line 311
    .line 312
    cmpl-float v5, v6, v10

    .line 313
    .line 314
    if-gtz v5, :cond_7

    .line 315
    .line 316
    invoke-virtual {v0}, LAd/x;->C0()Ljava/util/List;

    .line 317
    .line 318
    .line 319
    move-result-object p2

    .line 320
    check-cast p2, Ljava/lang/Iterable;

    .line 321
    .line 322
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 323
    .line 324
    .line 325
    move-result-object p2

    .line 326
    :cond_a
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 327
    .line 328
    .line 329
    move-result v2

    .line 330
    if-eqz v2, :cond_b

    .line 331
    .line 332
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    move-result-object v2

    .line 336
    move-object v5, v2

    .line 337
    check-cast v5, LAd/y;

    .line 338
    .line 339
    iget-object v5, v5, LAd/y;->c:Ljava/lang/String;

    .line 340
    .line 341
    invoke-static {v5, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 342
    .line 343
    .line 344
    move-result v5

    .line 345
    if-eqz v5, :cond_a

    .line 346
    .line 347
    goto :goto_5

    .line 348
    :cond_b
    move-object v2, v3

    .line 349
    :goto_5
    check-cast v2, LAd/y;

    .line 350
    .line 351
    invoke-virtual {v0}, LAd/x;->C0()Ljava/util/List;

    .line 352
    .line 353
    .line 354
    move-result-object p2

    .line 355
    check-cast p2, Ljava/lang/Iterable;

    .line 356
    .line 357
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 358
    .line 359
    .line 360
    move-result-object p2

    .line 361
    :cond_c
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 362
    .line 363
    .line 364
    move-result v5

    .line 365
    if-eqz v5, :cond_d

    .line 366
    .line 367
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v5

    .line 371
    move-object v6, v5

    .line 372
    check-cast v6, LAd/y;

    .line 373
    .line 374
    iget-object v6, v6, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 375
    .line 376
    if-eqz v6, :cond_c

    .line 377
    .line 378
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 379
    .line 380
    .line 381
    move-result v7

    .line 382
    invoke-virtual {v6}, Landroid/view/View;->getId()I

    .line 383
    .line 384
    .line 385
    move-result v6

    .line 386
    if-ne v7, v6, :cond_c

    .line 387
    .line 388
    goto :goto_6

    .line 389
    :cond_d
    move-object v5, v3

    .line 390
    :goto_6
    check-cast v5, LAd/y;

    .line 391
    .line 392
    if-eqz v2, :cond_f

    .line 393
    .line 394
    if-eqz v5, :cond_e

    .line 395
    .line 396
    iget-object v3, v5, LAd/y;->c:Ljava/lang/String;

    .line 397
    .line 398
    :cond_e
    iput-object v3, v2, LAd/y;->c:Ljava/lang/String;

    .line 399
    .line 400
    :cond_f
    if-eqz v5, :cond_10

    .line 401
    .line 402
    iput-object p1, v5, LAd/y;->c:Ljava/lang/String;

    .line 403
    .line 404
    :cond_10
    if-eqz v2, :cond_11

    .line 405
    .line 406
    invoke-virtual {v0, v2}, LAd/x;->M0(LAd/y;)V

    .line 407
    .line 408
    .line 409
    :cond_11
    if-eqz v5, :cond_12

    .line 410
    .line 411
    invoke-virtual {v0, v5}, LAd/x;->M0(LAd/y;)V

    .line 412
    .line 413
    .line 414
    :cond_12
    invoke-virtual {v0}, LAd/x;->Q0()V

    .line 415
    .line 416
    .line 417
    :cond_13
    :pswitch_3
    return v1

    .line 418
    nop

    .line 419
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_3
    .end packed-switch
.end method
