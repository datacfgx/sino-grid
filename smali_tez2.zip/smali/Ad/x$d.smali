.class public final LAd/x$d;
.super LE3/c;
.source "TemplateFragment.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LAd/x;->M0(LAd/y;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LE3/c<",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic d:LAd/y;


# direct methods
.method public constructor <init>(LAd/y;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAd/x$d;->d:LAd/y;

    .line 2
    .line 3
    invoke-direct {p0}, LE3/c;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final h(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final i(Ljava/lang/Object;LF3/d;)V
    .locals 0

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 2
    .line 3
    const-string p2, "resource"

    .line 4
    .line 5
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object p2, p0, LAd/x$d;->d:LAd/y;

    .line 9
    .line 10
    iget-object p2, p2, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 11
    .line 12
    if-eqz p2, :cond_0

    .line 13
    .line 14
    invoke-virtual {p2, p1}, LMd/o;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method
