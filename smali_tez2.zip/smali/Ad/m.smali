.class public final synthetic LAd/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LAd/m;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LAd/m;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, LAd/m;->b:Ljava/lang/Object;

    .line 2
    .line 3
    iget v1, p0, LAd/m;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast v0, Lh4/g;

    .line 9
    .line 10
    iget-object v0, v0, Lh4/g;->F:Landroid/widget/ImageView;

    .line 11
    .line 12
    const/16 v1, 0x8

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    check-cast v0, Lcom/appsflyer/internal/AFd1uSDK;

    .line 19
    .line 20
    invoke-static {v0}, Lcom/appsflyer/internal/AFd1uSDK;->d(Lcom/appsflyer/internal/AFd1uSDK;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_1
    check-cast v0, LLc/r0;

    .line 25
    .line 26
    iget-object v1, v0, LLc/r0;->g:LLc/u2;

    .line 27
    .line 28
    if-eqz v1, :cond_0

    .line 29
    .line 30
    sget-object v2, LLc/c2;->q1:Lorg/tezza/presentation/utils/media/Size;

    .line 31
    .line 32
    iget-object v1, v1, LLc/u2;->a:LLc/c2;

    .line 33
    .line 34
    invoke-virtual {v1}, LLc/c2;->n1()V

    .line 35
    .line 36
    .line 37
    :cond_0
    iget-object v0, v0, LLc/r0;->g:LLc/u2;

    .line 38
    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    const/4 v1, 0x1

    .line 42
    invoke-virtual {v0, v1}, LLc/u2;->a(Z)V

    .line 43
    .line 44
    .line 45
    :cond_1
    return-void

    .line 46
    :pswitch_2
    check-cast v0, LAd/u;

    .line 47
    .line 48
    invoke-virtual {v0}, LAd/u;->invoke()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
