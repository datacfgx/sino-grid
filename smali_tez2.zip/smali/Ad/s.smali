.class public final synthetic LAd/s;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:LAd/x;

.field public final synthetic b:LAd/r;


# direct methods
.method public synthetic constructor <init>(LAd/x;LAd/r;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAd/s;->a:LAd/x;

    .line 5
    .line 6
    iput-object p2, p0, LAd/s;->b:LAd/r;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    new-instance v0, LAd/v;

    .line 2
    .line 3
    iget-object v1, p0, LAd/s;->a:LAd/x;

    .line 4
    .line 5
    iget-object v2, p0, LAd/s;->b:LAd/r;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, LAd/v;-><init>(LAd/x;LAd/r;)V

    .line 8
    .line 9
    .line 10
    new-instance v2, Lw6/b;

    .line 11
    .line 12
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->c0()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    const v4, 0x7f130002

    .line 17
    .line 18
    .line 19
    invoke-direct {v2, v3, v4}, Lw6/b;-><init>(Landroid/content/Context;I)V

    .line 20
    .line 21
    .line 22
    const v3, 0x7f120238

    .line 23
    .line 24
    .line 25
    invoke-static {v3, v1}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    iget-object v4, v2, Landroidx/appcompat/app/b$a;->a:Landroidx/appcompat/app/AlertController$b;

    .line 30
    .line 31
    iput-object v3, v4, Landroidx/appcompat/app/AlertController$b;->d:Ljava/lang/CharSequence;

    .line 32
    .line 33
    const v3, 0x7f12023c

    .line 34
    .line 35
    .line 36
    invoke-static {v3, v1}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    iput-object v3, v4, Landroidx/appcompat/app/AlertController$b;->f:Ljava/lang/String;

    .line 41
    .line 42
    const v3, 0x7f12023e

    .line 43
    .line 44
    .line 45
    invoke-static {v3, v1}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    new-instance v5, LAd/k;

    .line 50
    .line 51
    invoke-direct {v5, v0}, LAd/k;-><init>(LAd/v;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, v3, v5}, Lw6/b;->d(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 55
    .line 56
    .line 57
    const v0, 0x7f120239

    .line 58
    .line 59
    .line 60
    invoke-static {v0, v1}, LBd/w;->c(ILjava/lang/Object;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    new-instance v3, LAd/l;

    .line 65
    .line 66
    invoke-direct {v3, v1}, LAd/l;-><init>(LAd/x;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2, v0, v3}, Lw6/b;->c(Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V

    .line 70
    .line 71
    .line 72
    const/4 v0, 0x0

    .line 73
    iput-boolean v0, v4, Landroidx/appcompat/app/AlertController$b;->m:Z

    .line 74
    .line 75
    invoke-virtual {v2}, Landroidx/appcompat/app/b$a;->b()V

    .line 76
    .line 77
    .line 78
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 79
    .line 80
    return-object v0
.end method
