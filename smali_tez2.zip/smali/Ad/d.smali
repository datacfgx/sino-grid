.class public final LAd/d;
.super LAd/f;
.source "Template.kt"


# instance fields
.field public b:D
