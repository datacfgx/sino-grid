.class public abstract LAd/x;
.super Landroidx/fragment/app/Fragment;
.source "TemplateFragment.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAd/x$a;,
        LAd/x$b;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0008&\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003\u00a8\u0006\u0005"
    }
    d2 = {
        "LAd/x;",
        "Landroidx/fragment/app/Fragment;",
        "<init>",
        "()V",
        "a",
        "app_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field public A0:LAd/y;

.field public B0:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final C0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcd/d;",
            ">;"
        }
    .end annotation
.end field

.field public D0:I

.field public E0:Lcd/B;

.field public final F0:LAd/j;

.field public final G0:LAd/o;

.field public final H0:LAd/p;

.field public I0:Landroid/view/View;

.field public J0:I

.field public K0:I

.field public L0:I

.field public M0:I

.field public N0:Ljava/lang/Integer;

.field public O0:Ljava/lang/Integer;

.field public u0:J

.field public final v0:Landroid/view/GestureDetector;

.field public w0:I

.field public x0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LAd/y;",
            ">;"
        }
    .end annotation
.end field

.field public y0:Ljava/util/ArrayList;

.field public z0:Lcd/d;


# direct methods
.method public constructor <init>()V
    .locals 198

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-direct {v0}, Landroidx/fragment/app/Fragment;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Landroid/view/GestureDetector;

    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->p()Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    new-instance v3, Lorg/tezza/presentation/widgets/sticker/c$b;

    .line 13
    .line 14
    invoke-direct {v3}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    .line 15
    .line 16
    .line 17
    invoke-direct {v1, v2, v3}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    .line 18
    .line 19
    .line 20
    iput-object v1, v0, LAd/x;->v0:Landroid/view/GestureDetector;

    .line 21
    .line 22
    sget-object v4, Lcd/d;->HYPERVISUAL_1:Lcd/d;

    .line 23
    .line 24
    sget-object v5, Lcd/d;->HYPERVISUAL_2:Lcd/d;

    .line 25
    .line 26
    sget-object v6, Lcd/d;->HYPERVISUAL_3:Lcd/d;

    .line 27
    .line 28
    sget-object v7, Lcd/d;->HYPERVISUAL_4:Lcd/d;

    .line 29
    .line 30
    sget-object v8, Lcd/d;->HYPERVISUAL_5:Lcd/d;

    .line 31
    .line 32
    sget-object v9, Lcd/d;->HYPERVISUAL_6:Lcd/d;

    .line 33
    .line 34
    sget-object v10, Lcd/d;->HYPERVISUAL_7:Lcd/d;

    .line 35
    .line 36
    sget-object v11, Lcd/d;->HYPERVISUAL_8:Lcd/d;

    .line 37
    .line 38
    sget-object v12, Lcd/d;->HYPERVISUAL_9:Lcd/d;

    .line 39
    .line 40
    sget-object v13, Lcd/d;->HYPERVISUAL_10:Lcd/d;

    .line 41
    .line 42
    sget-object v14, Lcd/d;->HYPERVISUAL_11:Lcd/d;

    .line 43
    .line 44
    sget-object v15, Lcd/d;->HYPERVISUAL_12:Lcd/d;

    .line 45
    .line 46
    sget-object v16, Lcd/d;->HYPERVISUAL_13:Lcd/d;

    .line 47
    .line 48
    sget-object v17, Lcd/d;->HYPERVISUAL_14:Lcd/d;

    .line 49
    .line 50
    sget-object v18, Lcd/d;->HYPERVISUAL_15:Lcd/d;

    .line 51
    .line 52
    sget-object v19, Lcd/d;->HYPERVISUAL_16:Lcd/d;

    .line 53
    .line 54
    sget-object v20, Lcd/d;->HYPERVISUAL_17:Lcd/d;

    .line 55
    .line 56
    sget-object v21, Lcd/d;->HYPERVISUAL_18:Lcd/d;

    .line 57
    .line 58
    sget-object v22, Lcd/d;->HYPERVISUAL_19:Lcd/d;

    .line 59
    .line 60
    sget-object v23, Lcd/d;->HYPERVISUAL_20:Lcd/d;

    .line 61
    .line 62
    sget-object v24, Lcd/d;->HYPERVISUAL_21:Lcd/d;

    .line 63
    .line 64
    sget-object v25, Lcd/d;->ZINE_1:Lcd/d;

    .line 65
    .line 66
    sget-object v26, Lcd/d;->ZINE_2:Lcd/d;

    .line 67
    .line 68
    sget-object v27, Lcd/d;->ZINE_3:Lcd/d;

    .line 69
    .line 70
    sget-object v28, Lcd/d;->ZINE_4:Lcd/d;

    .line 71
    .line 72
    sget-object v29, Lcd/d;->ZINE_5:Lcd/d;

    .line 73
    .line 74
    sget-object v30, Lcd/d;->ZINE_6:Lcd/d;

    .line 75
    .line 76
    sget-object v31, Lcd/d;->ZINE_7:Lcd/d;

    .line 77
    .line 78
    sget-object v32, Lcd/d;->ZINE_8:Lcd/d;

    .line 79
    .line 80
    sget-object v33, Lcd/d;->ZINE_9:Lcd/d;

    .line 81
    .line 82
    sget-object v34, Lcd/d;->ZINE_10:Lcd/d;

    .line 83
    .line 84
    sget-object v35, Lcd/d;->ZINE_11:Lcd/d;

    .line 85
    .line 86
    sget-object v36, Lcd/d;->ZINE_12:Lcd/d;

    .line 87
    .line 88
    sget-object v37, Lcd/d;->ZINE_13:Lcd/d;

    .line 89
    .line 90
    sget-object v38, Lcd/d;->ZINE_14:Lcd/d;

    .line 91
    .line 92
    sget-object v39, Lcd/d;->ZINE_15:Lcd/d;

    .line 93
    .line 94
    sget-object v40, Lcd/d;->ZINE_16:Lcd/d;

    .line 95
    .line 96
    sget-object v41, Lcd/d;->ZINE_17:Lcd/d;

    .line 97
    .line 98
    sget-object v42, Lcd/d;->ZINE_18:Lcd/d;

    .line 99
    .line 100
    sget-object v43, Lcd/d;->ZINE_19:Lcd/d;

    .line 101
    .line 102
    sget-object v44, Lcd/d;->ZINE_20:Lcd/d;

    .line 103
    .line 104
    sget-object v45, Lcd/d;->ZINE_21:Lcd/d;

    .line 105
    .line 106
    sget-object v46, Lcd/d;->LOVE_LETTERS_1:Lcd/d;

    .line 107
    .line 108
    sget-object v47, Lcd/d;->LOVE_LETTERS_2:Lcd/d;

    .line 109
    .line 110
    sget-object v48, Lcd/d;->LOVE_LETTERS_3:Lcd/d;

    .line 111
    .line 112
    sget-object v49, Lcd/d;->LOVE_LETTERS_4:Lcd/d;

    .line 113
    .line 114
    sget-object v50, Lcd/d;->LOVE_LETTERS_5:Lcd/d;

    .line 115
    .line 116
    sget-object v51, Lcd/d;->LOVE_LETTERS_6:Lcd/d;

    .line 117
    .line 118
    sget-object v52, Lcd/d;->LOVE_LETTERS_7:Lcd/d;

    .line 119
    .line 120
    sget-object v53, Lcd/d;->LOVE_LETTERS_8:Lcd/d;

    .line 121
    .line 122
    sget-object v54, Lcd/d;->LOVE_LETTERS_9:Lcd/d;

    .line 123
    .line 124
    sget-object v55, Lcd/d;->LOVE_LETTERS_10:Lcd/d;

    .line 125
    .line 126
    sget-object v56, Lcd/d;->LOVE_LETTERS_11:Lcd/d;

    .line 127
    .line 128
    sget-object v57, Lcd/d;->LOVE_LETTERS_12:Lcd/d;

    .line 129
    .line 130
    sget-object v58, Lcd/d;->LOVE_LETTERS_13:Lcd/d;

    .line 131
    .line 132
    sget-object v59, Lcd/d;->LOVE_LETTERS_14:Lcd/d;

    .line 133
    .line 134
    sget-object v60, Lcd/d;->LOVE_LETTERS_15:Lcd/d;

    .line 135
    .line 136
    sget-object v61, Lcd/d;->LOVE_LETTERS_16:Lcd/d;

    .line 137
    .line 138
    sget-object v62, Lcd/d;->LINE_1:Lcd/d;

    .line 139
    .line 140
    sget-object v63, Lcd/d;->LINE_2:Lcd/d;

    .line 141
    .line 142
    sget-object v64, Lcd/d;->LINE_3:Lcd/d;

    .line 143
    .line 144
    sget-object v65, Lcd/d;->LINE_4:Lcd/d;

    .line 145
    .line 146
    sget-object v66, Lcd/d;->LINE_5:Lcd/d;

    .line 147
    .line 148
    sget-object v67, Lcd/d;->LINE_6:Lcd/d;

    .line 149
    .line 150
    sget-object v68, Lcd/d;->LINE_7:Lcd/d;

    .line 151
    .line 152
    sget-object v69, Lcd/d;->LINE_8:Lcd/d;

    .line 153
    .line 154
    sget-object v70, Lcd/d;->LINE_9:Lcd/d;

    .line 155
    .line 156
    sget-object v71, Lcd/d;->LINE_10:Lcd/d;

    .line 157
    .line 158
    sget-object v72, Lcd/d;->LINE_11:Lcd/d;

    .line 159
    .line 160
    sget-object v73, Lcd/d;->LINE_12:Lcd/d;

    .line 161
    .line 162
    sget-object v74, Lcd/d;->ANGEL_1:Lcd/d;

    .line 163
    .line 164
    sget-object v75, Lcd/d;->ANGEL_2:Lcd/d;

    .line 165
    .line 166
    sget-object v76, Lcd/d;->ANGEL_3:Lcd/d;

    .line 167
    .line 168
    sget-object v77, Lcd/d;->ANGEL_4:Lcd/d;

    .line 169
    .line 170
    sget-object v78, Lcd/d;->ANGEL_5:Lcd/d;

    .line 171
    .line 172
    sget-object v79, Lcd/d;->ANGEL_6:Lcd/d;

    .line 173
    .line 174
    sget-object v80, Lcd/d;->ANGEL_7:Lcd/d;

    .line 175
    .line 176
    sget-object v81, Lcd/d;->ANGEL_8:Lcd/d;

    .line 177
    .line 178
    sget-object v82, Lcd/d;->ANGEL_9:Lcd/d;

    .line 179
    .line 180
    sget-object v83, Lcd/d;->ANGEL_10:Lcd/d;

    .line 181
    .line 182
    sget-object v84, Lcd/d;->ANGEL_11:Lcd/d;

    .line 183
    .line 184
    sget-object v85, Lcd/d;->ANGEL_12:Lcd/d;

    .line 185
    .line 186
    sget-object v86, Lcd/d;->ANGEL_13:Lcd/d;

    .line 187
    .line 188
    sget-object v87, Lcd/d;->PRIDE_1:Lcd/d;

    .line 189
    .line 190
    sget-object v88, Lcd/d;->PRIDE_2:Lcd/d;

    .line 191
    .line 192
    sget-object v89, Lcd/d;->PRIDE_3:Lcd/d;

    .line 193
    .line 194
    sget-object v90, Lcd/d;->PRIDE_4:Lcd/d;

    .line 195
    .line 196
    sget-object v91, Lcd/d;->PRIDE_5:Lcd/d;

    .line 197
    .line 198
    sget-object v92, Lcd/d;->PRIDE_6:Lcd/d;

    .line 199
    .line 200
    sget-object v93, Lcd/d;->PRIDE_7:Lcd/d;

    .line 201
    .line 202
    sget-object v94, Lcd/d;->PRIDE_8:Lcd/d;

    .line 203
    .line 204
    sget-object v95, Lcd/d;->PRIDE_9:Lcd/d;

    .line 205
    .line 206
    sget-object v96, Lcd/d;->PRIDE_10:Lcd/d;

    .line 207
    .line 208
    sget-object v97, Lcd/d;->PRIDE_11:Lcd/d;

    .line 209
    .line 210
    sget-object v98, Lcd/d;->PRIDE_12:Lcd/d;

    .line 211
    .line 212
    sget-object v99, Lcd/d;->PRIDE_13:Lcd/d;

    .line 213
    .line 214
    sget-object v100, Lcd/d;->PRIDE_14:Lcd/d;

    .line 215
    .line 216
    sget-object v101, Lcd/d;->PRIDE_15:Lcd/d;

    .line 217
    .line 218
    sget-object v102, Lcd/d;->SKETCH_1:Lcd/d;

    .line 219
    .line 220
    sget-object v103, Lcd/d;->SKETCH_2:Lcd/d;

    .line 221
    .line 222
    sget-object v104, Lcd/d;->SKETCH_3:Lcd/d;

    .line 223
    .line 224
    sget-object v105, Lcd/d;->SKETCH_4:Lcd/d;

    .line 225
    .line 226
    sget-object v106, Lcd/d;->SKETCH_5:Lcd/d;

    .line 227
    .line 228
    sget-object v107, Lcd/d;->SKETCH_6:Lcd/d;

    .line 229
    .line 230
    sget-object v108, Lcd/d;->SKETCH_7:Lcd/d;

    .line 231
    .line 232
    sget-object v109, Lcd/d;->SKETCH_8:Lcd/d;

    .line 233
    .line 234
    sget-object v110, Lcd/d;->SKETCH_9:Lcd/d;

    .line 235
    .line 236
    sget-object v111, Lcd/d;->SKETCH_10:Lcd/d;

    .line 237
    .line 238
    sget-object v112, Lcd/d;->FILMLINE_1:Lcd/d;

    .line 239
    .line 240
    sget-object v113, Lcd/d;->FILMLINE_2:Lcd/d;

    .line 241
    .line 242
    sget-object v114, Lcd/d;->FILMLINE_3:Lcd/d;

    .line 243
    .line 244
    sget-object v115, Lcd/d;->FILMLINE_4:Lcd/d;

    .line 245
    .line 246
    sget-object v116, Lcd/d;->FILMLINE_5:Lcd/d;

    .line 247
    .line 248
    sget-object v117, Lcd/d;->FILMLINE_6:Lcd/d;

    .line 249
    .line 250
    sget-object v118, Lcd/d;->FILMLINE_7:Lcd/d;

    .line 251
    .line 252
    sget-object v119, Lcd/d;->FILMLINE_8:Lcd/d;

    .line 253
    .line 254
    sget-object v120, Lcd/d;->FILMLINE_9:Lcd/d;

    .line 255
    .line 256
    sget-object v121, Lcd/d;->FILMLINE_10:Lcd/d;

    .line 257
    .line 258
    sget-object v122, Lcd/d;->FILMLINE_11:Lcd/d;

    .line 259
    .line 260
    sget-object v123, Lcd/d;->FILMLINE_12:Lcd/d;

    .line 261
    .line 262
    sget-object v124, Lcd/d;->FILMLINE_13:Lcd/d;

    .line 263
    .line 264
    sget-object v125, Lcd/d;->FILMLINE_14:Lcd/d;

    .line 265
    .line 266
    sget-object v126, Lcd/d;->FILMLINE_15:Lcd/d;

    .line 267
    .line 268
    sget-object v127, Lcd/d;->REVOLVEFESTIVAL_1:Lcd/d;

    .line 269
    .line 270
    sget-object v128, Lcd/d;->REVOLVEFESTIVAL_2:Lcd/d;

    .line 271
    .line 272
    sget-object v129, Lcd/d;->REVOLVEFESTIVAL_3:Lcd/d;

    .line 273
    .line 274
    sget-object v130, Lcd/d;->REVOLVEFESTIVAL_4:Lcd/d;

    .line 275
    .line 276
    sget-object v131, Lcd/d;->REVOLVEFESTIVAL_5:Lcd/d;

    .line 277
    .line 278
    sget-object v132, Lcd/d;->REVOLVEFESTIVAL_6:Lcd/d;

    .line 279
    .line 280
    sget-object v133, Lcd/d;->REVOLVEFESTIVAL_7:Lcd/d;

    .line 281
    .line 282
    sget-object v134, Lcd/d;->REVOLVEFESTIVAL_8:Lcd/d;

    .line 283
    .line 284
    sget-object v135, Lcd/d;->REVOLVEFESTIVAL_9:Lcd/d;

    .line 285
    .line 286
    sget-object v136, Lcd/d;->REVOLVEFESTIVAL_10:Lcd/d;

    .line 287
    .line 288
    sget-object v137, Lcd/d;->REVOLVEFESTIVAL_11:Lcd/d;

    .line 289
    .line 290
    sget-object v138, Lcd/d;->REVOLVEFESTIVAL_12:Lcd/d;

    .line 291
    .line 292
    sget-object v139, Lcd/d;->FILMCLASSIC_1:Lcd/d;

    .line 293
    .line 294
    sget-object v140, Lcd/d;->FILMCLASSIC_2:Lcd/d;

    .line 295
    .line 296
    sget-object v141, Lcd/d;->FILMCLASSIC_3:Lcd/d;

    .line 297
    .line 298
    sget-object v142, Lcd/d;->FILMCLASSIC_4:Lcd/d;

    .line 299
    .line 300
    sget-object v143, Lcd/d;->FILMCLASSIC_5:Lcd/d;

    .line 301
    .line 302
    sget-object v144, Lcd/d;->FILMCLASSIC_6:Lcd/d;

    .line 303
    .line 304
    sget-object v145, Lcd/d;->FILMCLASSIC_7:Lcd/d;

    .line 305
    .line 306
    sget-object v146, Lcd/d;->FILMCLASSIC_8:Lcd/d;

    .line 307
    .line 308
    sget-object v147, Lcd/d;->FILMCLASSIC_9:Lcd/d;

    .line 309
    .line 310
    sget-object v148, Lcd/d;->FILMCLASSIC_10:Lcd/d;

    .line 311
    .line 312
    sget-object v149, Lcd/d;->FILMCLASSIC_11:Lcd/d;

    .line 313
    .line 314
    sget-object v150, Lcd/d;->FILMCLASSIC_12:Lcd/d;

    .line 315
    .line 316
    sget-object v151, Lcd/d;->FILMCLASSIC_13:Lcd/d;

    .line 317
    .line 318
    sget-object v152, Lcd/d;->FILMCLASSIC_14:Lcd/d;

    .line 319
    .line 320
    sget-object v153, Lcd/d;->FILMCLASSIC_15:Lcd/d;

    .line 321
    .line 322
    sget-object v154, Lcd/d;->FILMCLASSIC_16:Lcd/d;

    .line 323
    .line 324
    sget-object v155, Lcd/d;->TEZZAXAMAS_1:Lcd/d;

    .line 325
    .line 326
    sget-object v156, Lcd/d;->TEZZAXAMAS_2:Lcd/d;

    .line 327
    .line 328
    sget-object v157, Lcd/d;->TEZZAXAMAS_3:Lcd/d;

    .line 329
    .line 330
    sget-object v158, Lcd/d;->TEZZAXAMAS_4:Lcd/d;

    .line 331
    .line 332
    sget-object v159, Lcd/d;->TEZZAXAMAS_5:Lcd/d;

    .line 333
    .line 334
    sget-object v160, Lcd/d;->TEZZAXAMAS_6:Lcd/d;

    .line 335
    .line 336
    sget-object v161, Lcd/d;->TEZZAXAMAS_7:Lcd/d;

    .line 337
    .line 338
    sget-object v162, Lcd/d;->TEZZAXAMAS_8:Lcd/d;

    .line 339
    .line 340
    sget-object v163, Lcd/d;->TEZZAXAMAS_9:Lcd/d;

    .line 341
    .line 342
    sget-object v164, Lcd/d;->TEZZAXAMAS_10:Lcd/d;

    .line 343
    .line 344
    sget-object v165, Lcd/d;->TEZZAXAMAS_11:Lcd/d;

    .line 345
    .line 346
    sget-object v166, Lcd/d;->TEZZAXAMAS_12:Lcd/d;

    .line 347
    .line 348
    sget-object v167, Lcd/d;->TEZZAXAMAS_13:Lcd/d;

    .line 349
    .line 350
    sget-object v168, Lcd/d;->TEZZAXAMAS_14:Lcd/d;

    .line 351
    .line 352
    sget-object v169, Lcd/d;->TEZZAXAMAS_15:Lcd/d;

    .line 353
    .line 354
    sget-object v170, Lcd/d;->TEZZAXAMAS_16:Lcd/d;

    .line 355
    .line 356
    sget-object v171, Lcd/d;->TEZZAXAMAS_17:Lcd/d;

    .line 357
    .line 358
    sget-object v172, Lcd/d;->TEZZAXAMAS_18:Lcd/d;

    .line 359
    .line 360
    sget-object v173, Lcd/d;->MOTHERS_1:Lcd/d;

    .line 361
    .line 362
    sget-object v174, Lcd/d;->MOTHERS_2:Lcd/d;

    .line 363
    .line 364
    sget-object v175, Lcd/d;->MOTHERS_3:Lcd/d;

    .line 365
    .line 366
    sget-object v176, Lcd/d;->MOTHERS_4:Lcd/d;

    .line 367
    .line 368
    sget-object v177, Lcd/d;->MOTHERS_5:Lcd/d;

    .line 369
    .line 370
    sget-object v178, Lcd/d;->MOTHERS_6:Lcd/d;

    .line 371
    .line 372
    sget-object v179, Lcd/d;->MOTHERS_7:Lcd/d;

    .line 373
    .line 374
    sget-object v180, Lcd/d;->MOTHERS_8:Lcd/d;

    .line 375
    .line 376
    sget-object v181, Lcd/d;->MOTHERS_9:Lcd/d;

    .line 377
    .line 378
    sget-object v182, Lcd/d;->MOTHERS_10:Lcd/d;

    .line 379
    .line 380
    sget-object v183, Lcd/d;->MOTHERS_11:Lcd/d;

    .line 381
    .line 382
    sget-object v184, Lcd/d;->MOTHERS_12:Lcd/d;

    .line 383
    .line 384
    sget-object v185, Lcd/d;->MOTHERS_13:Lcd/d;

    .line 385
    .line 386
    sget-object v186, Lcd/d;->MOTHERS_14:Lcd/d;

    .line 387
    .line 388
    sget-object v187, Lcd/d;->MOTHERS_15:Lcd/d;

    .line 389
    .line 390
    sget-object v188, Lcd/d;->SUNBATH_1:Lcd/d;

    .line 391
    .line 392
    sget-object v189, Lcd/d;->SUNBATH_2:Lcd/d;

    .line 393
    .line 394
    sget-object v190, Lcd/d;->SUNBATH_3:Lcd/d;

    .line 395
    .line 396
    sget-object v191, Lcd/d;->SUNBATH_4:Lcd/d;

    .line 397
    .line 398
    sget-object v192, Lcd/d;->SUNBATH_5:Lcd/d;

    .line 399
    .line 400
    sget-object v193, Lcd/d;->SUNBATH_6:Lcd/d;

    .line 401
    .line 402
    sget-object v194, Lcd/d;->SUNBATH_7:Lcd/d;

    .line 403
    .line 404
    sget-object v195, Lcd/d;->SUNBATH_8:Lcd/d;

    .line 405
    .line 406
    sget-object v196, Lcd/d;->SUNBATH_9:Lcd/d;

    .line 407
    .line 408
    sget-object v197, Lcd/d;->SUNBATH_10:Lcd/d;

    .line 409
    .line 410
    filled-new-array/range {v4 .. v197}, [Lcd/d;

    .line 411
    .line 412
    .line 413
    move-result-object v1

    .line 414
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 415
    .line 416
    .line 417
    move-result-object v1

    .line 418
    iput-object v1, v0, LAd/x;->C0:Ljava/util/List;

    .line 419
    .line 420
    invoke-virtual {v0}, LAd/x;->B0()I

    .line 421
    .line 422
    .line 423
    move-result v1

    .line 424
    iput v1, v0, LAd/x;->D0:I

    .line 425
    .line 426
    sget-object v1, Lcd/B;->RATIO_9_16:Lcd/B;

    .line 427
    .line 428
    iput-object v1, v0, LAd/x;->E0:Lcd/B;

    .line 429
    .line 430
    new-instance v1, LAd/j;

    .line 431
    .line 432
    const/4 v2, 0x0

    .line 433
    invoke-direct {v1, v2, v0}, LAd/j;-><init>(ILjava/lang/Object;)V

    .line 434
    .line 435
    .line 436
    iput-object v1, v0, LAd/x;->F0:LAd/j;

    .line 437
    .line 438
    new-instance v1, LAd/o;

    .line 439
    .line 440
    invoke-direct {v1, v0}, LAd/o;-><init>(LAd/x;)V

    .line 441
    .line 442
    .line 443
    iput-object v1, v0, LAd/x;->G0:LAd/o;

    .line 444
    .line 445
    new-instance v1, LAd/p;

    .line 446
    .line 447
    invoke-direct {v1, v0}, LAd/p;-><init>(LAd/x;)V

    .line 448
    .line 449
    .line 450
    iput-object v1, v0, LAd/x;->H0:LAd/p;

    .line 451
    .line 452
    return-void
.end method

.method public static F0(Landroid/view/View;)I
    .locals 2

    .line 1
    invoke-static {p0}, LAd/x;->L0(Landroid/view/View;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return p0

    .line 9
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string v1, "null cannot be cast to non-null type android.view.View"

    .line 18
    .line 19
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p0, Landroid/view/View;

    .line 23
    .line 24
    invoke-static {p0}, LAd/x;->F0(Landroid/view/View;)I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    add-int/2addr p0, v0

    .line 29
    return p0
.end method

.method public static G0(Landroid/view/View;)I
    .locals 2

    .line 1
    invoke-static {p0}, LAd/x;->L0(Landroid/view/View;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return p0

    .line 9
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string v1, "null cannot be cast to non-null type android.view.View"

    .line 18
    .line 19
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p0, Landroid/view/View;

    .line 23
    .line 24
    invoke-static {p0}, LAd/x;->G0(Landroid/view/View;)I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    add-int/2addr p0, v0

    .line 29
    return p0
.end method

.method public static L0(Landroid/view/View;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string v0, "vParent"

    .line 18
    .line 19
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0
.end method

.method public static o0(Landroid/view/View;Landroid/graphics/PorterDuff$Mode;)V
    .locals 4

    .line 1
    invoke-static {p0}, LBd/n;->l(Landroid/view/View;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 7
    .line 8
    .line 9
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    .line 11
    const/16 v2, 0x1c

    .line 12
    .line 13
    if-gt v0, v2, :cond_1

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    instance-of v3, v2, Landroid/view/View;

    .line 24
    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    check-cast v2, Landroid/view/View;

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    move-object v2, v1

    .line 31
    :goto_0
    if-eqz v2, :cond_1

    .line 32
    .line 33
    invoke-virtual {v2, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 34
    .line 35
    .line 36
    :cond_1
    new-instance v0, Landroid/graphics/Paint;

    .line 37
    .line 38
    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    .line 39
    .line 40
    .line 41
    new-instance v1, Landroid/graphics/PorterDuffXfermode;

    .line 42
    .line 43
    invoke-direct {v1, p1}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayerPaint(Landroid/graphics/Paint;)V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public static synthetic q0(LAd/x;Landroidx/constraintlayout/widget/ConstraintLayout;LAd/a;II)V
    .locals 6

    .line 1
    const/high16 v5, 0x3f800000    # 1.0f

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    move-object v1, p1

    .line 5
    move-object v2, p2

    .line 6
    move v3, p3

    .line 7
    move v4, p4

    .line 8
    invoke-virtual/range {v0 .. v5}, LAd/x;->p0(Landroidx/constraintlayout/widget/ConstraintLayout;LAd/a;IIF)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static t0(Lorg/tezza/presentation/widgets/sticker/TemplateImageView;LAd/y;)V
    .locals 12

    .line 1
    const-string v0, "view"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "it"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    move-object v0, p0

    .line 12
    :goto_0
    invoke-static {v0}, LAd/x;->L0(Landroid/view/View;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const-string v2, "null cannot be cast to non-null type android.view.View"

    .line 17
    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    check-cast v0, Landroid/view/View;

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    int-to-double v0, v0

    .line 35
    move-object v3, p0

    .line 36
    :goto_1
    invoke-static {v3}, LAd/x;->L0(Landroid/view/View;)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-nez v4, :cond_1

    .line 41
    .line 42
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    check-cast v3, Landroid/view/View;

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_1
    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    int-to-double v2, v2

    .line 57
    invoke-static {p0}, LAd/x;->F0(Landroid/view/View;)I

    .line 58
    .line 59
    .line 60
    move-result v4

    .line 61
    int-to-double v4, v4

    .line 62
    invoke-static {p0}, LAd/x;->G0(Landroid/view/View;)I

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    int-to-double v6, v6

    .line 67
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 68
    .line 69
    .line 70
    move-result v8

    .line 71
    int-to-double v8, v8

    .line 72
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 73
    .line 74
    .line 75
    move-result p0

    .line 76
    int-to-double v10, p0

    .line 77
    iget-object p0, p1, LAd/y;->a:LAd/a;

    .line 78
    .line 79
    div-double/2addr v8, v0

    .line 80
    iput-wide v8, p0, LAd/a;->c:D

    .line 81
    .line 82
    div-double/2addr v10, v2

    .line 83
    iput-wide v10, p0, LAd/a;->d:D

    .line 84
    .line 85
    div-double/2addr v4, v0

    .line 86
    iput-wide v4, p0, LAd/a;->a:D

    .line 87
    .line 88
    div-double/2addr v6, v2

    .line 89
    iput-wide v6, p0, LAd/a;->b:D

    .line 90
    .line 91
    return-void
.end method

.method public static y0(Landroid/view/View;)Ljava/util/ArrayList;
    .locals 6

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    if-nez p0, :cond_0

    .line 7
    .line 8
    goto :goto_1

    .line 9
    :cond_0
    instance-of v1, p0, Landroid/view/ViewGroup;

    .line 10
    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    new-instance v0, Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    move-object v1, p0

    .line 23
    check-cast v1, Landroid/view/ViewGroup;

    .line 24
    .line 25
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    const/4 v3, 0x0

    .line 30
    :goto_0
    if-ge v3, v2, :cond_2

    .line 31
    .line 32
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    new-instance v5, Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v5, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    invoke-static {v4}, LAd/x;->y0(Landroid/view/View;)Ljava/util/ArrayList;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 55
    .line 56
    .line 57
    add-int/lit8 v3, v3, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    :goto_1
    return-object v0
.end method


# virtual methods
.method public A0()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Landroid/view/View;",
            ">;>;"
        }
    .end annotation

    .line 1
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public B0()I
    .locals 1

    .line 1
    const v0, 0x7f0503d1

    .line 2
    .line 3
    .line 4
    invoke-static {v0, p0}, LBd/w;->d(ILjava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    return v0
.end method

.method public final C0()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LAd/y;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LAd/x;->x0:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    const-string v0, "items"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0
.end method

.method public D0()Landroid/view/ViewGroup;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final E0()Ljava/lang/String;
    .locals 3

    .line 1
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move-object v0, v1

    .line 15
    :goto_0
    instance-of v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 16
    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_1
    move-object v0, v1

    .line 23
    :goto_1
    if-eqz v0, :cond_2

    .line 24
    .line 25
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    goto :goto_2

    .line 30
    :cond_2
    move-object v0, v1

    .line 31
    :goto_2
    instance-of v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 32
    .line 33
    if-eqz v2, :cond_3

    .line 34
    .line 35
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 36
    .line 37
    goto :goto_3

    .line 38
    :cond_3
    move-object v0, v1

    .line 39
    :goto_3
    if-eqz v0, :cond_4

    .line 40
    .line 41
    iget-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->G:Ljava/lang/String;

    .line 42
    .line 43
    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string v2, "tak , ratio = "

    .line 46
    .line 47
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-static {p0, v0}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    return-object v1
.end method

.method public final H(IILandroid/content/Intent;)V
    .locals 5

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/Fragment;->H(IILandroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    if-ne p2, v0, :cond_10

    .line 6
    .line 7
    const/16 p2, 0x3eb

    .line 8
    .line 9
    if-ne p1, p2, :cond_10

    .line 10
    .line 11
    const-string p1, "extra_result_selection"

    .line 12
    .line 13
    invoke-virtual {p3, p1}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string p2, "obtainResult(...)"

    .line 18
    .line 19
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Ljava/lang/Iterable;

    .line 27
    .line 28
    new-instance p2, Ljava/util/ArrayList;

    .line 29
    .line 30
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 31
    .line 32
    .line 33
    move-result p3

    .line 34
    invoke-direct {p2, p3}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    .line 36
    .line 37
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result p3

    .line 45
    if-eqz p3, :cond_0

    .line 46
    .line 47
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p3

    .line 51
    check-cast p3, Landroid/net/Uri;

    .line 52
    .line 53
    invoke-virtual {p3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p3

    .line 57
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    instance-of p1, p0, Lzd/c;

    .line 62
    .line 63
    const/4 p3, 0x0

    .line 64
    const/4 v0, 0x0

    .line 65
    if-eqz p1, :cond_7

    .line 66
    .line 67
    invoke-virtual {p2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 72
    .line 73
    .line 74
    move-result p2

    .line 75
    if-eqz p2, :cond_d

    .line 76
    .line 77
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object p2

    .line 81
    add-int/lit8 v1, p3, 0x1

    .line 82
    .line 83
    if-gez p3, :cond_1

    .line 84
    .line 85
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    .line 86
    .line 87
    .line 88
    :cond_1
    check-cast p2, Ljava/lang/String;

    .line 89
    .line 90
    if-nez p3, :cond_2

    .line 91
    .line 92
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    iget-object v3, p0, LAd/x;->A0:LAd/y;

    .line 97
    .line 98
    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->indexOf(Ljava/util/List;Ljava/lang/Object;)I

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    if-nez v2, :cond_2

    .line 103
    .line 104
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 105
    .line 106
    .line 107
    move-result-object p3

    .line 108
    check-cast p3, Ljava/lang/Iterable;

    .line 109
    .line 110
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 111
    .line 112
    .line 113
    move-result-object p3

    .line 114
    :goto_2
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 115
    .line 116
    .line 117
    move-result v2

    .line 118
    if-eqz v2, :cond_6

    .line 119
    .line 120
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    check-cast v2, LAd/y;

    .line 125
    .line 126
    iput-object p2, v2, LAd/y;->c:Ljava/lang/String;

    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_2
    if-nez p3, :cond_3

    .line 130
    .line 131
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 132
    .line 133
    .line 134
    move-result-object p3

    .line 135
    iget-object v2, p0, LAd/x;->A0:LAd/y;

    .line 136
    .line 137
    invoke-static {p3, v2}, Lkotlin/collections/CollectionsKt;->indexOf(Ljava/util/List;Ljava/lang/Object;)I

    .line 138
    .line 139
    .line 140
    move-result p3

    .line 141
    if-eqz p3, :cond_3

    .line 142
    .line 143
    iget-object p3, p0, LAd/x;->A0:LAd/y;

    .line 144
    .line 145
    if-eqz p3, :cond_6

    .line 146
    .line 147
    iput-object p2, p3, LAd/y;->c:Ljava/lang/String;

    .line 148
    .line 149
    goto :goto_4

    .line 150
    :cond_3
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 151
    .line 152
    .line 153
    move-result-object p3

    .line 154
    check-cast p3, Ljava/lang/Iterable;

    .line 155
    .line 156
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 157
    .line 158
    .line 159
    move-result-object p3

    .line 160
    :cond_4
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    if-eqz v2, :cond_5

    .line 165
    .line 166
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v2

    .line 170
    move-object v3, v2

    .line 171
    check-cast v3, LAd/y;

    .line 172
    .line 173
    iget-object v3, v3, LAd/y;->c:Ljava/lang/String;

    .line 174
    .line 175
    if-nez v3, :cond_4

    .line 176
    .line 177
    goto :goto_3

    .line 178
    :cond_5
    move-object v2, v0

    .line 179
    :goto_3
    check-cast v2, LAd/y;

    .line 180
    .line 181
    if-eqz v2, :cond_6

    .line 182
    .line 183
    iput-object p2, v2, LAd/y;->c:Ljava/lang/String;

    .line 184
    .line 185
    :cond_6
    :goto_4
    move p3, v1

    .line 186
    goto :goto_1

    .line 187
    :cond_7
    invoke-virtual {p2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 192
    .line 193
    .line 194
    move-result p2

    .line 195
    if-eqz p2, :cond_d

    .line 196
    .line 197
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object p2

    .line 201
    add-int/lit8 v1, p3, 0x1

    .line 202
    .line 203
    if-gez p3, :cond_8

    .line 204
    .line 205
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    .line 206
    .line 207
    .line 208
    :cond_8
    check-cast p2, Ljava/lang/String;

    .line 209
    .line 210
    if-nez p3, :cond_9

    .line 211
    .line 212
    iget-object p3, p0, LAd/x;->A0:LAd/y;

    .line 213
    .line 214
    if-eqz p3, :cond_c

    .line 215
    .line 216
    iput-object p2, p3, LAd/y;->c:Ljava/lang/String;

    .line 217
    .line 218
    goto :goto_7

    .line 219
    :cond_9
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 220
    .line 221
    .line 222
    move-result-object p3

    .line 223
    check-cast p3, Ljava/lang/Iterable;

    .line 224
    .line 225
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 226
    .line 227
    .line 228
    move-result-object p3

    .line 229
    :cond_a
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 230
    .line 231
    .line 232
    move-result v2

    .line 233
    if-eqz v2, :cond_b

    .line 234
    .line 235
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v2

    .line 239
    move-object v3, v2

    .line 240
    check-cast v3, LAd/y;

    .line 241
    .line 242
    iget-object v4, v3, LAd/y;->c:Ljava/lang/String;

    .line 243
    .line 244
    if-nez v4, :cond_a

    .line 245
    .line 246
    invoke-virtual {p0, v3}, LAd/x;->K0(LAd/y;)Z

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    if-nez v3, :cond_a

    .line 251
    .line 252
    goto :goto_6

    .line 253
    :cond_b
    move-object v2, v0

    .line 254
    :goto_6
    check-cast v2, LAd/y;

    .line 255
    .line 256
    if-eqz v2, :cond_c

    .line 257
    .line 258
    iput-object p2, v2, LAd/y;->c:Ljava/lang/String;

    .line 259
    .line 260
    :cond_c
    :goto_7
    move p3, v1

    .line 261
    goto :goto_5

    .line 262
    :cond_d
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    check-cast p1, Ljava/lang/Iterable;

    .line 267
    .line 268
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 269
    .line 270
    .line 271
    move-result-object p1

    .line 272
    :goto_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 273
    .line 274
    .line 275
    move-result p2

    .line 276
    if-eqz p2, :cond_e

    .line 277
    .line 278
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p2

    .line 282
    check-cast p2, LAd/y;

    .line 283
    .line 284
    invoke-virtual {p0, p2}, LAd/x;->M0(LAd/y;)V

    .line 285
    .line 286
    .line 287
    goto :goto_8

    .line 288
    :cond_e
    invoke-virtual {p0}, LAd/x;->Q0()V

    .line 289
    .line 290
    .line 291
    iget-object p1, p0, Landroidx/fragment/app/Fragment;->S:Landroidx/fragment/app/Fragment;

    .line 292
    .line 293
    instance-of p2, p1, Lcd/N;

    .line 294
    .line 295
    if-eqz p2, :cond_f

    .line 296
    .line 297
    move-object v0, p1

    .line 298
    check-cast v0, Lcd/N;

    .line 299
    .line 300
    :cond_f
    if-eqz v0, :cond_10

    .line 301
    .line 302
    invoke-virtual {v0}, Lcd/N;->I0()V

    .line 303
    .line 304
    .line 305
    :cond_10
    return-void
.end method

.method public final H0()Landroidx/constraintlayout/widget/ConstraintLayout;
    .locals 1

    .line 1
    iget-object v0, p0, LAd/x;->B0:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    const-string v0, "stickerLayer"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0
.end method

.method public final I0()Lcd/d;
    .locals 1

    .line 1
    iget-object v0, p0, LAd/x;->z0:Lcd/d;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    const-string v0, "type"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0
.end method

.method public final J0()Z
    .locals 2

    .line 1
    iget-object v0, p0, LAd/x;->x0:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ljava/lang/Iterable;

    .line 10
    .line 11
    instance-of v1, v0, Ljava/util/Collection;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    move-object v1, v0

    .line 16
    check-cast v1, Ljava/util/Collection;

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, LAd/y;

    .line 40
    .line 41
    iget-object v1, v1, LAd/y;->c:Ljava/lang/String;

    .line 42
    .line 43
    if-eqz v1, :cond_1

    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_2
    :goto_0
    invoke-virtual {p0}, LAd/x;->z0()Ljava/util/ArrayList;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-nez v0, :cond_3

    .line 55
    .line 56
    :goto_1
    const/4 v0, 0x1

    .line 57
    return v0

    .line 58
    :cond_3
    const/4 v0, 0x0

    .line 59
    return v0
.end method

.method public final K0(LAd/y;)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    invoke-virtual {p0}, LAd/x;->u0()Ljava/util/Map;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Ljava/lang/Iterable;

    .line 22
    .line 23
    instance-of v2, v1, Ljava/util/Collection;

    .line 24
    .line 25
    if-eqz v2, :cond_1

    .line 26
    .line 27
    move-object v2, v1

    .line 28
    check-cast v2, Ljava/util/Collection;

    .line 29
    .line 30
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_1

    .line 35
    .line 36
    return v0

    .line 37
    :cond_1
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    :cond_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    if-eqz v2, :cond_3

    .line 46
    .line 47
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    check-cast v2, Ljava/util/List;

    .line 52
    .line 53
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_2

    .line 62
    .line 63
    const/4 p1, 0x1

    .line 64
    return p1

    .line 65
    :cond_3
    return v0
.end method

.method public final M0(LAd/y;)V
    .locals 3

    .line 1
    iget-object v0, p1, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    iget-object v1, p1, LAd/y;->c:Ljava/lang/String;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    const p1, 0x7f0700be

    .line 10
    .line 11
    .line 12
    invoke-static {p1, p0}, LBd/w;->b(ILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {v0, p1}, LMd/o;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    const-string v0, "pathUri"

    .line 21
    .line 22
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const-string v0, "content"

    .line 26
    .line 27
    invoke-static {v1, v0}, Lkotlin/text/o;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 34
    .line 35
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    goto :goto_0

    .line 52
    :cond_1
    invoke-static {v1}, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-virtual {v1, v0}, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    goto :goto_0

    .line 67
    :cond_2
    const/4 v0, 0x0

    .line 68
    :goto_0
    const/4 v1, 0x0

    .line 69
    if-eqz v0, :cond_3

    .line 70
    .line 71
    const-string v2, "image/"

    .line 72
    .line 73
    invoke-static {v0, v2, v1}, Lkotlin/text/StringsKt;->x(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    :cond_3
    iget-object v0, p1, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 78
    .line 79
    if-eqz v1, :cond_4

    .line 80
    .line 81
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-static {v0}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lcom/bumptech/glide/l;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {v0}, Lcom/bumptech/glide/l;->m()Lcom/bumptech/glide/k;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-virtual {v0, v1, v2}, LD3/a;->n(II)LD3/a;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    check-cast v0, Lcom/bumptech/glide/k;

    .line 115
    .line 116
    iget-object v1, p1, LAd/y;->c:Ljava/lang/String;

    .line 117
    .line 118
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    invoke-virtual {v0, v1}, Lcom/bumptech/glide/k;->R(Landroid/net/Uri;)Lcom/bumptech/glide/k;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    new-instance v1, LAd/x$c;

    .line 130
    .line 131
    invoke-direct {v1, p1}, LAd/x$c;-><init>(LAd/y;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v0, v1, v0}, Lcom/bumptech/glide/k;->Q(LE3/i;LD3/a;)V

    .line 135
    .line 136
    .line 137
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    return-void

    .line 141
    :cond_4
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    invoke-static {v0}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lcom/bumptech/glide/l;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    invoke-virtual {v0}, Lcom/bumptech/glide/l;->m()Lcom/bumptech/glide/k;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    iget-object v1, p1, LAd/y;->c:Ljava/lang/String;

    .line 157
    .line 158
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    invoke-virtual {v0, v1}, Lcom/bumptech/glide/k;->R(Landroid/net/Uri;)Lcom/bumptech/glide/k;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    new-instance v1, LAd/x$d;

    .line 170
    .line 171
    invoke-direct {v1, p1}, LAd/x$d;-><init>(LAd/y;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0, v1, v0}, Lcom/bumptech/glide/k;->Q(LE3/i;LD3/a;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    :cond_5
    return-void
.end method

.method public final N0(I)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/Fragment;->d0:Landroid/view/View;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    iget v1, p0, LAd/x;->w0:I

    .line 12
    .line 13
    if-lez v1, :cond_1

    .line 14
    .line 15
    goto/16 :goto_2

    .line 16
    .line 17
    :cond_1
    const-string v1, "Transl ----------------------------------"

    .line 18
    .line 19
    invoke-static {p0, v1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    if-eqz v0, :cond_3

    .line 23
    .line 24
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 33
    .line 34
    new-instance v2, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string v3, "Transl res height ----------------------- "

    .line 37
    .line 38
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    invoke-static {p0, v1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    new-instance v1, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    const-string v2, "Transl keyboard h ----------------------- "

    .line 54
    .line 55
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    invoke-static {p0, v1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 77
    .line 78
    sub-int/2addr v1, p1

    .line 79
    new-instance p1, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    const-string v2, "Transl visibleTemplateHeight h ---------- "

    .line 82
    .line 83
    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-static {p0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    const-string p1, "view"

    .line 97
    .line 98
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    const/4 v2, 0x2

    .line 102
    new-array v3, v2, [I

    .line 103
    .line 104
    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 105
    .line 106
    .line 107
    const/4 v4, 0x1

    .line 108
    aget v3, v3, v4

    .line 109
    .line 110
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 111
    .line 112
    .line 113
    move-result v5

    .line 114
    add-int/2addr v5, v3

    .line 115
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    new-array p1, v2, [I

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 121
    .line 122
    .line 123
    aget p1, p1, v4

    .line 124
    .line 125
    new-instance v2, Ljava/lang/StringBuilder;

    .line 126
    .line 127
    const-string v3, "Transl rawY from focused       ---------- "

    .line 128
    .line 129
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-static {p0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 143
    .line 144
    .line 145
    move-result p1

    .line 146
    new-instance v0, Ljava/lang/StringBuilder;

    .line 147
    .line 148
    const-string v2, "Transl focusedView.height      ---------- "

    .line 149
    .line 150
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-static {p0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    new-instance p1, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string v0, "Transl rawY                    ---------- "

    .line 166
    .line 167
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    invoke-static {p0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    if-le v5, v1, :cond_2

    .line 181
    .line 182
    sub-int/2addr v5, v1

    .line 183
    neg-int p1, v5

    .line 184
    iput p1, p0, LAd/x;->w0:I

    .line 185
    .line 186
    goto :goto_1

    .line 187
    :cond_2
    const/4 p1, 0x0

    .line 188
    iput p1, p0, LAd/x;->w0:I

    .line 189
    .line 190
    :goto_1
    iget p1, p0, LAd/x;->w0:I

    .line 191
    .line 192
    new-instance v0, Ljava/lang/StringBuilder;

    .line 193
    .line 194
    const-string v1, "Transl viewTranslationY       ---------- "

    .line 195
    .line 196
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    invoke-static {p0, p1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    iget p1, p0, LAd/x;->w0:I

    .line 210
    .line 211
    invoke-virtual {p0, p1}, LAd/x;->R0(I)V

    .line 212
    .line 213
    .line 214
    :cond_3
    :goto_2
    return-void
.end method

.method public abstract O0()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "LAd/y;",
            ">;"
        }
    .end annotation
.end method

.method public final P0(Ljava/util/ArrayList;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LAd/x;->C0:Ljava/util/List;

    .line 4
    .line 5
    invoke-virtual {v0}, LAd/x;->I0()Lcd/d;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    goto/16 :goto_b

    .line 16
    .line 17
    :cond_0
    instance-of v1, v0, Ljd/l;

    .line 18
    .line 19
    if-nez v1, :cond_8

    .line 20
    .line 21
    instance-of v2, v0, Lmd/j;

    .line 22
    .line 23
    if-eqz v2, :cond_1

    .line 24
    .line 25
    goto :goto_2

    .line 26
    :cond_1
    instance-of v2, v0, Lmd/o;

    .line 27
    .line 28
    if-nez v2, :cond_7

    .line 29
    .line 30
    instance-of v2, v0, Lhd/h;

    .line 31
    .line 32
    if-nez v2, :cond_7

    .line 33
    .line 34
    instance-of v2, v0, Lhd/j;

    .line 35
    .line 36
    if-eqz v2, :cond_2

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_2
    invoke-virtual {v0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    if-eqz v2, :cond_3

    .line 44
    .line 45
    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_3
    const/4 v2, 0x0

    .line 49
    :goto_0
    if-eqz v2, :cond_6

    .line 50
    .line 51
    invoke-virtual {v0}, LAd/x;->E0()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    const-string v3, "9:16"

    .line 56
    .line 57
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    if-eqz v3, :cond_4

    .line 62
    .line 63
    sget-object v2, LAd/x$a;->FIXED_HEIGHT:LAd/x$a;

    .line 64
    .line 65
    goto :goto_3

    .line 66
    :cond_4
    const-string v3, "4:5"

    .line 67
    .line 68
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    if-eqz v2, :cond_5

    .line 73
    .line 74
    sget-object v2, LAd/x$a;->FIXED_WIDTH:LAd/x$a;

    .line 75
    .line 76
    goto :goto_3

    .line 77
    :cond_5
    sget-object v2, LAd/x$a;->NONE:LAd/x$a;

    .line 78
    .line 79
    goto :goto_3

    .line 80
    :cond_6
    sget-object v2, LAd/x$a;->NONE:LAd/x$a;

    .line 81
    .line 82
    goto :goto_3

    .line 83
    :cond_7
    :goto_1
    sget-object v2, LAd/x$a;->FIXED_WIDTH:LAd/x$a;

    .line 84
    .line 85
    goto :goto_3

    .line 86
    :cond_8
    :goto_2
    sget-object v2, LAd/x$a;->FIXED_HEIGHT:LAd/x$a;

    .line 87
    .line 88
    :goto_3
    iget-object v3, v0, LAd/x;->E0:Lcd/B;

    .line 89
    .line 90
    sget-object v4, LAd/x$b;->b:[I

    .line 91
    .line 92
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    aget v3, v4, v3

    .line 97
    .line 98
    const/4 v4, 0x1

    .line 99
    if-ne v3, v4, :cond_9

    .line 100
    .line 101
    goto :goto_4

    .line 102
    :cond_9
    sget-object v2, LAd/x$a;->NONE:LAd/x$a;

    .line 103
    .line 104
    :goto_4
    sget-object v3, LAd/x$b;->a:[I

    .line 105
    .line 106
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    aget v2, v3, v2

    .line 111
    .line 112
    const/4 v3, 0x2

    .line 113
    const-wide/high16 v5, 0x4000000000000000L    # 2.0

    .line 114
    .line 115
    const-wide/high16 v7, 0x3ff0000000000000L    # 1.0

    .line 116
    .line 117
    if-eq v2, v4, :cond_a

    .line 118
    .line 119
    const-string v4, "tak"

    .line 120
    .line 121
    const-string v9, ", result = "

    .line 122
    .line 123
    if-eq v2, v3, :cond_c

    .line 124
    .line 125
    const/4 v10, 0x3

    .line 126
    if-ne v2, v10, :cond_b

    .line 127
    .line 128
    invoke-interface/range {p1 .. p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 129
    .line 130
    .line 131
    move-result-object v2

    .line 132
    :goto_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 133
    .line 134
    .line 135
    move-result v10

    .line 136
    if-eqz v10, :cond_a

    .line 137
    .line 138
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v10

    .line 142
    check-cast v10, LAd/y;

    .line 143
    .line 144
    iget-object v10, v10, LAd/y;->a:LAd/a;

    .line 145
    .line 146
    iget-wide v11, v10, LAd/a;->a:D

    .line 147
    .line 148
    sget-object v13, Lcd/B;->Companion:Lcd/B$a;

    .line 149
    .line 150
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    invoke-static {}, Lcd/B$a;->a()D

    .line 154
    .line 155
    .line 156
    move-result-wide v13

    .line 157
    sub-double v15, v7, v13

    .line 158
    .line 159
    div-double/2addr v15, v5

    .line 160
    mul-double/2addr v11, v13

    .line 161
    add-double/2addr v11, v15

    .line 162
    new-instance v15, Ljava/lang/StringBuilder;

    .line 163
    .line 164
    move-wide/from16 v16, v5

    .line 165
    .line 166
    const-string v5, "recalculateWidthForRatio45: f = "

    .line 167
    .line 168
    invoke-direct {v15, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v15, v13, v14}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v15, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v6

    .line 184
    invoke-static {v4, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 185
    .line 186
    .line 187
    iput-wide v11, v10, LAd/a;->a:D

    .line 188
    .line 189
    iget-wide v11, v10, LAd/a;->c:D

    .line 190
    .line 191
    invoke-static {}, Lcd/B$a;->a()D

    .line 192
    .line 193
    .line 194
    move-result-wide v13

    .line 195
    mul-double/2addr v11, v13

    .line 196
    new-instance v6, Ljava/lang/StringBuilder;

    .line 197
    .line 198
    invoke-direct {v6, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v6, v13, v14}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    invoke-virtual {v6, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 208
    .line 209
    .line 210
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v5

    .line 214
    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 215
    .line 216
    .line 217
    iput-wide v11, v10, LAd/a;->c:D

    .line 218
    .line 219
    move-wide/from16 v5, v16

    .line 220
    .line 221
    goto :goto_5

    .line 222
    :cond_a
    move-wide/from16 v16, v5

    .line 223
    .line 224
    goto :goto_7

    .line 225
    :cond_b
    new-instance v1, Lkotlin/NoWhenBranchMatchedException;

    .line 226
    .line 227
    invoke-direct {v1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    .line 228
    .line 229
    .line 230
    throw v1

    .line 231
    :cond_c
    move-wide/from16 v16, v5

    .line 232
    .line 233
    invoke-interface/range {p1 .. p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 238
    .line 239
    .line 240
    move-result v5

    .line 241
    if-eqz v5, :cond_d

    .line 242
    .line 243
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v5

    .line 247
    check-cast v5, LAd/y;

    .line 248
    .line 249
    iget-object v5, v5, LAd/y;->a:LAd/a;

    .line 250
    .line 251
    iget-wide v10, v5, LAd/a;->b:D

    .line 252
    .line 253
    sget-object v6, Lcd/B;->Companion:Lcd/B$a;

    .line 254
    .line 255
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 256
    .line 257
    .line 258
    invoke-static {}, Lcd/B$a;->a()D

    .line 259
    .line 260
    .line 261
    move-result-wide v12

    .line 262
    div-double v12, v7, v12

    .line 263
    .line 264
    sub-double v14, v7, v12

    .line 265
    .line 266
    div-double v14, v14, v16

    .line 267
    .line 268
    mul-double/2addr v10, v12

    .line 269
    add-double/2addr v10, v14

    .line 270
    new-instance v6, Ljava/lang/StringBuilder;

    .line 271
    .line 272
    const-string v14, "recalculateHeightForRatio45: f = "

    .line 273
    .line 274
    invoke-direct {v6, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {v6, v12, v13}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 278
    .line 279
    .line 280
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 281
    .line 282
    .line 283
    invoke-virtual {v6, v10, v11}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 284
    .line 285
    .line 286
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object v6

    .line 290
    invoke-static {v4, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 291
    .line 292
    .line 293
    iput-wide v10, v5, LAd/a;->b:D

    .line 294
    .line 295
    iget-wide v10, v5, LAd/a;->d:D

    .line 296
    .line 297
    invoke-static {}, Lcd/B$a;->a()D

    .line 298
    .line 299
    .line 300
    move-result-wide v12

    .line 301
    div-double v12, v7, v12

    .line 302
    .line 303
    mul-double/2addr v10, v12

    .line 304
    new-instance v6, Ljava/lang/StringBuilder;

    .line 305
    .line 306
    invoke-direct {v6, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v6, v12, v13}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 310
    .line 311
    .line 312
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 313
    .line 314
    .line 315
    invoke-virtual {v6, v10, v11}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 316
    .line 317
    .line 318
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v6

    .line 322
    invoke-static {v4, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 323
    .line 324
    .line 325
    iput-wide v10, v5, LAd/a;->d:D

    .line 326
    .line 327
    goto :goto_6

    .line 328
    :cond_d
    :goto_7
    const-wide/16 v4, 0x0

    .line 329
    .line 330
    if-eqz v1, :cond_10

    .line 331
    .line 332
    iget-object v1, v0, LAd/x;->E0:Lcd/B;

    .line 333
    .line 334
    sget-object v2, Lcd/B;->RATIO_4_5:Lcd/B;

    .line 335
    .line 336
    if-ne v1, v2, :cond_13

    .line 337
    .line 338
    sget-object v1, Lcd/B;->Companion:Lcd/B$a;

    .line 339
    .line 340
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    .line 342
    .line 343
    invoke-static {}, Lcd/B$a;->a()D

    .line 344
    .line 345
    .line 346
    move-result-wide v1

    .line 347
    sub-double v1, v7, v1

    .line 348
    .line 349
    div-double v1, v1, v16

    .line 350
    .line 351
    invoke-interface/range {p1 .. p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 352
    .line 353
    .line 354
    move-result-object v3

    .line 355
    const/4 v6, 0x0

    .line 356
    :goto_8
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 357
    .line 358
    .line 359
    move-result v9

    .line 360
    if-eqz v9, :cond_13

    .line 361
    .line 362
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object v9

    .line 366
    add-int/lit8 v10, v6, 0x1

    .line 367
    .line 368
    if-gez v6, :cond_e

    .line 369
    .line 370
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    .line 371
    .line 372
    .line 373
    :cond_e
    check-cast v9, LAd/y;

    .line 374
    .line 375
    if-nez v6, :cond_f

    .line 376
    .line 377
    iget-object v6, v9, LAd/y;->a:LAd/a;

    .line 378
    .line 379
    iput-wide v4, v6, LAd/a;->a:D

    .line 380
    .line 381
    iput-wide v4, v6, LAd/a;->b:D

    .line 382
    .line 383
    iput-wide v7, v6, LAd/a;->c:D

    .line 384
    .line 385
    iput-wide v7, v6, LAd/a;->d:D

    .line 386
    .line 387
    goto :goto_9

    .line 388
    :cond_f
    iget-object v6, v9, LAd/y;->a:LAd/a;

    .line 389
    .line 390
    iget-wide v11, v6, LAd/a;->a:D

    .line 391
    .line 392
    add-double/2addr v11, v1

    .line 393
    iput-wide v11, v6, LAd/a;->a:D

    .line 394
    .line 395
    :goto_9
    move v6, v10

    .line 396
    goto :goto_8

    .line 397
    :cond_10
    instance-of v1, v0, Lmd/j;

    .line 398
    .line 399
    if-nez v1, :cond_12

    .line 400
    .line 401
    instance-of v1, v0, Lmd/o;

    .line 402
    .line 403
    if-nez v1, :cond_12

    .line 404
    .line 405
    instance-of v1, v0, Lhd/h;

    .line 406
    .line 407
    if-nez v1, :cond_12

    .line 408
    .line 409
    instance-of v1, v0, Lhd/j;

    .line 410
    .line 411
    if-nez v1, :cond_12

    .line 412
    .line 413
    instance-of v1, v0, Lhd/e;

    .line 414
    .line 415
    if-eqz v1, :cond_11

    .line 416
    .line 417
    goto :goto_a

    .line 418
    :cond_11
    instance-of v1, v0, Lmd/e;

    .line 419
    .line 420
    if-eqz v1, :cond_13

    .line 421
    .line 422
    invoke-static/range {p1 .. p1}, Lkotlin/collections/CollectionsKt;->lastOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v1

    .line 426
    check-cast v1, LAd/y;

    .line 427
    .line 428
    if-eqz v1, :cond_13

    .line 429
    .line 430
    iget-object v2, v0, LAd/x;->E0:Lcd/B;

    .line 431
    .line 432
    sget-object v6, Lcd/B;->RATIO_4_5:Lcd/B;

    .line 433
    .line 434
    if-ne v2, v6, :cond_13

    .line 435
    .line 436
    iget-object v2, v1, LAd/y;->a:LAd/a;

    .line 437
    .line 438
    sget-object v6, Lcd/B;->Companion:Lcd/B$a;

    .line 439
    .line 440
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 441
    .line 442
    .line 443
    invoke-static {}, Lcd/B$a;->a()D

    .line 444
    .line 445
    .line 446
    move-result-wide v9

    .line 447
    sub-double v9, v7, v9

    .line 448
    .line 449
    int-to-double v11, v3

    .line 450
    div-double/2addr v9, v11

    .line 451
    sub-double v9, v7, v9

    .line 452
    .line 453
    iput-wide v9, v2, LAd/a;->a:D

    .line 454
    .line 455
    iget-object v2, v1, LAd/y;->a:LAd/a;

    .line 456
    .line 457
    iput-wide v4, v2, LAd/a;->b:D

    .line 458
    .line 459
    invoke-static {}, Lcd/B$a;->a()D

    .line 460
    .line 461
    .line 462
    move-result-wide v3

    .line 463
    sub-double v3, v7, v3

    .line 464
    .line 465
    div-double/2addr v3, v11

    .line 466
    iput-wide v3, v2, LAd/a;->c:D

    .line 467
    .line 468
    iget-object v1, v1, LAd/y;->a:LAd/a;

    .line 469
    .line 470
    iput-wide v7, v1, LAd/a;->d:D

    .line 471
    .line 472
    return-void

    .line 473
    :cond_12
    :goto_a
    invoke-static/range {p1 .. p1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    check-cast v1, LAd/y;

    .line 478
    .line 479
    if-eqz v1, :cond_13

    .line 480
    .line 481
    iget-object v1, v1, LAd/y;->a:LAd/a;

    .line 482
    .line 483
    iput-wide v4, v1, LAd/a;->a:D

    .line 484
    .line 485
    iput-wide v4, v1, LAd/a;->b:D

    .line 486
    .line 487
    iput-wide v7, v1, LAd/a;->c:D

    .line 488
    .line 489
    iput-wide v7, v1, LAd/a;->d:D

    .line 490
    .line 491
    :cond_13
    :goto_b
    return-void
.end method

.method public final Q0()V
    .locals 6

    .line 1
    invoke-virtual {p0}, LAd/x;->u0()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_5

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Ljava/util/Map$Entry;

    .line 24
    .line 25
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    check-cast v2, Ljava/lang/Number;

    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Ljava/util/List;

    .line 40
    .line 41
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    invoke-static {v3, v2}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    check-cast v2, LAd/y;

    .line 50
    .line 51
    if-eqz v2, :cond_1

    .line 52
    .line 53
    iget-object v2, v2, LAd/y;->c:Ljava/lang/String;

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    const/4 v2, 0x0

    .line 57
    :goto_0
    check-cast v1, Ljava/lang/Iterable;

    .line 58
    .line 59
    new-instance v3, Ljava/util/ArrayList;

    .line 60
    .line 61
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 62
    .line 63
    .line 64
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    :cond_2
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 69
    .line 70
    .line 71
    move-result v4

    .line 72
    if-eqz v4, :cond_3

    .line 73
    .line 74
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    check-cast v4, Ljava/lang/Number;

    .line 79
    .line 80
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 81
    .line 82
    .line 83
    move-result v4

    .line 84
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    invoke-static {v5, v4}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    check-cast v4, LAd/y;

    .line 93
    .line 94
    if-eqz v4, :cond_2

    .line 95
    .line 96
    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_3
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    :cond_4
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 105
    .line 106
    .line 107
    move-result v3

    .line 108
    if-eqz v3, :cond_0

    .line 109
    .line 110
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    check-cast v3, LAd/y;

    .line 115
    .line 116
    iget-object v4, v3, LAd/y;->c:Ljava/lang/String;

    .line 117
    .line 118
    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v4

    .line 122
    if-nez v4, :cond_4

    .line 123
    .line 124
    iput-object v2, v3, LAd/y;->c:Ljava/lang/String;

    .line 125
    .line 126
    invoke-virtual {p0, v3}, LAd/x;->M0(LAd/y;)V

    .line 127
    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_5
    return-void
.end method

.method public final R0(I)V
    .locals 4

    .line 1
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const-string v1, "null cannot be cast to non-null type android.view.View"

    .line 25
    .line 26
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    check-cast v0, Landroid/view/View;

    .line 30
    .line 31
    int-to-float p1, p1

    .line 32
    const/4 v1, 0x2

    .line 33
    new-array v1, v1, [F

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    const/4 v3, 0x0

    .line 37
    aput v2, v1, v3

    .line 38
    .line 39
    const/4 v2, 0x1

    .line 40
    aput p1, v1, v2

    .line 41
    .line 42
    const-string p1, "translationY"

    .line 43
    .line 44
    invoke-static {v0, p1, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    const-string v0, "ofFloat(...)"

    .line 49
    .line 50
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->start()V

    .line 54
    .line 55
    .line 56
    return-void
.end method

.method public W(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 5

    .line 1
    const-string p2, "view"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    const-string p2, "<set-?>"

    .line 12
    .line 13
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, LAd/x;->y0:Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {p0}, LAd/x;->O0()Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, LAd/x;->x0:Ljava/util/List;

    .line 26
    .line 27
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    check-cast p1, Ljava/lang/Iterable;

    .line 32
    .line 33
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, LAd/y;

    .line 48
    .line 49
    iget-object v1, v0, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 50
    .line 51
    if-eqz v1, :cond_1

    .line 52
    .line 53
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 54
    .line 55
    .line 56
    move-result-wide v2

    .line 57
    new-instance v4, Ljava/lang/StringBuilder;

    .line 58
    .line 59
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_1
    iget-object v1, v0, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 73
    .line 74
    if-eqz v1, :cond_2

    .line 75
    .line 76
    iget-object v2, p0, LAd/x;->F0:LAd/j;

    .line 77
    .line 78
    invoke-virtual {v1, v2}, LMd/o;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 79
    .line 80
    .line 81
    :cond_2
    if-eqz v1, :cond_3

    .line 82
    .line 83
    iget-object v2, p0, LAd/x;->G0:LAd/o;

    .line 84
    .line 85
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 86
    .line 87
    .line 88
    :cond_3
    if-eqz v1, :cond_0

    .line 89
    .line 90
    new-instance v2, LAd/x$e;

    .line 91
    .line 92
    invoke-direct {v2, v0}, LAd/x$e;-><init>(LAd/y;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1, v2}, LMd/o;->setOnUpdateListener(LMd/o$j;)V

    .line 96
    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_4
    invoke-virtual {p0}, LAd/x;->u0()Ljava/util/Map;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    check-cast p1, Ljava/lang/Iterable;

    .line 108
    .line 109
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->flatten(Ljava/lang/Iterable;)Ljava/util/List;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    check-cast p1, Ljava/lang/Iterable;

    .line 114
    .line 115
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    :cond_5
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    if-eqz v0, :cond_6

    .line 124
    .line 125
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    check-cast v0, Ljava/lang/Number;

    .line 130
    .line 131
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-static {v1, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, LAd/y;

    .line 144
    .line 145
    if-eqz v0, :cond_5

    .line 146
    .line 147
    iget-object v0, v0, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 148
    .line 149
    if-eqz v0, :cond_5

    .line 150
    .line 151
    const/4 v1, 0x0

    .line 152
    invoke-virtual {v0, v1}, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->setShowsAddPlaceholder(Z)V

    .line 153
    .line 154
    .line 155
    goto :goto_1

    .line 156
    :cond_6
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    const/4 v0, 0x0

    .line 161
    if-eqz p1, :cond_7

    .line 162
    .line 163
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    goto :goto_2

    .line 168
    :cond_7
    move-object p1, v0

    .line 169
    :goto_2
    instance-of v1, p1, Landroid/view/View;

    .line 170
    .line 171
    if-eqz v1, :cond_8

    .line 172
    .line 173
    check-cast p1, Landroid/view/View;

    .line 174
    .line 175
    goto :goto_3

    .line 176
    :cond_8
    move-object p1, v0

    .line 177
    :goto_3
    if-eqz p1, :cond_9

    .line 178
    .line 179
    iget-object v1, p0, LAd/x;->H0:LAd/p;

    .line 180
    .line 181
    invoke-virtual {p1, v1}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 182
    .line 183
    .line 184
    :cond_9
    iget p1, p0, LAd/x;->D0:I

    .line 185
    .line 186
    iget-object v1, p0, LAd/x;->E0:Lcd/B;

    .line 187
    .line 188
    invoke-virtual {p0, p1, v1}, LAd/x;->s0(ILcd/B;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p0}, LAd/x;->n0()V

    .line 192
    .line 193
    .line 194
    new-instance p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 195
    .line 196
    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->c0()Landroid/content/Context;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-direct {p1, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;-><init>(Landroid/content/Context;)V

    .line 201
    .line 202
    .line 203
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    iput-object p1, p0, LAd/x;->B0:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 207
    .line 208
    invoke-virtual {p0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    new-instance p2, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 213
    .line 214
    const/4 v1, -0x1

    .line 215
    invoke-direct {p2, v1, v1}, Landroidx/constraintlayout/widget/ConstraintLayout$b;-><init>(II)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {p1, p2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    if-eqz p1, :cond_a

    .line 226
    .line 227
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 228
    .line 229
    .line 230
    move-result-object p1

    .line 231
    goto :goto_4

    .line 232
    :cond_a
    move-object p1, v0

    .line 233
    :goto_4
    instance-of p2, p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 234
    .line 235
    if-eqz p2, :cond_b

    .line 236
    .line 237
    move-object v0, p1

    .line 238
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 239
    .line 240
    :cond_b
    if-eqz v0, :cond_c

    .line 241
    .line 242
    invoke-virtual {p0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 247
    .line 248
    .line 249
    :cond_c
    return-void
.end method

.method public final l0(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LAd/y;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LAd/x;->y0:Ljava/util/ArrayList;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const-string v0, "blends"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    :goto_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Lkotlin/Pair;

    .line 27
    .line 28
    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Ljava/lang/Number;

    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-interface {p1, v2, v1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_1
    return-void
.end method

.method public final m0(Ljava/util/ArrayList;Ljava/util/List;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    check-cast v1, Ljava/lang/Iterable;

    .line 6
    .line 7
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-eqz v2, :cond_7

    .line 16
    .line 17
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Lkotlin/Pair;

    .line 22
    .line 23
    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    check-cast v3, Landroid/view/View;

    .line 28
    .line 29
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    check-cast v4, Landroid/view/View;

    .line 42
    .line 43
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    const-string v4, "vStickers"

    .line 52
    .line 53
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-nez v4, :cond_3

    .line 58
    .line 59
    const-string v4, "vFixedParentStickers"

    .line 60
    .line 61
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    if-eqz v3, :cond_0

    .line 66
    .line 67
    goto/16 :goto_1

    .line 68
    .line 69
    :cond_0
    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    check-cast v3, Landroid/view/View;

    .line 74
    .line 75
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 84
    .line 85
    .line 86
    move-result v5

    .line 87
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 96
    .line 97
    .line 98
    move-result v6

    .line 99
    sget-object v7, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 100
    .line 101
    invoke-static {v5, v6, v7}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    const-string v6, "createBitmap(...)"

    .line 106
    .line 107
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    new-instance v7, Landroid/graphics/Canvas;

    .line 111
    .line 112
    invoke-direct {v7, v5}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v3, v7}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 116
    .line 117
    .line 118
    const-string v7, "vgSizeFixedRoot"

    .line 119
    .line 120
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    if-eqz v4, :cond_2

    .line 125
    .line 126
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 127
    .line 128
    .line 129
    move-result-object v3

    .line 130
    const-string v4, "null cannot be cast to non-null type android.view.View"

    .line 131
    .line 132
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    check-cast v3, Landroid/view/View;

    .line 136
    .line 137
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 138
    .line 139
    .line 140
    move-result v4

    .line 141
    int-to-float v4, v4

    .line 142
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 143
    .line 144
    .line 145
    move-result v3

    .line 146
    int-to-float v3, v3

    .line 147
    div-float/2addr v4, v3

    .line 148
    const v3, 0x3f4a3d71    # 0.79f

    .line 149
    .line 150
    .line 151
    cmpl-float v3, v4, v3

    .line 152
    .line 153
    if-lez v3, :cond_2

    .line 154
    .line 155
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    int-to-float v3, v3

    .line 160
    const/high16 v4, 0x3e980000    # 0.296875f

    .line 161
    .line 162
    mul-float/2addr v3, v4

    .line 163
    invoke-static {v3}, LU9/c;->b(F)I

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    .line 168
    .line 169
    .line 170
    move-result v4

    .line 171
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    .line 172
    .line 173
    .line 174
    move-result v7

    .line 175
    int-to-float v7, v7

    .line 176
    const/high16 v8, 0x3f340000    # 0.703125f

    .line 177
    .line 178
    mul-float/2addr v7, v8

    .line 179
    invoke-static {v7}, LU9/c;->b(F)I

    .line 180
    .line 181
    .line 182
    move-result v7

    .line 183
    const/4 v8, 0x0

    .line 184
    invoke-static {v5, v8, v3, v4, v7}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    .line 185
    .line 186
    .line 187
    move-result-object v3

    .line 188
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v4

    .line 195
    if-nez v4, :cond_1

    .line 196
    .line 197
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->recycle()V

    .line 198
    .line 199
    .line 200
    :cond_1
    move-object v5, v3

    .line 201
    :cond_2
    new-instance v6, LAd/y;

    .line 202
    .line 203
    new-instance v7, LAd/a;

    .line 204
    .line 205
    const-wide/high16 v12, 0x3ff0000000000000L    # 1.0

    .line 206
    .line 207
    const-wide/high16 v14, 0x3ff0000000000000L    # 1.0

    .line 208
    .line 209
    const-wide/16 v8, 0x0

    .line 210
    .line 211
    const-wide/16 v10, 0x0

    .line 212
    .line 213
    invoke-direct/range {v7 .. v15}, LAd/a;-><init>(DDDD)V

    .line 214
    .line 215
    .line 216
    new-instance v11, Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;

    .line 217
    .line 218
    new-instance v3, LFc/a;

    .line 219
    .line 220
    const/4 v4, 0x1

    .line 221
    invoke-direct {v3, v4, v5}, LFc/a;-><init>(ILjava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    invoke-direct {v11, v3}, Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 225
    .line 226
    .line 227
    const/4 v10, 0x0

    .line 228
    const/16 v14, 0x1be

    .line 229
    .line 230
    const/4 v12, 0x0

    .line 231
    const/4 v13, 0x0

    .line 232
    invoke-direct/range {v6 .. v14}, LAd/y;-><init>(LAd/a;DLorg/tezza/presentation/widgets/sticker/TemplateImageView;Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;LAd/g;LAd/b;I)V

    .line 233
    .line 234
    .line 235
    goto :goto_2

    .line 236
    :cond_3
    :goto_1
    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v3

    .line 240
    check-cast v3, Landroid/view/View;

    .line 241
    .line 242
    invoke-virtual {v0, v3}, LAd/x;->w0(Landroid/view/View;)LAd/y;

    .line 243
    .line 244
    .line 245
    move-result-object v6

    .line 246
    :goto_2
    invoke-virtual {v0}, LAd/x;->E0()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v3

    .line 250
    const-string v4, "4:5"

    .line 251
    .line 252
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result v3

    .line 256
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    .line 257
    .line 258
    if-nez v3, :cond_4

    .line 259
    .line 260
    instance-of v3, v0, Lmd/o;

    .line 261
    .line 262
    if-nez v3, :cond_4

    .line 263
    .line 264
    instance-of v3, v0, Lhd/j;

    .line 265
    .line 266
    if-eqz v3, :cond_5

    .line 267
    .line 268
    :cond_4
    iget-object v3, v6, LAd/y;->a:LAd/a;

    .line 269
    .line 270
    sget-object v7, Lcd/B;->Companion:Lcd/B$a;

    .line 271
    .line 272
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 273
    .line 274
    .line 275
    invoke-static {}, Lcd/B$a;->a()D

    .line 276
    .line 277
    .line 278
    move-result-wide v7

    .line 279
    iput-wide v7, v3, LAd/a;->d:D

    .line 280
    .line 281
    iget-object v3, v6, LAd/y;->a:LAd/a;

    .line 282
    .line 283
    invoke-static {}, Lcd/B$a;->a()D

    .line 284
    .line 285
    .line 286
    move-result-wide v7

    .line 287
    sub-double v7, v4, v7

    .line 288
    .line 289
    const/4 v9, 0x2

    .line 290
    int-to-double v9, v9

    .line 291
    div-double/2addr v7, v9

    .line 292
    iput-wide v7, v3, LAd/a;->b:D

    .line 293
    .line 294
    :cond_5
    iget-object v3, v0, LAd/x;->E0:Lcd/B;

    .line 295
    .line 296
    sget-object v7, Lcd/B;->RATIO_4_5:Lcd/B;

    .line 297
    .line 298
    if-ne v3, v7, :cond_6

    .line 299
    .line 300
    invoke-virtual {v0}, LAd/x;->E0()Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    const-string v7, "9:16"

    .line 305
    .line 306
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v3

    .line 310
    if-eqz v3, :cond_6

    .line 311
    .line 312
    iget-object v3, v0, LAd/x;->C0:Ljava/util/List;

    .line 313
    .line 314
    invoke-virtual {v0}, LAd/x;->I0()Lcd/d;

    .line 315
    .line 316
    .line 317
    move-result-object v7

    .line 318
    invoke-interface {v3, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v3

    .line 322
    if-eqz v3, :cond_6

    .line 323
    .line 324
    sget-object v3, Lcd/B;->Companion:Lcd/B$a;

    .line 325
    .line 326
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 327
    .line 328
    .line 329
    invoke-static {}, Lcd/B$a;->a()D

    .line 330
    .line 331
    .line 332
    move-result-wide v7

    .line 333
    sub-double v7, v4, v7

    .line 334
    .line 335
    const-wide/high16 v9, 0x4000000000000000L    # 2.0

    .line 336
    .line 337
    div-double/2addr v7, v9

    .line 338
    iget-object v3, v6, LAd/y;->a:LAd/a;

    .line 339
    .line 340
    iput-wide v7, v3, LAd/a;->a:D

    .line 341
    .line 342
    const-wide/16 v7, 0x0

    .line 343
    .line 344
    iput-wide v7, v3, LAd/a;->b:D

    .line 345
    .line 346
    iput-wide v4, v3, LAd/a;->d:D

    .line 347
    .line 348
    invoke-static {}, Lcd/B$a;->a()D

    .line 349
    .line 350
    .line 351
    move-result-wide v4

    .line 352
    iput-wide v4, v3, LAd/a;->c:D

    .line 353
    .line 354
    :cond_6
    invoke-virtual {v2}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v2

    .line 358
    check-cast v2, Ljava/lang/Number;

    .line 359
    .line 360
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 361
    .line 362
    .line 363
    move-result v2

    .line 364
    move-object/from16 v3, p1

    .line 365
    .line 366
    invoke-virtual {v3, v2, v6}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 367
    .line 368
    .line 369
    goto/16 :goto_0

    .line 370
    .line 371
    :cond_7
    return-void
.end method

.method public n0()V
    .locals 0

    .line 1
    return-void
.end method

.method public final p0(Landroidx/constraintlayout/widget/ConstraintLayout;LAd/a;IIF)V
    .locals 12

    .line 1
    const-string v0, "view"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "area"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->LIGHTEN:Landroid/graphics/PorterDuff$Mode;

    .line 12
    .line 13
    iget-object v1, p0, LAd/x;->y0:Ljava/util/ArrayList;

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string v1, "blends"

    .line 19
    .line 20
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    :goto_0
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    new-instance v3, LAd/y;

    .line 29
    .line 30
    new-instance v10, LAd/b;

    .line 31
    .line 32
    move/from16 v4, p5

    .line 33
    .line 34
    invoke-direct {v10, p3, v0, v4}, LAd/b;-><init>(ILandroid/graphics/PorterDuff$Mode;F)V

    .line 35
    .line 36
    .line 37
    const/4 v8, 0x0

    .line 38
    const/4 v9, 0x0

    .line 39
    const-wide/16 v5, 0x0

    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    const/16 v11, 0xfe

    .line 43
    .line 44
    move-object v4, p2

    .line 45
    invoke-direct/range {v3 .. v11}, LAd/y;-><init>(LAd/a;DLorg/tezza/presentation/widgets/sticker/TemplateImageView;Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;LAd/g;LAd/b;I)V

    .line 46
    .line 47
    .line 48
    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    invoke-interface {v1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    invoke-static {p1, v0}, LAd/x;->o0(Landroid/view/View;Landroid/graphics/PorterDuff$Mode;)V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public final r0(Landroid/view/View;LAd/a;IIF)V
    .locals 12

    .line 1
    const-string v0, "view"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "area"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SCREEN:Landroid/graphics/PorterDuff$Mode;

    .line 12
    .line 13
    iget-object v1, p0, LAd/x;->y0:Ljava/util/ArrayList;

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string v1, "blends"

    .line 19
    .line 20
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    :goto_0
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    new-instance v3, LAd/y;

    .line 29
    .line 30
    new-instance v10, LAd/b;

    .line 31
    .line 32
    move/from16 v4, p5

    .line 33
    .line 34
    invoke-direct {v10, p3, v0, v4}, LAd/b;-><init>(ILandroid/graphics/PorterDuff$Mode;F)V

    .line 35
    .line 36
    .line 37
    const/4 v8, 0x0

    .line 38
    const/4 v9, 0x0

    .line 39
    const-wide/16 v5, 0x0

    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    const/16 v11, 0xfe

    .line 43
    .line 44
    move-object v4, p2

    .line 45
    invoke-direct/range {v3 .. v11}, LAd/y;-><init>(LAd/a;DLorg/tezza/presentation/widgets/sticker/TemplateImageView;Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;LAd/g;LAd/b;I)V

    .line 46
    .line 47
    .line 48
    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    invoke-interface {v1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    invoke-static {p1, v0}, LAd/x;->o0(Landroid/view/View;Landroid/graphics/PorterDuff$Mode;)V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public s0(ILcd/B;)V
    .locals 1

    .line 1
    const-string v0, "ratio"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    if-eqz p2, :cond_0

    .line 11
    .line 12
    invoke-virtual {p2, p1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method public u0()Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;>;"
        }
    .end annotation

    .line 1
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final v0()Landroid/graphics/Bitmap;
    .locals 4

    .line 1
    .line 2
    .line 3
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 4
    move-result-object v0

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 11
    move-result-object v0

    .line 12
    .line 13
    const-string v1, "null cannot be cast to non-null type android.view.ViewGroup"

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    check-cast v0, Landroid/view/ViewGroup;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 22
    move-result v1

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 26
    move-result v2

    .line 27
    .line 28
    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 29
    .line 30
    .line 31
    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 32
    move-result-object v1

    .line 33
    .line 34
    const/4 v2, 0x0

    sget-object v2, Landroidx/appcompat/view/menu/OLmF/yuvNGsNizz;->oWFJFCewCBDYi:Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    new-instance v2, Landroid/graphics/Canvas;

    .line 40
    .line 41
    .line 42
    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 46
    return-object v1
.end method

.method public final w0(Landroid/view/View;)LAd/y;
    .locals 12

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 10
    .line 11
    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "createBitmap(...)"

    .line 16
    .line 17
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    new-instance v2, Landroid/graphics/Canvas;

    .line 21
    .line 22
    invoke-direct {v2, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 26
    .line 27
    .line 28
    iget p1, p0, LAd/x;->L0:I

    .line 29
    .line 30
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    invoke-static {p1, v2}, Ljava/lang/Math;->min(II)I

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    iget v2, p0, LAd/x;->M0:I

    .line 39
    .line 40
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    const/4 v3, 0x0

    .line 49
    invoke-static {v0, v3, v3, p1, v2}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-nez v1, :cond_0

    .line 61
    .line 62
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 63
    .line 64
    .line 65
    :cond_0
    new-instance v2, LAd/y;

    .line 66
    .line 67
    new-instance v3, LAd/a;

    .line 68
    .line 69
    const-wide/16 v4, 0x0

    .line 70
    .line 71
    const-wide/16 v6, 0x0

    .line 72
    .line 73
    const-wide/high16 v8, 0x3ff0000000000000L    # 1.0

    .line 74
    .line 75
    const-wide/high16 v10, 0x3ff0000000000000L    # 1.0

    .line 76
    .line 77
    invoke-direct/range {v3 .. v11}, LAd/a;-><init>(DDDD)V

    .line 78
    .line 79
    .line 80
    new-instance v7, Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;

    .line 81
    .line 82
    new-instance v0, LFc/a;

    .line 83
    .line 84
    const/4 v1, 0x1

    .line 85
    invoke-direct {v0, v1, p1}, LFc/a;-><init>(ILjava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    invoke-direct {v7, v0}, Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 89
    .line 90
    .line 91
    const/4 v8, 0x0

    .line 92
    const/4 v9, 0x0

    .line 93
    const/4 v6, 0x0

    .line 94
    const/16 v10, 0x1be

    .line 95
    .line 96
    invoke-direct/range {v2 .. v10}, LAd/y;-><init>(LAd/a;DLorg/tezza/presentation/widgets/sticker/TemplateImageView;Lorg/tezza/gpu_video/gpu/photo/BitmapLazy;LAd/g;LAd/b;I)V

    .line 97
    .line 98
    .line 99
    return-object v2
.end method

.method public x0()V
    .locals 4

    .line 1
    iget-object v0, p0, LAd/x;->C0:Ljava/util/List;

    .line 2
    .line 3
    invoke-virtual {p0}, LAd/x;->I0()Lcd/d;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0}, LAd/x;->C0()Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/lang/Iterable;

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, LAd/y;

    .line 34
    .line 35
    iget-object v2, v1, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 36
    .line 37
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-static {v2, v1}, LAd/x;->t0(Lorg/tezza/presentation/widgets/sticker/TemplateImageView;LAd/y;)V

    .line 41
    .line 42
    .line 43
    iget-object v1, v1, LAd/y;->a:LAd/a;

    .line 44
    .line 45
    new-instance v2, Ljava/lang/StringBuilder;

    .line 46
    .line 47
    const-string v3, "tak recalculated areas: "

    .line 48
    .line 49
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-static {p0, v1}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_0
    return-void
.end method

.method public final z0()Ljava/util/ArrayList;
    .locals 4

    .line 1
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move-object v0, v1

    .line 14
    :goto_0
    instance-of v2, v0, Landroid/view/ViewGroup;

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    move-object v1, v0

    .line 19
    check-cast v1, Landroid/view/ViewGroup;

    .line 20
    .line 21
    :cond_1
    if-eqz v1, :cond_4

    .line 22
    .line 23
    invoke-static {v1}, LAd/x;->y0(Landroid/view/View;)Ljava/util/ArrayList;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    new-instance v1, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    :cond_2
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_3

    .line 41
    .line 42
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    instance-of v3, v2, Lorg/tezza/presentation/widgets/sticker/StickerTextView;

    .line 47
    .line 48
    if-eqz v3, :cond_2

    .line 49
    .line 50
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_3
    return-object v1

    .line 55
    :cond_4
    invoke-virtual {p0}, LAd/x;->D0()Landroid/view/ViewGroup;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-static {v0}, LAd/x;->y0(Landroid/view/View;)Ljava/util/ArrayList;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    new-instance v1, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    :cond_5
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-eqz v2, :cond_6

    .line 77
    .line 78
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    instance-of v3, v2, Lorg/tezza/presentation/widgets/sticker/StickerTextView;

    .line 83
    .line 84
    if-eqz v3, :cond_5

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    goto :goto_2

    .line 90
    :cond_6
    return-object v1
.end method
