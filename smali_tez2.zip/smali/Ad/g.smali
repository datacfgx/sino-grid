.class public final LAd/g;
.super LAd/f;
.source "Template.kt"


# instance fields
.field public final b:D


# direct methods
.method public constructor <init>(LAd/a;D)V
    .locals 1

    .line 1
    const-string v0, "area"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1}, LAd/f;-><init>(LAd/a;)V

    .line 7
    .line 8
    .line 9
    iput-wide p2, p0, LAd/g;->b:D

    .line 10
    .line 11
    return-void
.end method
