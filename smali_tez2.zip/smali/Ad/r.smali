.class public final synthetic LAd/r;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LAd/r;->a:I

    .line 2
    .line 3
    iput-object p1, p0, LAd/r;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, LAd/r;->c:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 13

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x4

    .line 3
    .line 4
    iget-object v2, p0, LAd/r;->c:Ljava/lang/Object;

    .line 5
    const/4 v3, 0x0

    .line 6
    .line 7
    iget-object v4, p0, LAd/r;->b:Ljava/lang/Object;

    .line 8
    const/4 v5, 0x1

    .line 9
    .line 10
    iget v6, p0, LAd/r;->a:I

    .line 11
    .line 12
    .line 13
    packed-switch v6, :pswitch_data_0

    .line 14
    .line 15
    check-cast v4, LX/f;

    .line 16
    .line 17
    iget-object v4, v4, LX/f;->a:Landroidx/compose/runtime/b;

    .line 18
    .line 19
    iget-boolean v6, v4, Landroidx/compose/runtime/b;->C:Z

    .line 20
    .line 21
    if-nez v6, :cond_0

    .line 22
    .line 23
    .line 24
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 25
    move-result-object v0

    .line 26
    .line 27
    goto/16 :goto_b

    .line 28
    .line 29
    :cond_0
    iget-object v6, v4, Landroidx/compose/runtime/b;->c:Landroidx/compose/runtime/h;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v6}, Landroidx/compose/runtime/h;->m()Landroidx/compose/runtime/g;

    .line 33
    move-result-object v7

    .line 34
    .line 35
    :try_start_0
    new-instance v8, Lkotlin/jvm/internal/Q;

    .line 36
    .line 37
    .line 38
    invoke-direct {v8}, Lkotlin/jvm/internal/Q;-><init>()V

    .line 39
    .line 40
    :goto_0
    iget v9, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 41
    .line 42
    iget v10, v6, Landroidx/compose/runtime/h;->b:I

    .line 43
    .line 44
    if-ge v9, v10, :cond_b

    .line 45
    .line 46
    .line 47
    invoke-virtual {v7, v9}, Landroidx/compose/runtime/g;->l(I)Z

    .line 48
    move-result v9

    .line 49
    .line 50
    if-eqz v9, :cond_4

    .line 51
    .line 52
    iget v9, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 53
    .line 54
    .line 55
    invoke-virtual {v7, v9}, Landroidx/compose/runtime/g;->n(I)Ljava/lang/Object;

    .line 56
    move-result-object v9

    .line 57
    .line 58
    if-eq v9, v2, :cond_3

    .line 59
    .line 60
    instance-of v10, v9, LM/Y0;

    .line 61
    .line 62
    if-eqz v10, :cond_1

    .line 63
    .line 64
    check-cast v9, LM/Y0;

    .line 65
    goto :goto_1

    .line 66
    :cond_1
    move-object v9, v3

    .line 67
    .line 68
    :goto_1
    if-eqz v9, :cond_2

    .line 69
    .line 70
    iget-object v9, v9, LM/Y0;->a:LM/X0;

    .line 71
    goto :goto_2

    .line 72
    :cond_2
    move-object v9, v3

    .line 73
    .line 74
    :goto_2
    if-ne v9, v2, :cond_4

    .line 75
    .line 76
    :cond_3
    new-instance v0, LX/k;

    .line 77
    .line 78
    iget v1, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 79
    .line 80
    .line 81
    invoke-direct {v0, v1, v3}, LX/k;-><init>(ILjava/lang/Integer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 82
    .line 83
    .line 84
    invoke-virtual {v7}, Landroidx/compose/runtime/g;->c()V

    .line 85
    move-object v3, v0

    .line 86
    goto :goto_9

    .line 87
    :catchall_0
    move-exception v0

    .line 88
    .line 89
    goto/16 :goto_c

    .line 90
    .line 91
    :cond_4
    :try_start_1
    iget v9, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 92
    .line 93
    iget-object v10, v7, Landroidx/compose/runtime/g;->b:[I

    .line 94
    .line 95
    .line 96
    invoke-static {v10, v9}, LM/d1;->c([II)I

    .line 97
    move-result v11

    .line 98
    add-int/2addr v9, v5

    .line 99
    .line 100
    iget v12, v7, Landroidx/compose/runtime/g;->c:I

    .line 101
    .line 102
    if-ge v9, v12, :cond_5

    .line 103
    .line 104
    mul-int/lit8 v9, v9, 0x5

    .line 105
    add-int/2addr v9, v1

    .line 106
    .line 107
    aget v9, v10, v9

    .line 108
    goto :goto_3

    .line 109
    .line 110
    :cond_5
    iget v9, v7, Landroidx/compose/runtime/g;->e:I

    .line 111
    :goto_3
    sub-int/2addr v9, v11

    .line 112
    move v10, v0

    .line 113
    .line 114
    :goto_4
    if-ge v10, v9, :cond_a

    .line 115
    .line 116
    iget v11, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 117
    .line 118
    .line 119
    invoke-virtual {v7, v11, v10}, Landroidx/compose/runtime/g;->h(II)Ljava/lang/Object;

    .line 120
    move-result-object v11

    .line 121
    .line 122
    if-eq v11, v2, :cond_9

    .line 123
    .line 124
    instance-of v12, v11, LM/Y0;

    .line 125
    .line 126
    if-eqz v12, :cond_6

    .line 127
    .line 128
    check-cast v11, LM/Y0;

    .line 129
    goto :goto_5

    .line 130
    :cond_6
    move-object v11, v3

    .line 131
    .line 132
    :goto_5
    if-eqz v11, :cond_7

    .line 133
    .line 134
    iget-object v11, v11, LM/Y0;->a:LM/X0;

    .line 135
    goto :goto_6

    .line 136
    :cond_7
    move-object v11, v3

    .line 137
    .line 138
    :goto_6
    if-ne v11, v2, :cond_8

    .line 139
    goto :goto_7

    .line 140
    :cond_8
    add-int/2addr v10, v5

    .line 141
    goto :goto_4

    .line 142
    .line 143
    :cond_9
    :goto_7
    new-instance v3, LX/k;

    .line 144
    .line 145
    iget v0, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 146
    .line 147
    .line 148
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 149
    move-result-object v1

    .line 150
    .line 151
    .line 152
    invoke-direct {v3, v0, v1}, LX/k;-><init>(ILjava/lang/Integer;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 153
    .line 154
    .line 155
    :goto_8
    invoke-virtual {v7}, Landroidx/compose/runtime/g;->c()V

    .line 156
    goto :goto_9

    .line 157
    .line 158
    :cond_a
    :try_start_2
    iget v9, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 159
    add-int/2addr v9, v5

    .line 160
    .line 161
    iput v9, v8, Lkotlin/jvm/internal/Q;->a:I

    .line 162
    goto :goto_0

    .line 163
    .line 164
    :cond_b
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 165
    goto :goto_8

    .line 166
    .line 167
    :goto_9
    if-eqz v3, :cond_d

    .line 168
    .line 169
    iget v0, v3, LX/k;->a:I

    .line 170
    .line 171
    iget-object v1, v3, LX/k;->b:Ljava/lang/Integer;

    .line 172
    .line 173
    iget-boolean v2, v4, Landroidx/compose/runtime/b;->C:Z

    .line 174
    .line 175
    if-nez v2, :cond_c

    .line 176
    .line 177
    .line 178
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 179
    move-result-object v0

    .line 180
    goto :goto_a

    .line 181
    .line 182
    .line 183
    :cond_c
    invoke-virtual {v6}, Landroidx/compose/runtime/h;->m()Landroidx/compose/runtime/g;

    .line 184
    move-result-object v2

    .line 185
    .line 186
    .line 187
    :try_start_3
    invoke-static {v2, v0, v1}, LX/b;->c(Landroidx/compose/runtime/g;ILjava/lang/Integer;)Ljava/util/ArrayList;

    .line 188
    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 189
    .line 190
    .line 191
    invoke-virtual {v2}, Landroidx/compose/runtime/g;->c()V

    .line 192
    .line 193
    :goto_a
    check-cast v0, Ljava/util/Collection;

    .line 194
    .line 195
    .line 196
    invoke-virtual {v4}, Landroidx/compose/runtime/b;->g0()Ljava/util/List;

    .line 197
    move-result-object v1

    .line 198
    .line 199
    check-cast v1, Ljava/lang/Iterable;

    .line 200
    .line 201
    .line 202
    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    .line 203
    move-result-object v0

    .line 204
    .line 205
    if-eqz v0, :cond_d

    .line 206
    goto :goto_b

    .line 207
    :catchall_1
    move-exception v0

    .line 208
    .line 209
    .line 210
    invoke-virtual {v2}, Landroidx/compose/runtime/g;->c()V

    .line 211
    throw v0

    .line 212
    .line 213
    .line 214
    :cond_d
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 215
    move-result-object v0

    .line 216
    :goto_b
    return-object v0

    .line 217
    .line 218
    .line 219
    :goto_c
    invoke-virtual {v7}, Landroidx/compose/runtime/g;->c()V

    .line 220
    throw v0

    .line 221
    .line 222
    :pswitch_0
    sget v0, LVc/r;->G0:I

    .line 223
    .line 224
    sget-object v0, LBd/v;->a:LBd/v;

    .line 225
    .line 226
    check-cast v4, LVc/r;

    .line 227
    .line 228
    .line 229
    invoke-virtual {v4}, LJc/e;->q0()LJc/f;

    .line 230
    move-result-object v1

    .line 231
    .line 232
    check-cast v1, LVc/v;

    .line 233
    .line 234
    .line 235
    invoke-virtual {v1}, LJc/f;->c()Lg9/a;

    .line 236
    move-result-object v1

    .line 237
    .line 238
    new-instance v6, LGd/g;

    .line 239
    .line 240
    .line 241
    invoke-direct {v6, v5}, LGd/g;-><init>(I)V

    .line 242
    .line 243
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 244
    .line 245
    .line 246
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    .line 248
    .line 249
    invoke-static {v4, v1, v2, v6, v3}, LBd/v;->c(Landroidx/fragment/app/Fragment;Lg9/a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 250
    .line 251
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 252
    return-object v0

    .line 253
    .line 254
    :pswitch_1
    check-cast v4, LAd/x;

    .line 255
    .line 256
    .line 257
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->m()LP1/h;

    .line 258
    move-result-object v6

    .line 259
    .line 260
    new-instance v7, Ljava/lang/ref/WeakReference;

    .line 261
    .line 262
    .line 263
    invoke-direct {v7, v6}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 264
    .line 265
    new-instance v6, Ljava/lang/ref/WeakReference;

    .line 266
    .line 267
    .line 268
    invoke-direct {v6, v4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    invoke-static {}, LP8/a;->ofImage()Ljava/util/Set;

    .line 272
    move-result-object v8

    .line 273
    .line 274
    sget-object v9, LS8/c$a;->a:LS8/c;

    .line 275
    .line 276
    iput-object v3, v9, LS8/c;->a:Ljava/util/Set;

    .line 277
    .line 278
    iput-boolean v0, v9, LS8/c;->b:Z

    .line 279
    .line 280
    iput-boolean v0, v9, LS8/c;->c:Z

    .line 281
    .line 282
    .line 283
    const v10, 0x7f130159

    .line 284
    .line 285
    iput v10, v9, LS8/c;->d:I

    .line 286
    .line 287
    iput v0, v9, LS8/c;->e:I

    .line 288
    .line 289
    iput-boolean v0, v9, LS8/c;->f:Z

    .line 290
    .line 291
    iput v5, v9, LS8/c;->g:I

    .line 292
    const/4 v10, 0x3

    .line 293
    .line 294
    iput v10, v9, LS8/c;->h:I

    .line 295
    .line 296
    iput v0, v9, LS8/c;->i:I

    .line 297
    .line 298
    const/high16 v10, 0x3f000000    # 0.5f

    .line 299
    .line 300
    iput v10, v9, LS8/c;->j:F

    .line 301
    .line 302
    new-instance v10, LR8/a;

    .line 303
    .line 304
    .line 305
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 306
    .line 307
    iput-object v10, v9, LS8/c;->k:LR8/a;

    .line 308
    .line 309
    iput-boolean v5, v9, LS8/c;->l:Z

    .line 310
    .line 311
    iput-boolean v0, v9, LS8/c;->m:Z

    .line 312
    .line 313
    .line 314
    const v0, 0x7fffffff

    .line 315
    .line 316
    iput v0, v9, LS8/c;->n:I

    .line 317
    .line 318
    sget-object v0, LS8/b;->ALL:LS8/b;

    .line 319
    .line 320
    iput-object v0, v9, LS8/c;->o:LS8/b;

    .line 321
    .line 322
    iput-object v3, v9, LS8/c;->p:LDd/A;

    .line 323
    .line 324
    iput-object v8, v9, LS8/c;->a:Ljava/util/Set;

    .line 325
    .line 326
    iput-boolean v5, v9, LS8/c;->b:Z

    .line 327
    const/4 v0, -0x1

    .line 328
    .line 329
    iput v0, v9, LS8/c;->e:I

    .line 330
    .line 331
    .line 332
    const v0, 0x7f13015a

    .line 333
    .line 334
    iput v0, v9, LS8/c;->d:I

    .line 335
    .line 336
    new-instance v0, LDd/A;

    .line 337
    .line 338
    .line 339
    invoke-direct {v0}, LDd/A;-><init>()V

    .line 340
    .line 341
    iput-object v0, v9, LS8/c;->p:LDd/A;

    .line 342
    .line 343
    iput-boolean v5, v9, LS8/c;->c:Z

    .line 344
    .line 345
    iput-boolean v5, v9, LS8/c;->f:Z

    .line 346
    .line 347
    iput v1, v9, LS8/c;->h:I

    .line 348
    .line 349
    .line 350
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->u()Landroid/content/res/Resources;

    .line 351
    move-result-object v0

    .line 352
    .line 353
    .line 354
    const v1, 0x7f060264

    .line 355
    .line 356
    .line 357
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 358
    move-result v0

    .line 359
    .line 360
    iput v0, v9, LS8/c;->i:I

    .line 361
    .line 362
    check-cast v2, Lkotlin/jvm/internal/Q;

    .line 363
    .line 364
    iget v0, v2, Lkotlin/jvm/internal/Q;->a:I

    .line 365
    .line 366
    if-lt v0, v5, :cond_10

    .line 367
    .line 368
    iput v0, v9, LS8/c;->g:I

    .line 369
    .line 370
    const/high16 v0, 0x3f800000    # 1.0f

    .line 371
    .line 372
    iput v0, v9, LS8/c;->j:F

    .line 373
    .line 374
    iput-boolean v5, v9, LS8/c;->m:Z

    .line 375
    .line 376
    new-instance v0, LR8/a;

    .line 377
    .line 378
    .line 379
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 380
    .line 381
    iput-object v0, v9, LS8/c;->k:LR8/a;

    .line 382
    .line 383
    .line 384
    invoke-virtual {v7}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 385
    move-result-object v0

    .line 386
    .line 387
    check-cast v0, Landroid/app/Activity;

    .line 388
    .line 389
    if-nez v0, :cond_e

    .line 390
    goto :goto_d

    .line 391
    .line 392
    :cond_e
    new-instance v1, Landroid/content/Intent;

    .line 393
    .line 394
    const-class v2, Lcom/zhihu/matisse/ui/MatisseActivity;

    .line 395
    .line 396
    .line 397
    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 398
    .line 399
    .line 400
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 401
    move-result-object v2

    .line 402
    .line 403
    check-cast v2, Landroidx/fragment/app/Fragment;

    .line 404
    .line 405
    const/16 v3, 0x3eb

    .line 406
    .line 407
    if-eqz v2, :cond_f

    .line 408
    .line 409
    .line 410
    invoke-virtual {v2, v1, v3}, Landroidx/fragment/app/Fragment;->k0(Landroid/content/Intent;I)V

    .line 411
    goto :goto_d

    .line 412
    .line 413
    .line 414
    :cond_f
    invoke-virtual {v0, v1, v3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 415
    .line 416
    :goto_d
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 417
    return-object v0

    .line 418
    .line 419
    :cond_10
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 420
    .line 421
    const/4 v1, 0x0

    sget-object v1, Lu4/ZZJ/uTrGKIcFpjk;->nxMeT:Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 425
    throw v0

    .line 426
    .line 427
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
