.class public final synthetic LAd/v;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:LAd/x;

.field public final synthetic b:LAd/r;


# direct methods
.method public synthetic constructor <init>(LAd/x;LAd/r;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAd/v;->a:LAd/x;

    .line 5
    .line 6
    iput-object p2, p0, LAd/v;->b:LAd/r;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, LBd/v;->a:LBd/v;

    .line 2
    .line 3
    new-instance v1, LAd/n;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, v2}, LAd/n;-><init>(I)V

    .line 7
    .line 8
    .line 9
    iget-object v2, p0, LAd/v;->a:LAd/x;

    .line 10
    .line 11
    iget-object v3, p0, LAd/v;->b:LAd/r;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    invoke-static {v2, v0, v3, v1, v0}, LBd/v;->c(Landroidx/fragment/app/Fragment;Lg9/a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 18
    .line 19
    .line 20
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 21
    .line 22
    return-object v0
.end method
