.class public final synthetic LAd/t;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LAd/t;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 13

    .line 1
    iget v0, p0, LAd/t;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LCb/e;

    .line 7
    .line 8
    sget-object v1, Lorg/tezza/domain/gallery/HslItem$a;->a:Lorg/tezza/domain/gallery/HslItem$a;

    .line 9
    .line 10
    invoke-direct {v0, v1}, LCb/e;-><init>(Lyb/b;)V

    .line 11
    .line 12
    .line 13
    return-object v0

    .line 14
    :pswitch_0
    sget-object v0, LX/i;->a:LM/q1;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    return-object v0

    .line 18
    :pswitch_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_2
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 22
    .line 23
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const-string v1, "Tezza"

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const-string v3, "billingSupportCode"

    .line 35
    .line 36
    const-string v4, ""

    .line 37
    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    move-object v4, v0

    .line 49
    :goto_0
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_3

    .line 54
    .line 55
    new-instance v0, Ljava/security/SecureRandom;

    .line 56
    .line 57
    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    .line 58
    .line 59
    .line 60
    new-instance v4, Lkotlin/ranges/IntRange;

    .line 61
    .line 62
    const/4 v5, 0x1

    .line 63
    const/4 v6, 0x6

    .line 64
    invoke-direct {v4, v5, v6, v5}, Lkotlin/ranges/a;-><init>(III)V

    .line 65
    .line 66
    .line 67
    new-instance v7, Ljava/util/ArrayList;

    .line 68
    .line 69
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    invoke-direct {v7, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v4}, Lkotlin/ranges/a;->iterator()Ljava/util/Iterator;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    :goto_1
    move-object v5, v4

    .line 81
    check-cast v5, LY9/b;

    .line 82
    .line 83
    iget-boolean v5, v5, LY9/b;->c:Z

    .line 84
    .line 85
    if-eqz v5, :cond_2

    .line 86
    .line 87
    move-object v5, v4

    .line 88
    check-cast v5, Lkotlin/collections/IntIterator;

    .line 89
    .line 90
    invoke-virtual {v5}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 91
    .line 92
    .line 93
    const/16 v5, 0x20

    .line 94
    .line 95
    invoke-virtual {v0, v5}, Ljava/util/Random;->nextInt(I)I

    .line 96
    .line 97
    .line 98
    move-result v5

    .line 99
    const-string v6, "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    .line 100
    .line 101
    invoke-virtual {v6, v5}, Ljava/lang/String;->charAt(I)C

    .line 102
    .line 103
    .line 104
    move-result v5

    .line 105
    invoke-static {v5}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    .line 106
    .line 107
    .line 108
    move-result-object v5

    .line 109
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    goto :goto_1

    .line 113
    :cond_2
    const/4 v10, 0x0

    .line 114
    const/4 v11, 0x0

    .line 115
    const-string v8, ""

    .line 116
    .line 117
    const/4 v9, 0x0

    .line 118
    const/16 v12, 0x3e

    .line 119
    .line 120
    invoke-static/range {v7 .. v12}, Lkotlin/collections/CollectionsKt;->p(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v4

    .line 124
    const-string v0, "code"

    .line 125
    .line 126
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 130
    .line 131
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 144
    .line 145
    .line 146
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 147
    .line 148
    .line 149
    :cond_3
    return-object v4

    .line 150
    :pswitch_3
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 151
    .line 152
    return-object v0

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
