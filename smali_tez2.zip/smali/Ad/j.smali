.class public final synthetic LAd/j;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LAd/j;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LAd/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 9

    .line 1
    iget v0, p0, LAd/j;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAd/j;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lorg/tezza/presentation/widgets/sticker/c;

    .line 9
    .line 10
    invoke-static {v0, p1, p2}, Lorg/tezza/presentation/widgets/sticker/c;->h(Lorg/tezza/presentation/widgets/sticker/c;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    return p1

    .line 15
    :pswitch_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    float-to-int v0, v0

    .line 20
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    float-to-int v1, v1

    .line 25
    iget-object v2, p0, LAd/j;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, LAd/x;

    .line 28
    .line 29
    invoke-virtual {v2}, LAd/x;->C0()Ljava/util/List;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    check-cast v3, Ljava/lang/Iterable;

    .line 34
    .line 35
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    const/4 v5, 0x0

    .line 44
    if-eqz v4, :cond_1

    .line 45
    .line 46
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    move-object v6, v4

    .line 51
    check-cast v6, LAd/y;

    .line 52
    .line 53
    iget-object v6, v6, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 54
    .line 55
    if-eqz v6, :cond_0

    .line 56
    .line 57
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 58
    .line 59
    .line 60
    move-result v7

    .line 61
    invoke-virtual {v6}, Landroid/view/View;->getId()I

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    if-ne v7, v6, :cond_0

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_1
    move-object v4, v5

    .line 69
    :goto_0
    check-cast v4, LAd/y;

    .line 70
    .line 71
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    const/4 p2, 0x1

    .line 76
    const-string v3, "TAG"

    .line 77
    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    if-eq p1, p2, :cond_3

    .line 81
    .line 82
    const/4 v2, 0x2

    .line 83
    if-eq p1, v2, :cond_2

    .line 84
    .line 85
    goto/16 :goto_4

    .line 86
    .line 87
    :cond_2
    const-string p1, "moving: ("

    .line 88
    .line 89
    const-string v2, ", "

    .line 90
    .line 91
    const-string v4, ")"

    .line 92
    .line 93
    invoke-static {v0, v1, p1, v2, v4}, LG/k0;->b(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 98
    .line 99
    .line 100
    goto/16 :goto_4

    .line 101
    .line 102
    :cond_3
    const-string p1, "touched up"

    .line 103
    .line 104
    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 105
    .line 106
    .line 107
    goto/16 :goto_4

    .line 108
    .line 109
    :cond_4
    const-string p1, "touched down"

    .line 110
    .line 111
    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 112
    .line 113
    .line 114
    invoke-virtual {v2, v4}, LAd/x;->K0(LAd/y;)Z

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    if-eqz p1, :cond_5

    .line 119
    .line 120
    goto/16 :goto_4

    .line 121
    .line 122
    :cond_5
    invoke-virtual {v2}, LAd/x;->C0()Ljava/util/List;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    check-cast p1, Ljava/lang/Iterable;

    .line 127
    .line 128
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    :cond_6
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    const/4 v3, 0x0

    .line 137
    if-eqz v0, :cond_7

    .line 138
    .line 139
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, LAd/y;

    .line 144
    .line 145
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v6

    .line 149
    if-nez v6, :cond_6

    .line 150
    .line 151
    iget-object v0, v0, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 152
    .line 153
    if-eqz v0, :cond_6

    .line 154
    .line 155
    iput-boolean v3, v0, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->t0:Z

    .line 156
    .line 157
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 161
    .line 162
    .line 163
    goto :goto_1

    .line 164
    :cond_7
    if-eqz v4, :cond_8

    .line 165
    .line 166
    iget-object p1, v4, LAd/y;->c:Ljava/lang/String;

    .line 167
    .line 168
    goto :goto_2

    .line 169
    :cond_8
    move-object p1, v5

    .line 170
    :goto_2
    if-nez p1, :cond_c

    .line 171
    .line 172
    iput-object v4, v2, LAd/x;->A0:LAd/y;

    .line 173
    .line 174
    new-instance p1, Lkotlin/jvm/internal/Q;

    .line 175
    .line 176
    invoke-direct {p1}, Lkotlin/jvm/internal/Q;-><init>()V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v2}, LAd/x;->C0()Ljava/util/List;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    check-cast v0, Ljava/lang/Iterable;

    .line 184
    .line 185
    new-instance v1, Ljava/util/ArrayList;

    .line 186
    .line 187
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 188
    .line 189
    .line 190
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    :cond_9
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 195
    .line 196
    .line 197
    move-result v6

    .line 198
    if-eqz v6, :cond_a

    .line 199
    .line 200
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v6

    .line 204
    move-object v7, v6

    .line 205
    check-cast v7, LAd/y;

    .line 206
    .line 207
    iget-object v8, v7, LAd/y;->c:Ljava/lang/String;

    .line 208
    .line 209
    if-nez v8, :cond_9

    .line 210
    .line 211
    invoke-virtual {v2, v7}, LAd/x;->K0(LAd/y;)Z

    .line 212
    .line 213
    .line 214
    move-result v7

    .line 215
    if-nez v7, :cond_9

    .line 216
    .line 217
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    goto :goto_3

    .line 221
    :cond_a
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 222
    .line 223
    .line 224
    move-result v0

    .line 225
    iput v0, p1, Lkotlin/jvm/internal/Q;->a:I

    .line 226
    .line 227
    instance-of v1, v2, Lld/c;

    .line 228
    .line 229
    if-eqz v1, :cond_b

    .line 230
    .line 231
    iget-object v1, v2, LAd/x;->E0:Lcd/B;

    .line 232
    .line 233
    sget-object v6, Lcd/B;->RATIO_4_5:Lcd/B;

    .line 234
    .line 235
    if-ne v1, v6, :cond_b

    .line 236
    .line 237
    sub-int/2addr v0, p2

    .line 238
    iput v0, p1, Lkotlin/jvm/internal/Q;->a:I

    .line 239
    .line 240
    :cond_b
    new-instance v0, LAd/r;

    .line 241
    .line 242
    const/4 v1, 0x0

    .line 243
    invoke-direct {v0, v2, v1, p1}, LAd/r;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    new-instance p1, LAd/s;

    .line 247
    .line 248
    invoke-direct {p1, v2, v0}, LAd/s;-><init>(LAd/x;LAd/r;)V

    .line 249
    .line 250
    .line 251
    sget-object v1, LBd/v;->a:LBd/v;

    .line 252
    .line 253
    new-instance v6, LAd/t;

    .line 254
    .line 255
    const/4 v7, 0x0

    .line 256
    invoke-direct {v6, v7}, LAd/t;-><init>(I)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 260
    .line 261
    .line 262
    invoke-static {v2, v5, v0, v6, p1}, LBd/v;->c(Landroidx/fragment/app/Fragment;Lg9/a;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 263
    .line 264
    .line 265
    if-eqz v4, :cond_f

    .line 266
    .line 267
    iget-object p1, v4, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 268
    .line 269
    if-eqz p1, :cond_f

    .line 270
    .line 271
    iput-boolean v3, p1, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->t0:Z

    .line 272
    .line 273
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 274
    .line 275
    .line 276
    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    .line 277
    .line 278
    .line 279
    goto :goto_4

    .line 280
    :cond_c
    iget-object p1, v4, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 281
    .line 282
    if-eqz p1, :cond_e

    .line 283
    .line 284
    iget-boolean v0, p1, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->t0:Z

    .line 285
    .line 286
    if-eqz v0, :cond_e

    .line 287
    .line 288
    invoke-virtual {p1}, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->getRemoveBtnMargin()F

    .line 289
    .line 290
    .line 291
    move-result v0

    .line 292
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->c0()Landroid/content/Context;

    .line 293
    .line 294
    .line 295
    move-result-object v3

    .line 296
    const-string v6, "requireContext(...)"

    .line 297
    .line 298
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 299
    .line 300
    .line 301
    invoke-static {v0, v3}, LBd/P;->b(FLandroid/content/Context;)I

    .line 302
    .line 303
    .line 304
    move-result v0

    .line 305
    int-to-float v0, v0

    .line 306
    invoke-virtual {p1}, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->getRemoveBtnHeight()F

    .line 307
    .line 308
    .line 309
    move-result p1

    .line 310
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->c0()Landroid/content/Context;

    .line 311
    .line 312
    .line 313
    move-result-object v3

    .line 314
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    invoke-static {p1, v3}, LBd/P;->b(FLandroid/content/Context;)I

    .line 318
    .line 319
    .line 320
    move-result p1

    .line 321
    int-to-float p1, p1

    .line 322
    add-float/2addr p1, v0

    .line 323
    int-to-float v0, v1

    .line 324
    cmpg-float p1, v0, p1

    .line 325
    .line 326
    if-gtz p1, :cond_e

    .line 327
    .line 328
    iput-object v5, v4, LAd/y;->c:Ljava/lang/String;

    .line 329
    .line 330
    invoke-virtual {v2, v4}, LAd/x;->M0(LAd/y;)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v2}, LAd/x;->Q0()V

    .line 334
    .line 335
    .line 336
    iget-object p1, v2, Landroidx/fragment/app/Fragment;->S:Landroidx/fragment/app/Fragment;

    .line 337
    .line 338
    instance-of v0, p1, Lcd/N;

    .line 339
    .line 340
    if-eqz v0, :cond_d

    .line 341
    .line 342
    move-object v5, p1

    .line 343
    check-cast v5, Lcd/N;

    .line 344
    .line 345
    :cond_d
    if-eqz v5, :cond_e

    .line 346
    .line 347
    invoke-virtual {v5}, Lcd/N;->I0()V

    .line 348
    .line 349
    .line 350
    :cond_e
    iget-object p1, v4, LAd/y;->f:Lorg/tezza/presentation/widgets/sticker/TemplateImageView;

    .line 351
    .line 352
    if-eqz p1, :cond_f

    .line 353
    .line 354
    iget-boolean v0, p1, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->t0:Z

    .line 355
    .line 356
    xor-int/2addr v0, p2

    .line 357
    iput-boolean v0, p1, Lorg/tezza/presentation/widgets/sticker/TemplateImageView;->t0:Z

    .line 358
    .line 359
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 360
    .line 361
    .line 362
    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    .line 363
    .line 364
    .line 365
    :cond_f
    :goto_4
    return p2

    .line 366
    nop

    .line 367
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
