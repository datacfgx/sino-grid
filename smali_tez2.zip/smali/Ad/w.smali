.class public final synthetic LAd/w;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, LAd/w;->a:I

    .line 2
    .line 3
    iput-object p1, p0, LAd/w;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, LAd/w;->c:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, LAd/w;->d:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p4, p0, LAd/w;->e:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget v0, p0, LAd/w;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAd/w;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LI4/l;

    .line 9
    .line 10
    iget-object v1, v0, LI4/l;->a:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v2, p0, LAd/w;->d:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, LF4/j;

    .line 15
    .line 16
    iget-object v3, p0, LAd/w;->e:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v3, LI4/j;

    .line 19
    .line 20
    iget-object v4, p0, LAd/w;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v4, LN4/b;

    .line 23
    .line 24
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    sget-object v5, LN4/b;->f:Ljava/util/logging/Logger;

    .line 28
    .line 29
    const-string v6, "Transport backend \'"

    .line 30
    .line 31
    :try_start_0
    iget-object v7, v4, LN4/b;->c:LJ4/e;

    .line 32
    .line 33
    invoke-interface {v7, v1}, LJ4/e;->a(Ljava/lang/String;)LJ4/m;

    .line 34
    .line 35
    .line 36
    move-result-object v7

    .line 37
    if-nez v7, :cond_0

    .line 38
    .line 39
    new-instance v0, Ljava/lang/StringBuilder;

    .line 40
    .line 41
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string v1, "\' is not registered"

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-virtual {v5, v0}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 60
    .line 61
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-interface {v2, v1}, LF4/j;->a(Ljava/lang/Exception;)V

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :catch_0
    move-exception v0

    .line 69
    goto :goto_0

    .line 70
    :cond_0
    invoke-interface {v7, v3}, LJ4/m;->a(LI4/j;)LI4/j;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    iget-object v3, v4, LN4/b;->e:LQ4/a;

    .line 75
    .line 76
    new-instance v6, LN4/a;

    .line 77
    .line 78
    invoke-direct {v6, v4, v0, v1}, LN4/a;-><init>(LN4/b;LI4/l;LI4/q;)V

    .line 79
    .line 80
    .line 81
    invoke-interface {v3, v6}, LQ4/a;->i(LQ4/a$a;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    const/4 v0, 0x0

    .line 85
    invoke-interface {v2, v0}, LF4/j;->a(Ljava/lang/Exception;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    .line 87
    .line 88
    goto :goto_1

    .line 89
    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 90
    .line 91
    const-string v3, "Error scheduling event "

    .line 92
    .line 93
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {v5, v1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-interface {v2, v0}, LF4/j;->a(Ljava/lang/Exception;)V

    .line 111
    .line 112
    .line 113
    :goto_1
    return-void

    .line 114
    :pswitch_0
    iget-object v0, p0, LAd/w;->b:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v0, LAd/x;

    .line 117
    .line 118
    invoke-virtual {v0}, LAd/x;->x0()V

    .line 119
    .line 120
    .line 121
    iget-object v1, p0, LAd/w;->d:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast v1, Ljava/util/ArrayList;

    .line 124
    .line 125
    iget-object v2, p0, LAd/w;->c:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v2, Ljava/util/List;

    .line 128
    .line 129
    invoke-virtual {v0, v1, v2}, LAd/x;->m0(Ljava/util/ArrayList;Ljava/util/List;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v0, v1}, LAd/x;->l0(Ljava/util/List;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v0, v1}, LAd/x;->P0(Ljava/util/ArrayList;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 143
    .line 144
    .line 145
    move-result v2

    .line 146
    if-lez v2, :cond_1

    .line 147
    .line 148
    invoke-virtual {v0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 149
    .line 150
    .line 151
    move-result-object v2

    .line 152
    invoke-virtual {v0, v2}, LAd/x;->w0(Landroid/view/View;)LAd/y;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    :cond_1
    new-instance v2, LAd/z;

    .line 160
    .line 161
    iget-object v3, v0, LAd/x;->E0:Lcd/B;

    .line 162
    .line 163
    invoke-virtual {v3}, Lcd/B;->getSize()Lorg/tezza/presentation/utils/media/Size;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    iget v0, v0, LAd/x;->D0:I

    .line 168
    .line 169
    invoke-direct {v2, v3, v0}, LAd/z;-><init>(Lorg/tezza/presentation/utils/media/Size;I)V

    .line 170
    .line 171
    .line 172
    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    iget-object v1, p0, LAd/w;->e:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v1, LLc/C;

    .line 179
    .line 180
    invoke-virtual {v1, v0}, LLc/C;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    return-void

    .line 184
    nop

    .line 185
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
