.class public final synthetic LAd/q;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LAd/q;->a:I

    .line 2
    .line 3
    iput-object p1, p0, LAd/q;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, LAd/q;->c:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget v0, p0, LAd/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAd/q;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lt4/k;

    .line 9
    .line 10
    iget-object v0, v0, Lt4/k;->b:Lt4/i;

    .line 11
    .line 12
    iget-object v1, p0, LAd/q;->c:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-interface {v0, v1}, Lt4/i;->b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, LAd/q;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, LF5/z;

    .line 21
    .line 22
    invoke-virtual {v0}, LF5/z;->c()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    iget-object v1, p0, LAd/q;->c:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, LE5/j;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, LE5/j;->a(I)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_1
    iget-object v0, p0, LAd/q;->b:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, LAd/x;

    .line 37
    .line 38
    invoke-virtual {v0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    invoke-virtual {v0}, LAd/x;->H0()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    iget-object v2, p0, LAd/q;->c:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v2, Lorg/tezza/presentation/widgets/sticker/StickerTextView;

    .line 57
    .line 58
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/c;->getVBottomline()Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    const/4 v5, 0x0

    .line 67
    if-eqz v4, :cond_0

    .line 68
    .line 69
    invoke-virtual {v4}, Landroid/view/View;->getY()F

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    goto :goto_0

    .line 74
    :cond_0
    move v4, v5

    .line 75
    :goto_0
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/c;->getVBottomline()Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    if-eqz v6, :cond_1

    .line 80
    .line 81
    invoke-virtual {v6}, Landroid/view/View;->getHeight()I

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    int-to-float v5, v5

    .line 86
    :cond_1
    add-float/2addr v4, v5

    .line 87
    sub-int/2addr v1, v3

    .line 88
    int-to-float v1, v1

    .line 89
    const/high16 v3, 0x40000000    # 2.0f

    .line 90
    .line 91
    div-float/2addr v1, v3

    .line 92
    invoke-virtual {v2, v1}, Landroid/view/View;->setX(F)V

    .line 93
    .line 94
    .line 95
    int-to-float v0, v0

    .line 96
    mul-float/2addr v4, v3

    .line 97
    sub-float/2addr v0, v4

    .line 98
    div-float/2addr v0, v3

    .line 99
    invoke-virtual {v2, v0}, Landroid/view/View;->setY(F)V

    .line 100
    .line 101
    .line 102
    const/4 v0, 0x1

    .line 103
    invoke-virtual {v2, v0}, Lorg/tezza/presentation/widgets/sticker/c;->setUserPositioned(Z)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v2}, Landroid/view/View;->getX()F

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/c;->getParentWidth()F

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    div-float/2addr v0, v1

    .line 115
    invoke-virtual {v2, v0}, Lorg/tezza/presentation/widgets/sticker/c;->setXFactor(F)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v2}, Landroid/view/View;->getY()F

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/c;->getParentHeight()F

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    div-float/2addr v0, v1

    .line 127
    invoke-virtual {v2, v0}, Lorg/tezza/presentation/widgets/sticker/c;->setYFactor(F)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v2}, Lorg/tezza/presentation/widgets/sticker/c;->getSettings()LMd/i;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    if-eqz v0, :cond_2

    .line 135
    .line 136
    sget-object v1, LMd/g;->CENTER:LMd/g;

    .line 137
    .line 138
    const-string v3, "<set-?>"

    .line 139
    .line 140
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    iput-object v1, v0, LMd/i;->v:LMd/g;

    .line 144
    .line 145
    :cond_2
    if-eqz v0, :cond_3

    .line 146
    .line 147
    invoke-virtual {v2, v0}, Lorg/tezza/presentation/widgets/sticker/StickerTextView;->v(LMd/i;)V

    .line 148
    .line 149
    .line 150
    :cond_3
    const/4 v0, 0x0

    .line 151
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
