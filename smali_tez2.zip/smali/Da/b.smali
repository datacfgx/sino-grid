.class public final LDa/b;
.super Ljava/lang/Object;
.source "BuiltInsProtoBuf.java"


# static fields
.field public static final a:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/l;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final b:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/b;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final c:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/d;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final d:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/i;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final e:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/n;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final f:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/n;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final g:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/n;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final h:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/n;",
            "LCa/a$b$c;",
            ">;"
        }
    .end annotation
.end field

.field public static final i:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/g;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final j:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/u;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final k:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/q;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final l:LIa/g$f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/g$f<",
            "LCa/s;",
            "Ljava/util/List<",
            "LCa/a;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 10

    .line 1
    sget-object v0, LCa/l;->F:LCa/l;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    sget-object v4, LIa/v;->INT32:LIa/v;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    const/16 v3, 0x97

    .line 12
    .line 13
    const-class v5, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-static/range {v0 .. v5}, LIa/g;->i(LIa/g$d;Ljava/io/Serializable;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, LDa/b;->a:LIa/g$f;

    .line 20
    .line 21
    sget-object v0, LCa/b;->f0:LCa/b;

    .line 22
    .line 23
    sget-object v1, LCa/a;->v:LCa/a;

    .line 24
    .line 25
    sget-object v6, LIa/v;->MESSAGE:LIa/v;

    .line 26
    .line 27
    const/16 v8, 0x96

    .line 28
    .line 29
    const-class v9, LCa/a;

    .line 30
    .line 31
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    sput-object v0, LDa/b;->b:LIa/g$f;

    .line 36
    .line 37
    sget-object v0, LCa/d;->E:LCa/d;

    .line 38
    .line 39
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sput-object v0, LDa/b;->c:LIa/g$f;

    .line 44
    .line 45
    sget-object v0, LCa/i;->Q:LCa/i;

    .line 46
    .line 47
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    sput-object v0, LDa/b;->d:LIa/g$f;

    .line 52
    .line 53
    sget-object v2, LCa/n;->Q:LCa/n;

    .line 54
    .line 55
    invoke-static {v2, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sput-object v0, LDa/b;->e:LIa/g$f;

    .line 60
    .line 61
    const/16 v0, 0x98

    .line 62
    .line 63
    invoke-static {v2, v1, v0, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    sput-object v0, LDa/b;->f:LIa/g$f;

    .line 68
    .line 69
    const/16 v0, 0x99

    .line 70
    .line 71
    invoke-static {v2, v1, v0, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    sput-object v0, LDa/b;->g:LIa/g$f;

    .line 76
    .line 77
    sget-object v3, LCa/a$b$c;->K:LCa/a$b$c;

    .line 78
    .line 79
    const/16 v5, 0x97

    .line 80
    .line 81
    const-class v7, LCa/a$b$c;

    .line 82
    .line 83
    move-object v4, v3

    .line 84
    invoke-static/range {v2 .. v7}, LIa/g;->i(LIa/g$d;Ljava/io/Serializable;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    sput-object v0, LDa/b;->h:LIa/g$f;

    .line 89
    .line 90
    sget-object v0, LCa/g;->v:LCa/g;

    .line 91
    .line 92
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    sput-object v0, LDa/b;->i:LIa/g$f;

    .line 97
    .line 98
    sget-object v0, LCa/u;->G:LCa/u;

    .line 99
    .line 100
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    sput-object v0, LDa/b;->j:LIa/g$f;

    .line 105
    .line 106
    sget-object v0, LCa/q;->O:LCa/q;

    .line 107
    .line 108
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    sput-object v0, LDa/b;->k:LIa/g$f;

    .line 113
    .line 114
    sget-object v0, LCa/s;->H:LCa/s;

    .line 115
    .line 116
    invoke-static {v0, v1, v8, v6, v9}, LIa/g;->h(LIa/g$d;LIa/g;ILIa/v;Ljava/lang/Class;)LIa/g$f;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    sput-object v0, LDa/b;->l:LIa/g$f;

    .line 121
    .line 122
    return-void
.end method

.method public static a(LIa/e;)V
    .locals 1

    .line 1
    sget-object v0, LDa/b;->a:LIa/g$f;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, LDa/b;->b:LIa/g$f;

    .line 7
    .line 8
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, LDa/b;->c:LIa/g$f;

    .line 12
    .line 13
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 14
    .line 15
    .line 16
    sget-object v0, LDa/b;->d:LIa/g$f;

    .line 17
    .line 18
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 19
    .line 20
    .line 21
    sget-object v0, LDa/b;->e:LIa/g$f;

    .line 22
    .line 23
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 24
    .line 25
    .line 26
    sget-object v0, LDa/b;->f:LIa/g$f;

    .line 27
    .line 28
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 29
    .line 30
    .line 31
    sget-object v0, LDa/b;->g:LIa/g$f;

    .line 32
    .line 33
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 34
    .line 35
    .line 36
    sget-object v0, LDa/b;->h:LIa/g$f;

    .line 37
    .line 38
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 39
    .line 40
    .line 41
    sget-object v0, LDa/b;->i:LIa/g$f;

    .line 42
    .line 43
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 44
    .line 45
    .line 46
    sget-object v0, LDa/b;->j:LIa/g$f;

    .line 47
    .line 48
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 49
    .line 50
    .line 51
    sget-object v0, LDa/b;->k:LIa/g$f;

    .line 52
    .line 53
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 54
    .line 55
    .line 56
    sget-object v0, LDa/b;->l:LIa/g$f;

    .line 57
    .line 58
    invoke-virtual {p0, v0}, LIa/e;->a(LIa/g$f;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method
