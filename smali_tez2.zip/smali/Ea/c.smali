.class public final LEa/c;
.super LEa/a;
.source "MetadataVersion.kt"


# static fields
.field public static final g:LEa/c;

.field public static final h:LEa/c;


# instance fields
.field public final f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LEa/c;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    filled-new-array {v1, v2, v3}, [I

    .line 7
    .line 8
    .line 9
    move-result-object v4

    .line 10
    invoke-direct {v0, v4}, LEa/c;-><init>([I)V

    .line 11
    .line 12
    .line 13
    sput-object v0, LEa/c;->g:LEa/c;

    .line 14
    .line 15
    iget v4, v0, LEa/a;->c:I

    .line 16
    .line 17
    iget v0, v0, LEa/a;->b:I

    .line 18
    .line 19
    if-ne v0, v2, :cond_0

    .line 20
    .line 21
    const/16 v5, 0x9

    .line 22
    .line 23
    if-ne v4, v5, :cond_0

    .line 24
    .line 25
    new-instance v0, LEa/c;

    .line 26
    .line 27
    filled-new-array {v1, v3, v3}, [I

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-direct {v0, v1}, LEa/c;-><init>([I)V

    .line 32
    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_0
    new-instance v1, LEa/c;

    .line 36
    .line 37
    add-int/2addr v4, v2

    .line 38
    filled-new-array {v0, v4, v3}, [I

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-direct {v1, v0}, LEa/c;-><init>([I)V

    .line 43
    .line 44
    .line 45
    move-object v0, v1

    .line 46
    :goto_0
    sput-object v0, LEa/c;->h:LEa/c;

    .line 47
    .line 48
    new-instance v0, LEa/c;

    .line 49
    .line 50
    new-array v1, v3, [I

    .line 51
    .line 52
    invoke-direct {v0, v1}, LEa/c;-><init>([I)V

    .line 53
    .line 54
    .line 55
    return-void
.end method

.method public varargs constructor <init>([I)V
    .locals 1

    const-string v0, "numbers"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, v0}, LEa/c;-><init>([IZ)V

    return-void
.end method

.method public constructor <init>([IZ)V
    .locals 1

    const-string v0, "versionArray"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    array-length v0, p1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    invoke-direct {p0, p1}, LEa/a;-><init>([I)V

    iput-boolean p2, p0, LEa/c;->f:Z

    return-void
.end method


# virtual methods
.method public final b(LEa/c;)Z
    .locals 5

    .line 1
    const-string v0, "metadataVersionFromLanguageVersion"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-boolean v0, p0, LEa/c;->f:Z

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    sget-object v0, LEa/c;->g:LEa/c;

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    sget-object v0, LEa/c;->h:LEa/c;

    .line 17
    .line 18
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget v1, p1, LEa/a;->b:I

    .line 22
    .line 23
    iget v2, v0, LEa/a;->b:I

    .line 24
    .line 25
    if-le v2, v1, :cond_1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1
    if-ge v2, v1, :cond_2

    .line 29
    .line 30
    goto :goto_2

    .line 31
    :cond_2
    iget v1, v0, LEa/a;->c:I

    .line 32
    .line 33
    iget v2, p1, LEa/a;->c:I

    .line 34
    .line 35
    if-le v1, v2, :cond_3

    .line 36
    .line 37
    :goto_1
    move-object p1, v0

    .line 38
    :cond_3
    :goto_2
    const/4 v0, 0x0

    .line 39
    iget v1, p0, LEa/a;->c:I

    .line 40
    .line 41
    const/4 v2, 0x1

    .line 42
    iget v3, p0, LEa/a;->b:I

    .line 43
    .line 44
    if-ne v3, v2, :cond_4

    .line 45
    .line 46
    if-nez v1, :cond_4

    .line 47
    .line 48
    goto :goto_3

    .line 49
    :cond_4
    if-nez v3, :cond_5

    .line 50
    .line 51
    :goto_3
    return v0

    .line 52
    :cond_5
    iget v4, p1, LEa/a;->b:I

    .line 53
    .line 54
    if-le v3, v4, :cond_6

    .line 55
    .line 56
    :goto_4
    move v0, v2

    .line 57
    goto :goto_5

    .line 58
    :cond_6
    if-ge v3, v4, :cond_7

    .line 59
    .line 60
    goto :goto_5

    .line 61
    :cond_7
    iget p1, p1, LEa/a;->c:I

    .line 62
    .line 63
    if-le v1, p1, :cond_8

    .line 64
    .line 65
    goto :goto_4

    .line 66
    :cond_8
    :goto_5
    xor-int/lit8 p1, v0, 0x1

    .line 67
    .line 68
    return p1
.end method
