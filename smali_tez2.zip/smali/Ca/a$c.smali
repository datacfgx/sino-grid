.class public final LCa/a$c;
.super LIa/g$b;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$b<",
        "LCa/a;",
        "LCa/a$c;",
        ">;",
        "LIa/o;"
    }
.end annotation


# instance fields
.field public b:I

.field public c:I

.field public d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/a$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/g$b;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 5
    .line 6
    iput-object v0, p0, LCa/a$c;->d:Ljava/util/List;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic K(LIa/d;LIa/e;)LIa/n$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/a$c;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final c()LIa/n;
    .locals 2

    .line 1
    invoke-virtual {p0}, LCa/a$c;->l()LCa/a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LCa/a;->g()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    new-instance v0, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;

    .line 13
    .line 14
    invoke-direct {v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;-><init>()V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .line 1
    new-instance v0, LCa/a$c;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$c;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/a$c;->l()LCa/a;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/a$c;->m(LCa/a;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic h(LIa/d;LIa/e;)LIa/a$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/a$c;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final j()LIa/g$b;
    .locals 2

    .line 1
    new-instance v0, LCa/a$c;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$c;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/a$c;->l()LCa/a;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/a$c;->m(LCa/a;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic k(LIa/g;)LIa/g$b;
    .locals 0

    .line 1
    check-cast p1, LCa/a;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LCa/a$c;->m(LCa/a;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final l()LCa/a;
    .locals 4

    .line 1
    new-instance v0, LCa/a;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LCa/a;-><init>(LCa/a$c;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, LCa/a$c;->b:I

    .line 7
    .line 8
    and-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v2, v3, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v3, 0x0

    .line 15
    :goto_0
    iget v2, p0, LCa/a$c;->c:I

    .line 16
    .line 17
    iput v2, v0, LCa/a;->c:I

    .line 18
    .line 19
    const/4 v2, 0x2

    .line 20
    and-int/2addr v1, v2

    .line 21
    if-ne v1, v2, :cond_1

    .line 22
    .line 23
    iget-object v1, p0, LCa/a$c;->d:Ljava/util/List;

    .line 24
    .line 25
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iput-object v1, p0, LCa/a$c;->d:Ljava/util/List;

    .line 30
    .line 31
    iget v1, p0, LCa/a$c;->b:I

    .line 32
    .line 33
    and-int/lit8 v1, v1, -0x3

    .line 34
    .line 35
    iput v1, p0, LCa/a$c;->b:I

    .line 36
    .line 37
    :cond_1
    iget-object v1, p0, LCa/a$c;->d:Ljava/util/List;

    .line 38
    .line 39
    iput-object v1, v0, LCa/a;->d:Ljava/util/List;

    .line 40
    .line 41
    iput v3, v0, LCa/a;->b:I

    .line 42
    .line 43
    return-object v0
.end method

.method public final m(LCa/a;)V
    .locals 3

    .line 1
    sget-object v0, LCa/a;->v:LCa/a;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p1, LCa/a;->b:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    and-int/2addr v0, v1

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    iget v0, p1, LCa/a;->c:I

    .line 13
    .line 14
    iget v2, p0, LCa/a$c;->b:I

    .line 15
    .line 16
    or-int/2addr v1, v2

    .line 17
    iput v1, p0, LCa/a$c;->b:I

    .line 18
    .line 19
    iput v0, p0, LCa/a$c;->c:I

    .line 20
    .line 21
    :cond_1
    iget-object v0, p1, LCa/a;->d:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_4

    .line 28
    .line 29
    iget-object v0, p0, LCa/a$c;->d:Ljava/util/List;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_2

    .line 36
    .line 37
    iget-object v0, p1, LCa/a;->d:Ljava/util/List;

    .line 38
    .line 39
    iput-object v0, p0, LCa/a$c;->d:Ljava/util/List;

    .line 40
    .line 41
    iget v0, p0, LCa/a$c;->b:I

    .line 42
    .line 43
    and-int/lit8 v0, v0, -0x3

    .line 44
    .line 45
    iput v0, p0, LCa/a$c;->b:I

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    iget v0, p0, LCa/a$c;->b:I

    .line 49
    .line 50
    const/4 v1, 0x2

    .line 51
    and-int/2addr v0, v1

    .line 52
    if-eq v0, v1, :cond_3

    .line 53
    .line 54
    new-instance v0, Ljava/util/ArrayList;

    .line 55
    .line 56
    iget-object v2, p0, LCa/a$c;->d:Ljava/util/List;

    .line 57
    .line 58
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 59
    .line 60
    .line 61
    iput-object v0, p0, LCa/a$c;->d:Ljava/util/List;

    .line 62
    .line 63
    iget v0, p0, LCa/a$c;->b:I

    .line 64
    .line 65
    or-int/2addr v0, v1

    .line 66
    iput v0, p0, LCa/a$c;->b:I

    .line 67
    .line 68
    :cond_3
    iget-object v0, p0, LCa/a$c;->d:Ljava/util/List;

    .line 69
    .line 70
    iget-object v1, p1, LCa/a;->d:Ljava/util/List;

    .line 71
    .line 72
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 73
    .line 74
    .line 75
    :cond_4
    :goto_0
    iget-object v0, p0, LIa/g$b;->a:LIa/c;

    .line 76
    .line 77
    iget-object p1, p1, LCa/a;->a:LIa/c;

    .line 78
    .line 79
    invoke-virtual {v0, p1}, LIa/c;->g(LIa/c;)LIa/c;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    iput-object p1, p0, LIa/g$b;->a:LIa/c;

    .line 84
    .line 85
    return-void
.end method

.method public final n(LIa/d;LIa/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    sget-object v1, LCa/a;->w:LCa/a$a;

    .line 3
    .line 4
    invoke-virtual {v1, p1, p2}, LCa/a$a;->a(LIa/d;LIa/e;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    check-cast p1, LCa/a;
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    .line 10
    invoke-virtual {p0, p1}, LCa/a$c;->m(LCa/a;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception p1

    .line 15
    goto :goto_0

    .line 16
    :catch_0
    move-exception p1

    .line 17
    :try_start_1
    iget-object p2, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 18
    .line 19
    check-cast p2, LCa/a;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    .line 21
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 22
    :catchall_1
    move-exception p1

    .line 23
    move-object v0, p2

    .line 24
    :goto_0
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-virtual {p0, v0}, LCa/a$c;->m(LCa/a;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    throw p1
.end method
