.class public final LCa/g;
.super LIa/g$d;
.source "ProtoBuf.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/g$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$d<",
        "LCa/g;",
        ">;"
    }
.end annotation


# static fields
.field public static final v:LCa/g;

.field public static final w:LCa/g$a;


# instance fields
.field public final b:LIa/c;

.field public c:I

.field public d:I

.field public e:B

.field public i:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCa/g$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/g;->w:LCa/g$a;

    .line 7
    .line 8
    new-instance v0, LCa/g;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-direct {v0, v1}, LCa/g;-><init>(I)V

    .line 12
    .line 13
    .line 14
    sput-object v0, LCa/g;->v:LCa/g;

    .line 15
    .line 16
    iput v1, v0, LCa/g;->d:I

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 6
    invoke-direct {p0}, LIa/g$d;-><init>()V

    const/4 p1, -0x1

    .line 7
    iput-byte p1, p0, LCa/g;->e:B

    .line 8
    iput p1, p0, LCa/g;->i:I

    .line 9
    sget-object p1, LIa/c;->a:LIa/m;

    iput-object p1, p0, LCa/g;->b:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/g$b;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, LIa/g$d;-><init>(LIa/g$c;)V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/g;->e:B

    .line 3
    iput v0, p0, LCa/g;->i:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/g;->b:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g$d;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/g;->e:B

    .line 12
    iput v0, p0, LCa/g;->i:I

    const/4 v0, 0x0

    .line 13
    iput v0, p0, LCa/g;->d:I

    .line 14
    new-instance v1, LIa/c$b;

    invoke-direct {v1}, LIa/c$b;-><init>()V

    const/4 v2, 0x1

    .line 15
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v3

    :cond_0
    :goto_0
    if-nez v0, :cond_3

    .line 16
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v4

    if-eqz v4, :cond_1

    const/16 v5, 0x8

    if-eq v4, v5, :cond_2

    .line 17
    invoke-virtual {p0, p1, v3, p2, v4}, LIa/g$d;->o(LIa/d;Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;LIa/e;I)Z

    move-result v4

    if-nez v4, :cond_0

    :cond_1
    move v0, v2

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :catch_0
    move-exception p1

    goto :goto_1

    :catch_1
    move-exception p1

    goto :goto_2

    .line 18
    :cond_2
    iget v4, p0, LCa/g;->c:I

    or-int/2addr v4, v2

    iput v4, p0, LCa/g;->c:I

    .line 19
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 20
    iput v4, p0, LCa/g;->d:I
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 21
    :goto_1
    :try_start_1
    new-instance p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 23
    iput-object p0, p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 24
    throw p2

    .line 25
    :goto_2
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 26
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    :goto_3
    :try_start_2
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 28
    :catch_2
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/g;->b:LIa/c;

    goto :goto_4

    :catchall_1
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/g;->b:LIa/c;

    .line 29
    throw p1

    .line 30
    :goto_4
    invoke-virtual {p0}, LIa/g$d;->n()V

    .line 31
    throw p1

    .line 32
    :cond_3
    :try_start_3
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 33
    :catch_3
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/g;->b:LIa/c;

    goto :goto_5

    :catchall_2
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/g;->b:LIa/c;

    .line 34
    throw p1

    .line 35
    :goto_5
    invoke-virtual {p0}, LIa/g$d;->n()V

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 2

    .line 1
    iget v0, p0, LCa/g;->i:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/g;->c:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    iget v0, p0, LCa/g;->d:I

    .line 14
    .line 15
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 v0, 0x0

    .line 21
    :goto_0
    invoke-virtual {p0}, LIa/g$d;->k()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    add-int/2addr v1, v0

    .line 26
    iget-object v0, p0, LCa/g;->b:LIa/c;

    .line 27
    .line 28
    invoke-virtual {v0}, LIa/c;->size()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v0, v1

    .line 33
    iput v0, p0, LCa/g;->i:I

    .line 34
    .line 35
    return v0
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/g$b;

    .line 2
    .line 3
    invoke-direct {v0}, LIa/g$c;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final d()LIa/n;
    .locals 1

    .line 1
    sget-object v0, LCa/g;->v:LCa/g;

    .line 2
    .line 3
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/g$b;

    .line 2
    .line 3
    invoke-direct {v0}, LIa/g$c;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/g$b;->m(LCa/g;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/g;->a()I

    .line 2
    .line 3
    .line 4
    new-instance v0, LIa/g$d$a;

    .line 5
    .line 6
    invoke-direct {v0, p0}, LIa/g$d$a;-><init>(LIa/g$d;)V

    .line 7
    .line 8
    .line 9
    iget v1, p0, LCa/g;->c:I

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    and-int/2addr v1, v2

    .line 13
    if-ne v1, v2, :cond_0

    .line 14
    .line 15
    iget v1, p0, LCa/g;->d:I

    .line 16
    .line 17
    invoke-virtual {p1, v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 18
    .line 19
    .line 20
    :cond_0
    const/16 v1, 0xc8

    .line 21
    .line 22
    invoke-virtual {v0, v1, p1}, LIa/g$d$a;->a(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, LCa/g;->b:LIa/c;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final g()Z
    .locals 3

    .line 1
    iget-byte v0, p0, LCa/g;->e:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    invoke-virtual {p0}, LIa/g$d;->j()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_2

    .line 16
    .line 17
    iput-byte v2, p0, LCa/g;->e:B

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    iput-byte v1, p0, LCa/g;->e:B

    .line 21
    .line 22
    return v1
.end method
