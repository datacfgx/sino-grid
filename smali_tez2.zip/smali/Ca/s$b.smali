.class public final LCa/s$b;
.super LIa/g$c;
.source "ProtoBuf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$c<",
        "LCa/s;",
        "LCa/s$b;",
        ">;"
    }
.end annotation


# instance fields
.field public D:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/q;",
            ">;"
        }
    .end annotation
.end field

.field public E:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public d:I

.field public e:I

.field public i:I

.field public v:Z

.field public w:LCa/s$c;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/g$c;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, LCa/s$c;->INV:LCa/s$c;

    .line 5
    .line 6
    iput-object v0, p0, LCa/s$b;->w:LCa/s$c;

    .line 7
    .line 8
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 9
    .line 10
    iput-object v0, p0, LCa/s$b;->D:Ljava/util/List;

    .line 11
    .line 12
    iput-object v0, p0, LCa/s$b;->E:Ljava/util/List;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final bridge synthetic K(LIa/d;LIa/e;)LIa/n$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/s$b;->o(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final c()LIa/n;
    .locals 2

    .line 1
    invoke-virtual {p0}, LCa/s$b;->m()LCa/s;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LCa/s;->g()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    new-instance v0, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;

    .line 13
    .line 14
    invoke-direct {v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;-><init>()V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .line 1
    new-instance v0, LCa/s$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/s$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/s$b;->m()LCa/s;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/s$b;->n(LCa/s;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic h(LIa/d;LIa/e;)LIa/a$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/s$b;->o(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final j()LIa/g$b;
    .locals 2

    .line 1
    new-instance v0, LCa/s$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/s$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/s$b;->m()LCa/s;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/s$b;->n(LCa/s;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic k(LIa/g;)LIa/g$b;
    .locals 0

    .line 1
    check-cast p1, LCa/s;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LCa/s$b;->n(LCa/s;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final m()LCa/s;
    .locals 5

    .line 1
    new-instance v0, LCa/s;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LCa/s;-><init>(LCa/s$b;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, LCa/s$b;->d:I

    .line 7
    .line 8
    and-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v2, v3, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v3, 0x0

    .line 15
    :goto_0
    iget v2, p0, LCa/s$b;->e:I

    .line 16
    .line 17
    iput v2, v0, LCa/s;->d:I

    .line 18
    .line 19
    and-int/lit8 v2, v1, 0x2

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    if-ne v2, v4, :cond_1

    .line 23
    .line 24
    or-int/lit8 v3, v3, 0x2

    .line 25
    .line 26
    :cond_1
    iget v2, p0, LCa/s$b;->i:I

    .line 27
    .line 28
    iput v2, v0, LCa/s;->e:I

    .line 29
    .line 30
    and-int/lit8 v2, v1, 0x4

    .line 31
    .line 32
    const/4 v4, 0x4

    .line 33
    if-ne v2, v4, :cond_2

    .line 34
    .line 35
    or-int/lit8 v3, v3, 0x4

    .line 36
    .line 37
    :cond_2
    iget-boolean v2, p0, LCa/s$b;->v:Z

    .line 38
    .line 39
    iput-boolean v2, v0, LCa/s;->i:Z

    .line 40
    .line 41
    and-int/lit8 v2, v1, 0x8

    .line 42
    .line 43
    const/16 v4, 0x8

    .line 44
    .line 45
    if-ne v2, v4, :cond_3

    .line 46
    .line 47
    or-int/lit8 v3, v3, 0x8

    .line 48
    .line 49
    :cond_3
    iget-object v2, p0, LCa/s$b;->w:LCa/s$c;

    .line 50
    .line 51
    iput-object v2, v0, LCa/s;->v:LCa/s$c;

    .line 52
    .line 53
    const/16 v2, 0x10

    .line 54
    .line 55
    and-int/2addr v1, v2

    .line 56
    if-ne v1, v2, :cond_4

    .line 57
    .line 58
    iget-object v1, p0, LCa/s$b;->D:Ljava/util/List;

    .line 59
    .line 60
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    iput-object v1, p0, LCa/s$b;->D:Ljava/util/List;

    .line 65
    .line 66
    iget v1, p0, LCa/s$b;->d:I

    .line 67
    .line 68
    and-int/lit8 v1, v1, -0x11

    .line 69
    .line 70
    iput v1, p0, LCa/s$b;->d:I

    .line 71
    .line 72
    :cond_4
    iget-object v1, p0, LCa/s$b;->D:Ljava/util/List;

    .line 73
    .line 74
    iput-object v1, v0, LCa/s;->w:Ljava/util/List;

    .line 75
    .line 76
    iget v1, p0, LCa/s$b;->d:I

    .line 77
    .line 78
    const/16 v2, 0x20

    .line 79
    .line 80
    and-int/2addr v1, v2

    .line 81
    if-ne v1, v2, :cond_5

    .line 82
    .line 83
    iget-object v1, p0, LCa/s$b;->E:Ljava/util/List;

    .line 84
    .line 85
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    iput-object v1, p0, LCa/s$b;->E:Ljava/util/List;

    .line 90
    .line 91
    iget v1, p0, LCa/s$b;->d:I

    .line 92
    .line 93
    and-int/lit8 v1, v1, -0x21

    .line 94
    .line 95
    iput v1, p0, LCa/s$b;->d:I

    .line 96
    .line 97
    :cond_5
    iget-object v1, p0, LCa/s$b;->E:Ljava/util/List;

    .line 98
    .line 99
    iput-object v1, v0, LCa/s;->D:Ljava/util/List;

    .line 100
    .line 101
    iput v3, v0, LCa/s;->c:I

    .line 102
    .line 103
    return-object v0
.end method

.method public final n(LCa/s;)V
    .locals 4

    .line 1
    sget-object v0, LCa/s;->H:LCa/s;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p1, LCa/s;->c:I

    .line 7
    .line 8
    and-int/lit8 v1, v0, 0x1

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    if-ne v1, v2, :cond_1

    .line 12
    .line 13
    iget v1, p1, LCa/s;->d:I

    .line 14
    .line 15
    iget v3, p0, LCa/s$b;->d:I

    .line 16
    .line 17
    or-int/2addr v2, v3

    .line 18
    iput v2, p0, LCa/s$b;->d:I

    .line 19
    .line 20
    iput v1, p0, LCa/s$b;->e:I

    .line 21
    .line 22
    :cond_1
    and-int/lit8 v1, v0, 0x2

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    if-ne v1, v2, :cond_2

    .line 26
    .line 27
    iget v1, p1, LCa/s;->e:I

    .line 28
    .line 29
    iget v3, p0, LCa/s$b;->d:I

    .line 30
    .line 31
    or-int/2addr v2, v3

    .line 32
    iput v2, p0, LCa/s$b;->d:I

    .line 33
    .line 34
    iput v1, p0, LCa/s$b;->i:I

    .line 35
    .line 36
    :cond_2
    and-int/lit8 v1, v0, 0x4

    .line 37
    .line 38
    const/4 v2, 0x4

    .line 39
    if-ne v1, v2, :cond_3

    .line 40
    .line 41
    iget-boolean v1, p1, LCa/s;->i:Z

    .line 42
    .line 43
    iget v3, p0, LCa/s$b;->d:I

    .line 44
    .line 45
    or-int/2addr v2, v3

    .line 46
    iput v2, p0, LCa/s$b;->d:I

    .line 47
    .line 48
    iput-boolean v1, p0, LCa/s$b;->v:Z

    .line 49
    .line 50
    :cond_3
    const/16 v1, 0x8

    .line 51
    .line 52
    and-int/2addr v0, v1

    .line 53
    if-ne v0, v1, :cond_4

    .line 54
    .line 55
    iget-object v0, p1, LCa/s;->v:LCa/s$c;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    iget v2, p0, LCa/s$b;->d:I

    .line 61
    .line 62
    or-int/2addr v1, v2

    .line 63
    iput v1, p0, LCa/s$b;->d:I

    .line 64
    .line 65
    iput-object v0, p0, LCa/s$b;->w:LCa/s$c;

    .line 66
    .line 67
    :cond_4
    iget-object v0, p1, LCa/s;->w:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-nez v0, :cond_7

    .line 74
    .line 75
    iget-object v0, p0, LCa/s$b;->D:Ljava/util/List;

    .line 76
    .line 77
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_5

    .line 82
    .line 83
    iget-object v0, p1, LCa/s;->w:Ljava/util/List;

    .line 84
    .line 85
    iput-object v0, p0, LCa/s$b;->D:Ljava/util/List;

    .line 86
    .line 87
    iget v0, p0, LCa/s$b;->d:I

    .line 88
    .line 89
    and-int/lit8 v0, v0, -0x11

    .line 90
    .line 91
    iput v0, p0, LCa/s$b;->d:I

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_5
    iget v0, p0, LCa/s$b;->d:I

    .line 95
    .line 96
    const/16 v1, 0x10

    .line 97
    .line 98
    and-int/2addr v0, v1

    .line 99
    if-eq v0, v1, :cond_6

    .line 100
    .line 101
    new-instance v0, Ljava/util/ArrayList;

    .line 102
    .line 103
    iget-object v2, p0, LCa/s$b;->D:Ljava/util/List;

    .line 104
    .line 105
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 106
    .line 107
    .line 108
    iput-object v0, p0, LCa/s$b;->D:Ljava/util/List;

    .line 109
    .line 110
    iget v0, p0, LCa/s$b;->d:I

    .line 111
    .line 112
    or-int/2addr v0, v1

    .line 113
    iput v0, p0, LCa/s$b;->d:I

    .line 114
    .line 115
    :cond_6
    iget-object v0, p0, LCa/s$b;->D:Ljava/util/List;

    .line 116
    .line 117
    iget-object v1, p1, LCa/s;->w:Ljava/util/List;

    .line 118
    .line 119
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 120
    .line 121
    .line 122
    :cond_7
    :goto_0
    iget-object v0, p1, LCa/s;->D:Ljava/util/List;

    .line 123
    .line 124
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-nez v0, :cond_a

    .line 129
    .line 130
    iget-object v0, p0, LCa/s$b;->E:Ljava/util/List;

    .line 131
    .line 132
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_8

    .line 137
    .line 138
    iget-object v0, p1, LCa/s;->D:Ljava/util/List;

    .line 139
    .line 140
    iput-object v0, p0, LCa/s$b;->E:Ljava/util/List;

    .line 141
    .line 142
    iget v0, p0, LCa/s$b;->d:I

    .line 143
    .line 144
    and-int/lit8 v0, v0, -0x21

    .line 145
    .line 146
    iput v0, p0, LCa/s$b;->d:I

    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_8
    iget v0, p0, LCa/s$b;->d:I

    .line 150
    .line 151
    const/16 v1, 0x20

    .line 152
    .line 153
    and-int/2addr v0, v1

    .line 154
    if-eq v0, v1, :cond_9

    .line 155
    .line 156
    new-instance v0, Ljava/util/ArrayList;

    .line 157
    .line 158
    iget-object v2, p0, LCa/s$b;->E:Ljava/util/List;

    .line 159
    .line 160
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 161
    .line 162
    .line 163
    iput-object v0, p0, LCa/s$b;->E:Ljava/util/List;

    .line 164
    .line 165
    iget v0, p0, LCa/s$b;->d:I

    .line 166
    .line 167
    or-int/2addr v0, v1

    .line 168
    iput v0, p0, LCa/s$b;->d:I

    .line 169
    .line 170
    :cond_9
    iget-object v0, p0, LCa/s$b;->E:Ljava/util/List;

    .line 171
    .line 172
    iget-object v1, p1, LCa/s;->D:Ljava/util/List;

    .line 173
    .line 174
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 175
    .line 176
    .line 177
    :cond_a
    :goto_1
    invoke-virtual {p0, p1}, LIa/g$c;->l(LIa/g$d;)V

    .line 178
    .line 179
    .line 180
    iget-object v0, p0, LIa/g$b;->a:LIa/c;

    .line 181
    .line 182
    iget-object p1, p1, LCa/s;->b:LIa/c;

    .line 183
    .line 184
    invoke-virtual {v0, p1}, LIa/c;->g(LIa/c;)LIa/c;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    iput-object p1, p0, LIa/g$b;->a:LIa/c;

    .line 189
    .line 190
    return-void
.end method

.method public final o(LIa/d;LIa/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    sget-object v1, LCa/s;->I:LCa/s$a;

    .line 3
    .line 4
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    new-instance v1, LCa/s;

    .line 8
    .line 9
    invoke-direct {v1, p1, p2}, LCa/s;-><init>(LIa/d;LIa/e;)V
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v1}, LCa/s$b;->n(LCa/s;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    :try_start_1
    iget-object p2, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 20
    .line 21
    check-cast p2, LCa/s;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    .line 23
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 24
    :catchall_1
    move-exception p1

    .line 25
    move-object v0, p2

    .line 26
    :goto_0
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-virtual {p0, v0}, LCa/s$b;->n(LCa/s;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    throw p1
.end method
