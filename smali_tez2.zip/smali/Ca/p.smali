.class public final LCa/p;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/p$b;
    }
.end annotation


# static fields
.field public static final e:LCa/p;

.field public static final i:LCa/p$a;


# instance fields
.field public final a:LIa/c;

.field public b:LIa/l;

.field public c:B

.field public d:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCa/p$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/p;->i:LCa/p$a;

    .line 7
    .line 8
    new-instance v0, LCa/p;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/p;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/p;->e:LCa/p;

    .line 14
    .line 15
    sget-object v1, LIa/k;->b:LIa/t;

    .line 16
    .line 17
    iput-object v1, v0, LCa/p;->b:LIa/l;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/p;->c:B

    .line 8
    iput v0, p0, LCa/p;->d:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/p;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/p$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/p;->c:B

    .line 3
    iput v0, p0, LCa/p;->d:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/p;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/p;->c:B

    .line 12
    iput v0, p0, LCa/p;->d:I

    .line 13
    sget-object v0, LIa/k;->b:LIa/t;

    iput-object v0, p0, LCa/p;->b:LIa/l;

    .line 14
    new-instance v0, LIa/c$b;

    invoke-direct {v0}, LIa/c$b;-><init>()V

    const/4 v1, 0x1

    .line 15
    invoke-static {v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v2

    const/4 v3, 0x0

    move v4, v3

    :cond_0
    :goto_0
    if-nez v3, :cond_5

    .line 16
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v5

    if-eqz v5, :cond_1

    const/16 v6, 0xa

    if-eq v5, v6, :cond_2

    .line 17
    invoke-virtual {p1, v5, v2}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v5

    if-nez v5, :cond_0

    :cond_1
    move v3, v1

    goto :goto_0

    .line 18
    :cond_2
    invoke-virtual {p1}, LIa/d;->e()LIa/m;

    move-result-object v5

    if-eq v4, v1, :cond_3

    .line 19
    new-instance v6, LIa/k;

    invoke-direct {v6}, LIa/k;-><init>()V

    iput-object v6, p0, LCa/p;->b:LIa/l;

    move v4, v1

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_4

    :catch_0
    move-exception p1

    goto :goto_2

    :catch_1
    move-exception p1

    goto :goto_3

    .line 20
    :cond_3
    :goto_1
    iget-object v6, p0, LCa/p;->b:LIa/l;

    invoke-interface {v6, v5}, LIa/l;->L(LIa/m;)V
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 21
    :goto_2
    :try_start_1
    new-instance v3, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v3, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 23
    iput-object p0, v3, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 24
    throw v3

    .line 25
    :goto_3
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 26
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_4
    if-ne v4, v1, :cond_4

    .line 27
    iget-object v1, p0, LCa/p;->b:LIa/l;

    invoke-interface {v1}, LIa/l;->N()LIa/t;

    move-result-object v1

    iput-object v1, p0, LCa/p;->b:LIa/l;

    .line 28
    :cond_4
    :try_start_2
    invoke-virtual {v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 29
    :catch_2
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/p;->a:LIa/c;

    goto :goto_5

    :catchall_1
    move-exception p1

    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/p;->a:LIa/c;

    .line 30
    throw p1

    .line 31
    :goto_5
    throw p1

    :cond_5
    if-ne v4, v1, :cond_6

    .line 32
    iget-object p1, p0, LCa/p;->b:LIa/l;

    invoke-interface {p1}, LIa/l;->N()LIa/t;

    move-result-object p1

    iput-object p1, p0, LCa/p;->b:LIa/l;

    .line 33
    :cond_6
    :try_start_3
    invoke-virtual {v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 34
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/p;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/p;->a:LIa/c;

    .line 35
    throw p1

    .line 36
    :catch_3
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/p;->a:LIa/c;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 4

    .line 1
    iget v0, p0, LCa/p;->d:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    move v1, v0

    .line 9
    :goto_0
    iget-object v2, p0, LCa/p;->b:LIa/l;

    .line 10
    .line 11
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-ge v0, v2, :cond_1

    .line 16
    .line 17
    iget-object v2, p0, LCa/p;->b:LIa/l;

    .line 18
    .line 19
    invoke-interface {v2, v0}, LIa/l;->J(I)LIa/c;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-virtual {v2}, LIa/c;->size()I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    invoke-static {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->f(I)I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    invoke-virtual {v2}, LIa/c;->size()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    add-int/2addr v2, v3

    .line 36
    add-int/2addr v1, v2

    .line 37
    add-int/lit8 v0, v0, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    iget-object v0, p0, LCa/p;->b:LIa/l;

    .line 41
    .line 42
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    add-int/2addr v0, v1

    .line 47
    iget-object v1, p0, LCa/p;->a:LIa/c;

    .line 48
    .line 49
    invoke-virtual {v1}, LIa/c;->size()I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    add-int/2addr v1, v0

    .line 54
    iput v1, p0, LCa/p;->d:I

    .line 55
    .line 56
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/p$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/p$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/p$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/p$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/p$b;->m(LCa/p;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/p;->a()I

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :goto_0
    iget-object v1, p0, LCa/p;->b:LIa/l;

    .line 6
    .line 7
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-ge v0, v1, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, LCa/p;->b:LIa/l;

    .line 14
    .line 15
    invoke-interface {v1, v0}, LIa/l;->J(I)LIa/c;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const/4 v2, 0x2

    .line 20
    const/4 v3, 0x1

    .line 21
    invoke-virtual {p1, v3, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->x(II)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1}, LIa/c;->size()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    invoke-virtual {p1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 32
    .line 33
    .line 34
    add-int/lit8 v0, v0, 0x1

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    iget-object v0, p0, LCa/p;->a:LIa/c;

    .line 38
    .line 39
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final g()Z
    .locals 2

    .line 1
    iget-byte v0, p0, LCa/p;->c:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    return v0

    .line 11
    :cond_1
    iput-byte v1, p0, LCa/p;->c:B

    .line 12
    .line 13
    return v1
.end method
