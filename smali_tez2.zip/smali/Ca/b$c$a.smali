.class public final LCa/b$c$a;
.super Ljava/lang/Object;
.source "ProtoBuf.java"

# interfaces
.implements LIa/h$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/b$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LIa/h$b<",
        "LCa/b$c;",
        ">;"
    }
.end annotation
