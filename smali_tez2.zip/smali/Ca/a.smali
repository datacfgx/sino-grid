.class public final LCa/a;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/a$c;,
        LCa/a$b;
    }
.end annotation


# static fields
.field public static final v:LCa/a;

.field public static final w:LCa/a$a;


# instance fields
.field public final a:LIa/c;

.field public b:I

.field public c:I

.field public d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/a$b;",
            ">;"
        }
    .end annotation
.end field

.field public e:B

.field public i:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCa/a$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/a;->w:LCa/a$a;

    .line 7
    .line 8
    new-instance v0, LCa/a;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/a;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/a;->v:LCa/a;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput v1, v0, LCa/a;->c:I

    .line 17
    .line 18
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 19
    .line 20
    iput-object v1, v0, LCa/a;->d:Ljava/util/List;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/a;->e:B

    .line 8
    iput v0, p0, LCa/a;->i:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/a;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/a$c;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/a;->e:B

    .line 3
    iput v0, p0, LCa/a;->i:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/a;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/a;->e:B

    .line 12
    iput v0, p0, LCa/a;->i:I

    const/4 v0, 0x0

    .line 13
    iput v0, p0, LCa/a;->c:I

    .line 14
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object v1, p0, LCa/a;->d:Ljava/util/List;

    .line 15
    new-instance v1, LIa/c$b;

    invoke-direct {v1}, LIa/c$b;-><init>()V

    const/4 v2, 0x1

    .line 16
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v3

    move v4, v0

    :cond_0
    :goto_0
    const/4 v5, 0x2

    if-nez v0, :cond_6

    .line 17
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v6

    if-eqz v6, :cond_1

    const/16 v7, 0x8

    if-eq v6, v7, :cond_4

    const/16 v7, 0x12

    if-eq v6, v7, :cond_2

    .line 18
    invoke-virtual {p1, v6, v3}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v5

    if-nez v5, :cond_0

    :cond_1
    move v0, v2

    goto :goto_0

    :cond_2
    and-int/lit8 v6, v4, 0x2

    if-eq v6, v5, :cond_3

    .line 19
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iput-object v6, p0, LCa/a;->d:Ljava/util/List;

    move v4, v5

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_4

    :catch_0
    move-exception p1

    goto :goto_2

    :catch_1
    move-exception p1

    goto :goto_3

    .line 20
    :cond_3
    :goto_1
    iget-object v6, p0, LCa/a;->d:Ljava/util/List;

    sget-object v7, LCa/a$b;->w:LCa/a$b$a;

    invoke-virtual {p1, v7, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 21
    :cond_4
    iget v6, p0, LCa/a;->b:I

    or-int/2addr v6, v2

    iput v6, p0, LCa/a;->b:I

    .line 22
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 23
    iput v6, p0, LCa/a;->c:I
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 24
    :goto_2
    :try_start_1
    new-instance p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 25
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 26
    iput-object p0, p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 27
    throw p2

    .line 28
    :goto_3
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 29
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_4
    and-int/lit8 p2, v4, 0x2

    if-ne p2, v5, :cond_5

    .line 30
    iget-object p2, p0, LCa/a;->d:Ljava/util/List;

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    iput-object p2, p0, LCa/a;->d:Ljava/util/List;

    .line 31
    :cond_5
    :try_start_2
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 32
    :catch_2
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a;->a:LIa/c;

    goto :goto_5

    :catchall_1
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a;->a:LIa/c;

    .line 33
    throw p1

    .line 34
    :goto_5
    throw p1

    :cond_6
    and-int/lit8 p1, v4, 0x2

    if-ne p1, v5, :cond_7

    .line 35
    iget-object p1, p0, LCa/a;->d:Ljava/util/List;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCa/a;->d:Ljava/util/List;

    .line 36
    :cond_7
    :try_start_3
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 37
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/a;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a;->a:LIa/c;

    .line 38
    throw p1

    .line 39
    :catch_3
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/a;->a:LIa/c;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 4

    .line 1
    iget v0, p0, LCa/a;->i:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/a;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_1

    .line 13
    .line 14
    iget v0, p0, LCa/a;->c:I

    .line 15
    .line 16
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    move v0, v2

    .line 22
    :goto_0
    iget-object v1, p0, LCa/a;->d:Ljava/util/List;

    .line 23
    .line 24
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-ge v2, v1, :cond_2

    .line 29
    .line 30
    iget-object v1, p0, LCa/a;->d:Ljava/util/List;

    .line 31
    .line 32
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    check-cast v1, LIa/n;

    .line 37
    .line 38
    const/4 v3, 0x2

    .line 39
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    add-int/2addr v0, v1

    .line 44
    add-int/lit8 v2, v2, 0x1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_2
    iget-object v1, p0, LCa/a;->a:LIa/c;

    .line 48
    .line 49
    invoke-virtual {v1}, LIa/c;->size()I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    add-int/2addr v1, v0

    .line 54
    iput v1, p0, LCa/a;->i:I

    .line 55
    .line 56
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/a$c;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$c;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/a$c;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$c;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/a$c;->m(LCa/a;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/a;->a()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, LCa/a;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    iget v0, p0, LCa/a;->c:I

    .line 11
    .line 12
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 13
    .line 14
    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :goto_0
    iget-object v1, p0, LCa/a;->d:Ljava/util/List;

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-ge v0, v1, :cond_1

    .line 23
    .line 24
    iget-object v1, p0, LCa/a;->d:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, LIa/n;

    .line 31
    .line 32
    const/4 v2, 0x2

    .line 33
    invoke-virtual {p1, v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 34
    .line 35
    .line 36
    add-int/lit8 v0, v0, 0x1

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    iget-object v0, p0, LCa/a;->a:LIa/c;

    .line 40
    .line 41
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public final g()Z
    .locals 4

    .line 1
    iget-byte v0, p0, LCa/a;->e:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    iget v0, p0, LCa/a;->b:I

    .line 12
    .line 13
    and-int/2addr v0, v1

    .line 14
    if-ne v0, v1, :cond_4

    .line 15
    .line 16
    move v0, v2

    .line 17
    :goto_0
    iget-object v3, p0, LCa/a;->d:Ljava/util/List;

    .line 18
    .line 19
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-ge v0, v3, :cond_3

    .line 24
    .line 25
    iget-object v3, p0, LCa/a;->d:Ljava/util/List;

    .line 26
    .line 27
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, LCa/a$b;

    .line 32
    .line 33
    invoke-virtual {v3}, LCa/a$b;->g()Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-nez v3, :cond_2

    .line 38
    .line 39
    iput-byte v2, p0, LCa/a;->e:B

    .line 40
    .line 41
    return v2

    .line 42
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_3
    iput-byte v1, p0, LCa/a;->e:B

    .line 46
    .line 47
    return v1

    .line 48
    :cond_4
    iput-byte v2, p0, LCa/a;->e:B

    .line 49
    .line 50
    return v2
.end method
