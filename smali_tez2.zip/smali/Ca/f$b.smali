.class public final LCa/f$b;
.super LIa/g$b;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$b<",
        "LCa/f;",
        "LCa/f$b;",
        ">;",
        "LIa/o;"
    }
.end annotation


# instance fields
.field public b:I

.field public c:LCa/f$c;

.field public d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/h;",
            ">;"
        }
    .end annotation
.end field

.field public e:LCa/h;

.field public i:LCa/f$d;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/g$b;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, LCa/f$c;->RETURNS_CONSTANT:LCa/f$c;

    .line 5
    .line 6
    iput-object v0, p0, LCa/f$b;->c:LCa/f$c;

    .line 7
    .line 8
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 9
    .line 10
    iput-object v0, p0, LCa/f$b;->d:Ljava/util/List;

    .line 11
    .line 12
    sget-object v0, LCa/h;->G:LCa/h;

    .line 13
    .line 14
    iput-object v0, p0, LCa/f$b;->e:LCa/h;

    .line 15
    .line 16
    sget-object v0, LCa/f$d;->AT_MOST_ONCE:LCa/f$d;

    .line 17
    .line 18
    iput-object v0, p0, LCa/f$b;->i:LCa/f$d;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final bridge synthetic K(LIa/d;LIa/e;)LIa/n$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/f$b;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final c()LIa/n;
    .locals 2

    .line 1
    invoke-virtual {p0}, LCa/f$b;->l()LCa/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LCa/f;->g()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    new-instance v0, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;

    .line 13
    .line 14
    invoke-direct {v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;-><init>()V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .line 1
    new-instance v0, LCa/f$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/f$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/f$b;->l()LCa/f;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/f$b;->m(LCa/f;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic h(LIa/d;LIa/e;)LIa/a$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/f$b;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final j()LIa/g$b;
    .locals 2

    .line 1
    new-instance v0, LCa/f$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/f$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/f$b;->l()LCa/f;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/f$b;->m(LCa/f;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic k(LIa/g;)LIa/g$b;
    .locals 0

    .line 1
    check-cast p1, LCa/f;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LCa/f$b;->m(LCa/f;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final l()LCa/f;
    .locals 5

    .line 1
    new-instance v0, LCa/f;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LCa/f;-><init>(LCa/f$b;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, LCa/f$b;->b:I

    .line 7
    .line 8
    and-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v2, v3, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v3, 0x0

    .line 15
    :goto_0
    iget-object v2, p0, LCa/f$b;->c:LCa/f$c;

    .line 16
    .line 17
    iput-object v2, v0, LCa/f;->c:LCa/f$c;

    .line 18
    .line 19
    and-int/lit8 v2, v1, 0x2

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    if-ne v2, v4, :cond_1

    .line 23
    .line 24
    iget-object v2, p0, LCa/f$b;->d:Ljava/util/List;

    .line 25
    .line 26
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    iput-object v2, p0, LCa/f$b;->d:Ljava/util/List;

    .line 31
    .line 32
    iget v2, p0, LCa/f$b;->b:I

    .line 33
    .line 34
    and-int/lit8 v2, v2, -0x3

    .line 35
    .line 36
    iput v2, p0, LCa/f$b;->b:I

    .line 37
    .line 38
    :cond_1
    iget-object v2, p0, LCa/f$b;->d:Ljava/util/List;

    .line 39
    .line 40
    iput-object v2, v0, LCa/f;->d:Ljava/util/List;

    .line 41
    .line 42
    and-int/lit8 v2, v1, 0x4

    .line 43
    .line 44
    const/4 v4, 0x4

    .line 45
    if-ne v2, v4, :cond_2

    .line 46
    .line 47
    or-int/lit8 v3, v3, 0x2

    .line 48
    .line 49
    :cond_2
    iget-object v2, p0, LCa/f$b;->e:LCa/h;

    .line 50
    .line 51
    iput-object v2, v0, LCa/f;->e:LCa/h;

    .line 52
    .line 53
    const/16 v2, 0x8

    .line 54
    .line 55
    and-int/2addr v1, v2

    .line 56
    if-ne v1, v2, :cond_3

    .line 57
    .line 58
    or-int/lit8 v3, v3, 0x4

    .line 59
    .line 60
    :cond_3
    iget-object v1, p0, LCa/f$b;->i:LCa/f$d;

    .line 61
    .line 62
    iput-object v1, v0, LCa/f;->i:LCa/f$d;

    .line 63
    .line 64
    iput v3, v0, LCa/f;->b:I

    .line 65
    .line 66
    return-object v0
.end method

.method public final m(LCa/f;)V
    .locals 4

    .line 1
    sget-object v0, LCa/f;->D:LCa/f;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p1, LCa/f;->b:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    and-int/2addr v0, v1

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    iget-object v0, p1, LCa/f;->c:LCa/f$c;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget v2, p0, LCa/f$b;->b:I

    .line 18
    .line 19
    or-int/2addr v2, v1

    .line 20
    iput v2, p0, LCa/f$b;->b:I

    .line 21
    .line 22
    iput-object v0, p0, LCa/f$b;->c:LCa/f$c;

    .line 23
    .line 24
    :cond_1
    iget-object v0, p1, LCa/f;->d:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const/4 v2, 0x2

    .line 31
    if-nez v0, :cond_4

    .line 32
    .line 33
    iget-object v0, p0, LCa/f$b;->d:Ljava/util/List;

    .line 34
    .line 35
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    iget-object v0, p1, LCa/f;->d:Ljava/util/List;

    .line 42
    .line 43
    iput-object v0, p0, LCa/f$b;->d:Ljava/util/List;

    .line 44
    .line 45
    iget v0, p0, LCa/f$b;->b:I

    .line 46
    .line 47
    and-int/lit8 v0, v0, -0x3

    .line 48
    .line 49
    iput v0, p0, LCa/f$b;->b:I

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_2
    iget v0, p0, LCa/f$b;->b:I

    .line 53
    .line 54
    and-int/2addr v0, v2

    .line 55
    if-eq v0, v2, :cond_3

    .line 56
    .line 57
    new-instance v0, Ljava/util/ArrayList;

    .line 58
    .line 59
    iget-object v3, p0, LCa/f$b;->d:Ljava/util/List;

    .line 60
    .line 61
    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 62
    .line 63
    .line 64
    iput-object v0, p0, LCa/f$b;->d:Ljava/util/List;

    .line 65
    .line 66
    iget v0, p0, LCa/f$b;->b:I

    .line 67
    .line 68
    or-int/2addr v0, v2

    .line 69
    iput v0, p0, LCa/f$b;->b:I

    .line 70
    .line 71
    :cond_3
    iget-object v0, p0, LCa/f$b;->d:Ljava/util/List;

    .line 72
    .line 73
    iget-object v3, p1, LCa/f;->d:Ljava/util/List;

    .line 74
    .line 75
    invoke-interface {v0, v3}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 76
    .line 77
    .line 78
    :cond_4
    :goto_0
    iget v0, p1, LCa/f;->b:I

    .line 79
    .line 80
    and-int/2addr v0, v2

    .line 81
    if-ne v0, v2, :cond_5

    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_5
    const/4 v1, 0x0

    .line 85
    :goto_1
    const/4 v0, 0x4

    .line 86
    if-eqz v1, :cond_7

    .line 87
    .line 88
    iget-object v1, p1, LCa/f;->e:LCa/h;

    .line 89
    .line 90
    iget v2, p0, LCa/f$b;->b:I

    .line 91
    .line 92
    and-int/2addr v2, v0

    .line 93
    if-ne v2, v0, :cond_6

    .line 94
    .line 95
    iget-object v2, p0, LCa/f$b;->e:LCa/h;

    .line 96
    .line 97
    sget-object v3, LCa/h;->G:LCa/h;

    .line 98
    .line 99
    if-eq v2, v3, :cond_6

    .line 100
    .line 101
    new-instance v3, LCa/h$b;

    .line 102
    .line 103
    invoke-direct {v3}, LCa/h$b;-><init>()V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v3, v2}, LCa/h$b;->m(LCa/h;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v3, v1}, LCa/h$b;->m(LCa/h;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v3}, LCa/h$b;->l()LCa/h;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    iput-object v1, p0, LCa/f$b;->e:LCa/h;

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_6
    iput-object v1, p0, LCa/f$b;->e:LCa/h;

    .line 120
    .line 121
    :goto_2
    iget v1, p0, LCa/f$b;->b:I

    .line 122
    .line 123
    or-int/2addr v1, v0

    .line 124
    iput v1, p0, LCa/f$b;->b:I

    .line 125
    .line 126
    :cond_7
    iget v1, p1, LCa/f;->b:I

    .line 127
    .line 128
    and-int/2addr v1, v0

    .line 129
    if-ne v1, v0, :cond_8

    .line 130
    .line 131
    iget-object v0, p1, LCa/f;->i:LCa/f$d;

    .line 132
    .line 133
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    iget v1, p0, LCa/f$b;->b:I

    .line 137
    .line 138
    or-int/lit8 v1, v1, 0x8

    .line 139
    .line 140
    iput v1, p0, LCa/f$b;->b:I

    .line 141
    .line 142
    iput-object v0, p0, LCa/f$b;->i:LCa/f$d;

    .line 143
    .line 144
    :cond_8
    iget-object v0, p0, LIa/g$b;->a:LIa/c;

    .line 145
    .line 146
    iget-object p1, p1, LCa/f;->a:LIa/c;

    .line 147
    .line 148
    invoke-virtual {v0, p1}, LIa/c;->g(LIa/c;)LIa/c;

    .line 149
    .line 150
    .line 151
    move-result-object p1

    .line 152
    iput-object p1, p0, LIa/g$b;->a:LIa/c;

    .line 153
    .line 154
    return-void
.end method

.method public final n(LIa/d;LIa/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    sget-object v1, LCa/f;->E:LCa/f$a;

    .line 3
    .line 4
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    new-instance v1, LCa/f;

    .line 8
    .line 9
    invoke-direct {v1, p1, p2}, LCa/f;-><init>(LIa/d;LIa/e;)V
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v1}, LCa/f$b;->m(LCa/f;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    :try_start_1
    iget-object p2, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 20
    .line 21
    check-cast p2, LCa/f;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    .line 23
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 24
    :catchall_1
    move-exception p1

    .line 25
    move-object v0, p2

    .line 26
    :goto_0
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-virtual {p0, v0}, LCa/f$b;->m(LCa/f;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    throw p1
.end method
