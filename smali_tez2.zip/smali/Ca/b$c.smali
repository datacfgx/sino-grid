.class public final enum LCa/b$c;
.super Ljava/lang/Enum;
.source "ProtoBuf.java"

# interfaces
.implements LIa/h$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LCa/b$c;",
        ">;",
        "LIa/h$a;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LCa/b$c;

.field public static final enum ANNOTATION_CLASS:LCa/b$c;

.field public static final enum CLASS:LCa/b$c;

.field public static final enum COMPANION_OBJECT:LCa/b$c;

.field public static final enum ENUM_CLASS:LCa/b$c;

.field public static final enum ENUM_ENTRY:LCa/b$c;

.field public static final enum INTERFACE:LCa/b$c;

.field public static final enum OBJECT:LCa/b$c;

.field private static internalValueMap:LIa/h$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/h$b<",
            "LCa/b$c;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .line 1
    .line 2
    new-instance v0, LCa/b$c;

    .line 3
    .line 4
    const-string v1, "CLASS"

    .line 5
    const/4 v2, 0x0

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, v2, v2, v2}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 9
    .line 10
    sput-object v0, LCa/b$c;->CLASS:LCa/b$c;

    .line 11
    .line 12
    new-instance v1, LCa/b$c;

    .line 13
    .line 14
    const-string v2, "INTERFACE"

    .line 15
    const/4 v3, 0x1

    .line 16
    .line 17
    .line 18
    invoke-direct {v1, v2, v3, v3, v3}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 19
    .line 20
    sput-object v1, LCa/b$c;->INTERFACE:LCa/b$c;

    .line 21
    .line 22
    new-instance v2, LCa/b$c;

    .line 23
    .line 24
    const/4 v3, 0x0

    sget-object v3, Lf8/XNr/MicQxpPzLqqd;->arCGMv:Ljava/lang/String;

    .line 25
    const/4 v4, 0x2

    .line 26
    .line 27
    .line 28
    invoke-direct {v2, v3, v4, v4, v4}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 29
    .line 30
    sput-object v2, LCa/b$c;->ENUM_CLASS:LCa/b$c;

    .line 31
    .line 32
    new-instance v3, LCa/b$c;

    .line 33
    .line 34
    const-string v4, "ENUM_ENTRY"

    .line 35
    const/4 v5, 0x3

    .line 36
    .line 37
    .line 38
    invoke-direct {v3, v4, v5, v5, v5}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 39
    .line 40
    sput-object v3, LCa/b$c;->ENUM_ENTRY:LCa/b$c;

    .line 41
    .line 42
    new-instance v4, LCa/b$c;

    .line 43
    .line 44
    const-string v5, "ANNOTATION_CLASS"

    .line 45
    const/4 v6, 0x4

    .line 46
    .line 47
    .line 48
    invoke-direct {v4, v5, v6, v6, v6}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 49
    .line 50
    sput-object v4, LCa/b$c;->ANNOTATION_CLASS:LCa/b$c;

    .line 51
    .line 52
    new-instance v5, LCa/b$c;

    .line 53
    .line 54
    const-string v6, "OBJECT"

    .line 55
    const/4 v7, 0x5

    .line 56
    .line 57
    .line 58
    invoke-direct {v5, v6, v7, v7, v7}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 59
    .line 60
    sput-object v5, LCa/b$c;->OBJECT:LCa/b$c;

    .line 61
    .line 62
    new-instance v6, LCa/b$c;

    .line 63
    .line 64
    const-string v7, "COMPANION_OBJECT"

    .line 65
    const/4 v8, 0x6

    .line 66
    .line 67
    .line 68
    invoke-direct {v6, v7, v8, v8, v8}, LCa/b$c;-><init>(Ljava/lang/String;III)V

    .line 69
    .line 70
    sput-object v6, LCa/b$c;->COMPANION_OBJECT:LCa/b$c;

    .line 71
    .line 72
    .line 73
    filled-new-array/range {v0 .. v6}, [LCa/b$c;

    .line 74
    move-result-object v0

    .line 75
    .line 76
    sput-object v0, LCa/b$c;->$VALUES:[LCa/b$c;

    .line 77
    .line 78
    new-instance v0, LCa/b$c$a;

    .line 79
    .line 80
    .line 81
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 82
    .line 83
    sput-object v0, LCa/b$c;->internalValueMap:LIa/h$b;

    .line 84
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;III)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p4, p0, LCa/b$c;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(I)LCa/b$c;
    .locals 0

    packed-switch p0, :pswitch_data_0

    const/4 p0, 0x0

    return-object p0

    .line 2
    :pswitch_0
    sget-object p0, LCa/b$c;->COMPANION_OBJECT:LCa/b$c;

    return-object p0

    .line 3
    :pswitch_1
    sget-object p0, LCa/b$c;->OBJECT:LCa/b$c;

    return-object p0

    .line 4
    :pswitch_2
    sget-object p0, LCa/b$c;->ANNOTATION_CLASS:LCa/b$c;

    return-object p0

    .line 5
    :pswitch_3
    sget-object p0, LCa/b$c;->ENUM_ENTRY:LCa/b$c;

    return-object p0

    .line 6
    :pswitch_4
    sget-object p0, LCa/b$c;->ENUM_CLASS:LCa/b$c;

    return-object p0

    .line 7
    :pswitch_5
    sget-object p0, LCa/b$c;->INTERFACE:LCa/b$c;

    return-object p0

    .line 8
    :pswitch_6
    sget-object p0, LCa/b$c;->CLASS:LCa/b$c;

    return-object p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static valueOf(Ljava/lang/String;)LCa/b$c;
    .locals 1

    .line 1
    const-class v0, LCa/b$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LCa/b$c;

    return-object p0
.end method

.method public static values()[LCa/b$c;
    .locals 1

    .line 1
    sget-object v0, LCa/b$c;->$VALUES:[LCa/b$c;

    .line 2
    .line 3
    invoke-virtual {v0}, [LCa/b$c;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LCa/b$c;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .locals 1

    .line 1
    iget v0, p0, LCa/b$c;->value:I

    .line 2
    .line 3
    return v0
.end method
