.class public final LCa/c$b;
.super LIa/g$b;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$b<",
        "LCa/c;",
        "LCa/c$b;",
        ">;",
        "LIa/o;"
    }
.end annotation


# instance fields
.field public b:I

.field public c:I

.field public d:LIa/m;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/g$b;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, LIa/c;->a:LIa/m;

    .line 5
    .line 6
    iput-object v0, p0, LCa/c$b;->d:LIa/m;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic K(LIa/d;LIa/e;)LIa/n$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/c$b;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final c()LIa/n;
    .locals 2

    .line 1
    invoke-virtual {p0}, LCa/c$b;->l()LCa/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LCa/c;->g()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    new-instance v0, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;

    .line 13
    .line 14
    invoke-direct {v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/UninitializedMessageException;-><init>()V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .line 1
    new-instance v0, LCa/c$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/c$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/c$b;->l()LCa/c;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/c$b;->m(LCa/c;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic h(LIa/d;LIa/e;)LIa/a$a;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, LCa/c$b;->n(LIa/d;LIa/e;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final j()LIa/g$b;
    .locals 2

    .line 1
    new-instance v0, LCa/c$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/c$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LCa/c$b;->l()LCa/c;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, LCa/c$b;->m(LCa/c;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic k(LIa/g;)LIa/g$b;
    .locals 0

    .line 1
    check-cast p1, LCa/c;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LCa/c$b;->m(LCa/c;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final l()LCa/c;
    .locals 4

    .line 1
    new-instance v0, LCa/c;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LCa/c;-><init>(LCa/c$b;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, LCa/c$b;->b:I

    .line 7
    .line 8
    and-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v2, v3, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v3, 0x0

    .line 15
    :goto_0
    iget v2, p0, LCa/c$b;->c:I

    .line 16
    .line 17
    iput v2, v0, LCa/c;->c:I

    .line 18
    .line 19
    const/4 v2, 0x2

    .line 20
    and-int/2addr v1, v2

    .line 21
    if-ne v1, v2, :cond_1

    .line 22
    .line 23
    or-int/lit8 v3, v3, 0x2

    .line 24
    .line 25
    :cond_1
    iget-object v1, p0, LCa/c$b;->d:LIa/m;

    .line 26
    .line 27
    iput-object v1, v0, LCa/c;->d:LIa/m;

    .line 28
    .line 29
    iput v3, v0, LCa/c;->b:I

    .line 30
    .line 31
    return-object v0
.end method

.method public final m(LCa/c;)V
    .locals 4

    .line 1
    sget-object v0, LCa/c;->v:LCa/c;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p1, LCa/c;->b:I

    .line 7
    .line 8
    and-int/lit8 v1, v0, 0x1

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    if-ne v1, v2, :cond_1

    .line 12
    .line 13
    iget v1, p1, LCa/c;->c:I

    .line 14
    .line 15
    iget v3, p0, LCa/c$b;->b:I

    .line 16
    .line 17
    or-int/2addr v2, v3

    .line 18
    iput v2, p0, LCa/c$b;->b:I

    .line 19
    .line 20
    iput v1, p0, LCa/c$b;->c:I

    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x2

    .line 23
    and-int/2addr v0, v1

    .line 24
    if-ne v0, v1, :cond_2

    .line 25
    .line 26
    iget-object v0, p1, LCa/c;->d:LIa/m;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    iget v2, p0, LCa/c$b;->b:I

    .line 32
    .line 33
    or-int/2addr v1, v2

    .line 34
    iput v1, p0, LCa/c$b;->b:I

    .line 35
    .line 36
    iput-object v0, p0, LCa/c$b;->d:LIa/m;

    .line 37
    .line 38
    :cond_2
    iget-object v0, p0, LIa/g$b;->a:LIa/c;

    .line 39
    .line 40
    iget-object p1, p1, LCa/c;->a:LIa/c;

    .line 41
    .line 42
    invoke-virtual {v0, p1}, LIa/c;->g(LIa/c;)LIa/c;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    iput-object p1, p0, LIa/g$b;->a:LIa/c;

    .line 47
    .line 48
    return-void
.end method

.method public final n(LIa/d;LIa/e;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 p2, 0x0

    .line 2
    :try_start_0
    sget-object v0, LCa/c;->w:LCa/c$a;

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    new-instance v0, LCa/c;

    .line 8
    .line 9
    invoke-direct {v0, p1}, LCa/c;-><init>(LIa/d;)V
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v0}, LCa/c$b;->m(LCa/c;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    :try_start_1
    iget-object v0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 20
    .line 21
    check-cast v0, LCa/c;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    .line 23
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 24
    :catchall_1
    move-exception p1

    .line 25
    move-object p2, v0

    .line 26
    :goto_0
    if-eqz p2, :cond_0

    .line 27
    .line 28
    invoke-virtual {p0, p2}, LCa/c$b;->m(LCa/c;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    throw p1
.end method
