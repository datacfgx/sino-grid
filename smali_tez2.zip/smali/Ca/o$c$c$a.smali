.class public final LCa/o$c$c$a;
.super Ljava/lang/Object;
.source "ProtoBuf.java"

# interfaces
.implements LIa/h$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/o$c$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "LIa/h$b<",
        "LCa/o$c$c;",
        ">;"
    }
.end annotation
