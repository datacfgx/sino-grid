.class public final LCa/i;
.super LIa/g$d;
.source "ProtoBuf.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/i$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/g$d<",
        "LCa/i;",
        ">;"
    }
.end annotation


# static fields
.field public static final Q:LCa/i;

.field public static final R:LCa/i$a;


# instance fields
.field public D:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/s;",
            ">;"
        }
    .end annotation
.end field

.field public E:LCa/q;

.field public F:I

.field public G:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/q;",
            ">;"
        }
    .end annotation
.end field

.field public H:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public I:I

.field public J:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/u;",
            ">;"
        }
    .end annotation
.end field

.field public K:LCa/t;

.field public L:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public M:LCa/e;

.field public N:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/c;",
            ">;"
        }
    .end annotation
.end field

.field public O:B

.field public P:I

.field public final b:LIa/c;

.field public c:I

.field public d:I

.field public e:I

.field public i:I

.field public v:LCa/q;

.field public w:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCa/i$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/i;->R:LCa/i$a;

    .line 7
    .line 8
    new-instance v0, LCa/i;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-direct {v0, v1}, LCa/i;-><init>(I)V

    .line 12
    .line 13
    .line 14
    sput-object v0, LCa/i;->Q:LCa/i;

    .line 15
    .line 16
    invoke-virtual {v0}, LCa/i;->q()V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 7
    invoke-direct {p0}, LIa/g$d;-><init>()V

    const/4 p1, -0x1

    .line 8
    iput p1, p0, LCa/i;->I:I

    .line 9
    iput-byte p1, p0, LCa/i;->O:B

    .line 10
    iput p1, p0, LCa/i;->P:I

    .line 11
    sget-object p1, LIa/c;->a:LIa/m;

    iput-object p1, p0, LCa/i;->b:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/i$b;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, LIa/g$d;-><init>(LIa/g$c;)V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, LCa/i;->I:I

    .line 3
    iput-byte v0, p0, LCa/i;->O:B

    .line 4
    iput v0, p0, LCa/i;->P:I

    .line 5
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 6
    iput-object p1, p0, LCa/i;->b:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 18
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    .line 12
    invoke-direct {v1}, LIa/g$d;-><init>()V

    const/4 v3, -0x1

    .line 13
    iput v3, v1, LCa/i;->I:I

    .line 14
    iput-byte v3, v1, LCa/i;->O:B

    .line 15
    iput v3, v1, LCa/i;->P:I

    .line 16
    invoke-virtual {v1}, LCa/i;->q()V

    .line 17
    new-instance v3, LIa/c$b;

    invoke-direct {v3}, LIa/c$b;-><init>()V

    const/4 v4, 0x1

    .line 18
    invoke-static {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v5

    const/4 v6, 0x0

    move v7, v6

    :goto_0
    const/16 v8, 0x4000

    const/16 v9, 0x400

    const/16 v10, 0x20

    const/16 v11, 0x100

    const/16 v12, 0x200

    const/16 v13, 0x1000

    if-nez v6, :cond_19

    .line 19
    :try_start_0
    invoke-virtual {v0}, LIa/d;->n()I

    move-result v14

    const/4 v15, 0x0

    sparse-switch v14, :sswitch_data_0

    .line 20
    invoke-virtual {v1, v0, v5, v2, v14}, LIa/g$d;->o(LIa/d;Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;LIa/e;I)Z

    move-result v8

    if-nez v8, :cond_1

    move v6, v4

    move/from16 v17, v6

    goto/16 :goto_4

    :catchall_0
    move-exception v0

    goto/16 :goto_7

    :catch_0
    move-exception v0

    goto/16 :goto_5

    :catch_1
    move-exception v0

    goto/16 :goto_6

    :sswitch_0
    and-int/lit16 v14, v7, 0x4000

    if-eq v14, v8, :cond_0

    .line 21
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    iput-object v14, v1, LCa/i;->N:Ljava/util/List;

    or-int/lit16 v7, v7, 0x4000

    .line 22
    :cond_0
    iget-object v14, v1, LCa/i;->N:Ljava/util/List;

    sget-object v15, LCa/c;->w:LCa/c$a;

    invoke-virtual {v0, v15, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v15

    invoke-interface {v14, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    :goto_1
    move/from16 v17, v4

    goto/16 :goto_4

    .line 23
    :sswitch_1
    iget v14, v1, LCa/i;->c:I

    and-int/2addr v14, v11

    if-ne v14, v11, :cond_2

    .line 24
    iget-object v14, v1, LCa/i;->M:LCa/e;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    new-instance v15, LCa/e$b;

    invoke-direct {v15}, LCa/e$b;-><init>()V

    .line 26
    invoke-virtual {v15, v14}, LCa/e$b;->m(LCa/e;)V

    .line 27
    :cond_2
    sget-object v14, LCa/e;->i:LCa/e$a;

    invoke-virtual {v0, v14, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v14

    check-cast v14, LCa/e;

    iput-object v14, v1, LCa/i;->M:LCa/e;

    if-eqz v15, :cond_3

    .line 28
    invoke-virtual {v15, v14}, LCa/e$b;->m(LCa/e;)V

    .line 29
    invoke-virtual {v15}, LCa/e$b;->l()LCa/e;

    move-result-object v14

    iput-object v14, v1, LCa/i;->M:LCa/e;

    .line 30
    :cond_3
    iget v14, v1, LCa/i;->c:I

    or-int/2addr v14, v11

    iput v14, v1, LCa/i;->c:I

    goto :goto_1

    .line 31
    :sswitch_2
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v14

    .line 32
    invoke-virtual {v0, v14}, LIa/d;->d(I)I

    move-result v14

    and-int/lit16 v15, v7, 0x1000

    if-eq v15, v13, :cond_4

    .line 33
    invoke-virtual {v0}, LIa/d;->b()I

    move-result v15

    if-lez v15, :cond_4

    .line 34
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    iput-object v15, v1, LCa/i;->L:Ljava/util/List;

    or-int/lit16 v7, v7, 0x1000

    .line 35
    :cond_4
    :goto_2
    invoke-virtual {v0}, LIa/d;->b()I

    move-result v15

    if-lez v15, :cond_5

    .line 36
    iget-object v15, v1, LCa/i;->L:Ljava/util/List;

    .line 37
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v16

    move/from16 v17, v4

    .line 38
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v15, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move/from16 v4, v17

    goto :goto_2

    :cond_5
    move/from16 v17, v4

    .line 39
    invoke-virtual {v0, v14}, LIa/d;->c(I)V

    goto/16 :goto_4

    :sswitch_3
    move/from16 v17, v4

    and-int/lit16 v4, v7, 0x1000

    if-eq v4, v13, :cond_6

    .line 40
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v1, LCa/i;->L:Ljava/util/List;

    or-int/lit16 v7, v7, 0x1000

    .line 41
    :cond_6
    iget-object v4, v1, LCa/i;->L:Ljava/util/List;

    .line 42
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v14

    .line 43
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-interface {v4, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_4

    :sswitch_4
    move/from16 v17, v4

    .line 44
    iget v4, v1, LCa/i;->c:I

    const/16 v14, 0x80

    and-int/2addr v4, v14

    if-ne v4, v14, :cond_7

    .line 45
    iget-object v4, v1, LCa/i;->K:LCa/t;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    invoke-static {v4}, LCa/t;->j(LCa/t;)LCa/t$b;

    move-result-object v15

    .line 47
    :cond_7
    sget-object v4, LCa/t;->w:LCa/t$a;

    invoke-virtual {v0, v4, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v4

    check-cast v4, LCa/t;

    iput-object v4, v1, LCa/i;->K:LCa/t;

    if-eqz v15, :cond_8

    .line 48
    invoke-virtual {v15, v4}, LCa/t$b;->m(LCa/t;)V

    .line 49
    invoke-virtual {v15}, LCa/t$b;->l()LCa/t;

    move-result-object v4

    iput-object v4, v1, LCa/i;->K:LCa/t;

    .line 50
    :cond_8
    iget v4, v1, LCa/i;->c:I

    or-int/2addr v4, v14

    iput v4, v1, LCa/i;->c:I

    goto/16 :goto_4

    :sswitch_5
    move/from16 v17, v4

    .line 51
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 52
    invoke-virtual {v0, v4}, LIa/d;->d(I)I

    move-result v4

    and-int/lit16 v14, v7, 0x200

    if-eq v14, v12, :cond_9

    .line 53
    invoke-virtual {v0}, LIa/d;->b()I

    move-result v14

    if-lez v14, :cond_9

    .line 54
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    iput-object v14, v1, LCa/i;->H:Ljava/util/List;

    or-int/lit16 v7, v7, 0x200

    .line 55
    :cond_9
    :goto_3
    invoke-virtual {v0}, LIa/d;->b()I

    move-result v14

    if-lez v14, :cond_a

    .line 56
    iget-object v14, v1, LCa/i;->H:Ljava/util/List;

    .line 57
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v15

    .line 58
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-interface {v14, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3

    .line 59
    :cond_a
    invoke-virtual {v0, v4}, LIa/d;->c(I)V

    goto/16 :goto_4

    :sswitch_6
    move/from16 v17, v4

    and-int/lit16 v4, v7, 0x200

    if-eq v4, v12, :cond_b

    .line 60
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v1, LCa/i;->H:Ljava/util/List;

    or-int/lit16 v7, v7, 0x200

    .line 61
    :cond_b
    iget-object v4, v1, LCa/i;->H:Ljava/util/List;

    .line 62
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v14

    .line 63
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-interface {v4, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_4

    :sswitch_7
    move/from16 v17, v4

    and-int/lit16 v4, v7, 0x100

    if-eq v4, v11, :cond_c

    .line 64
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v1, LCa/i;->G:Ljava/util/List;

    or-int/lit16 v7, v7, 0x100

    .line 65
    :cond_c
    iget-object v4, v1, LCa/i;->G:Ljava/util/List;

    sget-object v14, LCa/q;->P:LCa/q$a;

    invoke-virtual {v0, v14, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v14

    invoke-interface {v4, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_4

    :sswitch_8
    move/from16 v17, v4

    .line 66
    iget v4, v1, LCa/i;->c:I

    or-int/lit8 v4, v4, 0x1

    iput v4, v1, LCa/i;->c:I

    .line 67
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 68
    iput v4, v1, LCa/i;->d:I

    goto/16 :goto_4

    :sswitch_9
    move/from16 v17, v4

    .line 69
    iget v4, v1, LCa/i;->c:I

    or-int/lit8 v4, v4, 0x40

    iput v4, v1, LCa/i;->c:I

    .line 70
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 71
    iput v4, v1, LCa/i;->F:I

    goto/16 :goto_4

    :sswitch_a
    move/from16 v17, v4

    .line 72
    iget v4, v1, LCa/i;->c:I

    or-int/lit8 v4, v4, 0x10

    iput v4, v1, LCa/i;->c:I

    .line 73
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 74
    iput v4, v1, LCa/i;->w:I

    goto/16 :goto_4

    :sswitch_b
    move/from16 v17, v4

    and-int/lit16 v4, v7, 0x400

    if-eq v4, v9, :cond_d

    .line 75
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v1, LCa/i;->J:Ljava/util/List;

    or-int/lit16 v7, v7, 0x400

    .line 76
    :cond_d
    iget-object v4, v1, LCa/i;->J:Ljava/util/List;

    sget-object v14, LCa/u;->H:LCa/u$a;

    invoke-virtual {v0, v14, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v14

    invoke-interface {v4, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_4

    :sswitch_c
    move/from16 v17, v4

    .line 77
    iget v4, v1, LCa/i;->c:I

    and-int/2addr v4, v10

    if-ne v4, v10, :cond_e

    .line 78
    iget-object v4, v1, LCa/i;->E:LCa/q;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    invoke-static {v4}, LCa/q;->r(LCa/q;)LCa/q$c;

    move-result-object v15

    .line 80
    :cond_e
    sget-object v4, LCa/q;->P:LCa/q$a;

    invoke-virtual {v0, v4, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v4

    check-cast v4, LCa/q;

    iput-object v4, v1, LCa/i;->E:LCa/q;

    if-eqz v15, :cond_f

    .line 81
    invoke-virtual {v15, v4}, LCa/q$c;->n(LCa/q;)LCa/q$c;

    .line 82
    invoke-virtual {v15}, LCa/q$c;->m()LCa/q;

    move-result-object v4

    iput-object v4, v1, LCa/i;->E:LCa/q;

    .line 83
    :cond_f
    iget v4, v1, LCa/i;->c:I

    or-int/2addr v4, v10

    iput v4, v1, LCa/i;->c:I

    goto :goto_4

    :sswitch_d
    move/from16 v17, v4

    and-int/lit8 v4, v7, 0x20

    if-eq v4, v10, :cond_10

    .line 84
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v1, LCa/i;->D:Ljava/util/List;

    or-int/lit8 v7, v7, 0x20

    .line 85
    :cond_10
    iget-object v4, v1, LCa/i;->D:Ljava/util/List;

    sget-object v14, LCa/s;->I:LCa/s$a;

    invoke-virtual {v0, v14, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v14

    invoke-interface {v4, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :sswitch_e
    move/from16 v17, v4

    .line 86
    iget v4, v1, LCa/i;->c:I

    const/16 v14, 0x8

    and-int/2addr v4, v14

    if-ne v4, v14, :cond_11

    .line 87
    iget-object v4, v1, LCa/i;->v:LCa/q;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    invoke-static {v4}, LCa/q;->r(LCa/q;)LCa/q$c;

    move-result-object v15

    .line 89
    :cond_11
    sget-object v4, LCa/q;->P:LCa/q$a;

    invoke-virtual {v0, v4, v2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v4

    check-cast v4, LCa/q;

    iput-object v4, v1, LCa/i;->v:LCa/q;

    if-eqz v15, :cond_12

    .line 90
    invoke-virtual {v15, v4}, LCa/q$c;->n(LCa/q;)LCa/q$c;

    .line 91
    invoke-virtual {v15}, LCa/q$c;->m()LCa/q;

    move-result-object v4

    iput-object v4, v1, LCa/i;->v:LCa/q;

    .line 92
    :cond_12
    iget v4, v1, LCa/i;->c:I

    or-int/2addr v4, v14

    iput v4, v1, LCa/i;->c:I

    goto :goto_4

    :sswitch_f
    move/from16 v17, v4

    .line 93
    iget v4, v1, LCa/i;->c:I

    or-int/lit8 v4, v4, 0x4

    iput v4, v1, LCa/i;->c:I

    .line 94
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 95
    iput v4, v1, LCa/i;->i:I

    goto :goto_4

    :sswitch_10
    move/from16 v17, v4

    .line 96
    iget v4, v1, LCa/i;->c:I

    or-int/lit8 v4, v4, 0x2

    iput v4, v1, LCa/i;->c:I

    .line 97
    invoke-virtual {v0}, LIa/d;->k()I

    move-result v4

    .line 98
    iput v4, v1, LCa/i;->e:I
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_4

    :sswitch_11
    move/from16 v17, v4

    move/from16 v6, v17

    :goto_4
    move/from16 v4, v17

    goto/16 :goto_0

    .line 99
    :goto_5
    :try_start_1
    new-instance v2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 100
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 101
    iput-object v1, v2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 102
    throw v2

    .line 103
    :goto_6
    iput-object v1, v0, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 104
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_7
    and-int/lit8 v2, v7, 0x20

    if-ne v2, v10, :cond_13

    .line 105
    iget-object v2, v1, LCa/i;->D:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->D:Ljava/util/List;

    :cond_13
    and-int/lit16 v2, v7, 0x400

    if-ne v2, v9, :cond_14

    .line 106
    iget-object v2, v1, LCa/i;->J:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->J:Ljava/util/List;

    :cond_14
    and-int/lit16 v2, v7, 0x100

    if-ne v2, v11, :cond_15

    .line 107
    iget-object v2, v1, LCa/i;->G:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->G:Ljava/util/List;

    :cond_15
    and-int/lit16 v2, v7, 0x200

    if-ne v2, v12, :cond_16

    .line 108
    iget-object v2, v1, LCa/i;->H:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->H:Ljava/util/List;

    :cond_16
    and-int/lit16 v2, v7, 0x1000

    if-ne v2, v13, :cond_17

    .line 109
    iget-object v2, v1, LCa/i;->L:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->L:Ljava/util/List;

    :cond_17
    and-int/lit16 v2, v7, 0x4000

    if-ne v2, v8, :cond_18

    .line 110
    iget-object v2, v1, LCa/i;->N:Ljava/util/List;

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, LCa/i;->N:Ljava/util/List;

    .line 111
    :cond_18
    :try_start_2
    invoke-virtual {v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 112
    :catch_2
    invoke-virtual {v3}, LIa/c$b;->i()LIa/c;

    move-result-object v2

    iput-object v2, v1, LCa/i;->b:LIa/c;

    goto :goto_8

    :catchall_1
    move-exception v0

    invoke-virtual {v3}, LIa/c$b;->i()LIa/c;

    move-result-object v2

    iput-object v2, v1, LCa/i;->b:LIa/c;

    .line 113
    throw v0

    .line 114
    :goto_8
    invoke-virtual {v1}, LIa/g$d;->n()V

    .line 115
    throw v0

    :cond_19
    and-int/lit8 v0, v7, 0x20

    if-ne v0, v10, :cond_1a

    .line 116
    iget-object v0, v1, LCa/i;->D:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->D:Ljava/util/List;

    :cond_1a
    and-int/lit16 v0, v7, 0x400

    if-ne v0, v9, :cond_1b

    .line 117
    iget-object v0, v1, LCa/i;->J:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->J:Ljava/util/List;

    :cond_1b
    and-int/lit16 v0, v7, 0x100

    if-ne v0, v11, :cond_1c

    .line 118
    iget-object v0, v1, LCa/i;->G:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->G:Ljava/util/List;

    :cond_1c
    and-int/lit16 v0, v7, 0x200

    if-ne v0, v12, :cond_1d

    .line 119
    iget-object v0, v1, LCa/i;->H:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->H:Ljava/util/List;

    :cond_1d
    and-int/lit16 v0, v7, 0x1000

    if-ne v0, v13, :cond_1e

    .line 120
    iget-object v0, v1, LCa/i;->L:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->L:Ljava/util/List;

    :cond_1e
    and-int/lit16 v0, v7, 0x4000

    if-ne v0, v8, :cond_1f

    .line 121
    iget-object v0, v1, LCa/i;->N:Ljava/util/List;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, LCa/i;->N:Ljava/util/List;

    .line 122
    :cond_1f
    :try_start_3
    invoke-virtual {v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 123
    :catch_3
    invoke-virtual {v3}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, v1, LCa/i;->b:LIa/c;

    goto :goto_9

    :catchall_2
    move-exception v0

    invoke-virtual {v3}, LIa/c$b;->i()LIa/c;

    move-result-object v2

    iput-object v2, v1, LCa/i;->b:LIa/c;

    .line 124
    throw v0

    .line 125
    :goto_9
    invoke-virtual {v1}, LIa/g$d;->n()V

    return-void

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_11
        0x8 -> :sswitch_10
        0x10 -> :sswitch_f
        0x1a -> :sswitch_e
        0x22 -> :sswitch_d
        0x2a -> :sswitch_c
        0x32 -> :sswitch_b
        0x38 -> :sswitch_a
        0x40 -> :sswitch_9
        0x48 -> :sswitch_8
        0x52 -> :sswitch_7
        0x58 -> :sswitch_6
        0x5a -> :sswitch_5
        0xf2 -> :sswitch_4
        0xf8 -> :sswitch_3
        0xfa -> :sswitch_2
        0x102 -> :sswitch_1
        0x10a -> :sswitch_0
    .end sparse-switch
.end method


# virtual methods
.method public final a()I
    .locals 9

    .line 1
    iget v0, p0, LCa/i;->P:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/i;->c:I

    .line 8
    .line 9
    const/4 v1, 0x2

    .line 10
    and-int/2addr v0, v1

    .line 11
    const/4 v2, 0x0

    .line 12
    const/4 v3, 0x1

    .line 13
    if-ne v0, v1, :cond_1

    .line 14
    .line 15
    iget v0, p0, LCa/i;->e:I

    .line 16
    .line 17
    invoke-static {v3, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    move v0, v2

    .line 23
    :goto_0
    iget v4, p0, LCa/i;->c:I

    .line 24
    .line 25
    const/4 v5, 0x4

    .line 26
    and-int/2addr v4, v5

    .line 27
    if-ne v4, v5, :cond_2

    .line 28
    .line 29
    iget v4, p0, LCa/i;->i:I

    .line 30
    .line 31
    invoke-static {v1, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    add-int/2addr v0, v4

    .line 36
    :cond_2
    iget v4, p0, LCa/i;->c:I

    .line 37
    .line 38
    const/16 v6, 0x8

    .line 39
    .line 40
    and-int/2addr v4, v6

    .line 41
    if-ne v4, v6, :cond_3

    .line 42
    .line 43
    const/4 v4, 0x3

    .line 44
    iget-object v7, p0, LCa/i;->v:LCa/q;

    .line 45
    .line 46
    invoke-static {v4, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    add-int/2addr v0, v4

    .line 51
    :cond_3
    move v4, v2

    .line 52
    :goto_1
    iget-object v7, p0, LCa/i;->D:Ljava/util/List;

    .line 53
    .line 54
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    if-ge v4, v7, :cond_4

    .line 59
    .line 60
    iget-object v7, p0, LCa/i;->D:Ljava/util/List;

    .line 61
    .line 62
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    check-cast v7, LIa/n;

    .line 67
    .line 68
    invoke-static {v5, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 69
    .line 70
    .line 71
    move-result v7

    .line 72
    add-int/2addr v0, v7

    .line 73
    add-int/lit8 v4, v4, 0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_4
    iget v4, p0, LCa/i;->c:I

    .line 77
    .line 78
    const/16 v5, 0x20

    .line 79
    .line 80
    and-int/2addr v4, v5

    .line 81
    if-ne v4, v5, :cond_5

    .line 82
    .line 83
    const/4 v4, 0x5

    .line 84
    iget-object v7, p0, LCa/i;->E:LCa/q;

    .line 85
    .line 86
    invoke-static {v4, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    add-int/2addr v0, v4

    .line 91
    :cond_5
    move v4, v2

    .line 92
    :goto_2
    iget-object v7, p0, LCa/i;->J:Ljava/util/List;

    .line 93
    .line 94
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 95
    .line 96
    .line 97
    move-result v7

    .line 98
    if-ge v4, v7, :cond_6

    .line 99
    .line 100
    iget-object v7, p0, LCa/i;->J:Ljava/util/List;

    .line 101
    .line 102
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v7

    .line 106
    check-cast v7, LIa/n;

    .line 107
    .line 108
    const/4 v8, 0x6

    .line 109
    invoke-static {v8, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 110
    .line 111
    .line 112
    move-result v7

    .line 113
    add-int/2addr v0, v7

    .line 114
    add-int/lit8 v4, v4, 0x1

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_6
    iget v4, p0, LCa/i;->c:I

    .line 118
    .line 119
    const/16 v7, 0x10

    .line 120
    .line 121
    and-int/2addr v4, v7

    .line 122
    if-ne v4, v7, :cond_7

    .line 123
    .line 124
    const/4 v4, 0x7

    .line 125
    iget v7, p0, LCa/i;->w:I

    .line 126
    .line 127
    invoke-static {v4, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 128
    .line 129
    .line 130
    move-result v4

    .line 131
    add-int/2addr v0, v4

    .line 132
    :cond_7
    iget v4, p0, LCa/i;->c:I

    .line 133
    .line 134
    const/16 v7, 0x40

    .line 135
    .line 136
    and-int/2addr v4, v7

    .line 137
    if-ne v4, v7, :cond_8

    .line 138
    .line 139
    iget v4, p0, LCa/i;->F:I

    .line 140
    .line 141
    invoke-static {v6, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 142
    .line 143
    .line 144
    move-result v4

    .line 145
    add-int/2addr v0, v4

    .line 146
    :cond_8
    iget v4, p0, LCa/i;->c:I

    .line 147
    .line 148
    and-int/2addr v4, v3

    .line 149
    if-ne v4, v3, :cond_9

    .line 150
    .line 151
    const/16 v3, 0x9

    .line 152
    .line 153
    iget v4, p0, LCa/i;->d:I

    .line 154
    .line 155
    invoke-static {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    add-int/2addr v0, v3

    .line 160
    :cond_9
    move v3, v2

    .line 161
    :goto_3
    iget-object v4, p0, LCa/i;->G:Ljava/util/List;

    .line 162
    .line 163
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 164
    .line 165
    .line 166
    move-result v4

    .line 167
    if-ge v3, v4, :cond_a

    .line 168
    .line 169
    iget-object v4, p0, LCa/i;->G:Ljava/util/List;

    .line 170
    .line 171
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v4

    .line 175
    check-cast v4, LIa/n;

    .line 176
    .line 177
    const/16 v6, 0xa

    .line 178
    .line 179
    invoke-static {v6, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 180
    .line 181
    .line 182
    move-result v4

    .line 183
    add-int/2addr v0, v4

    .line 184
    add-int/lit8 v3, v3, 0x1

    .line 185
    .line 186
    goto :goto_3

    .line 187
    :cond_a
    move v3, v2

    .line 188
    move v4, v3

    .line 189
    :goto_4
    iget-object v6, p0, LCa/i;->H:Ljava/util/List;

    .line 190
    .line 191
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 192
    .line 193
    .line 194
    move-result v6

    .line 195
    if-ge v3, v6, :cond_b

    .line 196
    .line 197
    iget-object v6, p0, LCa/i;->H:Ljava/util/List;

    .line 198
    .line 199
    invoke-interface {v6, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v6

    .line 203
    check-cast v6, Ljava/lang/Integer;

    .line 204
    .line 205
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 206
    .line 207
    .line 208
    move-result v6

    .line 209
    invoke-static {v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->c(I)I

    .line 210
    .line 211
    .line 212
    move-result v6

    .line 213
    add-int/2addr v4, v6

    .line 214
    add-int/lit8 v3, v3, 0x1

    .line 215
    .line 216
    goto :goto_4

    .line 217
    :cond_b
    add-int/2addr v0, v4

    .line 218
    iget-object v3, p0, LCa/i;->H:Ljava/util/List;

    .line 219
    .line 220
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    if-nez v3, :cond_c

    .line 225
    .line 226
    add-int/lit8 v0, v0, 0x1

    .line 227
    .line 228
    invoke-static {v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->c(I)I

    .line 229
    .line 230
    .line 231
    move-result v3

    .line 232
    add-int/2addr v0, v3

    .line 233
    :cond_c
    iput v4, p0, LCa/i;->I:I

    .line 234
    .line 235
    iget v3, p0, LCa/i;->c:I

    .line 236
    .line 237
    const/16 v4, 0x80

    .line 238
    .line 239
    and-int/2addr v3, v4

    .line 240
    if-ne v3, v4, :cond_d

    .line 241
    .line 242
    const/16 v3, 0x1e

    .line 243
    .line 244
    iget-object v4, p0, LCa/i;->K:LCa/t;

    .line 245
    .line 246
    invoke-static {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    add-int/2addr v0, v3

    .line 251
    :cond_d
    move v3, v2

    .line 252
    move v4, v3

    .line 253
    :goto_5
    iget-object v6, p0, LCa/i;->L:Ljava/util/List;

    .line 254
    .line 255
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 256
    .line 257
    .line 258
    move-result v6

    .line 259
    if-ge v3, v6, :cond_e

    .line 260
    .line 261
    iget-object v6, p0, LCa/i;->L:Ljava/util/List;

    .line 262
    .line 263
    invoke-interface {v6, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object v6

    .line 267
    check-cast v6, Ljava/lang/Integer;

    .line 268
    .line 269
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 270
    .line 271
    .line 272
    move-result v6

    .line 273
    invoke-static {v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->c(I)I

    .line 274
    .line 275
    .line 276
    move-result v6

    .line 277
    add-int/2addr v4, v6

    .line 278
    add-int/lit8 v3, v3, 0x1

    .line 279
    .line 280
    goto :goto_5

    .line 281
    :cond_e
    add-int/2addr v0, v4

    .line 282
    iget-object v3, p0, LCa/i;->L:Ljava/util/List;

    .line 283
    .line 284
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    mul-int/2addr v3, v1

    .line 289
    add-int/2addr v3, v0

    .line 290
    iget v0, p0, LCa/i;->c:I

    .line 291
    .line 292
    const/16 v1, 0x100

    .line 293
    .line 294
    and-int/2addr v0, v1

    .line 295
    if-ne v0, v1, :cond_f

    .line 296
    .line 297
    iget-object v0, p0, LCa/i;->M:LCa/e;

    .line 298
    .line 299
    invoke-static {v5, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 300
    .line 301
    .line 302
    move-result v0

    .line 303
    add-int/2addr v3, v0

    .line 304
    :cond_f
    :goto_6
    iget-object v0, p0, LCa/i;->N:Ljava/util/List;

    .line 305
    .line 306
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    if-ge v2, v0, :cond_10

    .line 311
    .line 312
    iget-object v0, p0, LCa/i;->N:Ljava/util/List;

    .line 313
    .line 314
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    check-cast v0, LIa/n;

    .line 319
    .line 320
    const/16 v1, 0x21

    .line 321
    .line 322
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 323
    .line 324
    .line 325
    move-result v0

    .line 326
    add-int/2addr v3, v0

    .line 327
    add-int/lit8 v2, v2, 0x1

    .line 328
    .line 329
    goto :goto_6

    .line 330
    :cond_10
    invoke-virtual {p0}, LIa/g$d;->k()I

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    add-int/2addr v0, v3

    .line 335
    iget-object v1, p0, LCa/i;->b:LIa/c;

    .line 336
    .line 337
    invoke-virtual {v1}, LIa/c;->size()I

    .line 338
    .line 339
    .line 340
    move-result v1

    .line 341
    add-int/2addr v1, v0

    .line 342
    iput v1, p0, LCa/i;->P:I

    .line 343
    .line 344
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/i$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/i$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final d()LIa/n;
    .locals 1

    .line 1
    sget-object v0, LCa/i;->Q:LCa/i;

    .line 2
    .line 3
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/i$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/i$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/i$b;->n(LCa/i;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/i;->a()I

    .line 2
    .line 3
    .line 4
    new-instance v0, LIa/g$d$a;

    .line 5
    .line 6
    invoke-direct {v0, p0}, LIa/g$d$a;-><init>(LIa/g$d;)V

    .line 7
    .line 8
    .line 9
    iget v1, p0, LCa/i;->c:I

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    and-int/2addr v1, v2

    .line 13
    const/4 v3, 0x1

    .line 14
    if-ne v1, v2, :cond_0

    .line 15
    .line 16
    iget v1, p0, LCa/i;->e:I

    .line 17
    .line 18
    invoke-virtual {p1, v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 19
    .line 20
    .line 21
    :cond_0
    iget v1, p0, LCa/i;->c:I

    .line 22
    .line 23
    const/4 v4, 0x4

    .line 24
    and-int/2addr v1, v4

    .line 25
    if-ne v1, v4, :cond_1

    .line 26
    .line 27
    iget v1, p0, LCa/i;->i:I

    .line 28
    .line 29
    invoke-virtual {p1, v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 30
    .line 31
    .line 32
    :cond_1
    iget v1, p0, LCa/i;->c:I

    .line 33
    .line 34
    const/16 v2, 0x8

    .line 35
    .line 36
    and-int/2addr v1, v2

    .line 37
    if-ne v1, v2, :cond_2

    .line 38
    .line 39
    const/4 v1, 0x3

    .line 40
    iget-object v5, p0, LCa/i;->v:LCa/q;

    .line 41
    .line 42
    invoke-virtual {p1, v1, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 43
    .line 44
    .line 45
    :cond_2
    const/4 v1, 0x0

    .line 46
    move v5, v1

    .line 47
    :goto_0
    iget-object v6, p0, LCa/i;->D:Ljava/util/List;

    .line 48
    .line 49
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    if-ge v5, v6, :cond_3

    .line 54
    .line 55
    iget-object v6, p0, LCa/i;->D:Ljava/util/List;

    .line 56
    .line 57
    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    check-cast v6, LIa/n;

    .line 62
    .line 63
    invoke-virtual {p1, v4, v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 64
    .line 65
    .line 66
    add-int/lit8 v5, v5, 0x1

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_3
    iget v4, p0, LCa/i;->c:I

    .line 70
    .line 71
    const/16 v5, 0x20

    .line 72
    .line 73
    and-int/2addr v4, v5

    .line 74
    if-ne v4, v5, :cond_4

    .line 75
    .line 76
    const/4 v4, 0x5

    .line 77
    iget-object v6, p0, LCa/i;->E:LCa/q;

    .line 78
    .line 79
    invoke-virtual {p1, v4, v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 80
    .line 81
    .line 82
    :cond_4
    move v4, v1

    .line 83
    :goto_1
    iget-object v6, p0, LCa/i;->J:Ljava/util/List;

    .line 84
    .line 85
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 86
    .line 87
    .line 88
    move-result v6

    .line 89
    if-ge v4, v6, :cond_5

    .line 90
    .line 91
    iget-object v6, p0, LCa/i;->J:Ljava/util/List;

    .line 92
    .line 93
    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    check-cast v6, LIa/n;

    .line 98
    .line 99
    const/4 v7, 0x6

    .line 100
    invoke-virtual {p1, v7, v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 101
    .line 102
    .line 103
    add-int/lit8 v4, v4, 0x1

    .line 104
    .line 105
    goto :goto_1

    .line 106
    :cond_5
    iget v4, p0, LCa/i;->c:I

    .line 107
    .line 108
    const/16 v6, 0x10

    .line 109
    .line 110
    and-int/2addr v4, v6

    .line 111
    if-ne v4, v6, :cond_6

    .line 112
    .line 113
    const/4 v4, 0x7

    .line 114
    iget v6, p0, LCa/i;->w:I

    .line 115
    .line 116
    invoke-virtual {p1, v4, v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 117
    .line 118
    .line 119
    :cond_6
    iget v4, p0, LCa/i;->c:I

    .line 120
    .line 121
    const/16 v6, 0x40

    .line 122
    .line 123
    and-int/2addr v4, v6

    .line 124
    if-ne v4, v6, :cond_7

    .line 125
    .line 126
    iget v4, p0, LCa/i;->F:I

    .line 127
    .line 128
    invoke-virtual {p1, v2, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 129
    .line 130
    .line 131
    :cond_7
    iget v2, p0, LCa/i;->c:I

    .line 132
    .line 133
    and-int/2addr v2, v3

    .line 134
    if-ne v2, v3, :cond_8

    .line 135
    .line 136
    const/16 v2, 0x9

    .line 137
    .line 138
    iget v3, p0, LCa/i;->d:I

    .line 139
    .line 140
    invoke-virtual {p1, v2, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 141
    .line 142
    .line 143
    :cond_8
    move v2, v1

    .line 144
    :goto_2
    iget-object v3, p0, LCa/i;->G:Ljava/util/List;

    .line 145
    .line 146
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 147
    .line 148
    .line 149
    move-result v3

    .line 150
    if-ge v2, v3, :cond_9

    .line 151
    .line 152
    iget-object v3, p0, LCa/i;->G:Ljava/util/List;

    .line 153
    .line 154
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v3

    .line 158
    check-cast v3, LIa/n;

    .line 159
    .line 160
    const/16 v4, 0xa

    .line 161
    .line 162
    invoke-virtual {p1, v4, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 163
    .line 164
    .line 165
    add-int/lit8 v2, v2, 0x1

    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_9
    iget-object v2, p0, LCa/i;->H:Ljava/util/List;

    .line 169
    .line 170
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 171
    .line 172
    .line 173
    move-result v2

    .line 174
    if-lez v2, :cond_a

    .line 175
    .line 176
    const/16 v2, 0x5a

    .line 177
    .line 178
    invoke-virtual {p1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 179
    .line 180
    .line 181
    iget v2, p0, LCa/i;->I:I

    .line 182
    .line 183
    invoke-virtual {p1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 184
    .line 185
    .line 186
    :cond_a
    move v2, v1

    .line 187
    :goto_3
    iget-object v3, p0, LCa/i;->H:Ljava/util/List;

    .line 188
    .line 189
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 190
    .line 191
    .line 192
    move-result v3

    .line 193
    if-ge v2, v3, :cond_b

    .line 194
    .line 195
    iget-object v3, p0, LCa/i;->H:Ljava/util/List;

    .line 196
    .line 197
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v3

    .line 201
    check-cast v3, Ljava/lang/Integer;

    .line 202
    .line 203
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 204
    .line 205
    .line 206
    move-result v3

    .line 207
    invoke-virtual {p1, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->n(I)V

    .line 208
    .line 209
    .line 210
    add-int/lit8 v2, v2, 0x1

    .line 211
    .line 212
    goto :goto_3

    .line 213
    :cond_b
    iget v2, p0, LCa/i;->c:I

    .line 214
    .line 215
    const/16 v3, 0x80

    .line 216
    .line 217
    and-int/2addr v2, v3

    .line 218
    if-ne v2, v3, :cond_c

    .line 219
    .line 220
    const/16 v2, 0x1e

    .line 221
    .line 222
    iget-object v3, p0, LCa/i;->K:LCa/t;

    .line 223
    .line 224
    invoke-virtual {p1, v2, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 225
    .line 226
    .line 227
    :cond_c
    move v2, v1

    .line 228
    :goto_4
    iget-object v3, p0, LCa/i;->L:Ljava/util/List;

    .line 229
    .line 230
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 231
    .line 232
    .line 233
    move-result v3

    .line 234
    if-ge v2, v3, :cond_d

    .line 235
    .line 236
    iget-object v3, p0, LCa/i;->L:Ljava/util/List;

    .line 237
    .line 238
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v3

    .line 242
    check-cast v3, Ljava/lang/Integer;

    .line 243
    .line 244
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 245
    .line 246
    .line 247
    move-result v3

    .line 248
    const/16 v4, 0x1f

    .line 249
    .line 250
    invoke-virtual {p1, v4, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 251
    .line 252
    .line 253
    add-int/lit8 v2, v2, 0x1

    .line 254
    .line 255
    goto :goto_4

    .line 256
    :cond_d
    iget v2, p0, LCa/i;->c:I

    .line 257
    .line 258
    const/16 v3, 0x100

    .line 259
    .line 260
    and-int/2addr v2, v3

    .line 261
    if-ne v2, v3, :cond_e

    .line 262
    .line 263
    iget-object v2, p0, LCa/i;->M:LCa/e;

    .line 264
    .line 265
    invoke-virtual {p1, v5, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 266
    .line 267
    .line 268
    :cond_e
    :goto_5
    iget-object v2, p0, LCa/i;->N:Ljava/util/List;

    .line 269
    .line 270
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 271
    .line 272
    .line 273
    move-result v2

    .line 274
    if-ge v1, v2, :cond_f

    .line 275
    .line 276
    iget-object v2, p0, LCa/i;->N:Ljava/util/List;

    .line 277
    .line 278
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object v2

    .line 282
    check-cast v2, LIa/n;

    .line 283
    .line 284
    const/16 v3, 0x21

    .line 285
    .line 286
    invoke-virtual {p1, v3, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 287
    .line 288
    .line 289
    add-int/lit8 v1, v1, 0x1

    .line 290
    .line 291
    goto :goto_5

    .line 292
    :cond_f
    const/16 v1, 0x4a38

    .line 293
    .line 294
    invoke-virtual {v0, v1, p1}, LIa/g$d$a;->a(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V

    .line 295
    .line 296
    .line 297
    iget-object v0, p0, LCa/i;->b:LIa/c;

    .line 298
    .line 299
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 300
    .line 301
    .line 302
    return-void
.end method

.method public final g()Z
    .locals 5

    .line 1
    iget-byte v0, p0, LCa/i;->O:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    iget v0, p0, LCa/i;->c:I

    .line 12
    .line 13
    and-int/lit8 v3, v0, 0x4

    .line 14
    .line 15
    const/4 v4, 0x4

    .line 16
    if-ne v3, v4, :cond_f

    .line 17
    .line 18
    const/16 v3, 0x8

    .line 19
    .line 20
    and-int/2addr v0, v3

    .line 21
    if-ne v0, v3, :cond_2

    .line 22
    .line 23
    iget-object v0, p0, LCa/i;->v:LCa/q;

    .line 24
    .line 25
    invoke-virtual {v0}, LCa/q;->g()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_2

    .line 30
    .line 31
    iput-byte v2, p0, LCa/i;->O:B

    .line 32
    .line 33
    return v2

    .line 34
    :cond_2
    move v0, v2

    .line 35
    :goto_0
    iget-object v3, p0, LCa/i;->D:Ljava/util/List;

    .line 36
    .line 37
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-ge v0, v3, :cond_4

    .line 42
    .line 43
    iget-object v3, p0, LCa/i;->D:Ljava/util/List;

    .line 44
    .line 45
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    check-cast v3, LCa/s;

    .line 50
    .line 51
    invoke-virtual {v3}, LCa/s;->g()Z

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-nez v3, :cond_3

    .line 56
    .line 57
    iput-byte v2, p0, LCa/i;->O:B

    .line 58
    .line 59
    return v2

    .line 60
    :cond_3
    add-int/lit8 v0, v0, 0x1

    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_4
    iget v0, p0, LCa/i;->c:I

    .line 64
    .line 65
    const/16 v3, 0x20

    .line 66
    .line 67
    and-int/2addr v0, v3

    .line 68
    if-ne v0, v3, :cond_5

    .line 69
    .line 70
    iget-object v0, p0, LCa/i;->E:LCa/q;

    .line 71
    .line 72
    invoke-virtual {v0}, LCa/q;->g()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-nez v0, :cond_5

    .line 77
    .line 78
    iput-byte v2, p0, LCa/i;->O:B

    .line 79
    .line 80
    return v2

    .line 81
    :cond_5
    move v0, v2

    .line 82
    :goto_1
    iget-object v3, p0, LCa/i;->G:Ljava/util/List;

    .line 83
    .line 84
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    if-ge v0, v3, :cond_7

    .line 89
    .line 90
    iget-object v3, p0, LCa/i;->G:Ljava/util/List;

    .line 91
    .line 92
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    check-cast v3, LCa/q;

    .line 97
    .line 98
    invoke-virtual {v3}, LCa/q;->g()Z

    .line 99
    .line 100
    .line 101
    move-result v3

    .line 102
    if-nez v3, :cond_6

    .line 103
    .line 104
    iput-byte v2, p0, LCa/i;->O:B

    .line 105
    .line 106
    return v2

    .line 107
    :cond_6
    add-int/lit8 v0, v0, 0x1

    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_7
    move v0, v2

    .line 111
    :goto_2
    iget-object v3, p0, LCa/i;->J:Ljava/util/List;

    .line 112
    .line 113
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    if-ge v0, v3, :cond_9

    .line 118
    .line 119
    iget-object v3, p0, LCa/i;->J:Ljava/util/List;

    .line 120
    .line 121
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    check-cast v3, LCa/u;

    .line 126
    .line 127
    invoke-virtual {v3}, LCa/u;->g()Z

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    if-nez v3, :cond_8

    .line 132
    .line 133
    iput-byte v2, p0, LCa/i;->O:B

    .line 134
    .line 135
    return v2

    .line 136
    :cond_8
    add-int/lit8 v0, v0, 0x1

    .line 137
    .line 138
    goto :goto_2

    .line 139
    :cond_9
    iget v0, p0, LCa/i;->c:I

    .line 140
    .line 141
    const/16 v3, 0x80

    .line 142
    .line 143
    and-int/2addr v0, v3

    .line 144
    if-ne v0, v3, :cond_a

    .line 145
    .line 146
    iget-object v0, p0, LCa/i;->K:LCa/t;

    .line 147
    .line 148
    invoke-virtual {v0}, LCa/t;->g()Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-nez v0, :cond_a

    .line 153
    .line 154
    iput-byte v2, p0, LCa/i;->O:B

    .line 155
    .line 156
    return v2

    .line 157
    :cond_a
    iget v0, p0, LCa/i;->c:I

    .line 158
    .line 159
    const/16 v3, 0x100

    .line 160
    .line 161
    and-int/2addr v0, v3

    .line 162
    if-ne v0, v3, :cond_b

    .line 163
    .line 164
    iget-object v0, p0, LCa/i;->M:LCa/e;

    .line 165
    .line 166
    invoke-virtual {v0}, LCa/e;->g()Z

    .line 167
    .line 168
    .line 169
    move-result v0

    .line 170
    if-nez v0, :cond_b

    .line 171
    .line 172
    iput-byte v2, p0, LCa/i;->O:B

    .line 173
    .line 174
    return v2

    .line 175
    :cond_b
    move v0, v2

    .line 176
    :goto_3
    iget-object v3, p0, LCa/i;->N:Ljava/util/List;

    .line 177
    .line 178
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 179
    .line 180
    .line 181
    move-result v3

    .line 182
    if-ge v0, v3, :cond_d

    .line 183
    .line 184
    iget-object v3, p0, LCa/i;->N:Ljava/util/List;

    .line 185
    .line 186
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    check-cast v3, LCa/c;

    .line 191
    .line 192
    invoke-virtual {v3}, LCa/c;->g()Z

    .line 193
    .line 194
    .line 195
    move-result v3

    .line 196
    if-nez v3, :cond_c

    .line 197
    .line 198
    iput-byte v2, p0, LCa/i;->O:B

    .line 199
    .line 200
    return v2

    .line 201
    :cond_c
    add-int/lit8 v0, v0, 0x1

    .line 202
    .line 203
    goto :goto_3

    .line 204
    :cond_d
    invoke-virtual {p0}, LIa/g$d;->j()Z

    .line 205
    .line 206
    .line 207
    move-result v0

    .line 208
    if-nez v0, :cond_e

    .line 209
    .line 210
    iput-byte v2, p0, LCa/i;->O:B

    .line 211
    .line 212
    return v2

    .line 213
    :cond_e
    iput-byte v1, p0, LCa/i;->O:B

    .line 214
    .line 215
    return v1

    .line 216
    :cond_f
    iput-byte v2, p0, LCa/i;->O:B

    .line 217
    .line 218
    return v2
.end method

.method public final q()V
    .locals 3

    .line 1
    const/4 v0, 0x6

    .line 2
    iput v0, p0, LCa/i;->d:I

    .line 3
    .line 4
    iput v0, p0, LCa/i;->e:I

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, LCa/i;->i:I

    .line 8
    .line 9
    sget-object v1, LCa/q;->O:LCa/q;

    .line 10
    .line 11
    iput-object v1, p0, LCa/i;->v:LCa/q;

    .line 12
    .line 13
    iput v0, p0, LCa/i;->w:I

    .line 14
    .line 15
    sget-object v2, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 16
    .line 17
    iput-object v2, p0, LCa/i;->D:Ljava/util/List;

    .line 18
    .line 19
    iput-object v1, p0, LCa/i;->E:LCa/q;

    .line 20
    .line 21
    iput v0, p0, LCa/i;->F:I

    .line 22
    .line 23
    iput-object v2, p0, LCa/i;->G:Ljava/util/List;

    .line 24
    .line 25
    iput-object v2, p0, LCa/i;->H:Ljava/util/List;

    .line 26
    .line 27
    iput-object v2, p0, LCa/i;->J:Ljava/util/List;

    .line 28
    .line 29
    sget-object v0, LCa/t;->v:LCa/t;

    .line 30
    .line 31
    iput-object v0, p0, LCa/i;->K:LCa/t;

    .line 32
    .line 33
    iput-object v2, p0, LCa/i;->L:Ljava/util/List;

    .line 34
    .line 35
    sget-object v0, LCa/e;->e:LCa/e;

    .line 36
    .line 37
    iput-object v0, p0, LCa/i;->M:LCa/e;

    .line 38
    .line 39
    iput-object v2, p0, LCa/i;->N:Ljava/util/List;

    .line 40
    .line 41
    return-void
.end method
