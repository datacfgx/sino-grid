.class public final LCa/m$a;
.super LIa/b;
.source "ProtoBuf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/b<",
        "LCa/m;",
        ">;"
    }
.end annotation


# virtual methods
.method public final a(LIa/d;LIa/e;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1
    new-instance v0, LCa/m;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, LCa/m;-><init>(LIa/d;LIa/e;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
