.class public final LCa/q$b;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/q$b$b;,
        LCa/q$b$c;
    }
.end annotation


# static fields
.field public static final D:LCa/q$b$a;

.field public static final w:LCa/q$b;


# instance fields
.field public final a:LIa/c;

.field public b:I

.field public c:LCa/q$b$c;

.field public d:LCa/q;

.field public e:I

.field public i:B

.field public v:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LCa/q$b$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/q$b;->D:LCa/q$b$a;

    .line 7
    .line 8
    new-instance v0, LCa/q$b;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/q$b;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/q$b;->w:LCa/q$b;

    .line 14
    .line 15
    sget-object v1, LCa/q$b$c;->INV:LCa/q$b$c;

    .line 16
    .line 17
    iput-object v1, v0, LCa/q$b;->c:LCa/q$b$c;

    .line 18
    .line 19
    sget-object v1, LCa/q;->O:LCa/q;

    .line 20
    .line 21
    iput-object v1, v0, LCa/q$b;->d:LCa/q;

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    iput v1, v0, LCa/q$b;->e:I

    .line 25
    .line 26
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/q$b;->i:B

    .line 8
    iput v0, p0, LCa/q$b;->v:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/q$b;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/q$b$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/q$b;->i:B

    .line 3
    iput v0, p0, LCa/q$b;->v:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/q$b;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/q$b;->i:B

    .line 12
    iput v0, p0, LCa/q$b;->v:I

    .line 13
    sget-object v0, LCa/q$b$c;->INV:LCa/q$b$c;

    iput-object v0, p0, LCa/q$b;->c:LCa/q$b$c;

    .line 14
    sget-object v0, LCa/q;->O:LCa/q;

    .line 15
    iput-object v0, p0, LCa/q$b;->d:LCa/q;

    const/4 v0, 0x0

    .line 16
    iput v0, p0, LCa/q$b;->e:I

    .line 17
    new-instance v1, LIa/c$b;

    invoke-direct {v1}, LIa/c$b;-><init>()V

    const/4 v2, 0x1

    .line 18
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v3

    :cond_0
    :goto_0
    if-nez v0, :cond_8

    .line 19
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v4

    if-eqz v4, :cond_1

    const/16 v5, 0x8

    if-eq v4, v5, :cond_6

    const/16 v5, 0x12

    if-eq v4, v5, :cond_3

    const/16 v5, 0x18

    if-eq v4, v5, :cond_2

    .line 20
    invoke-virtual {p1, v4, v3}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v4

    if-nez v4, :cond_0

    :cond_1
    move v0, v2

    goto :goto_0

    .line 21
    :cond_2
    iget v4, p0, LCa/q$b;->b:I

    or-int/lit8 v4, v4, 0x4

    iput v4, p0, LCa/q$b;->b:I

    .line 22
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 23
    iput v4, p0, LCa/q$b;->e:I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_4

    :catch_0
    move-exception p1

    goto :goto_2

    :catch_1
    move-exception p1

    goto :goto_3

    .line 24
    :cond_3
    iget v4, p0, LCa/q$b;->b:I

    const/4 v5, 0x2

    and-int/2addr v4, v5

    if-ne v4, v5, :cond_4

    .line 25
    iget-object v4, p0, LCa/q$b;->d:LCa/q;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    invoke-static {v4}, LCa/q;->r(LCa/q;)LCa/q$c;

    move-result-object v4

    goto :goto_1

    :cond_4
    const/4 v4, 0x0

    .line 27
    :goto_1
    sget-object v6, LCa/q;->P:LCa/q$a;

    invoke-virtual {p1, v6, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v6

    check-cast v6, LCa/q;

    iput-object v6, p0, LCa/q$b;->d:LCa/q;

    if-eqz v4, :cond_5

    .line 28
    invoke-virtual {v4, v6}, LCa/q$c;->n(LCa/q;)LCa/q$c;

    .line 29
    invoke-virtual {v4}, LCa/q$c;->m()LCa/q;

    move-result-object v4

    iput-object v4, p0, LCa/q$b;->d:LCa/q;

    .line 30
    :cond_5
    iget v4, p0, LCa/q$b;->b:I

    or-int/2addr v4, v5

    iput v4, p0, LCa/q$b;->b:I

    goto :goto_0

    .line 31
    :cond_6
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v5

    .line 32
    invoke-static {v5}, LCa/q$b$c;->valueOf(I)LCa/q$b$c;

    move-result-object v6

    if-nez v6, :cond_7

    .line 33
    invoke-virtual {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 34
    invoke-virtual {v3, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    goto :goto_0

    .line 35
    :cond_7
    iget v4, p0, LCa/q$b;->b:I

    or-int/2addr v4, v2

    iput v4, p0, LCa/q$b;->b:I

    .line 36
    iput-object v6, p0, LCa/q$b;->c:LCa/q$b$c;
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 37
    :goto_2
    :try_start_1
    new-instance p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 38
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 39
    iput-object p0, p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 40
    throw p2

    .line 41
    :goto_3
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 42
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 43
    :goto_4
    :try_start_2
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 44
    :catch_2
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/q$b;->a:LIa/c;

    goto :goto_5

    :catchall_1
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/q$b;->a:LIa/c;

    .line 45
    throw p1

    .line 46
    :goto_5
    throw p1

    .line 47
    :cond_8
    :try_start_3
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 48
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/q$b;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/q$b;->a:LIa/c;

    .line 49
    throw p1

    .line 50
    :catch_3
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/q$b;->a:LIa/c;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    .line 1
    iget v0, p0, LCa/q$b;->v:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/q$b;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    iget-object v0, p0, LCa/q$b;->c:LCa/q$b$c;

    .line 14
    .line 15
    invoke-virtual {v0}, LCa/q$b$c;->getNumber()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->a(II)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const/4 v0, 0x0

    .line 25
    :goto_0
    iget v1, p0, LCa/q$b;->b:I

    .line 26
    .line 27
    const/4 v2, 0x2

    .line 28
    and-int/2addr v1, v2

    .line 29
    if-ne v1, v2, :cond_2

    .line 30
    .line 31
    iget-object v1, p0, LCa/q$b;->d:LCa/q;

    .line 32
    .line 33
    invoke-static {v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    add-int/2addr v0, v1

    .line 38
    :cond_2
    iget v1, p0, LCa/q$b;->b:I

    .line 39
    .line 40
    const/4 v2, 0x4

    .line 41
    and-int/2addr v1, v2

    .line 42
    if-ne v1, v2, :cond_3

    .line 43
    .line 44
    const/4 v1, 0x3

    .line 45
    iget v2, p0, LCa/q$b;->e:I

    .line 46
    .line 47
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v0, v1

    .line 52
    :cond_3
    iget-object v1, p0, LCa/q$b;->a:LIa/c;

    .line 53
    .line 54
    invoke-virtual {v1}, LIa/c;->size()I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    add-int/2addr v1, v0

    .line 59
    iput v1, p0, LCa/q$b;->v:I

    .line 60
    .line 61
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/q$b$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/q$b$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/q$b$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/q$b$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/q$b$b;->m(LCa/q$b;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/q$b;->a()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, LCa/q$b;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, LCa/q$b;->c:LCa/q$b$c;

    .line 11
    .line 12
    invoke-virtual {v0}, LCa/q$b$c;->getNumber()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->l(II)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget v0, p0, LCa/q$b;->b:I

    .line 20
    .line 21
    const/4 v1, 0x2

    .line 22
    and-int/2addr v0, v1

    .line 23
    if-ne v0, v1, :cond_1

    .line 24
    .line 25
    iget-object v0, p0, LCa/q$b;->d:LCa/q;

    .line 26
    .line 27
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 28
    .line 29
    .line 30
    :cond_1
    iget v0, p0, LCa/q$b;->b:I

    .line 31
    .line 32
    const/4 v1, 0x4

    .line 33
    and-int/2addr v0, v1

    .line 34
    if-ne v0, v1, :cond_2

    .line 35
    .line 36
    const/4 v0, 0x3

    .line 37
    iget v1, p0, LCa/q$b;->e:I

    .line 38
    .line 39
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 40
    .line 41
    .line 42
    :cond_2
    iget-object v0, p0, LCa/q$b;->a:LIa/c;

    .line 43
    .line 44
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final g()Z
    .locals 4

    .line 1
    iget-byte v0, p0, LCa/q$b;->i:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    iget v0, p0, LCa/q$b;->b:I

    .line 12
    .line 13
    const/4 v3, 0x2

    .line 14
    and-int/2addr v0, v3

    .line 15
    if-ne v0, v3, :cond_2

    .line 16
    .line 17
    iget-object v0, p0, LCa/q$b;->d:LCa/q;

    .line 18
    .line 19
    invoke-virtual {v0}, LCa/q;->g()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_2

    .line 24
    .line 25
    iput-byte v2, p0, LCa/q$b;->i:B

    .line 26
    .line 27
    return v2

    .line 28
    :cond_2
    iput-byte v1, p0, LCa/q$b;->i:B

    .line 29
    .line 30
    return v1
.end method
