.class public final LCa/v;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/v$b;,
        LCa/v$d;,
        LCa/v$c;
    }
.end annotation


# static fields
.field public static final F:LCa/v;

.field public static final G:LCa/v$a;


# instance fields
.field public D:B

.field public E:I

.field public final a:LIa/c;

.field public b:I

.field public c:I

.field public d:I

.field public e:LCa/v$c;

.field public i:I

.field public v:I

.field public w:LCa/v$d;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LCa/v$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/v;->G:LCa/v$a;

    .line 7
    .line 8
    new-instance v0, LCa/v;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/v;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/v;->F:LCa/v;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput v1, v0, LCa/v;->c:I

    .line 17
    .line 18
    iput v1, v0, LCa/v;->d:I

    .line 19
    .line 20
    sget-object v2, LCa/v$c;->ERROR:LCa/v$c;

    .line 21
    .line 22
    iput-object v2, v0, LCa/v;->e:LCa/v$c;

    .line 23
    .line 24
    iput v1, v0, LCa/v;->i:I

    .line 25
    .line 26
    iput v1, v0, LCa/v;->v:I

    .line 27
    .line 28
    sget-object v1, LCa/v$d;->LANGUAGE_VERSION:LCa/v$d;

    .line 29
    .line 30
    iput-object v1, v0, LCa/v;->w:LCa/v$d;

    .line 31
    .line 32
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/v;->D:B

    .line 8
    iput v0, p0, LCa/v;->E:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/v;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/v$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/v;->D:B

    .line 3
    iput v0, p0, LCa/v;->E:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/v;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/v;->D:B

    .line 12
    iput v0, p0, LCa/v;->E:I

    const/4 v0, 0x0

    .line 13
    iput v0, p0, LCa/v;->c:I

    .line 14
    iput v0, p0, LCa/v;->d:I

    .line 15
    sget-object v1, LCa/v$c;->ERROR:LCa/v$c;

    iput-object v1, p0, LCa/v;->e:LCa/v$c;

    .line 16
    iput v0, p0, LCa/v;->i:I

    .line 17
    iput v0, p0, LCa/v;->v:I

    .line 18
    sget-object v1, LCa/v$d;->LANGUAGE_VERSION:LCa/v$d;

    iput-object v1, p0, LCa/v;->w:LCa/v$d;

    .line 19
    new-instance v1, LIa/c$b;

    invoke-direct {v1}, LIa/c$b;-><init>()V

    const/4 v2, 0x1

    .line 20
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v3

    :cond_0
    :goto_0
    if-nez v0, :cond_a

    .line 21
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v4

    if-eqz v4, :cond_1

    const/16 v5, 0x8

    if-eq v4, v5, :cond_9

    const/16 v6, 0x10

    if-eq v4, v6, :cond_8

    const/16 v7, 0x18

    if-eq v4, v7, :cond_6

    const/16 v7, 0x20

    if-eq v4, v7, :cond_5

    const/16 v5, 0x28

    if-eq v4, v5, :cond_4

    const/16 v5, 0x30

    if-eq v4, v5, :cond_2

    .line 22
    invoke-virtual {p1, v4, v3}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v4

    if-nez v4, :cond_0

    :cond_1
    move v0, v2

    goto :goto_0

    .line 23
    :cond_2
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v5

    .line 24
    invoke-static {v5}, LCa/v$d;->valueOf(I)LCa/v$d;

    move-result-object v6

    if-nez v6, :cond_3

    .line 25
    invoke-virtual {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 26
    invoke-virtual {v3, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :catch_0
    move-exception p1

    goto :goto_1

    :catch_1
    move-exception p1

    goto :goto_2

    .line 27
    :cond_3
    iget v4, p0, LCa/v;->b:I

    or-int/2addr v4, v7

    iput v4, p0, LCa/v;->b:I

    .line 28
    iput-object v6, p0, LCa/v;->w:LCa/v$d;

    goto :goto_0

    .line 29
    :cond_4
    iget v4, p0, LCa/v;->b:I

    or-int/2addr v4, v6

    iput v4, p0, LCa/v;->b:I

    .line 30
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 31
    iput v4, p0, LCa/v;->v:I

    goto :goto_0

    .line 32
    :cond_5
    iget v4, p0, LCa/v;->b:I

    or-int/2addr v4, v5

    iput v4, p0, LCa/v;->b:I

    .line 33
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 34
    iput v4, p0, LCa/v;->i:I

    goto :goto_0

    .line 35
    :cond_6
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v5

    .line 36
    invoke-static {v5}, LCa/v$c;->valueOf(I)LCa/v$c;

    move-result-object v6

    if-nez v6, :cond_7

    .line 37
    invoke-virtual {v3, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 38
    invoke-virtual {v3, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    goto :goto_0

    .line 39
    :cond_7
    iget v4, p0, LCa/v;->b:I

    or-int/lit8 v4, v4, 0x4

    iput v4, p0, LCa/v;->b:I

    .line 40
    iput-object v6, p0, LCa/v;->e:LCa/v$c;

    goto :goto_0

    .line 41
    :cond_8
    iget v4, p0, LCa/v;->b:I

    or-int/lit8 v4, v4, 0x2

    iput v4, p0, LCa/v;->b:I

    .line 42
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 43
    iput v4, p0, LCa/v;->d:I

    goto/16 :goto_0

    .line 44
    :cond_9
    iget v4, p0, LCa/v;->b:I

    or-int/2addr v4, v2

    iput v4, p0, LCa/v;->b:I

    .line 45
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v4

    .line 46
    iput v4, p0, LCa/v;->c:I
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto/16 :goto_0

    .line 47
    :goto_1
    :try_start_1
    new-instance v0, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 48
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 49
    iput-object p0, v0, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 50
    throw v0

    .line 51
    :goto_2
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 52
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 53
    :goto_3
    :try_start_2
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 54
    :catch_2
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/v;->a:LIa/c;

    goto :goto_4

    :catchall_1
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/v;->a:LIa/c;

    .line 55
    throw p1

    .line 56
    :goto_4
    throw p1

    .line 57
    :cond_a
    :try_start_3
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 58
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/v;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object v0

    iput-object v0, p0, LCa/v;->a:LIa/c;

    .line 59
    throw p1

    .line 60
    :catch_3
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/v;->a:LIa/c;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 4

    .line 1
    iget v0, p0, LCa/v;->E:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/v;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    iget v0, p0, LCa/v;->c:I

    .line 14
    .line 15
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 v0, 0x0

    .line 21
    :goto_0
    iget v1, p0, LCa/v;->b:I

    .line 22
    .line 23
    const/4 v2, 0x2

    .line 24
    and-int/2addr v1, v2

    .line 25
    if-ne v1, v2, :cond_2

    .line 26
    .line 27
    iget v1, p0, LCa/v;->d:I

    .line 28
    .line 29
    invoke-static {v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v0, v1

    .line 34
    :cond_2
    iget v1, p0, LCa/v;->b:I

    .line 35
    .line 36
    const/4 v2, 0x4

    .line 37
    and-int/2addr v1, v2

    .line 38
    if-ne v1, v2, :cond_3

    .line 39
    .line 40
    iget-object v1, p0, LCa/v;->e:LCa/v$c;

    .line 41
    .line 42
    invoke-virtual {v1}, LCa/v$c;->getNumber()I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    const/4 v3, 0x3

    .line 47
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->a(II)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v0, v1

    .line 52
    :cond_3
    iget v1, p0, LCa/v;->b:I

    .line 53
    .line 54
    const/16 v3, 0x8

    .line 55
    .line 56
    and-int/2addr v1, v3

    .line 57
    if-ne v1, v3, :cond_4

    .line 58
    .line 59
    iget v1, p0, LCa/v;->i:I

    .line 60
    .line 61
    invoke-static {v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    add-int/2addr v0, v1

    .line 66
    :cond_4
    iget v1, p0, LCa/v;->b:I

    .line 67
    .line 68
    const/16 v2, 0x10

    .line 69
    .line 70
    and-int/2addr v1, v2

    .line 71
    if-ne v1, v2, :cond_5

    .line 72
    .line 73
    const/4 v1, 0x5

    .line 74
    iget v2, p0, LCa/v;->v:I

    .line 75
    .line 76
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    add-int/2addr v0, v1

    .line 81
    :cond_5
    iget v1, p0, LCa/v;->b:I

    .line 82
    .line 83
    const/16 v2, 0x20

    .line 84
    .line 85
    and-int/2addr v1, v2

    .line 86
    if-ne v1, v2, :cond_6

    .line 87
    .line 88
    iget-object v1, p0, LCa/v;->w:LCa/v$d;

    .line 89
    .line 90
    invoke-virtual {v1}, LCa/v$d;->getNumber()I

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    const/4 v2, 0x6

    .line 95
    invoke-static {v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->a(II)I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    add-int/2addr v0, v1

    .line 100
    :cond_6
    iget-object v1, p0, LCa/v;->a:LIa/c;

    .line 101
    .line 102
    invoke-virtual {v1}, LIa/c;->size()I

    .line 103
    .line 104
    .line 105
    move-result v1

    .line 106
    add-int/2addr v1, v0

    .line 107
    iput v1, p0, LCa/v;->E:I

    .line 108
    .line 109
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/v$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/v$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/v$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/v$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/v$b;->m(LCa/v;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/v;->a()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, LCa/v;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    iget v0, p0, LCa/v;->c:I

    .line 11
    .line 12
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget v0, p0, LCa/v;->b:I

    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    and-int/2addr v0, v1

    .line 19
    if-ne v0, v1, :cond_1

    .line 20
    .line 21
    iget v0, p0, LCa/v;->d:I

    .line 22
    .line 23
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 24
    .line 25
    .line 26
    :cond_1
    iget v0, p0, LCa/v;->b:I

    .line 27
    .line 28
    const/4 v1, 0x4

    .line 29
    and-int/2addr v0, v1

    .line 30
    if-ne v0, v1, :cond_2

    .line 31
    .line 32
    iget-object v0, p0, LCa/v;->e:LCa/v$c;

    .line 33
    .line 34
    invoke-virtual {v0}, LCa/v$c;->getNumber()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    const/4 v2, 0x3

    .line 39
    invoke-virtual {p1, v2, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->l(II)V

    .line 40
    .line 41
    .line 42
    :cond_2
    iget v0, p0, LCa/v;->b:I

    .line 43
    .line 44
    const/16 v2, 0x8

    .line 45
    .line 46
    and-int/2addr v0, v2

    .line 47
    if-ne v0, v2, :cond_3

    .line 48
    .line 49
    iget v0, p0, LCa/v;->i:I

    .line 50
    .line 51
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 52
    .line 53
    .line 54
    :cond_3
    iget v0, p0, LCa/v;->b:I

    .line 55
    .line 56
    const/16 v1, 0x10

    .line 57
    .line 58
    and-int/2addr v0, v1

    .line 59
    if-ne v0, v1, :cond_4

    .line 60
    .line 61
    const/4 v0, 0x5

    .line 62
    iget v1, p0, LCa/v;->v:I

    .line 63
    .line 64
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 65
    .line 66
    .line 67
    :cond_4
    iget v0, p0, LCa/v;->b:I

    .line 68
    .line 69
    const/16 v1, 0x20

    .line 70
    .line 71
    and-int/2addr v0, v1

    .line 72
    if-ne v0, v1, :cond_5

    .line 73
    .line 74
    iget-object v0, p0, LCa/v;->w:LCa/v$d;

    .line 75
    .line 76
    invoke-virtual {v0}, LCa/v$d;->getNumber()I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    const/4 v1, 0x6

    .line 81
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->l(II)V

    .line 82
    .line 83
    .line 84
    :cond_5
    iget-object v0, p0, LCa/v;->a:LIa/c;

    .line 85
    .line 86
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 87
    .line 88
    .line 89
    return-void
.end method

.method public final g()Z
    .locals 2

    .line 1
    iget-byte v0, p0, LCa/v;->D:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    return v0

    .line 11
    :cond_1
    iput-byte v1, p0, LCa/v;->D:B

    .line 12
    .line 13
    return v1
.end method
