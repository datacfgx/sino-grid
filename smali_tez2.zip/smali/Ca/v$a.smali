.class public final LCa/v$a;
.super LIa/b;
.source "ProtoBuf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LIa/b<",
        "LCa/v;",
        ">;"
    }
.end annotation


# virtual methods
.method public final a(LIa/d;LIa/e;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1
    new-instance p2, LCa/v;

    .line 2
    .line 3
    invoke-direct {p2, p1}, LCa/v;-><init>(LIa/d;)V

    .line 4
    .line 5
    .line 6
    return-object p2
.end method
