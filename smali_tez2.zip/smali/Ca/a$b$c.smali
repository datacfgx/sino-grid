.class public final LCa/a$b$c;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/a$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/a$b$c$b;,
        LCa/a$b$c$c;
    }
.end annotation


# static fields
.field public static final K:LCa/a$b$c;

.field public static final L:LCa/a$b$c$a;


# instance fields
.field public D:I

.field public E:LCa/a;

.field public F:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/a$b$c;",
            ">;"
        }
    .end annotation
.end field

.field public G:I

.field public H:I

.field public I:B

.field public J:I

.field public final a:LIa/c;

.field public b:I

.field public c:LCa/a$b$c$c;

.field public d:J

.field public e:F

.field public i:D

.field public v:I

.field public w:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LCa/a$b$c$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/a$b$c;->L:LCa/a$b$c$a;

    .line 7
    .line 8
    new-instance v0, LCa/a$b$c;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/a$b$c;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/a$b$c;->K:LCa/a$b$c;

    .line 14
    .line 15
    invoke-virtual {v0}, LCa/a$b$c;->j()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/a$b$c;->I:B

    .line 8
    iput v0, p0, LCa/a$b$c;->J:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/a$b$c;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/a$b$c$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/a$b$c;->I:B

    .line 3
    iput v0, p0, LCa/a$b$c;->J:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/a$b$c;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/a$b$c;->I:B

    .line 12
    iput v0, p0, LCa/a$b$c;->J:I

    .line 13
    invoke-virtual {p0}, LCa/a$b$c;->j()V

    .line 14
    new-instance v0, LIa/c$b;

    invoke-direct {v0}, LIa/c$b;-><init>()V

    const/4 v1, 0x1

    .line 15
    invoke-static {v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v2

    const/4 v3, 0x0

    move v4, v3

    :cond_0
    :goto_0
    const/16 v5, 0x100

    if-nez v3, :cond_6

    .line 16
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v6

    sparse-switch v6, :sswitch_data_0

    .line 17
    invoke-virtual {p1, v6, v2}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v5

    if-nez v5, :cond_0

    :sswitch_0
    move v3, v1

    goto :goto_0

    .line 18
    :sswitch_1
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/2addr v6, v5

    iput v6, p0, LCa/a$b$c;->b:I

    .line 19
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 20
    iput v6, p0, LCa/a$b$c;->G:I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto/16 :goto_4

    :catch_0
    move-exception p1

    goto/16 :goto_2

    :catch_1
    move-exception p1

    goto/16 :goto_3

    .line 21
    :sswitch_2
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit16 v6, v6, 0x200

    iput v6, p0, LCa/a$b$c;->b:I

    .line 22
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 23
    iput v6, p0, LCa/a$b$c;->H:I

    goto :goto_0

    :sswitch_3
    and-int/lit16 v6, v4, 0x100

    if-eq v6, v5, :cond_1

    .line 24
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iput-object v6, p0, LCa/a$b$c;->F:Ljava/util/List;

    move v4, v5

    .line 25
    :cond_1
    iget-object v6, p0, LCa/a$b$c;->F:Ljava/util/List;

    sget-object v7, LCa/a$b$c;->L:LCa/a$b$c$a;

    invoke-virtual {p1, v7, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 26
    :sswitch_4
    iget v6, p0, LCa/a$b$c;->b:I

    const/16 v7, 0x80

    and-int/2addr v6, v7

    if-ne v6, v7, :cond_2

    .line 27
    iget-object v6, p0, LCa/a$b$c;->E:LCa/a;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    new-instance v8, LCa/a$c;

    invoke-direct {v8}, LCa/a$c;-><init>()V

    .line 29
    invoke-virtual {v8, v6}, LCa/a$c;->m(LCa/a;)V

    goto :goto_1

    :cond_2
    const/4 v8, 0x0

    .line 30
    :goto_1
    sget-object v6, LCa/a;->w:LCa/a$a;

    invoke-virtual {p1, v6, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v6

    check-cast v6, LCa/a;

    iput-object v6, p0, LCa/a$b$c;->E:LCa/a;

    if-eqz v8, :cond_3

    .line 31
    invoke-virtual {v8, v6}, LCa/a$c;->m(LCa/a;)V

    .line 32
    invoke-virtual {v8}, LCa/a$c;->l()LCa/a;

    move-result-object v6

    iput-object v6, p0, LCa/a$b$c;->E:LCa/a;

    .line 33
    :cond_3
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/2addr v6, v7

    iput v6, p0, LCa/a$b$c;->b:I

    goto :goto_0

    .line 34
    :sswitch_5
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x40

    iput v6, p0, LCa/a$b$c;->b:I

    .line 35
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 36
    iput v6, p0, LCa/a$b$c;->D:I

    goto/16 :goto_0

    .line 37
    :sswitch_6
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x20

    iput v6, p0, LCa/a$b$c;->b:I

    .line 38
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 39
    iput v6, p0, LCa/a$b$c;->w:I

    goto/16 :goto_0

    .line 40
    :sswitch_7
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x10

    iput v6, p0, LCa/a$b$c;->b:I

    .line 41
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v6

    .line 42
    iput v6, p0, LCa/a$b$c;->v:I

    goto/16 :goto_0

    .line 43
    :sswitch_8
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x8

    iput v6, p0, LCa/a$b$c;->b:I

    .line 44
    invoke-virtual {p1}, LIa/d;->j()J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v6

    .line 45
    iput-wide v6, p0, LCa/a$b$c;->i:D

    goto/16 :goto_0

    .line 46
    :sswitch_9
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x4

    iput v6, p0, LCa/a$b$c;->b:I

    .line 47
    invoke-virtual {p1}, LIa/d;->i()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v6

    .line 48
    iput v6, p0, LCa/a$b$c;->e:F

    goto/16 :goto_0

    .line 49
    :sswitch_a
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/lit8 v6, v6, 0x2

    iput v6, p0, LCa/a$b$c;->b:I

    .line 50
    invoke-virtual {p1}, LIa/d;->l()J

    move-result-wide v6

    ushr-long v8, v6, v1

    const-wide/16 v10, 0x1

    and-long/2addr v6, v10

    neg-long v6, v6

    xor-long/2addr v6, v8

    .line 51
    iput-wide v6, p0, LCa/a$b$c;->d:J

    goto/16 :goto_0

    .line 52
    :sswitch_b
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v7

    .line 53
    invoke-static {v7}, LCa/a$b$c$c;->valueOf(I)LCa/a$b$c$c;

    move-result-object v8

    if-nez v8, :cond_4

    .line 54
    invoke-virtual {v2, v6}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 55
    invoke-virtual {v2, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    goto/16 :goto_0

    .line 56
    :cond_4
    iget v6, p0, LCa/a$b$c;->b:I

    or-int/2addr v6, v1

    iput v6, p0, LCa/a$b$c;->b:I

    .line 57
    iput-object v8, p0, LCa/a$b$c;->c:LCa/a$b$c$c;
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto/16 :goto_0

    .line 58
    :goto_2
    :try_start_1
    new-instance p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 59
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 60
    iput-object p0, p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 61
    throw p2

    .line 62
    :goto_3
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 63
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_4
    and-int/lit16 p2, v4, 0x100

    if-ne p2, v5, :cond_5

    .line 64
    iget-object p2, p0, LCa/a$b$c;->F:Ljava/util/List;

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    iput-object p2, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 65
    :cond_5
    :try_start_2
    invoke-virtual {v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 66
    :catch_2
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a$b$c;->a:LIa/c;

    goto :goto_5

    :catchall_1
    move-exception p1

    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a$b$c;->a:LIa/c;

    .line 67
    throw p1

    .line 68
    :goto_5
    throw p1

    :cond_6
    and-int/lit16 p1, v4, 0x100

    if-ne p1, v5, :cond_7

    .line 69
    iget-object p1, p0, LCa/a$b$c;->F:Ljava/util/List;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 70
    :cond_7
    :try_start_3
    invoke-virtual {v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 71
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/a$b$c;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/a$b$c;->a:LIa/c;

    .line 72
    throw p1

    .line 73
    :catch_3
    invoke-virtual {v0}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/a$b$c;->a:LIa/c;

    return-void

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_0
        0x8 -> :sswitch_b
        0x10 -> :sswitch_a
        0x1d -> :sswitch_9
        0x21 -> :sswitch_8
        0x28 -> :sswitch_7
        0x30 -> :sswitch_6
        0x38 -> :sswitch_5
        0x42 -> :sswitch_4
        0x4a -> :sswitch_3
        0x50 -> :sswitch_2
        0x58 -> :sswitch_1
    .end sparse-switch
.end method


# virtual methods
.method public final a()I
    .locals 9

    .line 1
    iget v0, p0, LCa/a$b$c;->J:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/a$b$c;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_1

    .line 13
    .line 14
    iget-object v0, p0, LCa/a$b$c;->c:LCa/a$b$c$c;

    .line 15
    .line 16
    invoke-virtual {v0}, LCa/a$b$c$c;->getNumber()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->a(II)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    move v0, v2

    .line 26
    :goto_0
    iget v3, p0, LCa/a$b$c;->b:I

    .line 27
    .line 28
    const/4 v4, 0x2

    .line 29
    and-int/2addr v3, v4

    .line 30
    if-ne v3, v4, :cond_2

    .line 31
    .line 32
    iget-wide v5, p0, LCa/a$b$c;->d:J

    .line 33
    .line 34
    invoke-static {v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->h(I)I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    shl-long v7, v5, v1

    .line 39
    .line 40
    const/16 v1, 0x3f

    .line 41
    .line 42
    shr-long v4, v5, v1

    .line 43
    .line 44
    xor-long/2addr v4, v7

    .line 45
    invoke-static {v4, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->g(J)I

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    add-int/2addr v1, v3

    .line 50
    add-int/2addr v0, v1

    .line 51
    :cond_2
    iget v1, p0, LCa/a$b$c;->b:I

    .line 52
    .line 53
    const/4 v3, 0x4

    .line 54
    and-int/2addr v1, v3

    .line 55
    if-ne v1, v3, :cond_3

    .line 56
    .line 57
    const/4 v1, 0x3

    .line 58
    invoke-static {v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->h(I)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    add-int/2addr v1, v3

    .line 63
    add-int/2addr v0, v1

    .line 64
    :cond_3
    iget v1, p0, LCa/a$b$c;->b:I

    .line 65
    .line 66
    const/16 v4, 0x8

    .line 67
    .line 68
    and-int/2addr v1, v4

    .line 69
    if-ne v1, v4, :cond_4

    .line 70
    .line 71
    invoke-static {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->h(I)I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    add-int/2addr v1, v4

    .line 76
    add-int/2addr v0, v1

    .line 77
    :cond_4
    iget v1, p0, LCa/a$b$c;->b:I

    .line 78
    .line 79
    const/16 v3, 0x10

    .line 80
    .line 81
    and-int/2addr v1, v3

    .line 82
    if-ne v1, v3, :cond_5

    .line 83
    .line 84
    const/4 v1, 0x5

    .line 85
    iget v3, p0, LCa/a$b$c;->v:I

    .line 86
    .line 87
    invoke-static {v1, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    add-int/2addr v0, v1

    .line 92
    :cond_5
    iget v1, p0, LCa/a$b$c;->b:I

    .line 93
    .line 94
    const/16 v3, 0x20

    .line 95
    .line 96
    and-int/2addr v1, v3

    .line 97
    if-ne v1, v3, :cond_6

    .line 98
    .line 99
    const/4 v1, 0x6

    .line 100
    iget v3, p0, LCa/a$b$c;->w:I

    .line 101
    .line 102
    invoke-static {v1, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 103
    .line 104
    .line 105
    move-result v1

    .line 106
    add-int/2addr v0, v1

    .line 107
    :cond_6
    iget v1, p0, LCa/a$b$c;->b:I

    .line 108
    .line 109
    const/16 v3, 0x40

    .line 110
    .line 111
    and-int/2addr v1, v3

    .line 112
    if-ne v1, v3, :cond_7

    .line 113
    .line 114
    const/4 v1, 0x7

    .line 115
    iget v3, p0, LCa/a$b$c;->D:I

    .line 116
    .line 117
    invoke-static {v1, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    add-int/2addr v0, v1

    .line 122
    :cond_7
    iget v1, p0, LCa/a$b$c;->b:I

    .line 123
    .line 124
    const/16 v3, 0x80

    .line 125
    .line 126
    and-int/2addr v1, v3

    .line 127
    if-ne v1, v3, :cond_8

    .line 128
    .line 129
    iget-object v1, p0, LCa/a$b$c;->E:LCa/a;

    .line 130
    .line 131
    invoke-static {v4, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    add-int/2addr v0, v1

    .line 136
    :cond_8
    :goto_1
    iget-object v1, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 137
    .line 138
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-ge v2, v1, :cond_9

    .line 143
    .line 144
    iget-object v1, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 145
    .line 146
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    check-cast v1, LIa/n;

    .line 151
    .line 152
    const/16 v3, 0x9

    .line 153
    .line 154
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    add-int/2addr v0, v1

    .line 159
    add-int/lit8 v2, v2, 0x1

    .line 160
    .line 161
    goto :goto_1

    .line 162
    :cond_9
    iget v1, p0, LCa/a$b$c;->b:I

    .line 163
    .line 164
    const/16 v2, 0x200

    .line 165
    .line 166
    and-int/2addr v1, v2

    .line 167
    if-ne v1, v2, :cond_a

    .line 168
    .line 169
    const/16 v1, 0xa

    .line 170
    .line 171
    iget v2, p0, LCa/a$b$c;->H:I

    .line 172
    .line 173
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    add-int/2addr v0, v1

    .line 178
    :cond_a
    iget v1, p0, LCa/a$b$c;->b:I

    .line 179
    .line 180
    const/16 v2, 0x100

    .line 181
    .line 182
    and-int/2addr v1, v2

    .line 183
    if-ne v1, v2, :cond_b

    .line 184
    .line 185
    const/16 v1, 0xb

    .line 186
    .line 187
    iget v2, p0, LCa/a$b$c;->G:I

    .line 188
    .line 189
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    add-int/2addr v0, v1

    .line 194
    :cond_b
    iget-object v1, p0, LCa/a$b$c;->a:LIa/c;

    .line 195
    .line 196
    invoke-virtual {v1}, LIa/c;->size()I

    .line 197
    .line 198
    .line 199
    move-result v1

    .line 200
    add-int/2addr v1, v0

    .line 201
    iput v1, p0, LCa/a$b$c;->J:I

    .line 202
    .line 203
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/a$b$c$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$b$c$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/a$b$c$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/a$b$c$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/a$b$c$b;->m(LCa/a$b$c;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/a$b$c;->a()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, LCa/a$b$c;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, LCa/a$b$c;->c:LCa/a$b$c$c;

    .line 11
    .line 12
    invoke-virtual {v0}, LCa/a$b$c$c;->getNumber()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->l(II)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget v0, p0, LCa/a$b$c;->b:I

    .line 20
    .line 21
    const/4 v2, 0x2

    .line 22
    and-int/2addr v0, v2

    .line 23
    const/4 v3, 0x0

    .line 24
    if-ne v0, v2, :cond_1

    .line 25
    .line 26
    iget-wide v4, p0, LCa/a$b$c;->d:J

    .line 27
    .line 28
    invoke-virtual {p1, v2, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->x(II)V

    .line 29
    .line 30
    .line 31
    shl-long v6, v4, v1

    .line 32
    .line 33
    const/16 v0, 0x3f

    .line 34
    .line 35
    shr-long/2addr v4, v0

    .line 36
    xor-long/2addr v4, v6

    .line 37
    invoke-virtual {p1, v4, v5}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->w(J)V

    .line 38
    .line 39
    .line 40
    :cond_1
    iget v0, p0, LCa/a$b$c;->b:I

    .line 41
    .line 42
    const/4 v2, 0x4

    .line 43
    and-int/2addr v0, v2

    .line 44
    const/4 v4, 0x5

    .line 45
    if-ne v0, v2, :cond_2

    .line 46
    .line 47
    iget v0, p0, LCa/a$b$c;->e:F

    .line 48
    .line 49
    const/4 v5, 0x3

    .line 50
    invoke-virtual {p1, v5, v4}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->x(II)V

    .line 51
    .line 52
    .line 53
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->t(I)V

    .line 58
    .line 59
    .line 60
    :cond_2
    iget v0, p0, LCa/a$b$c;->b:I

    .line 61
    .line 62
    const/16 v5, 0x8

    .line 63
    .line 64
    and-int/2addr v0, v5

    .line 65
    if-ne v0, v5, :cond_3

    .line 66
    .line 67
    iget-wide v6, p0, LCa/a$b$c;->i:D

    .line 68
    .line 69
    invoke-virtual {p1, v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->x(II)V

    .line 70
    .line 71
    .line 72
    invoke-static {v6, v7}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 73
    .line 74
    .line 75
    move-result-wide v0

    .line 76
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->u(J)V

    .line 77
    .line 78
    .line 79
    :cond_3
    iget v0, p0, LCa/a$b$c;->b:I

    .line 80
    .line 81
    const/16 v1, 0x10

    .line 82
    .line 83
    and-int/2addr v0, v1

    .line 84
    if-ne v0, v1, :cond_4

    .line 85
    .line 86
    iget v0, p0, LCa/a$b$c;->v:I

    .line 87
    .line 88
    invoke-virtual {p1, v4, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 89
    .line 90
    .line 91
    :cond_4
    iget v0, p0, LCa/a$b$c;->b:I

    .line 92
    .line 93
    const/16 v1, 0x20

    .line 94
    .line 95
    and-int/2addr v0, v1

    .line 96
    if-ne v0, v1, :cond_5

    .line 97
    .line 98
    const/4 v0, 0x6

    .line 99
    iget v1, p0, LCa/a$b$c;->w:I

    .line 100
    .line 101
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 102
    .line 103
    .line 104
    :cond_5
    iget v0, p0, LCa/a$b$c;->b:I

    .line 105
    .line 106
    const/16 v1, 0x40

    .line 107
    .line 108
    and-int/2addr v0, v1

    .line 109
    if-ne v0, v1, :cond_6

    .line 110
    .line 111
    const/4 v0, 0x7

    .line 112
    iget v1, p0, LCa/a$b$c;->D:I

    .line 113
    .line 114
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 115
    .line 116
    .line 117
    :cond_6
    iget v0, p0, LCa/a$b$c;->b:I

    .line 118
    .line 119
    const/16 v1, 0x80

    .line 120
    .line 121
    and-int/2addr v0, v1

    .line 122
    if-ne v0, v1, :cond_7

    .line 123
    .line 124
    iget-object v0, p0, LCa/a$b$c;->E:LCa/a;

    .line 125
    .line 126
    invoke-virtual {p1, v5, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 127
    .line 128
    .line 129
    :cond_7
    :goto_0
    iget-object v0, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 130
    .line 131
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    if-ge v3, v0, :cond_8

    .line 136
    .line 137
    iget-object v0, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 138
    .line 139
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, LIa/n;

    .line 144
    .line 145
    const/16 v1, 0x9

    .line 146
    .line 147
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 148
    .line 149
    .line 150
    add-int/lit8 v3, v3, 0x1

    .line 151
    .line 152
    goto :goto_0

    .line 153
    :cond_8
    iget v0, p0, LCa/a$b$c;->b:I

    .line 154
    .line 155
    const/16 v1, 0x200

    .line 156
    .line 157
    and-int/2addr v0, v1

    .line 158
    if-ne v0, v1, :cond_9

    .line 159
    .line 160
    const/16 v0, 0xa

    .line 161
    .line 162
    iget v1, p0, LCa/a$b$c;->H:I

    .line 163
    .line 164
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 165
    .line 166
    .line 167
    :cond_9
    iget v0, p0, LCa/a$b$c;->b:I

    .line 168
    .line 169
    const/16 v1, 0x100

    .line 170
    .line 171
    and-int/2addr v0, v1

    .line 172
    if-ne v0, v1, :cond_a

    .line 173
    .line 174
    const/16 v0, 0xb

    .line 175
    .line 176
    iget v1, p0, LCa/a$b$c;->G:I

    .line 177
    .line 178
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 179
    .line 180
    .line 181
    :cond_a
    iget-object v0, p0, LCa/a$b$c;->a:LIa/c;

    .line 182
    .line 183
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 184
    .line 185
    .line 186
    return-void
.end method

.method public final g()Z
    .locals 4

    .line 1
    iget-byte v0, p0, LCa/a$b$c;->I:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    iget v0, p0, LCa/a$b$c;->b:I

    .line 12
    .line 13
    const/16 v3, 0x80

    .line 14
    .line 15
    and-int/2addr v0, v3

    .line 16
    if-ne v0, v3, :cond_2

    .line 17
    .line 18
    iget-object v0, p0, LCa/a$b$c;->E:LCa/a;

    .line 19
    .line 20
    invoke-virtual {v0}, LCa/a;->g()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    iput-byte v2, p0, LCa/a$b$c;->I:B

    .line 27
    .line 28
    return v2

    .line 29
    :cond_2
    move v0, v2

    .line 30
    :goto_0
    iget-object v3, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 31
    .line 32
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-ge v0, v3, :cond_4

    .line 37
    .line 38
    iget-object v3, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 39
    .line 40
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    check-cast v3, LCa/a$b$c;

    .line 45
    .line 46
    invoke-virtual {v3}, LCa/a$b$c;->g()Z

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    if-nez v3, :cond_3

    .line 51
    .line 52
    iput-byte v2, p0, LCa/a$b$c;->I:B

    .line 53
    .line 54
    return v2

    .line 55
    :cond_3
    add-int/lit8 v0, v0, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_4
    iput-byte v1, p0, LCa/a$b$c;->I:B

    .line 59
    .line 60
    return v1
.end method

.method public final j()V
    .locals 2

    .line 1
    sget-object v0, LCa/a$b$c$c;->BYTE:LCa/a$b$c$c;

    .line 2
    .line 3
    iput-object v0, p0, LCa/a$b$c;->c:LCa/a$b$c$c;

    .line 4
    .line 5
    const-wide/16 v0, 0x0

    .line 6
    .line 7
    iput-wide v0, p0, LCa/a$b$c;->d:J

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput v0, p0, LCa/a$b$c;->e:F

    .line 11
    .line 12
    const-wide/16 v0, 0x0

    .line 13
    .line 14
    iput-wide v0, p0, LCa/a$b$c;->i:D

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput v0, p0, LCa/a$b$c;->v:I

    .line 18
    .line 19
    iput v0, p0, LCa/a$b$c;->w:I

    .line 20
    .line 21
    iput v0, p0, LCa/a$b$c;->D:I

    .line 22
    .line 23
    sget-object v1, LCa/a;->v:LCa/a;

    .line 24
    .line 25
    iput-object v1, p0, LCa/a$b$c;->E:LCa/a;

    .line 26
    .line 27
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 28
    .line 29
    iput-object v1, p0, LCa/a$b$c;->F:Ljava/util/List;

    .line 30
    .line 31
    iput v0, p0, LCa/a$b$c;->G:I

    .line 32
    .line 33
    iput v0, p0, LCa/a$b$c;->H:I

    .line 34
    .line 35
    return-void
.end method
