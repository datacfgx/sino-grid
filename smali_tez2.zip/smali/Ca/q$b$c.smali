.class public final enum LCa/q$b$c;
.super Ljava/lang/Enum;
.source "ProtoBuf.java"

# interfaces
.implements LIa/h$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCa/q$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LCa/q$b$c;",
        ">;",
        "LIa/h$a;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LCa/q$b$c;

.field public static final enum IN:LCa/q$b$c;

.field public static final enum INV:LCa/q$b$c;

.field public static final enum OUT:LCa/q$b$c;

.field public static final enum STAR:LCa/q$b$c;

.field private static internalValueMap:LIa/h$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/h$b<",
            "LCa/q$b$c;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    .line 2
    new-instance v0, LCa/q$b$c;

    .line 3
    .line 4
    const-string v1, "IN"

    .line 5
    const/4 v2, 0x0

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, v2, v2, v2}, LCa/q$b$c;-><init>(Ljava/lang/String;III)V

    .line 9
    .line 10
    sput-object v0, LCa/q$b$c;->IN:LCa/q$b$c;

    .line 11
    .line 12
    new-instance v1, LCa/q$b$c;

    .line 13
    .line 14
    const-string v2, "OUT"

    .line 15
    const/4 v3, 0x1

    .line 16
    .line 17
    .line 18
    invoke-direct {v1, v2, v3, v3, v3}, LCa/q$b$c;-><init>(Ljava/lang/String;III)V

    .line 19
    .line 20
    sput-object v1, LCa/q$b$c;->OUT:LCa/q$b$c;

    .line 21
    .line 22
    new-instance v2, LCa/q$b$c;

    .line 23
    .line 24
    const-string v3, "INV"

    .line 25
    const/4 v4, 0x2

    .line 26
    .line 27
    .line 28
    invoke-direct {v2, v3, v4, v4, v4}, LCa/q$b$c;-><init>(Ljava/lang/String;III)V

    .line 29
    .line 30
    sput-object v2, LCa/q$b$c;->INV:LCa/q$b$c;

    .line 31
    .line 32
    new-instance v3, LCa/q$b$c;

    .line 33
    .line 34
    const/4 v4, 0x0

    sget-object v4, Lzd/MBZl/dMyYFe;->qgWZlXDGMwfc:Ljava/lang/String;

    .line 35
    const/4 v5, 0x3

    .line 36
    .line 37
    .line 38
    invoke-direct {v3, v4, v5, v5, v5}, LCa/q$b$c;-><init>(Ljava/lang/String;III)V

    .line 39
    .line 40
    sput-object v3, LCa/q$b$c;->STAR:LCa/q$b$c;

    .line 41
    .line 42
    .line 43
    filled-new-array {v0, v1, v2, v3}, [LCa/q$b$c;

    .line 44
    move-result-object v0

    .line 45
    .line 46
    sput-object v0, LCa/q$b$c;->$VALUES:[LCa/q$b$c;

    .line 47
    .line 48
    new-instance v0, LCa/q$b$c$a;

    .line 49
    .line 50
    .line 51
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 52
    .line 53
    sput-object v0, LCa/q$b$c;->internalValueMap:LIa/h$b;

    .line 54
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;III)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p4, p0, LCa/q$b$c;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(I)LCa/q$b$c;
    .locals 1

    if-eqz p0, :cond_3

    const/4 v0, 0x1

    if-eq p0, v0, :cond_2

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1

    const/4 v0, 0x3

    if-eq p0, v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    .line 2
    :cond_0
    sget-object p0, LCa/q$b$c;->STAR:LCa/q$b$c;

    return-object p0

    .line 3
    :cond_1
    sget-object p0, LCa/q$b$c;->INV:LCa/q$b$c;

    return-object p0

    .line 4
    :cond_2
    sget-object p0, LCa/q$b$c;->OUT:LCa/q$b$c;

    return-object p0

    .line 5
    :cond_3
    sget-object p0, LCa/q$b$c;->IN:LCa/q$b$c;

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)LCa/q$b$c;
    .locals 1

    .line 1
    const-class v0, LCa/q$b$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LCa/q$b$c;

    return-object p0
.end method

.method public static values()[LCa/q$b$c;
    .locals 1

    .line 1
    sget-object v0, LCa/q$b$c;->$VALUES:[LCa/q$b$c;

    .line 2
    .line 3
    invoke-virtual {v0}, [LCa/q$b$c;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LCa/q$b$c;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .locals 1

    .line 1
    iget v0, p0, LCa/q$b$c;->value:I

    .line 2
    .line 3
    return v0
.end method
