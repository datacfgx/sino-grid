.class public final enum LCa/j;
.super Ljava/lang/Enum;
.source "ProtoBuf.java"

# interfaces
.implements LIa/h$a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LCa/j;",
        ">;",
        "LIa/h$a;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[LCa/j;

.field public static final enum DECLARATION:LCa/j;

.field public static final enum DELEGATION:LCa/j;

.field public static final enum FAKE_OVERRIDE:LCa/j;

.field public static final enum SYNTHESIZED:LCa/j;

.field private static internalValueMap:LIa/h$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "LIa/h$b<",
            "LCa/j;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LCa/j;

    .line 2
    .line 3
    const-string v1, "DECLARATION"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2, v2, v2}, LCa/j;-><init>(Ljava/lang/String;III)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LCa/j;->DECLARATION:LCa/j;

    .line 10
    .line 11
    new-instance v1, LCa/j;

    .line 12
    .line 13
    const-string v2, "FAKE_OVERRIDE"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v1, v2, v3, v3, v3}, LCa/j;-><init>(Ljava/lang/String;III)V

    .line 17
    .line 18
    .line 19
    sput-object v1, LCa/j;->FAKE_OVERRIDE:LCa/j;

    .line 20
    .line 21
    new-instance v2, LCa/j;

    .line 22
    .line 23
    const-string v3, "DELEGATION"

    .line 24
    .line 25
    const/4 v4, 0x2

    .line 26
    invoke-direct {v2, v3, v4, v4, v4}, LCa/j;-><init>(Ljava/lang/String;III)V

    .line 27
    .line 28
    .line 29
    sput-object v2, LCa/j;->DELEGATION:LCa/j;

    .line 30
    .line 31
    new-instance v3, LCa/j;

    .line 32
    .line 33
    const-string v4, "SYNTHESIZED"

    .line 34
    .line 35
    const/4 v5, 0x3

    .line 36
    invoke-direct {v3, v4, v5, v5, v5}, LCa/j;-><init>(Ljava/lang/String;III)V

    .line 37
    .line 38
    .line 39
    sput-object v3, LCa/j;->SYNTHESIZED:LCa/j;

    .line 40
    .line 41
    filled-new-array {v0, v1, v2, v3}, [LCa/j;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    sput-object v0, LCa/j;->$VALUES:[LCa/j;

    .line 46
    .line 47
    new-instance v0, LCa/j$a;

    .line 48
    .line 49
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 50
    .line 51
    .line 52
    sput-object v0, LCa/j;->internalValueMap:LIa/h$b;

    .line 53
    .line 54
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;III)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p4, p0, LCa/j;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(I)LCa/j;
    .locals 1

    if-eqz p0, :cond_3

    const/4 v0, 0x1

    if-eq p0, v0, :cond_2

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1

    const/4 v0, 0x3

    if-eq p0, v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    .line 2
    :cond_0
    sget-object p0, LCa/j;->SYNTHESIZED:LCa/j;

    return-object p0

    .line 3
    :cond_1
    sget-object p0, LCa/j;->DELEGATION:LCa/j;

    return-object p0

    .line 4
    :cond_2
    sget-object p0, LCa/j;->FAKE_OVERRIDE:LCa/j;

    return-object p0

    .line 5
    :cond_3
    sget-object p0, LCa/j;->DECLARATION:LCa/j;

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)LCa/j;
    .locals 1

    .line 1
    const-class v0, LCa/j;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LCa/j;

    return-object p0
.end method

.method public static values()[LCa/j;
    .locals 1

    .line 1
    sget-object v0, LCa/j;->$VALUES:[LCa/j;

    .line 2
    .line 3
    invoke-virtual {v0}, [LCa/j;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LCa/j;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .locals 1

    .line 1
    iget v0, p0, LCa/j;->value:I

    .line 2
    .line 3
    return v0
.end method
