.class public final LCa/h;
.super LIa/g;
.source "ProtoBuf.java"

# interfaces
.implements LIa/o;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCa/h$b;,
        LCa/h$c;
    }
.end annotation


# static fields
.field public static final G:LCa/h;

.field public static final H:LCa/h$a;


# instance fields
.field public D:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/h;",
            ">;"
        }
    .end annotation
.end field

.field public E:B

.field public F:I

.field public final a:LIa/c;

.field public b:I

.field public c:I

.field public d:I

.field public e:LCa/h$c;

.field public i:LCa/q;

.field public v:I

.field public w:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCa/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LCa/h$a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LCa/h;->H:LCa/h$a;

    .line 7
    .line 8
    new-instance v0, LCa/h;

    .line 9
    .line 10
    invoke-direct {v0}, LCa/h;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LCa/h;->G:LCa/h;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput v1, v0, LCa/h;->c:I

    .line 17
    .line 18
    iput v1, v0, LCa/h;->d:I

    .line 19
    .line 20
    sget-object v2, LCa/h$c;->TRUE:LCa/h$c;

    .line 21
    .line 22
    iput-object v2, v0, LCa/h;->e:LCa/h$c;

    .line 23
    .line 24
    sget-object v2, LCa/q;->O:LCa/q;

    .line 25
    .line 26
    iput-object v2, v0, LCa/h;->i:LCa/q;

    .line 27
    .line 28
    iput v1, v0, LCa/h;->v:I

    .line 29
    .line 30
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 31
    .line 32
    iput-object v1, v0, LCa/h;->w:Ljava/util/List;

    .line 33
    .line 34
    iput-object v1, v0, LCa/h;->D:Ljava/util/List;

    .line 35
    .line 36
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 7
    iput-byte v0, p0, LCa/h;->E:B

    .line 8
    iput v0, p0, LCa/h;->F:I

    .line 9
    sget-object v0, LIa/c;->a:LIa/m;

    iput-object v0, p0, LCa/h;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LCa/h$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LIa/a;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput-byte v0, p0, LCa/h;->E:B

    .line 3
    iput v0, p0, LCa/h;->F:I

    .line 4
    iget-object p1, p1, LIa/g$b;->a:LIa/c;

    .line 5
    iput-object p1, p0, LCa/h;->a:LIa/c;

    return-void
.end method

.method public constructor <init>(LIa/d;LIa/e;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10
    invoke-direct {p0}, LIa/g;-><init>()V

    const/4 v0, -0x1

    .line 11
    iput-byte v0, p0, LCa/h;->E:B

    .line 12
    iput v0, p0, LCa/h;->F:I

    const/4 v0, 0x0

    .line 13
    iput v0, p0, LCa/h;->c:I

    .line 14
    iput v0, p0, LCa/h;->d:I

    .line 15
    sget-object v1, LCa/h$c;->TRUE:LCa/h$c;

    iput-object v1, p0, LCa/h;->e:LCa/h$c;

    .line 16
    sget-object v1, LCa/q;->O:LCa/q;

    .line 17
    iput-object v1, p0, LCa/h;->i:LCa/q;

    .line 18
    iput v0, p0, LCa/h;->v:I

    .line 19
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object v1, p0, LCa/h;->w:Ljava/util/List;

    .line 20
    iput-object v1, p0, LCa/h;->D:Ljava/util/List;

    .line 21
    new-instance v1, LIa/c$b;

    invoke-direct {v1}, LIa/c$b;-><init>()V

    const/4 v2, 0x1

    .line 22
    invoke-static {v1, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->j(Ljava/io/OutputStream;I)Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;

    move-result-object v3

    move v4, v0

    :cond_0
    :goto_0
    const/16 v5, 0x40

    const/16 v6, 0x20

    if-nez v0, :cond_10

    .line 23
    :try_start_0
    invoke-virtual {p1}, LIa/d;->n()I

    move-result v7
    :try_end_0
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v7, :cond_1

    const/16 v8, 0x8

    if-eq v7, v8, :cond_d

    const/16 v9, 0x10

    if-eq v7, v9, :cond_c

    const/16 v10, 0x18

    if-eq v7, v10, :cond_a

    const/16 v10, 0x22

    if-eq v7, v10, :cond_7

    const/16 v8, 0x28

    if-eq v7, v8, :cond_6

    .line 24
    sget-object v8, LCa/h;->H:LCa/h$a;

    const/16 v9, 0x32

    if-eq v7, v9, :cond_4

    const/16 v9, 0x3a

    if-eq v7, v9, :cond_2

    .line 25
    :try_start_1
    invoke-virtual {p1, v7, v3}, LIa/d;->q(ILkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)Z

    move-result v5

    if-nez v5, :cond_0

    :cond_1
    move v0, v2

    goto :goto_0

    :cond_2
    and-int/lit8 v7, v4, 0x40

    if-eq v7, v5, :cond_3

    .line 26
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v7, p0, LCa/h;->D:Ljava/util/List;

    or-int/lit8 v4, v4, 0x40

    goto :goto_1

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :catch_0
    move-exception p1

    goto/16 :goto_3

    :catch_1
    move-exception p1

    goto/16 :goto_4

    .line 27
    :cond_3
    :goto_1
    iget-object v7, p0, LCa/h;->D:Ljava/util/List;

    invoke-virtual {p1, v8, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    and-int/lit8 v7, v4, 0x20

    if-eq v7, v6, :cond_5

    .line 28
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v7, p0, LCa/h;->w:Ljava/util/List;

    or-int/lit8 v4, v4, 0x20

    .line 29
    :cond_5
    iget-object v7, p0, LCa/h;->w:Ljava/util/List;

    invoke-virtual {p1, v8, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 30
    :cond_6
    iget v7, p0, LCa/h;->b:I

    or-int/2addr v7, v9

    iput v7, p0, LCa/h;->b:I

    .line 31
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v7

    .line 32
    iput v7, p0, LCa/h;->v:I

    goto :goto_0

    .line 33
    :cond_7
    iget v7, p0, LCa/h;->b:I

    and-int/2addr v7, v8

    if-ne v7, v8, :cond_8

    .line 34
    iget-object v7, p0, LCa/h;->i:LCa/q;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    invoke-static {v7}, LCa/q;->r(LCa/q;)LCa/q$c;

    move-result-object v7

    goto :goto_2

    :cond_8
    const/4 v7, 0x0

    .line 36
    :goto_2
    sget-object v9, LCa/q;->P:LCa/q$a;

    invoke-virtual {p1, v9, p2}, LIa/d;->g(LIa/p;LIa/e;)LIa/n;

    move-result-object v9

    check-cast v9, LCa/q;

    iput-object v9, p0, LCa/h;->i:LCa/q;

    if-eqz v7, :cond_9

    .line 37
    invoke-virtual {v7, v9}, LCa/q$c;->n(LCa/q;)LCa/q$c;

    .line 38
    invoke-virtual {v7}, LCa/q$c;->m()LCa/q;

    move-result-object v7

    iput-object v7, p0, LCa/h;->i:LCa/q;

    .line 39
    :cond_9
    iget v7, p0, LCa/h;->b:I

    or-int/2addr v7, v8

    iput v7, p0, LCa/h;->b:I

    goto/16 :goto_0

    .line 40
    :cond_a
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v8

    .line 41
    invoke-static {v8}, LCa/h$c;->valueOf(I)LCa/h$c;

    move-result-object v9

    if-nez v9, :cond_b

    .line 42
    invoke-virtual {v3, v7}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    .line 43
    invoke-virtual {v3, v8}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->v(I)V

    goto/16 :goto_0

    .line 44
    :cond_b
    iget v7, p0, LCa/h;->b:I

    or-int/lit8 v7, v7, 0x4

    iput v7, p0, LCa/h;->b:I

    .line 45
    iput-object v9, p0, LCa/h;->e:LCa/h$c;

    goto/16 :goto_0

    .line 46
    :cond_c
    iget v7, p0, LCa/h;->b:I

    or-int/lit8 v7, v7, 0x2

    iput v7, p0, LCa/h;->b:I

    .line 47
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v7

    .line 48
    iput v7, p0, LCa/h;->d:I

    goto/16 :goto_0

    .line 49
    :cond_d
    iget v7, p0, LCa/h;->b:I

    or-int/2addr v7, v2

    iput v7, p0, LCa/h;->b:I

    .line 50
    invoke-virtual {p1}, LIa/d;->k()I

    move-result v7

    .line 51
    iput v7, p0, LCa/h;->c:I
    :try_end_1
    .catch Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto/16 :goto_0

    .line 52
    :goto_3
    :try_start_2
    new-instance p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;

    .line 53
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    .line 54
    iput-object p0, p2, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 55
    throw p2

    .line 56
    :goto_4
    iput-object p0, p1, Lkotlin/reflect/jvm/internal/impl/protobuf/InvalidProtocolBufferException;->a:LIa/n;

    .line 57
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_5
    and-int/lit8 p2, v4, 0x20

    if-ne p2, v6, :cond_e

    .line 58
    iget-object p2, p0, LCa/h;->w:Ljava/util/List;

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    iput-object p2, p0, LCa/h;->w:Ljava/util/List;

    :cond_e
    and-int/lit8 p2, v4, 0x40

    if-ne p2, v5, :cond_f

    .line 59
    iget-object p2, p0, LCa/h;->D:Ljava/util/List;

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    iput-object p2, p0, LCa/h;->D:Ljava/util/List;

    .line 60
    :cond_f
    :try_start_3
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 61
    :catch_2
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/h;->a:LIa/c;

    goto :goto_6

    :catchall_1
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/h;->a:LIa/c;

    .line 62
    throw p1

    .line 63
    :goto_6
    throw p1

    :cond_10
    and-int/lit8 p1, v4, 0x20

    if-ne p1, v6, :cond_11

    .line 64
    iget-object p1, p0, LCa/h;->w:Ljava/util/List;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCa/h;->w:Ljava/util/List;

    :cond_11
    and-int/lit8 p1, v4, 0x40

    if-ne p1, v5, :cond_12

    .line 65
    iget-object p1, p0, LCa/h;->D:Ljava/util/List;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCa/h;->D:Ljava/util/List;

    .line 66
    :cond_12
    :try_start_4
    invoke-virtual {v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->i()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 67
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/h;->a:LIa/c;

    return-void

    :catchall_2
    move-exception p1

    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p2

    iput-object p2, p0, LCa/h;->a:LIa/c;

    .line 68
    throw p1

    .line 69
    :catch_3
    invoke-virtual {v1}, LIa/c$b;->i()LIa/c;

    move-result-object p1

    iput-object p1, p0, LCa/h;->a:LIa/c;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 5

    .line 1
    iget v0, p0, LCa/h;->F:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    iget v0, p0, LCa/h;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_1

    .line 13
    .line 14
    iget v0, p0, LCa/h;->c:I

    .line 15
    .line 16
    invoke-static {v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    move v0, v2

    .line 22
    :goto_0
    iget v1, p0, LCa/h;->b:I

    .line 23
    .line 24
    const/4 v3, 0x2

    .line 25
    and-int/2addr v1, v3

    .line 26
    if-ne v1, v3, :cond_2

    .line 27
    .line 28
    iget v1, p0, LCa/h;->d:I

    .line 29
    .line 30
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    add-int/2addr v0, v1

    .line 35
    :cond_2
    iget v1, p0, LCa/h;->b:I

    .line 36
    .line 37
    const/4 v3, 0x4

    .line 38
    and-int/2addr v1, v3

    .line 39
    if-ne v1, v3, :cond_3

    .line 40
    .line 41
    iget-object v1, p0, LCa/h;->e:LCa/h$c;

    .line 42
    .line 43
    invoke-virtual {v1}, LCa/h$c;->getNumber()I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    const/4 v4, 0x3

    .line 48
    invoke-static {v4, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->a(II)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    add-int/2addr v0, v1

    .line 53
    :cond_3
    iget v1, p0, LCa/h;->b:I

    .line 54
    .line 55
    const/16 v4, 0x8

    .line 56
    .line 57
    and-int/2addr v1, v4

    .line 58
    if-ne v1, v4, :cond_4

    .line 59
    .line 60
    iget-object v1, p0, LCa/h;->i:LCa/q;

    .line 61
    .line 62
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    add-int/2addr v0, v1

    .line 67
    :cond_4
    iget v1, p0, LCa/h;->b:I

    .line 68
    .line 69
    const/16 v3, 0x10

    .line 70
    .line 71
    and-int/2addr v1, v3

    .line 72
    if-ne v1, v3, :cond_5

    .line 73
    .line 74
    const/4 v1, 0x5

    .line 75
    iget v3, p0, LCa/h;->v:I

    .line 76
    .line 77
    invoke-static {v1, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->b(II)I

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    add-int/2addr v0, v1

    .line 82
    :cond_5
    move v1, v2

    .line 83
    :goto_1
    iget-object v3, p0, LCa/h;->w:Ljava/util/List;

    .line 84
    .line 85
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    if-ge v1, v3, :cond_6

    .line 90
    .line 91
    iget-object v3, p0, LCa/h;->w:Ljava/util/List;

    .line 92
    .line 93
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    check-cast v3, LIa/n;

    .line 98
    .line 99
    const/4 v4, 0x6

    .line 100
    invoke-static {v4, v3}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    add-int/2addr v0, v3

    .line 105
    add-int/lit8 v1, v1, 0x1

    .line 106
    .line 107
    goto :goto_1

    .line 108
    :cond_6
    :goto_2
    iget-object v1, p0, LCa/h;->D:Ljava/util/List;

    .line 109
    .line 110
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    if-ge v2, v1, :cond_7

    .line 115
    .line 116
    iget-object v1, p0, LCa/h;->D:Ljava/util/List;

    .line 117
    .line 118
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    check-cast v1, LIa/n;

    .line 123
    .line 124
    const/4 v3, 0x7

    .line 125
    invoke-static {v3, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->d(ILIa/n;)I

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    add-int/2addr v0, v1

    .line 130
    add-int/lit8 v2, v2, 0x1

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_7
    iget-object v1, p0, LCa/h;->a:LIa/c;

    .line 134
    .line 135
    invoke-virtual {v1}, LIa/c;->size()I

    .line 136
    .line 137
    .line 138
    move-result v1

    .line 139
    add-int/2addr v1, v0

    .line 140
    iput v1, p0, LCa/h;->F:I

    .line 141
    .line 142
    return v1
.end method

.method public final b()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/h$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/h$b;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()LIa/n$a;
    .locals 1

    .line 1
    new-instance v0, LCa/h$b;

    .line 2
    .line 3
    invoke-direct {v0}, LCa/h$b;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, LCa/h$b;->m(LCa/h;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, LCa/h;->a()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, LCa/h;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    iget v0, p0, LCa/h;->c:I

    .line 11
    .line 12
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget v0, p0, LCa/h;->b:I

    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    and-int/2addr v0, v1

    .line 19
    if-ne v0, v1, :cond_1

    .line 20
    .line 21
    iget v0, p0, LCa/h;->d:I

    .line 22
    .line 23
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 24
    .line 25
    .line 26
    :cond_1
    iget v0, p0, LCa/h;->b:I

    .line 27
    .line 28
    const/4 v1, 0x4

    .line 29
    and-int/2addr v0, v1

    .line 30
    if-ne v0, v1, :cond_2

    .line 31
    .line 32
    iget-object v0, p0, LCa/h;->e:LCa/h$c;

    .line 33
    .line 34
    invoke-virtual {v0}, LCa/h$c;->getNumber()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    const/4 v2, 0x3

    .line 39
    invoke-virtual {p1, v2, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->l(II)V

    .line 40
    .line 41
    .line 42
    :cond_2
    iget v0, p0, LCa/h;->b:I

    .line 43
    .line 44
    const/16 v2, 0x8

    .line 45
    .line 46
    and-int/2addr v0, v2

    .line 47
    if-ne v0, v2, :cond_3

    .line 48
    .line 49
    iget-object v0, p0, LCa/h;->i:LCa/q;

    .line 50
    .line 51
    invoke-virtual {p1, v1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 52
    .line 53
    .line 54
    :cond_3
    iget v0, p0, LCa/h;->b:I

    .line 55
    .line 56
    const/16 v1, 0x10

    .line 57
    .line 58
    and-int/2addr v0, v1

    .line 59
    if-ne v0, v1, :cond_4

    .line 60
    .line 61
    const/4 v0, 0x5

    .line 62
    iget v1, p0, LCa/h;->v:I

    .line 63
    .line 64
    invoke-virtual {p1, v0, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->m(II)V

    .line 65
    .line 66
    .line 67
    :cond_4
    const/4 v0, 0x0

    .line 68
    move v1, v0

    .line 69
    :goto_0
    iget-object v2, p0, LCa/h;->w:Ljava/util/List;

    .line 70
    .line 71
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-ge v1, v2, :cond_5

    .line 76
    .line 77
    iget-object v2, p0, LCa/h;->w:Ljava/util/List;

    .line 78
    .line 79
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    check-cast v2, LIa/n;

    .line 84
    .line 85
    const/4 v3, 0x6

    .line 86
    invoke-virtual {p1, v3, v2}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 87
    .line 88
    .line 89
    add-int/lit8 v1, v1, 0x1

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_5
    :goto_1
    iget-object v1, p0, LCa/h;->D:Ljava/util/List;

    .line 93
    .line 94
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    if-ge v0, v1, :cond_6

    .line 99
    .line 100
    iget-object v1, p0, LCa/h;->D:Ljava/util/List;

    .line 101
    .line 102
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    check-cast v1, LIa/n;

    .line 107
    .line 108
    const/4 v2, 0x7

    .line 109
    invoke-virtual {p1, v2, v1}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->o(ILIa/n;)V

    .line 110
    .line 111
    .line 112
    add-int/lit8 v0, v0, 0x1

    .line 113
    .line 114
    goto :goto_1

    .line 115
    :cond_6
    iget-object v0, p0, LCa/h;->a:LIa/c;

    .line 116
    .line 117
    invoke-virtual {p1, v0}, Lkotlin/reflect/jvm/internal/impl/protobuf/CodedOutputStream;->r(LIa/c;)V

    .line 118
    .line 119
    .line 120
    return-void
.end method

.method public final g()Z
    .locals 4

    .line 1
    iget-byte v0, p0, LCa/h;->E:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    iget v0, p0, LCa/h;->b:I

    .line 12
    .line 13
    const/16 v3, 0x8

    .line 14
    .line 15
    and-int/2addr v0, v3

    .line 16
    if-ne v0, v3, :cond_2

    .line 17
    .line 18
    iget-object v0, p0, LCa/h;->i:LCa/q;

    .line 19
    .line 20
    invoke-virtual {v0}, LCa/q;->g()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    iput-byte v2, p0, LCa/h;->E:B

    .line 27
    .line 28
    return v2

    .line 29
    :cond_2
    move v0, v2

    .line 30
    :goto_0
    iget-object v3, p0, LCa/h;->w:Ljava/util/List;

    .line 31
    .line 32
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-ge v0, v3, :cond_4

    .line 37
    .line 38
    iget-object v3, p0, LCa/h;->w:Ljava/util/List;

    .line 39
    .line 40
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    check-cast v3, LCa/h;

    .line 45
    .line 46
    invoke-virtual {v3}, LCa/h;->g()Z

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    if-nez v3, :cond_3

    .line 51
    .line 52
    iput-byte v2, p0, LCa/h;->E:B

    .line 53
    .line 54
    return v2

    .line 55
    :cond_3
    add-int/lit8 v0, v0, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_4
    move v0, v2

    .line 59
    :goto_1
    iget-object v3, p0, LCa/h;->D:Ljava/util/List;

    .line 60
    .line 61
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    if-ge v0, v3, :cond_6

    .line 66
    .line 67
    iget-object v3, p0, LCa/h;->D:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    check-cast v3, LCa/h;

    .line 74
    .line 75
    invoke-virtual {v3}, LCa/h;->g()Z

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    if-nez v3, :cond_5

    .line 80
    .line 81
    iput-byte v2, p0, LCa/h;->E:B

    .line 82
    .line 83
    return v2

    .line 84
    :cond_5
    add-int/lit8 v0, v0, 0x1

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_6
    iput-byte v1, p0, LCa/h;->E:B

    .line 88
    .line 89
    return v1
.end method
