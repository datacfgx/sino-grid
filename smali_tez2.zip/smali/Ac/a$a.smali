.class public interface abstract LAc/a$a;
.super Ljava/lang/Object;
.source "OnClickListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAc/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Landroid/view/View;I)V
.end method
