.class public final LAb/b;
.super Ljava/lang/Object;
.source "ContextAware.kt"


# direct methods
.method public static final a(LAb/f;)LZ9/d;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LAb/f;",
            ")",
            "LZ9/d<",
            "*>;"
        }
    .end annotation

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    instance-of v0, p0, LAb/c;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast p0, LAb/c;

    .line 11
    .line 12
    iget-object p0, p0, LAb/c;->b:LZ9/d;

    .line 13
    .line 14
    return-object p0

    .line 15
    :cond_0
    instance-of v0, p0, LCb/o0;

    .line 16
    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    check-cast p0, LCb/o0;

    .line 20
    .line 21
    iget-object p0, p0, LCb/o0;->a:LAb/f;

    .line 22
    .line 23
    invoke-static {p0}, LAb/b;->a(LAb/f;)LZ9/d;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :cond_1
    const/4 p0, 0x0

    .line 29
    return-object p0
.end method
