.class public final LAb/n$a;
.super LAb/n;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAb/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:LAb/n$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LAb/n$a;

    .line 2
    .line 3
    invoke-direct {v0}, LAb/n;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LAb/n$a;->a:LAb/n$a;

    .line 7
    .line 8
    return-void
.end method
