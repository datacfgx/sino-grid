.class public final LAb/o$b;
.super LAb/o;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAb/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:LAb/o$b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LAb/o$b;

    .line 2
    .line 3
    invoke-direct {v0}, LAb/n;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LAb/o$b;->a:LAb/o$b;

    .line 7
    .line 8
    return-void
.end method
