.class public abstract LAb/o;
.super LAb/n;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAb/o$a;,
        LAb/o$b;,
        LAb/o$c;,
        LAb/o$d;
    }
.end annotation
