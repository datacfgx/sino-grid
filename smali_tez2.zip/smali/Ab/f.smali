.class public interface abstract LAb/f;
.super Ljava/lang/Object;
.source "SerialDescriptor.kt"


# virtual methods
.method public abstract f()LAb/n;
.end method

.method public abstract getAnnotations()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/annotation/Annotation;",
            ">;"
        }
    .end annotation
.end method

.method public abstract i()Z
.end method

.method public abstract j()Ljava/lang/String;
.end method

.method public abstract k()Z
.end method

.method public abstract l(Ljava/lang/String;)I
.end method

.method public abstract m()I
.end method

.method public abstract n(I)Ljava/lang/String;
.end method

.method public abstract o(I)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/annotation/Annotation;",
            ">;"
        }
    .end annotation
.end method

.method public abstract p(I)LAb/f;
.end method

.method public abstract q(I)Z
.end method
