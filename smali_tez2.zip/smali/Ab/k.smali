.class public final LAb/k;
.super Ljava/lang/Object;
.source "Iterables.kt"

# interfaces
.implements Ljava/lang/Iterable;
.implements LT9/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "Ljava/lang/String;",
        ">;",
        "LT9/a;"
    }
.end annotation


# instance fields
.field public final synthetic a:LCb/w;


# direct methods
.method public constructor <init>(LCb/w;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAb/k;->a:LCb/w;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, LAb/j;

    .line 2
    .line 3
    iget-object v1, p0, LAb/k;->a:LCb/w;

    .line 4
    .line 5
    invoke-direct {v0, v1}, LAb/j;-><init>(LCb/w;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method
