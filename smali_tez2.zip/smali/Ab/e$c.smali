.class public final LAb/e$c;
.super LAb/e;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAb/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final a:LAb/e$c;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LAb/e$c;

    .line 2
    .line 3
    invoke-direct {v0}, LAb/e;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LAb/e$c;->a:LAb/e$c;

    .line 7
    .line 8
    return-void
.end method
