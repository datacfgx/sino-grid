.class public abstract LAb/d;
.super LAb/n;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAb/d$a;,
        LAb/d$b;
    }
.end annotation
