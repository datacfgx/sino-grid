.class public final LAb/n$b;
.super LAb/n;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LAb/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:LAb/n$b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LAb/n$b;

    .line 2
    .line 3
    invoke-direct {v0}, LAb/n;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LAb/n$b;->a:LAb/n$b;

    .line 7
    .line 8
    return-void
.end method
