.class public abstract LAb/e;
.super LAb/n;
.source "SerialKinds.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LAb/e$a;,
        LAb/e$b;,
        LAb/e$c;,
        LAb/e$d;,
        LAb/e$e;,
        LAb/e$f;,
        LAb/e$g;,
        LAb/e$h;,
        LAb/e$i;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LAb/n;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
