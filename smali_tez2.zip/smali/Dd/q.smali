.class public final synthetic LDd/q;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Ljava/util/List;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LDd/q;->a:Ljava/util/List;

    .line 5
    .line 6
    iput-object p2, p0, LDd/q;->b:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, LDd/q;->c:Landroid/content/Context;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v2, v1, LDd/q;->c:Landroid/content/Context;

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 6
    .line 7
    .line 8
    move-result-wide v3

    .line 9
    new-instance v5, Ljava/util/ArrayList;

    .line 10
    .line 11
    iget-object v6, v1, LDd/q;->a:Ljava/util/List;

    .line 12
    .line 13
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-direct {v5, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 18
    .line 19
    .line 20
    move-object v0, v6

    .line 21
    check-cast v0, Ljava/lang/Iterable;

    .line 22
    .line 23
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object v7

    .line 27
    const/4 v9, 0x0

    .line 28
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    move-object v10, v0

    .line 39
    check-cast v10, Lorg/tezza/domain/gallery/a;

    .line 40
    .line 41
    iget-object v0, v10, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 42
    .line 43
    :try_start_0
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-static {v2, v0}, LDd/v;->b(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    new-instance v11, Ljava/io/File;

    .line 52
    .line 53
    invoke-direct {v11, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v11}, Ljava/io/File;->exists()Z

    .line 57
    .line 58
    .line 59
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 60
    goto :goto_1

    .line 61
    :catchall_0
    const/4 v0, 0x0

    .line 62
    :goto_1
    if-nez v0, :cond_0

    .line 63
    .line 64
    :try_start_1
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    iget-object v11, v10, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v11}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 71
    .line 72
    .line 73
    move-result-object v11

    .line 74
    invoke-virtual {v0, v11}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    .line 75
    .line 76
    .line 77
    move-result-object v11
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 78
    if-eqz v11, :cond_0

    .line 79
    .line 80
    :try_start_2
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 81
    .line 82
    :try_start_3
    invoke-interface {v11}, Ljava/io/Closeable;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 83
    .line 84
    .line 85
    goto :goto_2

    .line 86
    :catchall_1
    move-exception v0

    .line 87
    move-object v12, v0

    .line 88
    :try_start_4
    throw v12
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 89
    :catchall_2
    move-exception v0

    .line 90
    :try_start_5
    invoke-static {v11, v12}, LR9/b;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 91
    .line 92
    .line 93
    throw v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 94
    :catch_0
    move-exception v0

    .line 95
    goto :goto_3

    .line 96
    :cond_0
    :goto_2
    move/from16 v17, v9

    .line 97
    .line 98
    goto/16 :goto_a

    .line 99
    .line 100
    :goto_3
    sget-object v11, LGc/b;->a:LGc/b;

    .line 101
    .line 102
    iget-object v12, v10, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 103
    .line 104
    const-string v13, "\n"

    .line 105
    .line 106
    const-string v14, "Gallery item missed: \n"

    .line 107
    .line 108
    const-string v15, "path"

    .line 109
    .line 110
    invoke-static {v12, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    const-string v15, "exception"

    .line 114
    .line 115
    invoke-static {v0, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    const-wide v15, 0x1773a35daf9L

    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    move/from16 v17, v9

    .line 124
    .line 125
    iget-wide v8, v10, Lorg/tezza/domain/gallery/a;->b:J

    .line 126
    .line 127
    cmp-long v8, v8, v15

    .line 128
    .line 129
    if-lez v8, :cond_4

    .line 130
    .line 131
    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v8

    .line 135
    new-instance v9, Landroid/os/Bundle;

    .line 136
    .line 137
    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    .line 138
    .line 139
    .line 140
    const-string v10, "missed_exceptions_msg"

    .line 141
    .line 142
    const/16 v15, 0x64

    .line 143
    .line 144
    if-eqz v8, :cond_2

    .line 145
    .line 146
    invoke-static {v15, v8}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v16

    .line 150
    if-nez v16, :cond_1

    .line 151
    .line 152
    goto :goto_5

    .line 153
    :cond_1
    :goto_4
    move-object/from16 v15, v16

    .line 154
    .line 155
    goto :goto_6

    .line 156
    :catchall_3
    move-exception v0

    .line 157
    goto :goto_8

    .line 158
    :cond_2
    :goto_5
    const-string v16, ""

    .line 159
    .line 160
    goto :goto_4

    .line 161
    :goto_6
    invoke-virtual {v9, v10, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    const-string v10, "missed_exception"

    .line 165
    .line 166
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v15

    .line 170
    move-object/from16 v16, v0

    .line 171
    .line 172
    const/16 v0, 0x64

    .line 173
    .line 174
    invoke-static {v0, v15}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v15

    .line 178
    invoke-virtual {v9, v10, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    const-string v10, "missed_path"

    .line 182
    .line 183
    invoke-static {v0, v12}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v15

    .line 187
    invoke-virtual {v9, v10, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    invoke-static {v0, v12}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v10

    .line 194
    if-eqz v8, :cond_3

    .line 195
    .line 196
    invoke-static {v0, v8}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v8

    .line 200
    goto :goto_7

    .line 201
    :cond_3
    const/4 v8, 0x0

    .line 202
    :goto_7
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v12

    .line 206
    invoke-static {v0, v12}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    new-instance v12, Ljava/lang/StringBuilder;

    .line 211
    .line 212
    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 216
    .line 217
    .line 218
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    .line 220
    .line 221
    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 222
    .line 223
    .line 224
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 225
    .line 226
    .line 227
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 228
    .line 229
    .line 230
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-static {v11, v0}, LBd/n;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    .line 236
    .line 237
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 238
    .line 239
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    invoke-static {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    const-string v8, "gallery_item_missed"

    .line 248
    .line 249
    invoke-virtual {v0, v8, v9}, Lcom/google/firebase/analytics/FirebaseAnalytics;->a(Ljava/lang/String;Landroid/os/Bundle;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 250
    .line 251
    .line 252
    goto :goto_9

    .line 253
    :goto_8
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 254
    .line 255
    .line 256
    :cond_4
    :goto_9
    add-int/lit8 v9, v17, 0x1

    .line 257
    .line 258
    goto/16 :goto_0

    .line 259
    .line 260
    :goto_a
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    move/from16 v9, v17

    .line 264
    .line 265
    goto/16 :goto_0

    .line 266
    .line 267
    :cond_5
    move/from16 v17, v9

    .line 268
    .line 269
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 270
    .line 271
    .line 272
    move-result-wide v7

    .line 273
    sub-long/2addr v7, v3

    .line 274
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    iget-object v2, v1, LDd/q;->b:Ljava/lang/String;

    .line 279
    .line 280
    const-string v3, "source"

    .line 281
    .line 282
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    :try_start_7
    new-instance v4, Landroid/os/Bundle;

    .line 286
    .line 287
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 288
    .line 289
    .line 290
    const-string v6, "items_count"

    .line 291
    .line 292
    invoke-virtual {v4, v6, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 293
    .line 294
    .line 295
    const-string v0, "duration_ms"

    .line 296
    .line 297
    invoke-virtual {v4, v0, v7, v8}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 298
    .line 299
    .line 300
    const/16 v0, 0x28

    .line 301
    .line 302
    invoke-static {v0, v2}, Lkotlin/text/t;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object v0

    .line 306
    invoke-virtual {v4, v3, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    sget-object v0, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 310
    .line 311
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    invoke-static {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    .line 316
    .line 317
    .line 318
    move-result-object v0

    .line 319
    const-string v2, "gallery_fetch_timing"

    .line 320
    .line 321
    invoke-virtual {v0, v2, v4}, Lcom/google/firebase/analytics/FirebaseAnalytics;->a(Ljava/lang/String;Landroid/os/Bundle;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 322
    .line 323
    .line 324
    goto :goto_b

    .line 325
    :catchall_4
    move-exception v0

    .line 326
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 327
    .line 328
    .line 329
    :goto_b
    new-instance v0, LDd/r;

    .line 330
    .line 331
    move/from16 v9, v17

    .line 332
    .line 333
    invoke-direct {v0, v5, v9, v7, v8}, LDd/r;-><init>(Ljava/util/ArrayList;IJ)V

    .line 334
    .line 335
    .line 336
    return-object v0
.end method
