.class public final synthetic LDd/l;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/d;
.implements LC1/c$a;
.implements Li9/c;
.implements Lg0/i;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LDd/l;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LDd/l;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LDd/l;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDd/l;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lec/f;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/flow/FlowRepositoryImpl;->m(Lec/f;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LDd/l;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LLc/Y2;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LLc/Y2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "p0"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDd/l;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LDd/k;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LDd/k;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Ljava/util/List;

    .line 15
    .line 16
    return-object p1
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    iget-object v0, p0, LDd/l;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LOc/r1;

    .line 4
    .line 5
    invoke-virtual {v0}, LOc/r1;->K()LOc/a2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-virtual {v1}, LOc/a2;->C()Lorg/tezza/domain/gallery/ShimmyAdjustments;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    if-eqz v1, :cond_1

    .line 22
    .line 23
    int-to-float p1, p1

    .line 24
    const/high16 p2, 0x42c80000    # 100.0f

    .line 25
    .line 26
    div-float/2addr p1, p2

    .line 27
    iput p1, v1, Lorg/tezza/domain/gallery/ShimmyAdjustments;->g:F

    .line 28
    .line 29
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 30
    .line 31
    invoke-virtual {v0}, LOc/r1;->k0()V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public g(D)D
    .locals 7

    .line 1
    iget-object v0, p0, LDd/l;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lg0/p;

    .line 4
    .line 5
    iget-wide v1, v0, Lg0/p;->b:D

    .line 6
    .line 7
    iget-wide v3, v0, Lg0/p;->e:D

    .line 8
    .line 9
    iget-wide v5, v0, Lg0/p;->d:D

    .line 10
    .line 11
    mul-double/2addr v3, v5

    .line 12
    cmpl-double v3, p1, v3

    .line 13
    .line 14
    if-ltz v3, :cond_0

    .line 15
    .line 16
    iget-wide v3, v0, Lg0/p;->f:D

    .line 17
    .line 18
    sub-double/2addr p1, v3

    .line 19
    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    .line 20
    .line 21
    iget-wide v5, v0, Lg0/p;->a:D

    .line 22
    .line 23
    div-double/2addr v3, v5

    .line 24
    invoke-static {p1, p2, v3, v4}, Ljava/lang/Math;->pow(DD)D

    .line 25
    .line 26
    .line 27
    move-result-wide p1

    .line 28
    iget-wide v3, v0, Lg0/p;->c:D

    .line 29
    .line 30
    sub-double/2addr p1, v3

    .line 31
    div-double/2addr p1, v1

    .line 32
    return-wide p1

    .line 33
    :cond_0
    iget-wide v0, v0, Lg0/p;->g:D

    .line 34
    .line 35
    sub-double/2addr p1, v0

    .line 36
    div-double/2addr p1, v5

    .line 37
    return-wide p1
.end method
