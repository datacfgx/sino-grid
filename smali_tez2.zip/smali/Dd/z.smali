.class public final LDd/z;
.super LCd/a;
.source "TezzaLibraryPickerSource.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LCd/a<",
        "Ljava/util/List<",
        "+",
        "Lorg/tezza/domain/gallery/a;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic b:LDd/A;

.field public final synthetic c:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/util/List<",
            "Lb9/a;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(LDd/A;Lkotlin/jvm/functions/Function1;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LDd/A;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lb9/a;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, LDd/z;->b:LDd/A;

    .line 2
    .line 3
    iput-object p2, p0, LDd/z;->c:Lkotlin/jvm/functions/Function1;

    .line 4
    .line 5
    invoke-direct {p0}, Lt9/a;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    check-cast p1, Ljava/util/List;

    .line 3
    .line 4
    const-string v1, "items"

    .line 5
    .line 6
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sget-object v2, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 10
    .line 11
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const-string v1, "ctx"

    .line 19
    .line 20
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const-string v1, "source"

    .line 24
    .line 25
    const-string v3, "TezzaLibraryPickerSource"

    .line 26
    .line 27
    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    new-instance v1, LDd/q;

    .line 31
    .line 32
    invoke-direct {v1, p1, v3, v2}, LDd/q;-><init>(Ljava/util/List;Ljava/lang/String;Landroid/content/Context;)V

    .line 33
    .line 34
    .line 35
    new-instance p1, Lp9/a;

    .line 36
    .line 37
    invoke-direct {p1, v1}, Lp9/a;-><init>(Ljava/util/concurrent/Callable;)V

    .line 38
    .line 39
    .line 40
    sget-object v1, Lw9/a;->c:Le9/m;

    .line 41
    .line 42
    invoke-virtual {p1, v1}, Le9/n;->e(Le9/m;)Lp9/d;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-static {}, Lf9/a;->a()Lf9/b;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    new-instance v2, Lp9/c;

    .line 51
    .line 52
    invoke-direct {v2, p1, v1}, Lp9/c;-><init>(Le9/n;Lf9/b;)V

    .line 53
    .line 54
    .line 55
    const-string p1, "observeOn(...)"

    .line 56
    .line 57
    invoke-static {v2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    new-instance p1, LDd/x;

    .line 61
    .line 62
    iget-object v1, p0, LDd/z;->c:Lkotlin/jvm/functions/Function1;

    .line 63
    .line 64
    invoke-direct {p1, v0, v1}, LDd/x;-><init>(ILjava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    new-instance v3, LDd/y;

    .line 68
    .line 69
    invoke-direct {v3, v0, v1}, LDd/y;-><init>(ILjava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    invoke-static {v2, p1, v3}, Lv9/b;->a(Le9/n;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)Lm9/e;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    iget-object v0, p0, LDd/z;->b:LDd/A;

    .line 77
    .line 78
    iget-object v0, v0, LDd/A;->a:Lg9/a;

    .line 79
    .line 80
    invoke-static {p1, v0}, Lv9/a;->a(Lg9/b;Lg9/a;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public final onError(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    const-string v0, "e"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LDd/z;->c:Lkotlin/jvm/functions/Function1;

    .line 7
    .line 8
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-void
.end method
