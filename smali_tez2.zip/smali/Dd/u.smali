.class public final enum LDd/u;
.super Ljava/lang/Enum;
.source "MediaUtils.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LDd/u;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u0008\n\u0002\u0008\u000c\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0013\u0008\u0002\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0019\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\u0006\u001a\u0004\u0008\u0007\u0010\u0008j\u0002\u0008\tj\u0002\u0008\nj\u0002\u0008\u000bj\u0002\u0008\u000cj\u0002\u0008\r\u00a8\u0006\u000e"
    }
    d2 = {
        "LDd/u;",
        "",
        "",
        "value",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/Integer;)V",
        "Ljava/lang/Integer;",
        "getValue",
        "()Ljava/lang/Integer;",
        "ROTATED_0",
        "ROTATED_90",
        "ROTATED_180",
        "ROTATED_270",
        "UNDEFINED",
        "app_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:LN9/a;

.field private static final synthetic $VALUES:[LDd/u;

.field public static final enum ROTATED_0:LDd/u;

.field public static final enum ROTATED_180:LDd/u;

.field public static final enum ROTATED_270:LDd/u;

.field public static final enum ROTATED_90:LDd/u;

.field public static final enum UNDEFINED:LDd/u;


# instance fields
.field private final value:Ljava/lang/Integer;


# direct methods
.method private static final synthetic $values()[LDd/u;
    .locals 5

    .line 1
    sget-object v0, LDd/u;->ROTATED_0:LDd/u;

    .line 2
    .line 3
    sget-object v1, LDd/u;->ROTATED_90:LDd/u;

    .line 4
    .line 5
    sget-object v2, LDd/u;->ROTATED_180:LDd/u;

    .line 6
    .line 7
    sget-object v3, LDd/u;->ROTATED_270:LDd/u;

    .line 8
    .line 9
    sget-object v4, LDd/u;->UNDEFINED:LDd/u;

    .line 10
    .line 11
    filled-new-array {v0, v1, v2, v3, v4}, [LDd/u;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 4

    .line 1
    .line 2
    new-instance v0, LDd/u;

    .line 3
    const/4 v1, 0x0

    .line 4
    .line 5
    .line 6
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    move-result-object v2

    .line 8
    .line 9
    const/4 v3, 0x0

    sget-object v3, Lorg/threeten/bp/zone/wc/sZCQCPwiuTGMYi;->zbJ:Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    invoke-direct {v0, v3, v1, v2}, LDd/u;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 13
    .line 14
    sput-object v0, LDd/u;->ROTATED_0:LDd/u;

    .line 15
    .line 16
    new-instance v0, LDd/u;

    .line 17
    .line 18
    const/16 v1, 0x5a

    .line 19
    .line 20
    .line 21
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    move-result-object v1

    .line 23
    .line 24
    const-string v2, "ROTATED_90"

    .line 25
    const/4 v3, 0x1

    .line 26
    .line 27
    .line 28
    invoke-direct {v0, v2, v3, v1}, LDd/u;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 29
    .line 30
    sput-object v0, LDd/u;->ROTATED_90:LDd/u;

    .line 31
    .line 32
    new-instance v0, LDd/u;

    .line 33
    .line 34
    const/16 v1, 0xb4

    .line 35
    .line 36
    .line 37
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 38
    move-result-object v1

    .line 39
    .line 40
    const-string v2, "ROTATED_180"

    .line 41
    const/4 v3, 0x2

    .line 42
    .line 43
    .line 44
    invoke-direct {v0, v2, v3, v1}, LDd/u;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 45
    .line 46
    sput-object v0, LDd/u;->ROTATED_180:LDd/u;

    .line 47
    .line 48
    new-instance v0, LDd/u;

    .line 49
    .line 50
    const/16 v1, 0x10e

    .line 51
    .line 52
    .line 53
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    move-result-object v1

    .line 55
    .line 56
    const-string v2, "ROTATED_270"

    .line 57
    const/4 v3, 0x3

    .line 58
    .line 59
    .line 60
    invoke-direct {v0, v2, v3, v1}, LDd/u;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 61
    .line 62
    sput-object v0, LDd/u;->ROTATED_270:LDd/u;

    .line 63
    .line 64
    new-instance v0, LDd/u;

    .line 65
    const/4 v1, 0x0

    .line 66
    .line 67
    const/4 v2, 0x0

    sget-object v2, Lva/ks/RWEdaNcGoAgPq;->jdZwNqZMZYPr:Ljava/lang/String;

    .line 68
    const/4 v3, 0x4

    .line 69
    .line 70
    .line 71
    invoke-direct {v0, v2, v3, v1}, LDd/u;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V

    .line 72
    .line 73
    sput-object v0, LDd/u;->UNDEFINED:LDd/u;

    .line 74
    .line 75
    .line 76
    invoke-static {}, LDd/u;->$values()[LDd/u;

    .line 77
    move-result-object v0

    .line 78
    .line 79
    sput-object v0, LDd/u;->$VALUES:[LDd/u;

    .line 80
    .line 81
    .line 82
    invoke-static {v0}, LN9/b;->a([Ljava/lang/Enum;)LN9/c;

    .line 83
    move-result-object v0

    .line 84
    .line 85
    sput-object v0, LDd/u;->$ENTRIES:LN9/a;

    .line 86
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/Integer;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Integer;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, LDd/u;->value:Ljava/lang/Integer;

    .line 5
    .line 6
    return-void
.end method

.method public static getEntries()LN9/a;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "LN9/a<",
            "LDd/u;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, LDd/u;->$ENTRIES:LN9/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LDd/u;
    .locals 1

    .line 1
    const-class v0, LDd/u;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LDd/u;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LDd/u;
    .locals 1

    .line 1
    sget-object v0, LDd/u;->$VALUES:[LDd/u;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LDd/u;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getValue()Ljava/lang/Integer;
    .locals 1

    .line 1
    iget-object v0, p0, LDd/u;->value:Ljava/lang/Integer;

    .line 2
    .line 3
    return-object v0
.end method
