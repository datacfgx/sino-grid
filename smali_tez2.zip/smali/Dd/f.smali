.class public final synthetic LDd/f;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/d;
.implements Lt1/u;
.implements LC1/c$a;
.implements Li9/c;
.implements Lg0/i;
.implements Lt4/i;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LDd/f;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LDd/f;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LDd/f;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LLc/V2;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/instafeed/InstagramFeedRepositoryImpl;->g(LLc/V2;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LLc/V2;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LLc/V2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :pswitch_1
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LLc/V2;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, LLc/V2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "p0"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LDd/o;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LDd/o;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lkotlin/Pair;

    .line 15
    .line 16
    return-object p1
.end method

.method public b(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Void;

    .line 2
    .line 3
    iget-object p1, p0, LDd/f;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Lh4/k;

    .line 6
    .line 7
    iget-object p1, p1, Lh4/k;->g:LJ3/E;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public d(Landroid/view/View;Lt1/h0;)Lt1/h0;
    .locals 2

    .line 1
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lkotlin/jvm/functions/Function2;

    .line 4
    .line 5
    const-string v1, "$marginAdjuster"

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v1, "v"

    .line 11
    .line 12
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v1, "insets"

    .line 16
    .line 17
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object p2, p2, Lt1/h0;->a:Lt1/h0$j;

    .line 21
    .line 22
    const/16 v1, 0x87

    .line 23
    .line 24
    invoke-virtual {p2, v1}, Lt1/h0$j;->f(I)Ll1/e;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    const-string v1, "getInsets(...)"

    .line 29
    .line 30
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    check-cast v1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 40
    .line 41
    invoke-interface {v0, p2, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 45
    .line 46
    .line 47
    sget-object p1, Lt1/h0;->b:Lt1/h0;

    .line 48
    .line 49
    return-object p1

    .line 50
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 51
    .line 52
    const-string p2, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams"

    .line 53
    .line 54
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    throw p1
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LOc/r1;

    .line 4
    .line 5
    invoke-virtual {v0}, LOc/r1;->K()LOc/a2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-virtual {v1}, LOc/a2;->k()Lorg/tezza/domain/gallery/DebugAdjustments;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    if-eqz v1, :cond_1

    .line 22
    .line 23
    int-to-float p1, p1

    .line 24
    const/high16 p2, 0x42c80000    # 100.0f

    .line 25
    .line 26
    div-float/2addr p1, p2

    .line 27
    iput p1, v1, Lorg/tezza/domain/gallery/DebugAdjustments;->g:F

    .line 28
    .line 29
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 30
    .line 31
    invoke-virtual {v0}, LOc/r1;->k0()V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public g(D)D
    .locals 8

    .line 1
    iget-object v0, p0, LDd/f;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lg0/o;

    .line 4
    .line 5
    iget-object v1, v0, Lg0/o;->k:Lg0/i;

    .line 6
    .line 7
    invoke-interface {v1, p1, p2}, Lg0/i;->g(D)D

    .line 8
    .line 9
    .line 10
    move-result-wide v2

    .line 11
    iget p1, v0, Lg0/o;->e:F

    .line 12
    .line 13
    float-to-double v4, p1

    .line 14
    iget p1, v0, Lg0/o;->f:F

    .line 15
    .line 16
    float-to-double v6, p1

    .line 17
    invoke-static/range {v2 .. v7}, Lkotlin/ranges/b;->a(DDD)D

    .line 18
    .line 19
    .line 20
    move-result-wide p1

    .line 21
    return-wide p1
.end method
