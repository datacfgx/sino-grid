.class public final synthetic LDd/y;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LDd/y;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LDd/y;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, LDd/y;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v3, p0, LDd/y;->a:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Ljava/util/List;

    .line 11
    .line 12
    sget v0, Lcd/N;->I0:I

    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    if-ne p1, v1, :cond_0

    .line 21
    .line 22
    check-cast v2, Lcd/N;

    .line 23
    .line 24
    invoke-virtual {v2}, LJc/e;->r0()V

    .line 25
    .line 26
    .line 27
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_0
    check-cast p1, Lorg/tezza/data/common/RepoResult;

    .line 31
    .line 32
    sget p1, LZc/m;->B0:I

    .line 33
    .line 34
    check-cast v2, LZc/m;

    .line 35
    .line 36
    invoke-virtual {v2}, LZc/m;->G0()V

    .line 37
    .line 38
    .line 39
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 40
    .line 41
    return-object p1

    .line 42
    :pswitch_1
    check-cast p1, LS0/c;

    .line 43
    .line 44
    const-string v1, "$this$offset"

    .line 45
    .line 46
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    check-cast v2, LX8/F0;

    .line 50
    .line 51
    iget-object p1, v2, LX8/F0;->e:LM/q0;

    .line 52
    .line 53
    check-cast p1, LM/e1;

    .line 54
    .line 55
    invoke-virtual {p1}, LM/e1;->k()F

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    invoke-static {p1}, LU9/c;->b(F)I

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    invoke-static {v0, p1}, LE3/f;->a(II)J

    .line 64
    .line 65
    .line 66
    move-result-wide v0

    .line 67
    new-instance p1, LS0/k;

    .line 68
    .line 69
    invoke-direct {p1, v0, v1}, LS0/k;-><init>(J)V

    .line 70
    .line 71
    .line 72
    return-object p1

    .line 73
    :pswitch_2
    check-cast p1, LLc/D3;

    .line 74
    .line 75
    sget v0, LVc/r;->G0:I

    .line 76
    .line 77
    check-cast v2, LVc/r;

    .line 78
    .line 79
    invoke-virtual {v2}, LJc/e;->q0()LJc/f;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    check-cast v0, LVc/v;

    .line 84
    .line 85
    iget-object v0, v0, LVc/v;->f:Landroidx/lifecycle/z;

    .line 86
    .line 87
    invoke-virtual {v0}, Landroidx/lifecycle/x;->d()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, LVc/u;

    .line 92
    .line 93
    invoke-virtual {v2, v0, p1}, LVc/r;->L0(LVc/u;LLc/D3;)V

    .line 94
    .line 95
    .line 96
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 97
    .line 98
    return-object p1

    .line 99
    :pswitch_3
    check-cast p1, LU3/b$b;

    .line 100
    .line 101
    check-cast v2, LT3/f;

    .line 102
    .line 103
    const-string v0, "$systemActionHandler"

    .line 104
    .line 105
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    const-string v0, "$this$function"

    .line 109
    .line 110
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    iput-boolean v1, p1, LU3/b$a;->b:Z

    .line 114
    .line 115
    const-string v0, "ctsystem_openurl"

    .line 116
    .line 117
    invoke-virtual {p1, v0}, LU3/b$a;->b(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    const-string v0, "Android"

    .line 121
    .line 122
    const-string v3, "name"

    .line 123
    .line 124
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    const-string v3, ""

    .line 128
    .line 129
    const-string v4, "defaultValue"

    .line 130
    .line 131
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    sget-object v4, LU3/j;->STRING:LU3/j;

    .line 135
    .line 136
    invoke-virtual {p1, v0, v4, v3}, LU3/b$a;->a(Ljava/lang/String;LU3/j;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    new-instance v0, LOc/g1;

    .line 140
    .line 141
    invoke-direct {v0, v1, v2}, LOc/g1;-><init>(ILjava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    const-string v1, "presenter"

    .line 145
    .line 146
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    iput-object v0, p1, LU3/b$a;->g:LU3/h;

    .line 150
    .line 151
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 152
    .line 153
    return-object p1

    .line 154
    :pswitch_4
    check-cast p1, LDd/r;

    .line 155
    .line 156
    const-string v3, "result"

    .line 157
    .line 158
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    iget-object p1, p1, LDd/r;->a:Ljava/util/ArrayList;

    .line 162
    .line 163
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->asReversed(Ljava/util/List;)Ljava/util/List;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    check-cast p1, Ljava/lang/Iterable;

    .line 168
    .line 169
    new-instance v3, Ljava/util/ArrayList;

    .line 170
    .line 171
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 172
    .line 173
    .line 174
    move-result v4

    .line 175
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 176
    .line 177
    .line 178
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 183
    .line 184
    .line 185
    move-result v4

    .line 186
    if-eqz v4, :cond_4

    .line 187
    .line 188
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v4

    .line 192
    check-cast v4, Lorg/tezza/domain/gallery/a;

    .line 193
    .line 194
    new-instance v5, Lb9/a;

    .line 195
    .line 196
    iget-object v6, v4, Lorg/tezza/domain/gallery/a;->a:Ljava/lang/String;

    .line 197
    .line 198
    iget-object v7, v4, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 199
    .line 200
    const-string v8, "://"

    .line 201
    .line 202
    invoke-static {v7, v8, v0}, Lkotlin/text/StringsKt;->x(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 203
    .line 204
    .line 205
    move-result v9

    .line 206
    const-string v10, "fromFile(...)"

    .line 207
    .line 208
    if-eqz v9, :cond_1

    .line 209
    .line 210
    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 211
    .line 212
    .line 213
    move-result-object v7

    .line 214
    goto :goto_1

    .line 215
    :cond_1
    new-instance v9, Ljava/io/File;

    .line 216
    .line 217
    invoke-direct {v9, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    invoke-static {v9}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 221
    .line 222
    .line 223
    move-result-object v7

    .line 224
    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    :goto_1
    iget-object v9, v4, Lorg/tezza/domain/gallery/a;->g:Ljava/lang/String;

    .line 228
    .line 229
    if-nez v9, :cond_2

    .line 230
    .line 231
    iget-object v9, v4, Lorg/tezza/domain/gallery/a;->f:Ljava/lang/String;

    .line 232
    .line 233
    :cond_2
    invoke-static {v9, v8, v0}, Lkotlin/text/StringsKt;->x(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 234
    .line 235
    .line 236
    move-result v8

    .line 237
    if-eqz v8, :cond_3

    .line 238
    .line 239
    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 240
    .line 241
    .line 242
    move-result-object v8

    .line 243
    goto :goto_2

    .line 244
    :cond_3
    new-instance v8, Ljava/io/File;

    .line 245
    .line 246
    invoke-direct {v8, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    invoke-static {v8}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 250
    .line 251
    .line 252
    move-result-object v8

    .line 253
    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 254
    .line 255
    .line 256
    :goto_2
    iget-boolean v9, v4, Lorg/tezza/domain/gallery/a;->d:Z

    .line 257
    .line 258
    xor-int/2addr v9, v1

    .line 259
    iget-boolean v10, v4, Lorg/tezza/domain/gallery/a;->e:Z

    .line 260
    .line 261
    invoke-direct/range {v5 .. v10}, Lb9/a;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;ZZ)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 265
    .line 266
    .line 267
    goto :goto_0

    .line 268
    :cond_4
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 269
    .line 270
    invoke-interface {v2, v3}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 274
    .line 275
    return-object p1

    .line 276
    nop

    .line 277
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
