.class public final synthetic LDd/i;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LDd/i;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget v2, p0, LDd/i;->a:I

    .line 4
    .line 5
    packed-switch v2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/util/List;

    .line 9
    .line 10
    invoke-static {p1}, Lorg/tezza/data/flow/FlowRepositoryImpl;->B(Ljava/util/List;)Le9/j;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_0
    check-cast p1, Lg4/d;

    .line 16
    .line 17
    const-string v2, "store"

    .line 18
    .line 19
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v2, p1, Lg4/d;->e:Lorg/json/JSONArray;

    .line 23
    .line 24
    const-string v3, "null cannot be cast to non-null type org.json.JSONArray"

    .line 25
    .line 26
    if-eqz v2, :cond_0

    .line 27
    .line 28
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    goto :goto_3

    .line 32
    :cond_0
    iget-object v2, p1, Lg4/d;->a:Ls4/a;

    .line 33
    .line 34
    const-string v4, "delayed_inapp_notifs_cs"

    .line 35
    .line 36
    const-string v5, ""

    .line 37
    .line 38
    invoke-virtual {v2, v4, v5}, Ls4/a;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    if-eqz v2, :cond_2

    .line 43
    .line 44
    invoke-static {v2}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 45
    .line 46
    .line 47
    move-result v4

    .line 48
    if-eqz v4, :cond_1

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    :try_start_0
    new-instance v4, Lorg/json/JSONArray;

    .line 52
    .line 53
    iget-object v5, p1, Lg4/d;->b:LL3/o;

    .line 54
    .line 55
    invoke-interface {v5, v2}, LL3/o;->c(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-direct {v4, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :catch_0
    new-instance v4, Lorg/json/JSONArray;

    .line 64
    .line 65
    invoke-direct {v4}, Lorg/json/JSONArray;-><init>()V

    .line 66
    .line 67
    .line 68
    :goto_0
    move-object v2, v4

    .line 69
    goto :goto_2

    .line 70
    :cond_2
    :goto_1
    new-instance v2, Lorg/json/JSONArray;

    .line 71
    .line 72
    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    .line 73
    .line 74
    .line 75
    :goto_2
    iput-object v2, p1, Lg4/d;->e:Lorg/json/JSONArray;

    .line 76
    .line 77
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    :goto_3
    new-instance p1, Ljava/util/ArrayList;

    .line 81
    .line 82
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    :goto_4
    if-ge v1, v3, :cond_4

    .line 90
    .line 91
    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    instance-of v5, v4, Lorg/json/JSONObject;

    .line 96
    .line 97
    if-eqz v5, :cond_3

    .line 98
    .line 99
    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    :cond_3
    add-int/2addr v1, v0

    .line 103
    goto :goto_4

    .line 104
    :cond_4
    return-object p1

    .line 105
    :pswitch_1
    check-cast p1, Lcom/android/billingclient/api/e$b;

    .line 106
    .line 107
    iget-object v0, p1, Lcom/android/billingclient/api/e$b;->a:Ljava/lang/String;

    .line 108
    .line 109
    const-string v1, "/"

    .line 110
    .line 111
    invoke-static {v0, v1}, LP4/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    iget-object v1, p1, Lcom/android/billingclient/api/e$b;->d:Ljava/lang/String;

    .line 116
    .line 117
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    const-string v1, "x"

    .line 121
    .line 122
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    iget p1, p1, Lcom/android/billingclient/api/e$b;->e:I

    .line 126
    .line 127
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    return-object p1

    .line 135
    :pswitch_2
    check-cast p1, Lkotlin/Pair;

    .line 136
    .line 137
    invoke-virtual {p1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    check-cast v2, Ljava/lang/Number;

    .line 142
    .line 143
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    invoke-virtual {p1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    check-cast p1, Ljava/util/List;

    .line 152
    .line 153
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    if-eqz v3, :cond_5

    .line 158
    .line 159
    goto/16 :goto_8

    .line 160
    .line 161
    :cond_5
    new-instance v3, Landroid/os/Bundle;

    .line 162
    .line 163
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 164
    .line 165
    .line 166
    const-string v4, "items_count"

    .line 167
    .line 168
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v5

    .line 172
    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    sget-object v4, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 176
    .line 177
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 178
    .line 179
    .line 180
    move-result-object v4

    .line 181
    invoke-static {v4}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    .line 182
    .line 183
    .line 184
    move-result-object v4

    .line 185
    const-string v5, "close_picker"

    .line 186
    .line 187
    invoke-virtual {v4, v5, v3}, Lcom/google/firebase/analytics/FirebaseAnalytics;->a(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 188
    .line 189
    .line 190
    check-cast p1, Ljava/lang/Iterable;

    .line 191
    .line 192
    instance-of v3, p1, Ljava/util/Collection;

    .line 193
    .line 194
    if-eqz v3, :cond_7

    .line 195
    .line 196
    move-object v4, p1

    .line 197
    check-cast v4, Ljava/util/Collection;

    .line 198
    .line 199
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    if-eqz v4, :cond_7

    .line 204
    .line 205
    :cond_6
    move v4, v1

    .line 206
    goto :goto_5

    .line 207
    :cond_7
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 208
    .line 209
    .line 210
    move-result-object v4

    .line 211
    :cond_8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 212
    .line 213
    .line 214
    move-result v5

    .line 215
    if-eqz v5, :cond_6

    .line 216
    .line 217
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v5

    .line 221
    check-cast v5, LDd/p;

    .line 222
    .line 223
    iget-boolean v5, v5, LDd/p;->b:Z

    .line 224
    .line 225
    if-eqz v5, :cond_8

    .line 226
    .line 227
    move v4, v0

    .line 228
    :goto_5
    if-eqz v3, :cond_a

    .line 229
    .line 230
    move-object v3, p1

    .line 231
    check-cast v3, Ljava/util/Collection;

    .line 232
    .line 233
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 234
    .line 235
    .line 236
    move-result v3

    .line 237
    if-eqz v3, :cond_a

    .line 238
    .line 239
    :cond_9
    move v0, v1

    .line 240
    goto :goto_6

    .line 241
    :cond_a
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 242
    .line 243
    .line 244
    move-result-object p1

    .line 245
    :cond_b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 246
    .line 247
    .line 248
    move-result v3

    .line 249
    if-eqz v3, :cond_9

    .line 250
    .line 251
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    check-cast v3, LDd/p;

    .line 256
    .line 257
    iget-boolean v3, v3, LDd/p;->b:Z

    .line 258
    .line 259
    if-nez v3, :cond_b

    .line 260
    .line 261
    :goto_6
    if-eqz v4, :cond_c

    .line 262
    .line 263
    if-eqz v0, :cond_c

    .line 264
    .line 265
    const-string p1, "Photo and Video"

    .line 266
    .line 267
    goto :goto_7

    .line 268
    :cond_c
    if-eqz v0, :cond_d

    .line 269
    .line 270
    const-string p1, "Video"

    .line 271
    .line 272
    goto :goto_7

    .line 273
    :cond_d
    const-string p1, "Photo"

    .line 274
    .line 275
    :goto_7
    const-string v0, "isPhoto"

    .line 276
    .line 277
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    new-instance v0, Ljava/util/HashMap;

    .line 281
    .line 282
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 283
    .line 284
    .line 285
    const-string v1, "it"

    .line 286
    .line 287
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    const-string v2, "Uploaded media count"

    .line 295
    .line 296
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    const-string v1, "Uploaded Media Type"

    .line 300
    .line 301
    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 305
    .line 306
    new-instance p1, Ljava/lang/StringBuilder;

    .line 307
    .line 308
    const-string v1, "sendEvent() called with: eventName = Upload Media, properties = "

    .line 309
    .line 310
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 314
    .line 315
    .line 316
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object p1

    .line 320
    const-string v1, "CleverTap"

    .line 321
    .line 322
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 323
    .line 324
    .line 325
    sget-object p1, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 326
    .line 327
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 328
    .line 329
    .line 330
    move-result-object p1

    .line 331
    invoke-static {p1}, Lcom/clevertap/android/sdk/a;->g(Landroid/content/Context;)Lcom/clevertap/android/sdk/a;

    .line 332
    .line 333
    .line 334
    move-result-object p1

    .line 335
    if-eqz p1, :cond_e

    .line 336
    .line 337
    const-string v1, "Upload Media"

    .line 338
    .line 339
    invoke-virtual {p1, v1, v0}, Lcom/clevertap/android/sdk/a;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 340
    .line 341
    .line 342
    :cond_e
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 343
    .line 344
    return-object p1

    .line 345
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
