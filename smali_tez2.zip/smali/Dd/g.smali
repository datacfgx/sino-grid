.class public final synthetic LDd/g;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LDd/g;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, LDd/g;->a:I

    .line 2
    .line 3
    check-cast p1, Lkotlin/Pair;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string v0, "="

    .line 30
    .line 31
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1

    .line 42
    :pswitch_0
    const-string v0, "<destruct>"

    .line 43
    .line 44
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Ljava/lang/Number;

    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-virtual {p1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    check-cast p1, Ljava/util/List;

    .line 62
    .line 63
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_0

    .line 68
    .line 69
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {p1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    invoke-static {p1}, Le9/g;->i(Ljava/lang/Object;)Lo9/x;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    goto/16 :goto_1

    .line 86
    .line 87
    :cond_0
    check-cast p1, Ljava/lang/Iterable;

    .line 88
    .line 89
    new-instance v1, Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->i(Ljava/lang/Iterable;)I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 96
    .line 97
    .line 98
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    if-eqz v2, :cond_1

    .line 107
    .line 108
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    check-cast v2, LDd/p;

    .line 113
    .line 114
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v5

    .line 122
    const-string v3, "toString(...)"

    .line 123
    .line 124
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 128
    .line 129
    .line 130
    move-result-wide v6

    .line 131
    iget-boolean v8, v2, LDd/p;->b:Z

    .line 132
    .line 133
    new-instance v10, Lorg/tezza/domain/gallery/GalleryItemAdjustments;

    .line 134
    .line 135
    const/16 v3, 0xf

    .line 136
    .line 137
    const/4 v4, 0x0

    .line 138
    invoke-direct {v10, v4, v4, v4, v3}, Lorg/tezza/domain/gallery/GalleryItemAdjustments;-><init>(Lorg/tezza/domain/gallery/LutsAdjustments;Ljava/util/List;Ljava/util/List;I)V

    .line 139
    .line 140
    .line 141
    new-instance v4, Lorg/tezza/domain/gallery/a;

    .line 142
    .line 143
    iget-object v9, v2, LDd/p;->a:Ljava/lang/String;

    .line 144
    .line 145
    invoke-direct/range {v4 .. v10}, Lorg/tezza/domain/gallery/a;-><init>(Ljava/lang/String;JZLjava/lang/String;Lorg/tezza/domain/gallery/GalleryItemAdjustments;)V

    .line 146
    .line 147
    .line 148
    const-string v3, "params"

    .line 149
    .line 150
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    invoke-static {v4}, Lhc/u;->b(Lorg/tezza/domain/gallery/a;)Lhc/t;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    new-instance v3, LOc/g1;

    .line 161
    .line 162
    const/4 v5, 0x6

    .line 163
    invoke-direct {v3, v5, v4}, LOc/g1;-><init>(ILjava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    new-instance v4, Lo9/j;

    .line 167
    .line 168
    invoke-direct {v4, v3}, Lo9/j;-><init>(Le9/i;)V

    .line 169
    .line 170
    .line 171
    const-string v3, "create(...)"

    .line 172
    .line 173
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    new-instance v3, LDd/m;

    .line 177
    .line 178
    const/4 v5, 0x0

    .line 179
    invoke-direct {v3, v5, v2}, LDd/m;-><init>(ILjava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    new-instance v2, LDd/n;

    .line 183
    .line 184
    invoke-direct {v2, v5, v3}, LDd/n;-><init>(ILjava/lang/Object;)V

    .line 185
    .line 186
    .line 187
    new-instance v3, Lo9/y;

    .line 188
    .line 189
    invoke-direct {v3, v4, v2}, Lo9/y;-><init>(Le9/g;Li9/d;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    goto :goto_0

    .line 196
    :cond_1
    invoke-static {v1}, Le9/g;->f(Ljava/util/ArrayList;)Le9/g;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 201
    .line 202
    .line 203
    const/16 v1, 0x10

    .line 204
    .line 205
    const-string v2, "capacityHint"

    .line 206
    .line 207
    invoke-static {v1, v2}, Lk9/b;->c(ILjava/lang/String;)V

    .line 208
    .line 209
    .line 210
    new-instance v1, Lo9/G;

    .line 211
    .line 212
    invoke-direct {v1, p1}, Lo9/G;-><init>(Le9/g;)V

    .line 213
    .line 214
    .line 215
    new-instance p1, LDd/o;

    .line 216
    .line 217
    invoke-direct {p1, v0}, LDd/o;-><init>(I)V

    .line 218
    .line 219
    .line 220
    new-instance v0, LDd/f;

    .line 221
    .line 222
    const/4 v2, 0x0

    .line 223
    invoke-direct {v0, v2, p1}, LDd/f;-><init>(ILjava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    new-instance p1, Lp9/b;

    .line 227
    .line 228
    invoke-direct {p1, v1, v0}, Lp9/b;-><init>(Lo9/G;LDd/f;)V

    .line 229
    .line 230
    .line 231
    instance-of v0, p1, Ll9/a;

    .line 232
    .line 233
    if-eqz v0, :cond_2

    .line 234
    .line 235
    check-cast p1, Ll9/a;

    .line 236
    .line 237
    invoke-interface {p1}, Ll9/a;->a()Le9/g;

    .line 238
    .line 239
    .line 240
    move-result-object p1

    .line 241
    goto :goto_1

    .line 242
    :cond_2
    new-instance v0, Lp9/e;

    .line 243
    .line 244
    invoke-direct {v0, p1}, Lp9/e;-><init>(Lp9/b;)V

    .line 245
    .line 246
    .line 247
    move-object p1, v0

    .line 248
    :goto_1
    return-object p1

    .line 249
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
