.class public final LDd/c;
.super Ljava/lang/Object;
.source "ExifMetadataWriter.kt"


# static fields
.field public static final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final b:LI9/p;


# direct methods
.method static constructor <clinit>()V
    .locals 32

    .line 1
    const-string v28, "CFAPattern"

    .line 2
    .line 3
    const-string v29, "MakerNote"

    .line 4
    .line 5
    const-string v1, "Orientation"

    .line 6
    .line 7
    const-string v2, "ImageWidth"

    .line 8
    .line 9
    const-string v3, "ImageLength"

    .line 10
    .line 11
    const-string v4, "PixelXDimension"

    .line 12
    .line 13
    const-string v5, "PixelYDimension"

    .line 14
    .line 15
    const-string v6, "Compression"

    .line 16
    .line 17
    const-string v7, "JPEGInterchangeFormat"

    .line 18
    .line 19
    const-string v8, "JPEGInterchangeFormatLength"

    .line 20
    .line 21
    const-string v9, "StripOffsets"

    .line 22
    .line 23
    const-string v10, "StripByteCounts"

    .line 24
    .line 25
    const-string v11, "RowsPerStrip"

    .line 26
    .line 27
    const-string v12, "PlanarConfiguration"

    .line 28
    .line 29
    const-string v13, "BitsPerSample"

    .line 30
    .line 31
    const-string v14, "SamplesPerPixel"

    .line 32
    .line 33
    const-string v15, "PhotometricInterpretation"

    .line 34
    .line 35
    const-string v16, "ThumbnailImageWidth"

    .line 36
    .line 37
    const-string v17, "ThumbnailImageLength"

    .line 38
    .line 39
    const-string v18, "Xmp"

    .line 40
    .line 41
    const-string v19, "OffsetTime"

    .line 42
    .line 43
    const-string v20, "OffsetTimeOriginal"

    .line 44
    .line 45
    const-string v21, "OffsetTimeDigitized"

    .line 46
    .line 47
    const-string v22, "SubSecTime"

    .line 48
    .line 49
    const-string v23, "SubSecTimeOriginal"

    .line 50
    .line 51
    const-string v24, "SubSecTimeDigitized"

    .line 52
    .line 53
    const-string v25, "ComponentsConfiguration"

    .line 54
    .line 55
    const-string v26, "SceneType"

    .line 56
    .line 57
    const-string v27, "FileSource"

    .line 58
    .line 59
    const-string v30, "OECF"

    .line 60
    .line 61
    const-string v31, "GPSVersionID"

    .line 62
    .line 63
    filled-new-array/range {v1 .. v31}, [Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, LDd/c;->a:Ljava/util/Set;

    .line 72
    .line 73
    new-instance v0, LDd/b;

    .line 74
    .line 75
    const/4 v1, 0x0

    .line 76
    invoke-direct {v0, v1}, LDd/b;-><init>(I)V

    .line 77
    .line 78
    .line 79
    invoke-static {v0}, LI9/k;->b(Lkotlin/jvm/functions/Function0;)LI9/p;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    sput-object v0, LDd/c;->b:LI9/p;

    .line 84
    .line 85
    return-void
.end method

.method public static a(LN1/a;LN1/a;Ljava/lang/String;II)V
    .locals 4

    .line 1
    .line 2
    new-instance v0, Ljava/util/Date;

    .line 3
    .line 4
    .line 5
    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    .line 6
    .line 7
    const-string v1, "dest"

    .line 8
    .line 9
    .line 10
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    const-string v1, "attribution"

    .line 13
    .line 14
    .line 15
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    const-string v1, "now"

    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    if-eqz p0, :cond_1

    .line 23
    .line 24
    sget-object v1, LDd/c;->b:LI9/p;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, LI9/p;->getValue()Ljava/lang/Object;

    .line 28
    move-result-object v1

    .line 29
    .line 30
    check-cast v1, Ljava/util/List;

    .line 31
    .line 32
    check-cast v1, Ljava/lang/Iterable;

    .line 33
    .line 34
    .line 35
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    move-result-object v1

    .line 37
    .line 38
    .line 39
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    move-result v2

    .line 41
    .line 42
    if-eqz v2, :cond_1

    .line 43
    .line 44
    .line 45
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v2

    .line 47
    .line 48
    check-cast v2, Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v2}, LN1/a;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    move-result-object v3

    .line 53
    .line 54
    if-eqz v3, :cond_0

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v2, v3}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    goto :goto_0

    .line 59
    .line 60
    :cond_1
    const-string p0, "Orientation"

    .line 61
    .line 62
    const-string v1, "1"

    .line 63
    .line 64
    .line 65
    invoke-virtual {p1, p0, v1}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 66
    .line 67
    const-string p0, "PixelXDimension"

    .line 68
    .line 69
    .line 70
    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 71
    move-result-object p3

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1, p0, p3}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 75
    .line 76
    const-string p0, "PixelYDimension"

    .line 77
    .line 78
    .line 79
    invoke-static {p4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 80
    move-result-object p3

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, p0, p3}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    .line 85
    const-string p0, "Software"

    .line 86
    .line 87
    const-string p3, "Tezza"

    .line 88
    .line 89
    .line 90
    invoke-virtual {p1, p0, p3}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    .line 92
    new-instance p0, Ljava/text/SimpleDateFormat;

    .line 93
    .line 94
    const-string p3, "yyyy:MM:dd HH:mm:ss"

    .line 95
    .line 96
    sget-object p4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 97
    .line 98
    .line 99
    invoke-direct {p0, p3, p4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {p0, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 103
    move-result-object p0

    .line 104
    .line 105
    const-string p3, "DateTime"

    .line 106
    .line 107
    .line 108
    invoke-virtual {p1, p3, p0}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    const-string p3, "DateTimeOriginal"

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, p3, p0}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    .line 115
    const-string p3, "DateTimeDigitized"

    .line 116
    .line 117
    .line 118
    invoke-virtual {p1, p3, p0}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 122
    move-result p0

    .line 123
    .line 124
    if-lez p0, :cond_2

    .line 125
    .line 126
    const-string p0, "ImageDescription"

    .line 127
    .line 128
    .line 129
    invoke-virtual {p1, p0, p2}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 130
    .line 131
    const/4 p0, 0x0

    sget-object p0, Le2/IPX/jaRKsJUzeIfpWZ;->bCTvtqNgJlbjN:Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p1, p0, p2}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    :cond_2
    invoke-virtual {p1}, LN1/a;->A()V

    .line 138
    return-void
.end method
