.class public final synthetic LDd/h;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Li9/d;
.implements LC1/c$a;
.implements Li9/c;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LDd/h;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LDd/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LDd/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljc/a;

    .line 4
    .line 5
    invoke-static {v0, p1}, Lorg/tezza/data/instafeed/InstagramFeedRepositoryImpl;->e(Ljc/a;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LDd/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDd/h;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LY3/a;

    .line 9
    .line 10
    invoke-static {v0, p1}, Lorg/tezza/data/flow/FlowRepositoryImpl;->r(LY3/a;Ljava/lang/Object;)Le9/j;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_0
    const-string v0, "p0"

    .line 16
    .line 17
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, LDd/h;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, LDd/g;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, LDd/g;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Le9/j;

    .line 29
    .line 30
    return-object p1

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public e(IZ)V
    .locals 2

    .line 1
    iget-object v0, p0, LDd/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LOc/r1;

    .line 4
    .line 5
    invoke-virtual {v0}, LOc/r1;->K()LOc/a2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-virtual {v1}, LOc/a2;->o()Lorg/tezza/domain/gallery/FocusAdjustments;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    if-eqz v1, :cond_1

    .line 22
    .line 23
    int-to-float p1, p1

    .line 24
    const/high16 p2, 0x41200000    # 10.0f

    .line 25
    .line 26
    div-float/2addr p1, p2

    .line 27
    iput p1, v1, Lorg/tezza/domain/gallery/FocusAdjustments;->g:F

    .line 28
    .line 29
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 30
    .line 31
    invoke-virtual {v0}, LOc/r1;->k0()V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method
