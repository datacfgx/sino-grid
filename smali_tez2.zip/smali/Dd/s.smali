.class public final LDd/s;
.super Ljava/lang/Object;
.source "ImageUtils.kt"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .locals 5

    .line 1
    const-string v0, "Tezza Exception"

    .line 2
    .line 3
    const-string v1, "Tezza"

    .line 4
    .line 5
    const-string v2, "throwable"

    .line 6
    .line 7
    const-string v3, "path"

    .line 8
    .line 9
    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    :try_start_0
    new-instance v3, LN1/a;

    .line 13
    .line 14
    invoke-direct {v3, p0}, LN1/a;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const-string p0, "Orientation"

    .line 18
    .line 19
    const/4 v4, 0x1

    .line 20
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    invoke-virtual {v3, p0, v4}, LN1/a;->E(Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v3}, LN1/a;->A()V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :catchall_0
    move-exception p0

    .line 32
    goto :goto_0

    .line 33
    :catch_0
    move-exception p0

    .line 34
    goto :goto_1

    .line 35
    :goto_0
    invoke-static {p0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-static {v1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 39
    .line 40
    .line 41
    goto :goto_2

    .line 42
    :goto_1
    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    const-string v3, "getTargetException(...)"

    .line 47
    .line 48
    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-static {p0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-static {v1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 55
    .line 56
    .line 57
    :goto_2
    return-void
.end method

.method public static b(Ljava/lang/String;)LDd/a;
    .locals 9

    .line 1
    const-string v0, "pathUri"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/16 v0, 0x280

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    const/4 v2, 0x0

    .line 10
    :try_start_0
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    const-string v4, "uri"

    .line 15
    .line 16
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    sget-object v4, Lorg/tezza/presentation/ui/appmain/App;->a:Landroid/content/Context;

    .line 20
    .line 21
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    invoke-virtual {v4, v3}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    if-eqz v3, :cond_0

    .line 34
    .line 35
    new-instance v4, LN1/a;

    .line 36
    .line 37
    invoke-direct {v4, v3}, LN1/a;-><init>(Ljava/io/InputStream;)V

    .line 38
    .line 39
    .line 40
    const-string v5, "Orientation"

    .line 41
    .line 42
    invoke-virtual {v4, v1, v5}, LN1/a;->c(ILjava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 46
    :try_start_1
    const-string v6, "ImageWidth"

    .line 47
    .line 48
    invoke-virtual {v4, v0, v6}, LN1/a;->c(ILjava/lang/String;)I

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    const-string v7, "ImageLength"

    .line 53
    .line 54
    invoke-virtual {v4, v0, v7}, LN1/a;->c(ILjava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    const-string v8, "DateTime"

    .line 59
    .line 60
    invoke-virtual {v4, v8}, LN1/a;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 64
    goto :goto_1

    .line 65
    :catchall_0
    :goto_0
    move v1, v5

    .line 66
    goto :goto_4

    .line 67
    :cond_0
    move v6, v0

    .line 68
    move v7, v6

    .line 69
    move v5, v1

    .line 70
    move-object v4, v2

    .line 71
    :goto_1
    if-eqz v6, :cond_1

    .line 72
    .line 73
    if-nez v7, :cond_2

    .line 74
    .line 75
    :cond_1
    :try_start_2
    new-instance v6, Landroid/graphics/BitmapFactory$Options;

    .line 76
    .line 77
    invoke-direct {v6}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 78
    .line 79
    .line 80
    iput-boolean v1, v6, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 81
    .line 82
    invoke-static {v3, v2, v6}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 83
    .line 84
    .line 85
    iget v7, v6, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    .line 86
    .line 87
    iget v6, v6, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    .line 88
    .line 89
    :cond_2
    if-lez v6, :cond_4

    .line 90
    .line 91
    if-gtz v7, :cond_3

    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_3
    move v0, v7

    .line 95
    goto :goto_5

    .line 96
    :cond_4
    :goto_2
    new-instance v3, Landroid/graphics/BitmapFactory$Options;

    .line 97
    .line 98
    invoke-direct {v3}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 99
    .line 100
    .line 101
    iput-boolean v1, v3, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 102
    .line 103
    invoke-static {}, Lorg/tezza/presentation/ui/appmain/App$b;->a()Landroid/content/Context;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    const-string v6, "r"

    .line 116
    .line 117
    invoke-virtual {v1, p0, v6}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    if-eqz p0, :cond_5

    .line 122
    .line 123
    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    goto :goto_3

    .line 128
    :catchall_1
    move-object v2, v4

    .line 129
    goto :goto_0

    .line 130
    :cond_5
    move-object p0, v2

    .line 131
    :goto_3
    invoke-static {p0, v2, v3}, Landroid/graphics/BitmapFactory;->decodeFileDescriptor(Ljava/io/FileDescriptor;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 132
    .line 133
    .line 134
    iget p0, v3, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    .line 135
    .line 136
    iget v0, v3, Landroid/graphics/BitmapFactory$Options;->outWidth:I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 137
    .line 138
    move v6, v0

    .line 139
    move v0, p0

    .line 140
    goto :goto_5

    .line 141
    :catchall_2
    :goto_4
    move v6, v0

    .line 142
    move v5, v1

    .line 143
    move-object v4, v2

    .line 144
    :goto_5
    const/4 p0, 0x6

    .line 145
    if-eq v5, p0, :cond_6

    .line 146
    .line 147
    const/16 p0, 0x8

    .line 148
    .line 149
    if-eq v5, p0, :cond_6

    .line 150
    .line 151
    new-instance p0, LDd/a;

    .line 152
    .line 153
    new-instance v1, Lorg/tezza/presentation/utils/media/Size;

    .line 154
    .line 155
    invoke-direct {v1, v6, v0}, Lorg/tezza/presentation/utils/media/Size;-><init>(II)V

    .line 156
    .line 157
    .line 158
    invoke-static {v5}, LDd/s;->c(I)LDd/u;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    invoke-direct {p0, v1, v0, v4}, LDd/a;-><init>(Lorg/tezza/presentation/utils/media/Size;LDd/u;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    goto :goto_6

    .line 166
    :cond_6
    new-instance p0, LDd/a;

    .line 167
    .line 168
    new-instance v1, Lorg/tezza/presentation/utils/media/Size;

    .line 169
    .line 170
    invoke-direct {v1, v0, v6}, Lorg/tezza/presentation/utils/media/Size;-><init>(II)V

    .line 171
    .line 172
    .line 173
    invoke-static {v5}, LDd/s;->c(I)LDd/u;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-direct {p0, v1, v0, v4}, LDd/a;-><init>(Lorg/tezza/presentation/utils/media/Size;LDd/u;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    :goto_6
    return-object p0
.end method

.method public static c(I)LDd/u;
    .locals 1

    .line 1
    if-eqz p0, :cond_3

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p0, v0, :cond_3

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    if-eq p0, v0, :cond_2

    .line 8
    .line 9
    const/4 v0, 0x6

    .line 10
    if-eq p0, v0, :cond_1

    .line 11
    .line 12
    const/16 v0, 0x8

    .line 13
    .line 14
    if-eq p0, v0, :cond_0

    .line 15
    .line 16
    sget-object p0, LDd/u;->ROTATED_0:LDd/u;

    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_0
    sget-object p0, LDd/u;->ROTATED_270:LDd/u;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_1
    sget-object p0, LDd/u;->ROTATED_90:LDd/u;

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_2
    sget-object p0, LDd/u;->ROTATED_180:LDd/u;

    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_3
    sget-object p0, LDd/u;->ROTATED_0:LDd/u;

    .line 29
    .line 30
    return-object p0
.end method
