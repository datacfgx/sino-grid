.class public final synthetic LDd/x;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LDd/x;->a:I

    .line 2
    .line 3
    iput-object p2, p0, LDd/x;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, LDd/x;->b:Ljava/lang/Object;

    .line 2
    .line 3
    iget v1, p0, LDd/x;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, LS0/m;

    .line 9
    .line 10
    iget-wide v1, p1, LS0/m;->a:J

    .line 11
    .line 12
    const-wide v3, 0xffffffffL

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    and-long/2addr v1, v3

    .line 18
    long-to-int p1, v1

    .line 19
    int-to-float p1, p1

    .line 20
    const/4 v1, 0x0

    .line 21
    cmpl-float v1, p1, v1

    .line 22
    .line 23
    check-cast v0, LX8/F0;

    .line 24
    .line 25
    if-lez v1, :cond_0

    .line 26
    .line 27
    iget-object v0, v0, LX8/F0;->g:LM/q0;

    .line 28
    .line 29
    check-cast v0, LM/e1;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, LM/e1;->f(F)V

    .line 32
    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 39
    .line 40
    return-object p1

    .line 41
    :pswitch_0
    check-cast p1, Ljava/util/List;

    .line 42
    .line 43
    sget p1, LVc/r;->G0:I

    .line 44
    .line 45
    check-cast v0, LVc/r;

    .line 46
    .line 47
    invoke-virtual {v0}, LJc/e;->q0()LJc/f;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    check-cast p1, LVc/v;

    .line 52
    .line 53
    iget-object p1, p1, LVc/v;->f:Landroidx/lifecycle/z;

    .line 54
    .line 55
    invoke-virtual {p1}, Landroidx/lifecycle/x;->d()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    sget-object v1, LVc/u;->CAM:LVc/u;

    .line 60
    .line 61
    if-ne p1, v1, :cond_1

    .line 62
    .line 63
    invoke-virtual {v0}, LVc/r;->H0()V

    .line 64
    .line 65
    .line 66
    :cond_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 67
    .line 68
    return-object p1

    .line 69
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 70
    .line 71
    sget p1, Lorg/tezza/presentation/ui/edit/EditActivity;->Z:I

    .line 72
    .line 73
    check-cast v0, Lorg/tezza/presentation/ui/edit/EditActivity;

    .line 74
    .line 75
    invoke-virtual {v0}, Lorg/tezza/presentation/ui/edit/EditActivity;->d0()V

    .line 76
    .line 77
    .line 78
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 79
    .line 80
    return-object p1

    .line 81
    :pswitch_2
    check-cast p1, Ljava/lang/Throwable;

    .line 82
    .line 83
    const-string v1, "it"

    .line 84
    .line 85
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 93
    .line 94
    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 98
    .line 99
    return-object p1

    .line 100
    nop

    .line 101
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
